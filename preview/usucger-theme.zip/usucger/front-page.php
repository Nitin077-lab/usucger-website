<?php
/**
 * Front page: the home page content carries its own hero section.
 * Imported pages are full-width HTML sections; pages written in the block editor
 * are wrapped in a readable column automatically.
 *
 * @package usucger
 */
get_header();
while ( have_posts() ) :
	the_post();
	echo usucger_render_page_hero( get_post() ); // phpcs:ignore WordPress.Security.EscapeOutput
	usucger_the_content_wrapped();
endwhile;
get_footer();
