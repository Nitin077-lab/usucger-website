<?php
/**
 * Fallback: news/blog listing and anything without a specific template.
 *
 * @package usucger
 */
get_header();
if ( is_singular() ) {
	while ( have_posts() ) {
		the_post();
		echo usucger_phero( array( 'eyebrow' => is_singular( 'post' ) ? esc_html( get_the_date() ) : 'USUCGER', 'h1' => esc_html( get_the_title() ), 'crumbs' => array( array( esc_html( get_the_title() ), null ) ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput
		usucger_the_content_wrapped();
	}
} else {
	$usg_title = is_search() ? sprintf( 'Search results for “%s”', esc_html( get_search_query() ) ) : ( is_home() ? 'News' : wp_strip_all_tags( get_the_archive_title() ) );
	echo usucger_phero( array( 'eyebrow' => 'USUCGER', 'h1' => esc_html( $usg_title ), 'crumbs' => array( array( esc_html( $usg_title ), null ) ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput
	echo '<section class="section bg-white"><div class="wrap wp-prose"><div class="linklist">';
	if ( have_posts() ) {
		while ( have_posts() ) {
			the_post();
			echo '<a class="linkrow" href="' . esc_url( get_permalink() ) . '"><div class="linkrow-body"><div class="linkrow-title">' . esc_html( get_the_title() ) . '</div><div class="linkrow-desc">' . esc_html( wp_trim_words( get_the_excerpt(), 28 ) ) . '</div><div class="linkrow-meta">' . esc_html( get_the_date() ) . '</div></div></a>';
		}
	} else {
		echo '<p>Nothing found. Try the search button at the top of the page.</p>';
	}
	echo '</div>';
	the_posts_pagination();
	echo '</div></section>';
}
get_footer();
