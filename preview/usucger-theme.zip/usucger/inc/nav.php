<?php
/**
 * Navigation: the built-in menu mirrors the static site. If a WordPress menu is
 * assigned to "Main navigation" (Appearance → Menus), it is used instead: top-level
 * items become the bar, their children the drop-downs.
 *
 * @package usucger
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** "Post a position": the online form when the plugin has it switched on, otherwise email. */
function usucger_post_position_href() {
	if ( function_exists( 'usucger_core_opt' ) && usucger_core_opt( 'form_positions' ) && get_page_by_path( 'post-a-position' ) ) {
		return 'post-a-position';
	}
	return 'mailto:' . usucger_setting( 'contact_email' ) . '?subject=Position%20Posting';
}

function usucger_default_nav() {
	$post_position = usucger_post_position_href();
	return apply_filters( 'usucger_nav', array(
		array( 'About', 'about', array(
			array( 'History &amp; Mission', 'about' ),
			array( 'By-Laws', 'bylaws' ),
			array( 'Board of Directors', 'board' ),
			array( 'Board Elections', 'elections' ),
			array( 'Contact USUCGER', 'contact' ),
		) ),
		array( 'Members', 'membership', array(
			array( 'Membership &amp; Dues', 'membership' ),
			array( 'Membership Directory', 'directory' ),
			array( 'Member Universities', 'universities' ),
			array( 'Member Area &amp; Login', 'login' ),
		) ),
		array( 'Positions', 'positions', array(
			array( 'Academic Positions', 'positions' ),
			array( 'Industry &amp; Agency Positions', 'industry-positions' ),
			array( 'Post a Position', $post_position ),
		) ),
		array( 'Activities', 'awards', array(
			array( 'Awards', 'awards' ),
			array( 'Student Travel Grants', 'travel-grants' ),
			array( 'Small Research Grants', 'research-grants' ),
			array( 'Meeting Minutes', 'minutes' ),
		) ),
		array( 'Resources', 'teaching-aids', array(
			array( 'Teaching Aids', 'teaching-aids' ),
			array( 'Books &amp; Publications', 'books' ),
			array( 'Software &amp; Data', 'software' ),
			array( 'Videos &amp; Webinars', 'videos' ),
			array( 'Funding Tips', 'funding-tips' ),
			array( 'Photo Collections', 'photos' ),
		) ),
		array( 'Events', 'conferences', array(
			array( 'Conferences', 'conferences' ),
			array( 'Workshops', 'workshops' ),
		) ),
	) );
}

function usucger_default_footer() {
	return apply_filters( 'usucger_footer_nav', array(
		array( 'About', array(
			array( 'History &amp; Mission', 'about' ),
			array( 'By-Laws', 'bylaws' ),
			array( 'Board of Directors', 'board' ),
			array( 'Contact USUCGER', 'contact' ),
		) ),
		array( 'Members', array(
			array( 'Membership &amp; Dues', 'membership' ),
			array( 'Membership Directory', 'directory' ),
			array( 'Member Universities', 'universities' ),
			array( 'Meeting Minutes', 'minutes' ),
			array( 'Board Elections', 'elections' ),
			array( 'Member Area &amp; Login', 'login' ),
		) ),
		array( 'Positions', array(
			array( 'Academic Positions', 'positions' ),
			array( 'Industry &amp; Agency Positions', 'industry-positions' ),
			array( 'Post a Position', usucger_post_position_href() ),
		) ),
		array( 'Resources', array(
			array( 'Awards', 'awards' ),
			array( 'Student Travel Grants', 'travel-grants' ),
			array( 'Small Research Grants', 'research-grants' ),
			array( 'Teaching Aids', 'teaching-aids' ),
			array( 'Books &amp; Publications', 'books' ),
			array( 'Software &amp; Data', 'software' ),
			array( 'Videos &amp; Webinars', 'videos' ),
			array( 'Conferences', 'conferences' ),
		) ),
	) );
}

/** Convert an assigned WP menu into the [label, href, children] shape. */
function usucger_menu_tree( $location ) {
	$locations = get_nav_menu_locations();
	if ( empty( $locations[ $location ] ) ) {
		return null;
	}
	$items = wp_get_nav_menu_items( $locations[ $location ] );
	if ( ! $items ) {
		return null;
	}
	$top = array();
	$kids = array();
	foreach ( $items as $it ) {
		if ( ! $it->menu_item_parent ) {
			$top[ $it->ID ] = $it;
		} else {
			$kids[ $it->menu_item_parent ][] = $it;
		}
	}
	$tree = array();
	foreach ( $top as $id => $it ) {
		$subs = array();
		foreach ( isset( $kids[ $id ] ) ? $kids[ $id ] : array() as $k ) {
			$subs[] = array( esc_html( $k->title ), $k->url );
		}
		$tree[] = array( esc_html( $it->title ), $it->url, $subs );
	}
	return $tree;
}

function usucger_nav_tree() {
	$t = usucger_menu_tree( 'primary' );
	return $t ? $t : usucger_default_nav();
}

function usucger_footer_tree() {
	$t = usucger_menu_tree( 'footer' );
	if ( $t ) {
		return array_map( function ( $row ) {
			return array( $row[0], $row[2] );
		}, $t );
	}
	return usucger_default_footer();
}

function usucger_is_current( $ref ) {
	$cur = usucger_current_slug();
	if ( '' === $cur ) {
		return false;
	}
	if ( preg_match( '#^https?:#', $ref ) ) {
		$here = trailingslashit( strtok( ( is_ssl() ? 'https://' : 'http://' ) . ( isset( $_SERVER['HTTP_HOST'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_HOST'] ) ) : '' ) . ( isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '' ), '?' ) );
		return trailingslashit( strtok( $ref, '?' ) ) === $here;
	}
	return preg_replace( '#\.html?$#', '', $ref ) === $cur;
}

function usucger_nav_html() {
	$out = '';
	foreach ( usucger_nav_tree() as $row ) {
		list( $label, $root, $subs ) = $row;
		$active = usucger_is_current( $root );
		foreach ( $subs as $s ) {
			$active = $active || usucger_is_current( $s[1] );
		}
		$href = usucger_url( $root );
		$out .= '<li class="nav-item' . ( 'Positions' === $label ? ' nav-hot' : '' ) . '">';
		$out .= '<a href="' . esc_url( $href ) . '"' . usucger_link_attrs( $href ) . ' class="' . ( $active ? 'active' : '' ) . '">' . $label . ' <span class="nav-caret" aria-hidden="true">&#9662;</span></a>';
		$out .= '<div class="nav-sub">';
		foreach ( $subs as $s ) {
			$h    = usucger_url( $s[1] );
			$out .= '<a href="' . esc_url( $h ) . '"' . usucger_link_attrs( $h ) . ( usucger_is_current( $s[1] ) ? ' class="active"' : '' ) . '>' . $s[0] . '</a>';
		}
		$out .= '</div></li>';
	}
	return $out;
}

function usucger_drawer_html() {
	$out = '';
	foreach ( usucger_nav_tree() as $row ) {
		list( $label, $root, $subs ) = $row;
		$active = usucger_is_current( $root );
		foreach ( $subs as $s ) {
			$active = $active || usucger_is_current( $s[1] );
		}
		$out .= '<div class="drawer-group' . ( $active ? ' open' : '' ) . '">';
		$out .= '<button type="button" aria-expanded="' . ( $active ? 'true' : 'false' ) . '">' . $label . '<span class="chev" aria-hidden="true">&#9662;</span></button><div class="drawer-links">';
		foreach ( $subs as $s ) {
			$h    = usucger_url( $s[1] );
			$out .= '<a href="' . esc_url( $h ) . '"' . usucger_link_attrs( $h ) . ( usucger_is_current( $s[1] ) ? ' class="active"' : '' ) . '>' . $s[0] . '</a>';
		}
		$out .= '</div></div>';
	}
	return $out;
}

function usucger_footer_links_html() {
	$out = '';
	foreach ( usucger_footer_tree() as $col ) {
		$out .= '<div><div class="ft-col-title">' . $col[0] . '</div><ul class="ft-links">';
		foreach ( $col[1] as $l ) {
			$h    = usucger_url( $l[1] );
			$out .= '<li><a href="' . esc_url( $h ) . '"' . usucger_link_attrs( $h ) . '>' . $l[0] . '</a></li>';
		}
		$out .= '</ul></div>';
	}
	return $out;
}
