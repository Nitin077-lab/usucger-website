<?php
/**
 * WooCommerce: wrap shop, product, cart, checkout and My Account screens in the
 * site shell so dues payment looks like the rest of the site.
 *
 * @package usucger
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10 );
remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10 );
remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10 );
add_filter( 'woocommerce_show_page_title', '__return_false' );

/** Header for WooCommerce archive/product screens (woocommerce.php template). */
function usucger_wc_hero() {
	if ( is_product() ) {
		return usucger_phero( array(
			'eyebrow' => 'Membership',
			'h1'      => esc_html( get_the_title() ),
			'crumbs'  => array( array( 'Members', 'membership' ), array( esc_html( get_the_title() ), null ) ),
		) );
	}
	return usucger_phero( array(
		'eyebrow' => 'Membership',
		'h1'      => function_exists( 'woocommerce_page_title' ) ? woocommerce_page_title( false ) : 'Shop',
		'crumbs'  => array( array( 'Members', 'membership' ), array( 'Dues', null ) ),
	) );
}
