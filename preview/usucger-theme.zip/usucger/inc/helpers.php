<?php
/**
 * Small helpers shared by templates (and by the USUCGER Core plugin when present).
 *
 * @package usucger
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** theme.json (palettes). */
function usucger_theme_data() {
	static $data = null;
	if ( null === $data ) {
		$data = json_decode( (string) file_get_contents( USUCGER_THEME_DIR . '/data/theme.json' ), true );
		if ( ! is_array( $data ) || empty( $data['themes'] ) ) {
			$data = array( 'active' => 'core-sample', 'themes' => array() );
		}
	}
	return $data;
}

function usucger_default_theme() {
	$data = usucger_theme_data();
	$key  = get_theme_mod( 'usucger_default_theme', $data['active'] );
	return isset( $data['themes'][ $key ] ) ? $key : $data['active'];
}

function usucger_theme_band( $key ) {
	$data = usucger_theme_data();
	return ( isset( $data['themes'][ $key ]['band'] ) && 'light' === $data['themes'][ $key ]['band'] ) ? 'light' : 'dark';
}

/**
 * Site-wide settings. The USUCGER Core plugin stores the canonical values; the theme
 * falls back to sensible defaults so it also works on its own.
 */
function usucger_setting( $key ) {
	$defaults = array(
		'contact_email' => 'webmaster@usucger.org',
		'board_email'   => 'uboard@usucger.org',
		'join_univ'     => 'https://usucger.org/membership/usucger-3-year-membership-us-universities-2025-2027/',
		'join_assoc'    => 'https://usucger.org/membership/usucger-3-year-membership-associate-2025-2027/',
		'credit'        => 'Website designed by Dr. Nitin Tiwari, Southern Illinois University Carbondale, IL',
		'dues'          => '$75',
		'cycle'         => '2025–2027',
	);
	$val = null;
	if ( function_exists( 'usucger_core_opt' ) ) {
		$val = usucger_core_opt( $key );
	}
	if ( null === $val || '' === $val ) {
		$val = get_theme_mod( 'usucger_' . $key, isset( $defaults[ $key ] ) ? $defaults[ $key ] : '' );
	}
	return $val;
}

/**
 * Resolve a link reference the way the static site wrote it.
 *   'about' / 'about.html' / 'about.html#x'  -> permalink of the page with that slug
 *   'index' / 'index.html' / ''              -> home
 *   'login'                                  -> WooCommerce My Account (or wp-login)
 *   http(s)://, mailto:                      -> unchanged
 */
function usucger_url( $ref ) {
	static $cache = array();
	$ref = (string) $ref;
	if ( preg_match( '#^(https?:|mailto:|tel:|//)#i', $ref ) ) {
		return $ref;
	}
	if ( isset( $cache[ $ref ] ) ) {
		return $cache[ $ref ];
	}
	$frag = '';
	if ( false !== strpos( $ref, '#' ) ) {
		list( $ref_only, $frag ) = explode( '#', $ref, 2 );
		$frag = '#' . $frag;
	} else {
		$ref_only = $ref;
	}
	$slug = preg_replace( '#\.html?$#', '', trim( $ref_only, '/' ) );
	if ( '' === $slug || 'index' === $slug ) {
		$url = home_url( '/' );
	} elseif ( 'login' === $slug ) {
		$area = get_page_by_path( 'members' );
		$url  = $area ? get_permalink( $area ) : ( function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : wp_login_url() );
	} else {
		$page = get_page_by_path( $slug );
		$url  = $page ? get_permalink( $page ) : home_url( '/' . $slug . '/' );
	}
	$cache[ $ref ] = $url . $frag;
	return $cache[ $ref ];
}

/** Current page slug used for nav highlighting ('index' on the front page). */
function usucger_current_slug() {
	if ( is_front_page() ) {
		return 'index';
	}
	$obj = get_queried_object();
	if ( $obj instanceof WP_Post ) {
		return $obj->post_name;
	}
	if ( function_exists( 'is_account_page' ) && is_account_page() ) {
		return 'login';
	}
	return '';
}

function usucger_is_external( $href ) {
	return (bool) preg_match( '#^(https?:|mailto:)#i', $href ) && 0 !== strpos( $href, home_url() );
}

function usucger_link_attrs( $href ) {
	return usucger_is_external( $href ) ? ' target="_blank" rel="noopener"' : '';
}

function usucger_meta_description() {
	if ( is_singular() ) {
		$hero = usucger_hero_meta( get_queried_object_id() );
		if ( ! empty( $hero['description'] ) ) {
			return wp_strip_all_tags( $hero['description'] );
		}
		$p = get_post();
		if ( $p && $p->post_excerpt ) {
			return wp_strip_all_tags( $p->post_excerpt );
		}
	}
	return get_bloginfo( 'description' );
}
