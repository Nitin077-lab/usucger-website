<?php
/**
 * Appearance → Customize → USUCGER: default color theme, home-page theme picker,
 * contact addresses and footer credit (used when the USUCGER Core plugin is not active).
 *
 * @package usucger
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'customize_register', function ( $wpc ) {
	$wpc->add_section( 'usucger', array( 'title' => __( 'USUCGER', 'usucger' ), 'priority' => 30 ) );
	$choices = array();
	foreach ( usucger_theme_data()['themes'] as $k => $t ) {
		$choices[ $k ] = $t['label'];
	}
	$wpc->add_setting( 'usucger_default_theme', array( 'default' => usucger_theme_data()['active'], 'sanitize_callback' => function ( $v ) use ( $choices ) {
		return isset( $choices[ $v ] ) ? $v : 'core-sample';
	} ) );
	$wpc->add_control( 'usucger_default_theme', array( 'label' => __( 'Default color theme', 'usucger' ), 'section' => 'usucger', 'type' => 'select', 'choices' => $choices ) );

	$wpc->add_setting( 'usucger_show_picker', array( 'default' => true, 'sanitize_callback' => 'wp_validate_boolean' ) );
	$wpc->add_control( 'usucger_show_picker', array( 'label' => __( 'Show the color-theme picker on the home page (Board review)', 'usucger' ), 'section' => 'usucger', 'type' => 'checkbox' ) );

	foreach ( array(
		'contact_email' => array( 'Webmaster / contact email', 'sanitize_email' ),
		'board_email'   => array( 'Board email', 'sanitize_email' ),
		'credit'        => array( 'Footer credit line', 'sanitize_text_field' ),
	) as $k => $d ) {
		$wpc->add_setting( 'usucger_' . $k, array( 'default' => usucger_setting( $k ), 'sanitize_callback' => $d[1] ) );
		$wpc->add_control( 'usucger_' . $k, array( 'label' => $d[0], 'section' => 'usucger', 'type' => 'text' ) );
	}
} );
