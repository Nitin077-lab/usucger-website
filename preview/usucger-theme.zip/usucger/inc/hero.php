<?php
/**
 * Page header ("hero") + call-to-action strip, edited in the "USUCGER page header"
 * box under the editor. Stored in post meta _usucger_hero (array).
 *
 * @package usucger
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function usucger_hero_meta( $post_id ) {
	$m = get_post_meta( $post_id, '_usucger_hero', true );
	return is_array( $m ) ? $m : array();
}

function usucger_strata_svg() {
	return '<svg class="phero-band" viewBox="0 0 1440 90" preserveAspectRatio="none" aria-hidden="true" focusable="false">
  <path d="M0 26 C 240 6, 420 54, 720 34 S 1200 0, 1440 22 V90 H0 Z" fill="var(--primary-md)" fill-opacity=".26"/>
  <path d="M0 52 C 260 36, 480 80, 760 62 S 1220 28, 1440 52 V90 H0 Z" fill="var(--primary)" fill-opacity=".6"/>
  <path d="M0 74 C 300 62, 520 90, 800 80 S 1240 58, 1440 74 V90 H0 Z" fill="var(--primary)"/>
</svg>';
}

function usucger_crumbs_html( $trail ) {
	if ( ! $trail ) {
		return '';
	}
	$o = '<nav class="crumbs" aria-label="Breadcrumb"><a href="' . esc_url( home_url( '/' ) ) . '">Home</a>';
	foreach ( $trail as $c ) {
		$o .= '<span class="sep" aria-hidden="true">/</span>';
		if ( ! empty( $c[1] ) ) {
			$o .= '<a href="' . esc_url( usucger_url( $c[1] ) ) . '">' . wp_kses_post( $c[0] ) . '</a>';
		} else {
			$o .= '<span>' . wp_kses_post( $c[0] ) . '</span>';
		}
	}
	return $o . '</nav>';
}

/**
 * Generic page header. $args: eyebrow, h1, lead, crumbs, actions.
 */
function usucger_phero( $args ) {
	$lead    = ! empty( $args['lead'] ) ? '<p class="phero-lead">' . wp_kses_post( $args['lead'] ) . '</p>' : '';
	$actions = '';
	if ( ! empty( $args['actions'] ) ) {
		$actions = '<div class="phero-actions">';
		foreach ( $args['actions'] as $a ) {
			$h        = apply_filters( 'usucger_action_href', usucger_url( $a[1] ), $a[1] );
			$actions .= '<a href="' . esc_url( $h ) . '"' . usucger_link_attrs( $h ) . ' class="btn ' . esc_attr( isset( $a[2] ) ? $a[2] : 'btn-amber' ) . '">' . wp_kses_post( $a[0] ) . '</a>';
		}
		$actions .= '</div>';
	}
	return '<section class="phero"><div class="wrap">' . usucger_crumbs_html( isset( $args['crumbs'] ) ? $args['crumbs'] : array() )
		. '<div class="eyebrow"><span class="eyebrow-line"></span>' . wp_kses_post( ! empty( $args['eyebrow'] ) ? $args['eyebrow'] : 'USUCGER' ) . '</div>'
		. '<h1>' . wp_kses_post( $args['h1'] ) . '</h1>' . $lead . $actions . '</div>' . usucger_strata_svg() . '</section>';
}

function usucger_render_page_hero( $post ) {
	$post = get_post( $post );
	if ( ! $post || is_front_page() ) {
		return '';
	}
	$m = usucger_hero_meta( $post->ID );
	if ( ! empty( $m['no_hero'] ) ) {
		return '';
	}
	if ( empty( $m['crumbs'] ) ) {
		$m['crumbs'] = array();
		foreach ( array_reverse( get_post_ancestors( $post ) ) as $anc ) {
			$m['crumbs'][] = array( esc_html( get_the_title( $anc ) ), get_post_field( 'post_name', $anc ) );
		}
		$m['crumbs'][] = array( esc_html( get_the_title( $post ) ), null );
	}
	return usucger_phero( array(
		'eyebrow' => isset( $m['eyebrow'] ) ? $m['eyebrow'] : '',
		'h1'      => ! empty( $m['h1'] ) ? $m['h1'] : esc_html( get_the_title( $post ) ),
		'lead'    => isset( $m['lead'] ) ? $m['lead'] : '',
		'crumbs'  => $m['crumbs'],
		'actions' => isset( $m['actions'] ) ? $m['actions'] : array(),
	) );
}

function usucger_cta_html( $heading = '', $sub = '' ) {
	$heading = $heading ? $heading : 'Be part of the geotechnical academic community';
	$sub     = $sub ? $sub : 'Membership is ' . esc_html( usucger_setting( 'dues' ) ) . ' per person for the ' . esc_html( usucger_setting( 'cycle' ) ) . ' cycle and open to faculty, researchers, students and practitioners with a stake in geotechnical education and research.';
	return '<section class="cta-strip"><div class="wrap"><div class="cta-inner"><div><h2>' . wp_kses_post( $heading ) . '</h2><p>' . wp_kses_post( $sub ) . '</p></div>'
		. '<div class="cta-actions"><a href="' . esc_url( usucger_url( 'membership' ) ) . '" class="btn btn-amber">Join / Renew &rarr;</a>'
		. '<a href="' . esc_url( usucger_url( 'contact' ) ) . '" class="btn btn-ghost">Contact USUCGER</a></div></div></div></section>';
}

function usucger_render_page_cta( $post ) {
	$post = get_post( $post );
	if ( ! $post ) {
		return usucger_cta_html();
	}
	$m = usucger_hero_meta( $post->ID );
	if ( isset( $m['cta'] ) && ! $m['cta'] ) {
		return '';
	}
	if ( is_front_page() && ! isset( $m['cta'] ) ) {
		return '';
	}
	return usucger_cta_html( isset( $m['cta_heading'] ) ? $m['cta_heading'] : '', isset( $m['cta_sub'] ) ? $m['cta_sub'] : '' );
}

/* ----------------------------------------------------------------- meta box */
add_action( 'add_meta_boxes', function () {
	foreach ( array( 'page', 'post' ) as $pt ) {
		add_meta_box( 'usucger_hero', __( 'USUCGER page header', 'usucger' ), 'usucger_hero_box', $pt, 'normal', 'high' );
	}
} );

function usucger_lines_to_rows( $text, $cols ) {
	$rows = array();
	foreach ( preg_split( '/\r?\n/', (string) $text ) as $line ) {
		if ( '' === trim( $line ) ) {
			continue;
		}
		$p = array_map( 'trim', explode( '|', $line ) );
		$p = array_pad( $p, $cols, '' );
		foreach ( $p as $i => $v ) {
			if ( '' === $v && $i > 0 ) {
				$p[ $i ] = null;
			}
		}
		$rows[] = array_slice( $p, 0, $cols );
	}
	return $rows;
}

function usucger_rows_to_lines( $rows ) {
	$out = array();
	foreach ( (array) $rows as $r ) {
		$out[] = implode( ' | ', array_map( function ( $v ) {
			return null === $v ? '' : $v;
		}, $r ) );
	}
	return implode( "\n", $out );
}

function usucger_hero_box( $post ) {
	$m = usucger_hero_meta( $post->ID );
	wp_nonce_field( 'usucger_hero', 'usucger_hero_nonce' );
	$f = function ( $k ) use ( $m ) {
		return isset( $m[ $k ] ) ? $m[ $k ] : '';
	};
	?>
	<style>.usg-hero-box label{display:block;font-weight:600;margin:.8em 0 .25em}.usg-hero-box input[type=text],.usg-hero-box textarea{width:100%}.usg-hero-box .desc{color:#646970;font-size:12px}</style>
	<div class="usg-hero-box">
		<p class="desc">The colored header band at the top of the page. Leave a field empty to use the default (page title, no lead).</p>
		<label><input type="checkbox" name="usg_hero[no_hero]" value="1" <?php checked( ! empty( $m['no_hero'] ) ); ?>> Hide the page header (the page content supplies its own)</label>
		<label for="usg_eyebrow">Small label above the title (eyebrow)</label>
		<input type="text" id="usg_eyebrow" name="usg_hero[eyebrow]" value="<?php echo esc_attr( $f( 'eyebrow' ) ); ?>" placeholder="e.g. About USUCGER">
		<label for="usg_h1">Header title (if different from the page title)</label>
		<input type="text" id="usg_h1" name="usg_hero[h1]" value="<?php echo esc_attr( $f( 'h1' ) ); ?>">
		<label for="usg_lead">Lead sentence</label>
		<textarea id="usg_lead" name="usg_hero[lead]" rows="3"><?php echo esc_textarea( $f( 'lead' ) ); ?></textarea>
		<label for="usg_actions">Buttons — one per line: <code>Text | link | style</code></label>
		<textarea id="usg_actions" name="usg_hero[actions]" rows="3" placeholder="Read the By-Laws &rarr; | bylaws | btn-amber&#10;Meet the Board | board | btn-ghost"><?php echo esc_textarea( usucger_rows_to_lines( isset( $m['actions'] ) ? $m['actions'] : array() ) ); ?></textarea>
		<p class="desc">Link can be a page slug (<code>bylaws</code>, <code>bylaws#article-vi</code>) or a full URL. Styles: <code>btn-amber</code>, <code>btn-ghost</code>, <code>btn-cobalt</code>, <code>btn-outline</code>.</p>
		<label for="usg_crumbs">Breadcrumb — one per line: <code>Label | link</code> (leave link empty for plain text)</label>
		<textarea id="usg_crumbs" name="usg_hero[crumbs]" rows="2"><?php echo esc_textarea( usucger_rows_to_lines( isset( $m['crumbs'] ) ? $m['crumbs'] : array() ) ); ?></textarea>
		<label for="usg_desc">Search-engine description</label>
		<textarea id="usg_desc" name="usg_hero[description]" rows="2"><?php echo esc_textarea( $f( 'description' ) ); ?></textarea>
		<label><input type="checkbox" name="usg_hero[cta_off]" value="1" <?php checked( isset( $m['cta'] ) && ! $m['cta'] ); ?>> Hide the "Join / Renew" strip at the bottom</label>
		<label for="usg_cta_h">Bottom strip heading (optional)</label>
		<input type="text" id="usg_cta_h" name="usg_hero[cta_heading]" value="<?php echo esc_attr( $f( 'cta_heading' ) ); ?>">
		<label for="usg_cta_s">Bottom strip text (optional)</label>
		<textarea id="usg_cta_s" name="usg_hero[cta_sub]" rows="2"><?php echo esc_textarea( $f( 'cta_sub' ) ); ?></textarea>
	</div>
	<?php
}

add_action( 'save_post', function ( $post_id ) {
	if ( ! isset( $_POST['usucger_hero_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['usucger_hero_nonce'] ) ), 'usucger_hero' ) ) {
		return;
	}
	if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	$in = isset( $_POST['usg_hero'] ) ? wp_unslash( $_POST['usg_hero'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	$m  = array(
		'no_hero'     => ! empty( $in['no_hero'] ),
		'eyebrow'     => wp_kses_post( isset( $in['eyebrow'] ) ? $in['eyebrow'] : '' ),
		'h1'          => wp_kses_post( isset( $in['h1'] ) ? $in['h1'] : '' ),
		'lead'        => wp_kses_post( isset( $in['lead'] ) ? $in['lead'] : '' ),
		'actions'     => usucger_lines_to_rows( wp_kses_post( isset( $in['actions'] ) ? $in['actions'] : '' ), 3 ),
		'crumbs'      => usucger_lines_to_rows( wp_kses_post( isset( $in['crumbs'] ) ? $in['crumbs'] : '' ), 2 ),
		'description' => sanitize_textarea_field( isset( $in['description'] ) ? $in['description'] : '' ),
		'cta_heading' => wp_kses_post( isset( $in['cta_heading'] ) ? $in['cta_heading'] : '' ),
		'cta_sub'     => wp_kses_post( isset( $in['cta_sub'] ) ? $in['cta_sub'] : '' ),
	);
	if ( ! empty( $in['cta_off'] ) ) {
		$m['cta'] = false;
	}
	update_post_meta( $post_id, '_usucger_hero', $m );
} );
