<?php
/**
 * Not found.
 *
 * @package usucger
 */
get_header();
echo usucger_phero( array( 'eyebrow' => 'Error 404', 'h1' => 'Page not found', 'lead' => 'The page may have moved when the site was reorganized. Try the search, or start from one of these.', 'crumbs' => array( array( 'Not found', null ) ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput
?>
<section class="section bg-white"><div class="wrap"><div class="grid-3">
<a class="card" href="<?php echo esc_url( usucger_url( 'membership' ) ); ?>"><div class="card-title">Membership &amp; dues</div><div class="card-desc">Join or renew, directory and member universities.</div></a>
<a class="card" href="<?php echo esc_url( usucger_url( 'positions' ) ); ?>"><div class="card-title">Academic positions</div><div class="card-desc">Faculty openings shared by member institutions.</div></a>
<a class="card" href="<?php echo esc_url( usucger_url( 'books' ) ); ?>"><div class="card-title">Resources</div><div class="card-desc">Books, teaching aids, software and videos.</div></a>
</div></div></section>
<?php
get_footer();
