<?php
/**
 * Site header: skip link, navigation bar, mobile drawer and search overlay.
 *
 * @package usucger
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link" href="#main">Skip to content</a>

<nav id="nav" aria-label="Primary">
  <div class="nav-wrap">
    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="nav-brand" aria-label="USUCGER home">
      <?php if ( has_custom_logo() ) { echo wp_get_attachment_image( get_theme_mod( 'custom_logo' ), 'full', false, array( 'class' => 'nav-mark', 'alt' => '' ) ); } ?>
      <div class="nav-brand-text"><strong>USUCGER</strong></div>
    </a>
    <ul class="nav-menu"><?php echo usucger_nav_html(); // phpcs:ignore WordPress.Security.EscapeOutput ?></ul>
    <div class="nav-end">
      <button type="button" class="nav-search" id="searchOpen" aria-label="Search the site" title="Search (Ctrl+K)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg><span>Search</span><kbd>&#8984;K</kbd></button>
      <?php if ( is_user_logged_in() ) : ?>
      <a href="<?php echo esc_url( usucger_url( 'login' ) ); ?>" class="btn btn-outline btn-sm">Member area</a>
      <?php else : ?>
      <a href="<?php echo esc_url( usucger_url( 'contact' ) ); ?>" class="btn btn-outline btn-sm">Contact</a>
      <?php endif; ?>
      <a href="<?php echo esc_url( usucger_url( 'membership' ) ); ?>" class="btn btn-cobalt btn-sm">Join / Renew &rarr;</a>
    </div>
    <button type="button" class="nav-search nav-search-m" id="searchOpenM" aria-label="Search the site"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg></button>
    <button class="nav-toggle" id="navToggle" type="button" aria-label="Open menu" aria-expanded="false" aria-controls="drawer">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M3 6h18M3 12h18M3 18h18"/></svg>
    </button>
  </div>
</nav>

<div class="drawer" id="drawer">
  <div class="drawer-scrim"></div>
  <div class="drawer-panel" role="dialog" aria-label="Site menu">
    <div class="drawer-head"><span style="display:flex;align-items:center;gap:.6rem"><strong>USUCGER</strong></span><button class="drawer-close" type="button" aria-label="Close menu">&times;</button></div>
    <?php echo usucger_drawer_html(); // phpcs:ignore WordPress.Security.EscapeOutput ?>
    <div class="drawer-cta">
      <a href="<?php echo esc_url( usucger_url( 'membership' ) ); ?>" class="btn btn-cobalt">Join / Renew Membership</a>
      <?php if ( is_user_logged_in() ) : ?>
      <a href="<?php echo esc_url( usucger_url( 'login' ) ); ?>" class="btn btn-outline">My account</a>
      <?php else : ?>
      <a href="<?php echo esc_url( usucger_url( 'contact' ) ); ?>" class="btn btn-outline">Contact USUCGER</a>
      <?php endif; ?>
    </div>
  </div>
</div>

<div class="search" id="search" hidden>
  <div class="search-scrim"></div>
  <div class="search-box" role="dialog" aria-modal="true" aria-label="Search USUCGER">
    <div class="search-field"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg><input type="search" id="searchInput" placeholder="Search pages, awards, resources, people&hellip;" autocomplete="off"><button type="button" class="search-close" id="searchClose" aria-label="Close search">Esc</button></div>
    <div class="search-results" id="searchResults"><div class="search-hint">Try <em>travel grant</em>, <em>by-laws</em>, <em>CPT proceedings</em>, <em>Purdue</em>&hellip;</div></div>
  </div>
</div>

<main id="main">
