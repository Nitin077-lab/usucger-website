<?php
/**
 * Site footer, fixed bottom bar and back-to-top button.
 *
 * @package usucger
 */
$usg_contact = usucger_setting( 'contact_email' );
$usg_board   = usucger_setting( 'board_email' );
?>
</main>

<?php
if ( ! isset( $GLOBALS['usucger_no_cta'] ) ) {
	echo is_singular() ? usucger_render_page_cta( get_queried_object_id() ) : usucger_cta_html(); // phpcs:ignore WordPress.Security.EscapeOutput
}
?>

<footer class="site-footer">
  <div class="wrap">
    <div class="footer-top">
      <div class="ft-brand">
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="USUCGER home"><strong>USUCGER</strong><span class="ft-tag">Geotechnical Education &amp; Research</span></a>
        <p>United States Universities Council on Geotechnical Education and Research. Founded 1985 in San Francisco &mdash; advocacy for geomechanical, geotechnical and geoenvironmental engineering research and education at U.S. universities.</p>
        <p style="margin-top:.8rem">Questions? <a href="mailto:<?php echo esc_attr( $usg_contact ); ?>"><?php echo esc_html( $usg_contact ); ?></a><br>Board: <a href="mailto:<?php echo esc_attr( $usg_board ); ?>"><?php echo esc_html( $usg_board ); ?></a></p>
      </div>
      <?php echo usucger_footer_links_html(); // phpcs:ignore WordPress.Security.EscapeOutput ?>
    </div>
  </div>
</footer>

<div class="footer-bottom fixed-bar">
  <div class="wrap fb-inner">
    <span class="fb-copy">&copy; <span data-now-year><?php echo esc_html( gmdate( 'Y' ) ); ?></span> USUCGER. All rights reserved.</span>
    <span class="fb-contact">Contact: <a href="mailto:<?php echo esc_attr( $usg_contact ); ?>"><?php echo esc_html( $usg_contact ); ?></a></span>
    <?php if ( get_page_by_path( 'privacy' ) ) : ?><span class="fb-privacy"><a href="<?php echo esc_url( home_url( '/privacy/' ) ); ?>">Privacy</a></span><?php endif; ?>
    <span class="footer-credit"><?php echo esc_html( usucger_setting( 'credit' ) ); ?></span>
  </div>
</div>

<button id="btt" type="button" title="Back to top" aria-label="Back to top">&uarr;</button>
<?php wp_footer(); ?>
</body>
</html>
