<?php
/**
 * USUCGER theme bootstrap.
 *
 * @package usucger
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'USUCGER_THEME_VER', '1.0.0' );
define( 'USUCGER_THEME_DIR', get_template_directory() );
define( 'USUCGER_THEME_URI', get_template_directory_uri() );

require_once USUCGER_THEME_DIR . '/inc/helpers.php';
require_once USUCGER_THEME_DIR . '/inc/nav.php';
require_once USUCGER_THEME_DIR . '/inc/hero.php';
require_once USUCGER_THEME_DIR . '/inc/customizer.php';
require_once USUCGER_THEME_DIR . '/inc/woocommerce.php';

add_action( 'after_setup_theme', function () {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array( 'search-form', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'woocommerce' );
	register_nav_menus( array(
		'primary' => __( 'Main navigation (optional; the built-in menu is used when empty)', 'usucger' ),
		'footer'  => __( 'Footer columns (optional)', 'usucger' ),
	) );
} );

/* The imported pages are hand-written HTML: keep quotes and dashes exactly as written. */
add_filter( 'run_wptexturize', '__return_false' );

/* Assets ------------------------------------------------------------------ */
add_action( 'wp_enqueue_scripts', function () {
	$v = function ( $rel ) {
		$f = USUCGER_THEME_DIR . '/' . $rel;
		return file_exists( $f ) ? substr( md5_file( $f ), 0, 8 ) : USUCGER_THEME_VER;
	};
	wp_enqueue_style( 'usucger-fonts', 'https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,300;0,9..144,400;0,9..144,600;0,9..144,700;1,9..144,400;1,9..144,600&family=Figtree:wght@300;400;500;600;700&display=swap', array(), null );
	wp_enqueue_style( 'usucger-site', USUCGER_THEME_URI . '/assets/site.css', array(), $v( 'assets/site.css' ) );
	wp_enqueue_style( 'usucger-theme', USUCGER_THEME_URI . '/assets/theme.css', array( 'usucger-site' ), $v( 'assets/theme.css' ) );
	wp_enqueue_style( 'usucger-wp', USUCGER_THEME_URI . '/assets/wp.css', array( 'usucger-theme' ), $v( 'assets/wp.css' ) );

	wp_enqueue_script( 'usucger-site', USUCGER_THEME_URI . '/assets/site.js', array(), $v( 'assets/site.js' ), true );
	$themes = usucger_theme_data();
	$list   = array();
	foreach ( $themes['themes'] as $k => $t ) {
		$list[] = array( 'k' => $k, 'n' => $t['label'], 'c' => $t['primary-dk'], 'a' => $t['accent'], 'l' => ( isset( $t['band'] ) && 'light' === $t['band'] ) );
	}
	$inline  = 'window.USUCGER_THEMES=' . wp_json_encode( array( 'default' => usucger_default_theme(), 'list' => $list ) ) . ';';
	$inline .= 'window.USUCGER_PICKER=' . ( get_theme_mod( 'usucger_show_picker', true ) ? 'true' : 'false' ) . ';';
	$inline .= 'window.USUCGER_LINKS=' . wp_json_encode( array(
		'membership' => usucger_url( 'membership' ),
		'directory'  => usucger_url( 'directory' ),
	) ) . ';';
	wp_add_inline_script( 'usucger-site', $inline, 'before' );

	// Site search index (built by the USUCGER Core plugin; cached, rebuilt when content changes).
	if ( function_exists( 'usucger_core_search_index_url' ) ) {
		wp_enqueue_script( 'usucger-search-index', usucger_core_search_index_url(), array(), null, true );
		wp_script_add_data( 'usucger-search-index', 'strategy', 'defer' );
	}
} );

add_filter( 'style_loader_tag', function ( $html, $handle ) {
	if ( 'usucger-fonts' === $handle ) {
		$html = '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' . $html;
	}
	return $html;
}, 10, 2 );

/* Early theme switcher: honours ?theme=key and the home-page picker for the current visit. */
add_action( 'wp_head', function () {
	$data  = usucger_theme_data();
	$light = array();
	foreach ( $data['themes'] as $k => $t ) {
		if ( isset( $t['band'] ) && 'light' === $t['band'] ) {
			$light[] = $k;
		}
	}
	$all = array_keys( $data['themes'] );
	echo '<script>(function(){var L=' . wp_json_encode( $light ) . ';try{var q=new URLSearchParams(location.search).get("theme");try{localStorage.removeItem("usucger-theme")}catch(e){}var t=q||sessionStorage.getItem("usucger-theme");if(q)sessionStorage.setItem("usucger-theme",q);if(t&&' . wp_json_encode( $all ) . '.indexOf(t)>-1){var h=document.documentElement;h.setAttribute("data-theme",t);h.setAttribute("data-band",L.indexOf(t)>-1?"light":"dark");}}catch(e){}})();</script>' . "\n";
	$desc = usucger_meta_description();
	if ( $desc ) {
		echo '<meta name="description" content="' . esc_attr( $desc ) . '">' . "\n";
		echo '<meta property="og:description" content="' . esc_attr( $desc ) . '">' . "\n";
	}
	echo '<meta property="og:title" content="' . esc_attr( wp_get_document_title() ) . '">' . "\n";
	echo '<meta property="og:type" content="website">' . "\n";
}, 1 );

add_filter( 'language_attributes', function ( $out ) {
	if ( is_admin() ) {
		return $out;
	}
	$key = usucger_default_theme();
	return $out . ' data-theme="' . esc_attr( $key ) . '" data-band="' . esc_attr( usucger_theme_band( $key ) ) . '"';
} );

/* Page titles: "History & Mission — USUCGER" like the static site. */
add_filter( 'document_title_separator', function () {
	return '—';
} );
add_filter( 'document_title_parts', function ( $parts ) {
	if ( is_front_page() ) {
		return array( 'title' => 'USUCGER — U.S. Universities Council on Geotechnical Education and Research' );
	}
	$parts['site'] = 'USUCGER';
	unset( $parts['tagline'] );
	return $parts;
} );

/* Hide the admin bar on the public site for non-editors (members/customers). */
add_filter( 'show_admin_bar', function ( $show ) {
	return $show && current_user_can( 'edit_posts' );
} );

/**
 * Print the post content. Imported static pages (meta _usucger_raw) are already made
 * of full-width <section> blocks; anything else is wrapped in a readable column.
 */
function usucger_the_content_wrapped() {
	$raw = get_post_meta( get_the_ID(), '_usucger_raw', true );
	if ( $raw ) {
		the_content();
		return;
	}
	echo '<section class="section bg-white"><div class="wrap wp-prose">';
	the_content();
	wp_link_pages();
	echo '</div></section>';
}

/* Accessibility: tab bars announce themselves as tabs; selected state follows clicks. */
add_action( 'wp_footer', function () {
	echo "<script>document.querySelectorAll('[role=tablist]').forEach(function(g){var b=g.querySelectorAll('.tab-btn');b.forEach(function(x){x.setAttribute('role','tab');x.setAttribute('aria-selected',x.classList.contains('on')?'true':'false');x.addEventListener('click',function(){b.forEach(function(y){y.setAttribute('aria-selected',y===x?'true':'false');});});});});</script>\n"; // phpcs:ignore
}, 50 );
