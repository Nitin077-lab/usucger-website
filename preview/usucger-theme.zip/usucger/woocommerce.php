<?php
/**
 * WooCommerce shop / product screens inside the site shell.
 * (Cart, checkout and My Account are normal pages and use page.php.)
 *
 * @package usucger
 */
get_header();
echo usucger_wc_hero(); // phpcs:ignore WordPress.Security.EscapeOutput
echo '<section class="section bg-white"><div class="wrap wp-prose usg-wc">';
woocommerce_content();
echo '</div></section>';
get_footer();
