<?php
/**
 * USUCGER → Dashboard.
 *
 * @package usucger-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function usucger_page_dashboard() {
	global $wpdb;
	$c       = Usucger_Members::counts();
	$pend    = usucger_pending_counts();
	$ot      = Usucger_DB::t( 'outbox' );
	$queued  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $ot WHERE status = 'queued'" ); // phpcs:ignore WordPress.DB
	$sent30  = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $ot WHERE status = 'sent' AND sent_at >= %s", gmdate( 'Y-m-d', strtotime( '-30 days' ) ) ) ); // phpcs:ignore WordPress.DB
	$failed  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $ot WHERE status = 'failed'" ); // phpcs:ignore WordPress.DB
	$inst    = count( Usucger_Members::institutions() );
	$risk    = count( Usucger_Members::institutions_at_risk() );
	$cands   = count( Usucger_Members::removal_candidates() );
	$views   = usucger_daily_views( 30 );
	$max     = max( 1, max( $views ) );
	$sync    = get_option( 'usucger_last_sync' );
	$can_m   = current_user_can( 'usucger_view_members' );
	$stat    = function ( $n, $label, $url = '', $cls = '' ) {
		$inner = '<b>' . esc_html( $n ) . '</b><span>' . esc_html( $label ) . '</span>';
		echo '<div class="usg-stat ' . esc_attr( $cls ) . '">' . ( $url ? '<a href="' . esc_url( $url ) . '">' . $inner . '</a>' : $inner ) . '</div>'; // phpcs:ignore
	};
	?>
	<div class="wrap usg-wrap">
		<h1>USUCGER dashboard</h1>
		<?php if ( ! get_option( 'usucger_imported' ) && current_user_can( 'manage_options' ) ) : ?>
			<div class="notice notice-warning"><p><strong>First step:</strong> import the redesigned pages and data in <a href="<?php echo esc_url( usucger_admin_url( 'usucger-setup' ) ); ?>">Setup &amp; import</a>.</p></div>
		<?php endif; ?>
		<?php if ( usucger_can_approve() && $pend['total'] ) : ?>
			<div class="notice notice-info"><p><strong>Waiting for you:</strong>
			<?php if ( $pend['content'] ) : ?><a href="<?php echo esc_url( usucger_admin_url( 'usucger-review' ) ); ?>"><?php echo (int) $pend['content']; ?> content change(s)</a><?php endif; ?>
			<?php echo $pend['content'] && $pend['email'] ? ' · ' : ''; ?>
			<?php if ( $pend['email'] ) : ?><a href="<?php echo esc_url( usucger_admin_url( 'usucger-outbox', array( 'status' => 'pending' ) ) ); ?>"><?php echo (int) $pend['email']; ?> email(s) to approve</a><?php endif; ?>
			</p></div>
		<?php endif; ?>

		<?php if ( $can_m ) : ?>
		<h2 class="title">Membership <?php echo esc_html( usucger_core_opt( 'cycle' ) ); ?></h2>
		<div class="usg-grid">
			<?php
			$stat( $c['current'], 'Current members (paid this cycle)', usucger_admin_url( 'usucger-members', array( 'status' => 'current' ) ), 'ok' );
			$stat( $c['lapsed'], 'Not renewed', usucger_admin_url( 'usucger-members', array( 'status' => 'lapsed' ) ), 'warn' );
			$stat( $c['expiring'], 'Ending within 30 days', usucger_admin_url( 'usucger-members', array( 'status' => 'expiring' ) ), 'warn' );
			$stat( $c['former'], 'Former (removed)', usucger_admin_url( 'usucger-members', array( 'status' => 'former' ) ) );
			$stat( $inst, 'Member universities', usucger_admin_url( 'usucger-institutions' ), 'blue' );
			$stat( $risk, 'Universities with no paid member', usucger_admin_url( 'usucger-renewals' ) . '#risk', $risk ? 'warn' : 'ok' );
			?>
		</div>
		<p class="usg-help">
			<?php
			if ( Usucger_Members::wcm_active() ) {
				echo 'Synced from WooCommerce Memberships ' . ( $sync ? esc_html( human_time_diff( strtotime( $sync['time'] ), current_time( 'timestamp' ) ) ) . ' ago' : 'not yet' ) . '. ';
			} else {
				echo 'WooCommerce Memberships is not active on this site, so the member list is managed in USUCGER → Members (imported from the directory). ';
			}
			if ( $c['no_email'] ) {
				echo '<strong>' . (int) $c['no_email'] . '</strong> members have no email address yet (they cannot receive reminders until matched to an account or edited). ';
			}
			if ( $cands ) {
				echo '<a href="' . esc_url( usucger_admin_url( 'usucger-renewals' ) ) . '#cleanup">' . (int) $cands . ' lapsed members are past the grace period</a>.';
			}
			?>
		</p>
		<?php endif; ?>

		<div class="usg-cols">
			<div>
				<div class="usg-card">
					<h2>Email</h2>
					<div class="usg-grid" style="margin:0 0 8px">
						<?php
						$stat( $pend['email'], 'Waiting for approval', usucger_admin_url( 'usucger-outbox', array( 'status' => 'pending' ) ), $pend['email'] ? 'warn' : '' );
						$stat( $queued, 'In the outbox now', usucger_admin_url( 'usucger-outbox' ), 'blue' );
						$stat( $sent30, 'Sent in 30 days', usucger_admin_url( 'usucger-outbox' ), 'ok' );
						if ( $failed ) {
							$stat( $failed, 'Failed', usucger_admin_url( 'usucger-outbox' ), 'warn' );
						}
						?>
					</div>
					<p><a class="button button-primary" href="<?php echo esc_url( usucger_admin_url( 'usucger-compose' ) ); ?>">Compose email</a>
					<?php if ( usucger_can_approve() ) : ?> <a class="button" href="<?php echo esc_url( usucger_admin_url( 'usucger-compose', array( 'group' => 'not_renewed', 'tpl' => 'renewal_reminder' ) ) ); ?>">Remind non-renewed members</a><?php endif; ?></p>
				</div>
				<div class="usg-card">
					<h2>Website content</h2>
					<table class="widefat striped"><tbody>
						<tr><td><a href="<?php echo esc_url( admin_url( 'edit.php?post_type=usucger_position' ) ); ?>">Positions shown</a></td><td><?php echo (int) count( usucger_items( 'usucger_position' ) ); ?></td><td><a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=usucger_position' ) ); ?>">Add</a></td></tr>
						<tr><td><a href="<?php echo esc_url( admin_url( 'edit.php?post_type=usucger_conference' ) ); ?>">Upcoming conferences</a></td><td><?php echo (int) count( usucger_items( 'usucger_conference' ) ); ?></td><td><a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=usucger_conference' ) ); ?>">Add</a></td></tr>
						<tr><td><a href="<?php echo esc_url( admin_url( 'edit.php?post_type=usucger_deadline' ) ); ?>">Deadlines</a></td><td><?php echo (int) count( usucger_items( 'usucger_deadline' ) ); ?></td><td><a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=usucger_deadline' ) ); ?>">Add</a></td></tr>
						<tr><td><a href="<?php echo esc_url( admin_url( 'edit.php?post_type=usucger_minutes' ) ); ?>">Minutes</a></td><td><?php echo (int) count( usucger_items( 'usucger_minutes' ) ); ?></td><td><a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=usucger_minutes' ) ); ?>">Add</a></td></tr>
						<tr><td><a href="<?php echo esc_url( admin_url( 'edit.php?post_type=page' ) ); ?>">Pages</a></td><td><?php echo (int) wp_count_posts( 'page' )->publish; ?></td><td><a href="<?php echo esc_url( usucger_admin_url( 'usucger-review' ) ); ?>">Review queue (<?php echo (int) $pend['content']; ?>)</a></td></tr>
					</tbody></table>
				</div>
			</div>
			<div>
				<div class="usg-card">
					<h2>Website visits — last 30 days (<?php echo (int) array_sum( $views ); ?> page views)</h2>
					<div class="usg-bars" title="Daily page views">
						<?php foreach ( $views as $d => $v ) : ?><i style="height:<?php echo (int) round( 100 * $v / $max ); ?>%" title="<?php echo esc_attr( $d . ': ' . $v ); ?>"></i><?php endforeach; ?>
					</div>
					<table class="widefat striped"><thead><tr><th>Page</th><th style="width:80px">Views</th></tr></thead><tbody>
					<?php
					$top = usucger_top_pages( 30, 12 );
					if ( ! $top ) {
						echo '<tr><td colspan="2">No visits recorded yet (logged-in editors are not counted).</td></tr>';
					}
					foreach ( $top as $r ) {
						echo '<tr><td><a href="' . esc_url( home_url( $r->path ) ) . '" target="_blank">' . esc_html( $r->path ) . '</a></td><td>' . (int) $r->v . '</td></tr>';
					}
					?>
					</tbody></table>
				</div>
				<?php if ( usucger_can_approve() ) : ?>
				<div class="usg-card">
					<h2>Recent activity</h2>
					<table class="widefat striped"><tbody>
					<?php
					$lt = Usucger_DB::t( 'log' );
					foreach ( $wpdb->get_results( "SELECT * FROM $lt ORDER BY id DESC LIMIT 12" ) as $l ) { // phpcs:ignore WordPress.DB
						$u = $l->user_id ? get_userdata( $l->user_id ) : null;
						echo '<tr><td style="white-space:nowrap">' . esc_html( mysql2date( 'M j, g:i a', $l->time ) ) . '</td><td>' . esc_html( str_replace( '_', ' ', $l->action ) ) . '</td><td>' . esc_html( $u ? $u->display_name : 'system' ) . '</td><td>' . esc_html( wp_trim_words( $l->object . ' ' . $l->detail, 10 ) ) . '</td></tr>';
					}
					?>
					</tbody></table>
				</div>
				<?php endif; ?>
			</div>
		</div>
	</div>
	<?php
}
