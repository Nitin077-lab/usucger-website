<?php
/**
 * USUCGER → Data cleanup: the fixes elections and mailings depend on.
 *   Delegates      member universities whose delegate has no usable email (auto-suggests matches)
 *   Imported names directory rows imported from the old site that match no membership account
 *   Institutions   institution changes requested by current members
 *   Bounced        addresses the email service reported as undeliverable
 *
 * @package usucger-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'admin_menu', function () {
	$n = usucger_datafix_counts();
	$t = array_sum( $n );
	add_submenu_page( 'usucger', 'Data cleanup', 'Data cleanup' . ( $t ? ' <span class="awaiting-mod">' . (int) $t . '</span>' : '' ), 'usucger_manage', 'usucger-datafix', 'usucger_page_datafix' );
}, 11 );

function usucger_datafix_counts() {
	static $c = null;
	if ( null === $c ) {
		$c = get_transient( 'usucger_datafix_counts' );
	}
	if ( ! is_array( $c ) ) {
		global $wpdb;
		$ct = Usucger_DB::t( 'contacts' );
		$c  = array(
			'delegates'    => count( usucger_delegate_problems() ),
			'institutions' => count( usucger_inst_requests() ),
			'bounced'      => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $ct WHERE bounced = 1 AND status IN ('current','lapsed')" ), // phpcs:ignore WordPress.DB
		);
		set_transient( 'usucger_datafix_counts', $c, 10 * MINUTE_IN_SECONDS ); // the menu badge runs on every admin page
	}
	return $c;
}

/** Member universities whose delegate cannot receive a ballot. */
function usucger_delegate_problems() {
	global $wpdb;
	$ct  = Usucger_DB::t( 'contacts' );
	$out = array();
	foreach ( Usucger_Members::institutions() as $i ) {
		$email = strtolower( trim( $i->contact_email ) );
		$c     = $email ? $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $ct WHERE email = %s", $email ) ) : null;
		$issue = '';
		if ( ! $i->contact_name && ! $email ) {
			$issue = 'No delegate named';
		} elseif ( ! $email ) {
			$issue = 'No email for the delegate';
		} elseif ( ! $c ) {
			$issue = 'Email does not match any member record';
		} elseif ( 'current' !== $c->status ) {
			$issue = 'Delegate is not a current paid member';
		} elseif ( ! empty( $c->bounced ) ) {
			$issue = 'Delegate email bounced';
		}
		if ( $issue ) {
			$sug = $i->contact_name ? usucger_contact_by_name( $i->contact_name, $i->name ) : null; // same institution only
			if ( $sug && ( ! $sug->email || strtolower( $sug->email ) === $email ) ) {
				$sug = null;
			}
			$out[] = (object) array( 'inst' => $i, 'issue' => $issue, 'suggest' => $sug, 'contact' => $c );
		}
	}
	return $out;
}

/** Imported directory rows (no email) that no membership account was linked to. */
function usucger_unmatched_imports() {
	global $wpdb;
	$ct = Usucger_DB::t( 'contacts' );
	return $wpdb->get_results( "SELECT * FROM $ct WHERE source = 'import' AND email = '' AND user_id = 0 AND status <> 'former' ORDER BY last_name, first_name" ); // phpcs:ignore WordPress.DB
}

/** Possible matches for an imported row: member records and site accounts with the same last name. */
function usucger_import_suggestions( $r ) {
	global $wpdb;
	$ct    = Usucger_DB::t( 'contacts' );
	$out   = array();
	$first = mb_strtolower( mb_substr( trim( $r->first_name ), 0, 1 ) );
	foreach ( $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $ct WHERE id <> %d AND email <> '' AND LOWER(last_name) = %s", $r->id, mb_strtolower( trim( $r->last_name ) ) ) ) as $c ) {
		if ( '' === $first || 0 === mb_stripos( $c->first_name, $first ) ) {
			$score = ( 0 === strcasecmp( trim( $c->first_name ), trim( $r->first_name ) ) ? 2 : 1 ) + ( usucger_norm( $c->institution ) === usucger_norm( $r->institution ) ? 2 : 0 );
			$out[] = array( 'contact', $c->id, trim( $c->first_name . ' ' . $c->last_name ) . ' <' . $c->email . '> · ' . $c->institution . ' · ' . $c->status, $score );
		}
	}
	foreach ( get_users( array( 'meta_key' => 'last_name', 'meta_value' => trim( $r->last_name ), 'number' => 10 ) ) as $u ) { // phpcs:ignore WordPress.DB.SlowDBQuery
		if ( ( '' === $first || 0 === mb_stripos( $u->first_name, $first ) ) && ! Usucger_Members::find_for_user( $u->ID, strtolower( $u->user_email ), '', '' ) ) {
			$out[] = array( 'user', $u->ID, trim( $u->first_name . ' ' . $u->last_name ) . ' <' . $u->user_email . '> · site account', 1 );
		}
	}
	usort( $out, function ( $a, $b ) {
		return $b[3] - $a[3];
	} );
	return $out;
}

function usucger_page_datafix() {
	$tabs = array( 'delegates' => 'Delegates', 'names' => 'Imported names', 'institutions' => 'Institution changes', 'bounced' => 'Bounced emails' );
	$tab  = isset( $_GET['tab'] ) && isset( $tabs[ $_GET['tab'] ] ) ? sanitize_key( $_GET['tab'] ) : 'delegates'; // phpcs:ignore WordPress.Security.NonceVerification
	delete_transient( 'usucger_datafix_counts' );
	$n    = usucger_datafix_counts();
	$n['names'] = count( usucger_unmatched_imports() );
	echo '<div class="wrap usg-wrap"><h1>Data cleanup</h1><p class="usg-help">Small fixes that keep ballots and emails going to the right people. Nothing here is sent to anyone.</p><nav class="nav-tab-wrapper">';
	foreach ( $tabs as $k => $l ) {
		echo '<a class="nav-tab' . ( $k === $tab ? ' nav-tab-active' : '' ) . '" href="' . esc_url( usucger_admin_url( 'usucger-datafix', array( 'tab' => $k ) ) ) . '">' . esc_html( $l ) . ( ! empty( $n[ $k ] ) ? ' <span class="awaiting-mod count-' . (int) $n[ $k ] . '"><span>' . (int) $n[ $k ] . '</span></span>' : '' ) . '</a>';
	}
	echo '</nav><div style="margin-top:16px">';
	call_user_func( 'usucger_datafix_' . $tab );
	echo '</div></div>';
}

function usucger_datafix_delegates() {
	$rows = usucger_delegate_problems();
	echo '<p class="usg-help">By-Laws Art. III: each member university votes through its delegate (a current, paid member). Universities below cannot get a ballot until this is fixed. Where a member record matches the delegate’s name, it is suggested — tick it, or type the email.</p>';
	if ( ! $rows ) {
		echo '<div class="usg-card"><p><strong>All member universities have a delegate with a working member email.</strong></p></div>';
		return;
	}
	$per   = 50;
	$total = count( $rows );
	$pg    = max( 1, min( (int) ceil( $total / $per ), isset( $_GET['pg'] ) ? (int) $_GET['pg'] : 1 ) ); // phpcs:ignore WordPress.Security.NonceVerification
	$rows  = array_slice( $rows, ( $pg - 1 ) * $per, $per );
	echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="usucger_fix_delegates"><input type="hidden" name="pg" value="' . (int) $pg . '">';
	wp_nonce_field( 'usucger_fix_delegates' );
	echo '<p><strong>Showing ' . ( ( $pg - 1 ) * $per + 1 ) . '–' . ( ( $pg - 1 ) * $per + count( $rows ) ) . ' of ' . (int) $total . '.</strong> ' . usucger_datafix_pager( 'delegates', $pg, $total, $per ) . ' <button class="button button-primary">Save delegates</button></p>'; // phpcs:ignore
	echo '<table class="widefat striped"><thead><tr><th>University</th><th>Delegate on file</th><th>Problem</th><th>Suggested match</th><th>New delegate email</th></tr></thead><tbody>';
	foreach ( $rows as $r ) {
		$i = $r->inst;
		echo '<tr><td><a href="' . esc_url( usucger_admin_url( 'usucger-institutions', array( 'edit' => $i->id ) ) ) . '">' . esc_html( $i->name ) . '</a></td><td>' . esc_html( $i->contact_name ) . ( $i->contact_email ? '<br><code>' . esc_html( $i->contact_email ) . '</code>' : '' ) . '</td><td>' . esc_html( $r->issue ) . '</td><td>';
		if ( $r->suggest ) {
			echo '<label><input type="checkbox" name="use[' . (int) $i->id . ']" value="' . esc_attr( $r->suggest->email ) . '" checked aria-label="' . esc_attr( 'Use suggested delegate for ' . $i->name ) . '"> ' . esc_html( trim( $r->suggest->first_name . ' ' . $r->suggest->last_name ) ) . ' <code>' . esc_html( $r->suggest->email ) . '</code> ' . usucger_pill( $r->suggest->status ) . '</label>'; // phpcs:ignore
		} else {
			echo '<span class="description">—</span>';
		}
		echo '</td><td><input type="email" name="email[' . (int) $i->id . ']" placeholder="name@university.edu" style="width:100%" aria-label="' . esc_attr( 'New delegate email for ' . $i->name ) . '"><br><input type="text" name="name[' . (int) $i->id . ']" placeholder="Delegate name (if different)" style="width:100%;margin-top:3px" aria-label="' . esc_attr( 'Delegate name for ' . $i->name ) . '"></td></tr>';
	}
	echo '</tbody></table><p><button class="button button-primary">Save delegates</button> <span class="description">Typed emails win over ticked suggestions. If an election is open, the voter roll is refreshed.</span></p></form>';
}

add_action( 'admin_post_usucger_fix_delegates', function () {
	usucger_check( 'usucger_fix_delegates', 'usucger_manage' );
	global $wpdb;
	$it   = Usucger_DB::t( 'institutions' );
	$ct   = Usucger_DB::t( 'contacts' );
	$use  = (array) wp_unslash( isset( $_POST['use'] ) ? $_POST['use'] : array() ); // phpcs:ignore
	$typed = (array) wp_unslash( isset( $_POST['email'] ) ? $_POST['email'] : array() ); // phpcs:ignore
	$names = (array) wp_unslash( isset( $_POST['name'] ) ? $_POST['name'] : array() ); // phpcs:ignore
	$n    = 0;
	foreach ( array_unique( array_merge( array_keys( $use ), array_keys( $typed ) ) ) as $iid ) {
		$iid   = (int) $iid;
		$email = strtolower( sanitize_email( isset( $typed[ $iid ] ) ? $typed[ $iid ] : '' ) );
		if ( ! is_email( $email ) ) {
			$email = strtolower( sanitize_email( isset( $use[ $iid ] ) ? $use[ $iid ] : '' ) );
			// a ticked suggestion must belong to this institution (typed emails are the admin's call)
			$inst = $wpdb->get_row( $wpdb->prepare( "SELECT name, aliases FROM $it WHERE id = %d", $iid ) );
			$sc   = $email ? $wpdb->get_row( $wpdb->prepare( "SELECT institution FROM $ct WHERE email = %s", $email ) ) : null;
			$ok   = $inst && $sc && ( '' === trim( (string) $sc->institution ) || in_array( usucger_norm( $sc->institution ), array_map( 'usucger_norm', array_merge( array( $inst->name ), explode( ';', (string) $inst->aliases ) ) ), true ) );
			if ( ! $ok ) {
				continue;
			}
		}
		if ( ! $iid || ! is_email( $email ) ) {
			continue;
		}
		$data = array( 'contact_email' => $email, 'updated' => current_time( 'mysql' ) );
		$nm   = sanitize_text_field( isset( $names[ $iid ] ) ? $names[ $iid ] : '' );
		if ( ! $nm ) {
			$c  = $wpdb->get_row( $wpdb->prepare( "SELECT first_name, last_name FROM $ct WHERE email = %s", $email ) );
			$nm = $c ? trim( $c->first_name . ' ' . $c->last_name ) : '';
		}
		if ( $nm ) {
			$data['contact_name'] = $nm;
		}
		$wpdb->update( $it, $data, array( 'id' => $iid ) );
		Usucger_DB::log( 'delegate_fixed', 'institution:' . $iid, $email );
		$n++;
	}
	$e = function_exists( 'usucger_current_election' ) ? usucger_current_election() : null;
	if ( $n && $e && ! in_array( usucger_election_phase( $e ), array( 'closed', 'certified', 'draft' ), true ) ) {
		usucger_election_build_roll( $e->id );
	}
	delete_transient( 'usucger_datafix_counts' );
	usucger_back( usucger_admin_url( 'usucger-datafix', array( 'tab' => 'delegates', 'pg' => isset( $_POST['pg'] ) ? (int) $_POST['pg'] : 1 ) ), sprintf( '%d delegate(s) updated.', $n ) );
} );

function usucger_datafix_names() {
	$rows = usucger_unmatched_imports();
	echo '<p class="usg-help">These people were listed in the old website’s directory but no membership account has been linked to them. If one is the same person as a member record or site account, merge them (this row is removed; the member’s own directory choice is kept). Otherwise add their email — they count as members again only once WooCommerce Memberships shows a payment — or remove the row if they are no longer members.</p>';
	if ( ! $rows ) {
		echo '<div class="usg-card"><p><strong>Every imported name is linked to a member record.</strong></p></div>';
		return;
	}
	echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="usucger_fix_names">';
	wp_nonce_field( 'usucger_fix_names' );
	echo '<p><strong>Showing ' . min( 50, count( $rows ) ) . ' of ' . count( $rows ) . '</strong> (apply to see the next ones). Strong matches (same first name and institution) are pre-selected — check them before applying. <button class="button button-primary">Apply</button></p>';
	echo '<table class="widefat striped"><thead><tr><th>Imported name</th><th>Institution</th><th>Action</th></tr></thead><tbody>';
	foreach ( array_slice( $rows, 0, 50 ) as $r ) {
		$sug = usucger_import_suggestions( $r );
		echo '<tr><td><strong>' . esc_html( trim( $r->first_name . ' ' . $r->last_name ) ) . '</strong></td><td>' . esc_html( $r->institution ) . '</td><td><select name="act[' . (int) $r->id . ']" style="max-width:520px" aria-label="' . esc_attr( 'Action for ' . trim( $r->first_name . ' ' . $r->last_name ) ) . '"><option value="">Leave for now</option>';
		foreach ( $sug as $k => $s ) {
			echo '<option value="' . esc_attr( $s[0] . ':' . $s[1] ) . '"' . selected( 0 === $k && $s[3] >= 3, true, false ) . '>Merge with ' . esc_html( $s[2] ) . '</option>';
		}
		echo '<option value="email">Add an email →</option><option value="former">Not a member any more — remove from directory</option></select> <input type="email" name="email[' . (int) $r->id . ']" placeholder="email (for “Add an email”)" style="width:230px" aria-label="' . esc_attr( 'Email for ' . trim( $r->first_name . ' ' . $r->last_name ) ) . '"></td></tr>';
	}
	echo '</tbody></table><p><button class="button button-primary">Apply</button></p></form>';
}

add_action( 'admin_post_usucger_fix_names', function () {
	usucger_check( 'usucger_fix_names', 'usucger_manage' );
	global $wpdb;
	$ct   = Usucger_DB::t( 'contacts' );
	$acts = (array) wp_unslash( isset( $_POST['act'] ) ? $_POST['act'] : array() ); // phpcs:ignore
	$ems  = (array) wp_unslash( isset( $_POST['email'] ) ? $_POST['email'] : array() ); // phpcs:ignore
	$done = array( 'merged' => 0, 'email' => 0, 'former' => 0 );
	foreach ( $acts as $id => $act ) {
		$id  = (int) $id;
		$imp = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $ct WHERE id = %d AND source = 'import' AND email = ''", $id ) );
		if ( ! $imp || ! $act ) {
			continue;
		}
		if ( 'former' === $act ) {
			Usucger_Members::remove( array( $id ), 'import_cleanup' );
			$done['former']++;
		} elseif ( 'email' === $act ) {
			$em = strtolower( sanitize_email( isset( $ems[ $id ] ) ? $ems[ $id ] : '' ) );
			if ( ! is_email( $em ) ) {
				continue;
			}
			$other = $wpdb->get_row( $wpdb->prepare( "SELECT id FROM $ct WHERE email = %s", $em ) );
			if ( $other ) {
				usucger_merge_import( $imp, (int) $other->id );
				$done['merged']++;
			} else {
				// an email alone does not prove payment: the next membership sync sets the real status
				$wpdb->update( $ct, array( 'email' => $em, 'source' => 'manual', 'status' => 'prospect', 'token' => usucger_token(), 'updated' => current_time( 'mysql' ) ), array( 'id' => $id ) );
				$done['email']++;
				$resync = true;
			}
		} elseif ( preg_match( '/^(contact|user):(\d+)$/', $act, $m ) ) {
			if ( 'contact' === $m[1] ) {
				usucger_merge_import( $imp, (int) $m[2] );
			} else {
				$u = get_userdata( (int) $m[2] );
				if ( ! $u ) {
					continue;
				}
				$have = Usucger_Members::find_for_user( $u->ID, strtolower( $u->user_email ), '', '' );
				if ( $have ) { // the account got a member record meanwhile (or another row was linked to it)
					usucger_merge_import( $imp, (int) $have->id );
				} else {
					$wpdb->update( $ct, array( 'email' => strtolower( $u->user_email ), 'user_id' => $u->ID, 'source' => 'manual', 'status' => 'prospect', 'token' => usucger_token(), 'updated' => current_time( 'mysql' ) ), array( 'id' => $id ) );
					$resync = true;
				}
			}
			$done['merged']++;
		}
	}
	if ( ! empty( $resync ) && class_exists( 'Usucger_Members' ) && Usucger_Members::wcm_active() ) {
		Usucger_Members::sync(); // linked people become current only if WooCommerce Memberships says they paid
	}
	Usucger_DB::log( 'imported_names_fixed', '', $done );
	usucger_bump_content_version();
	usucger_back( usucger_admin_url( 'usucger-datafix', array( 'tab' => 'names' ) ), sprintf( '%d merged, %d emails added, %d removed.', $done['merged'], $done['email'], $done['former'] ) );
} );

/** Fold an imported directory row into a real member record. */
function usucger_merge_import( $imp, $into_id ) {
	global $wpdb;
	$ct   = Usucger_DB::t( 'contacts' );
	$into = Usucger_Members::get( $into_id );
	if ( ! $into || (int) $into->id === (int) $imp->id ) {
		return false;
	}
	$upd = array( 'updated' => current_time( 'mysql' ) ); // keep the member's own directory choice
	if ( '' === trim( (string) $into->institution ) && $imp->institution ) {
		$upd['institution'] = $imp->institution;
	}
	if ( $imp->tags ) {
		$upd['tags'] = implode( ',', array_unique( array_filter( array_merge( explode( ',', (string) $into->tags ), explode( ',', (string) $imp->tags ) ) ) ) );
	}
	$wpdb->update( $ct, $upd, array( 'id' => $into->id ) );
	$wpdb->delete( $ct, array( 'id' => $imp->id ) );
	Usucger_DB::log( 'contact_merged', 'contact:' . $into->id, 'import row ' . $imp->id . ' (' . trim( $imp->first_name . ' ' . $imp->last_name ) . ')' );
	return true;
}

function usucger_datafix_institutions() {
	global $wpdb;
	$req = usucger_inst_requests();
	echo '<p class="usg-help">A current member’s institution decides which university they vote with, the directory and the member map, so changes wait here. Approving updates their record; declining keeps the old institution. The member is told either way.</p>';
	if ( ! $req ) {
		echo '<div class="usg-card"><p><strong>No institution changes waiting.</strong></p></div>';
		return;
	}
	echo '<table class="widefat striped"><thead><tr><th>Member</th><th>From</th><th>To</th><th>Asked</th><th></th></tr></thead><tbody>';
	foreach ( $req as $cid => $r ) {
		$c = Usucger_Members::get( $cid );
		if ( ! $c ) {
			continue;
		}
		$known = $wpdb->get_var( $wpdb->prepare( 'SELECT name FROM ' . Usucger_DB::t( 'institutions' ) . ' WHERE LOWER(name) = %s OR CONCAT(\';\', LOWER(aliases), \';\') LIKE %s', mb_strtolower( $r['new'] ), '%;' . $wpdb->esc_like( mb_strtolower( $r['new'] ) ) . ';%' ) );
		echo '<tr><td>' . esc_html( trim( $c->first_name . ' ' . $c->last_name ) ) . '<br><code>' . esc_html( $c->email ) . '</code></td><td>' . esc_html( $r['old'] ) . '</td><td><strong>' . esc_html( $r['new'] ) . '</strong>' . ( $known ? ' <span class="usg-pill current">member university</span>' : ' <span class="description">(not a member university name — check spelling)</span>' ) . '</td><td>' . esc_html( human_time_diff( strtotime( $r['at'] ), current_time( 'timestamp' ) ) ) . ' ago</td><td style="white-space:nowrap">';
		foreach ( array( 'approve' => 'Approve', 'decline' => 'Decline' ) as $a => $l ) {
			echo '<a class="button' . ( 'approve' === $a ? ' button-primary' : '' ) . '" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=usucger_inst_request&do=' . $a . '&c=' . (int) $cid ), 'usucger_inst_request_' . $cid ) ) . '">' . esc_html( $l ) . '</a> ';
		}
		echo '</td></tr>';
	}
	echo '</tbody></table>';
}

add_action( 'admin_post_usucger_inst_request', function () {
	$cid = isset( $_GET['c'] ) ? (int) $_GET['c'] : 0;
	usucger_check( 'usucger_inst_request_' . $cid, 'usucger_manage' );
	global $wpdb;
	$req = usucger_inst_requests();
	$c   = Usucger_Members::get( $cid );
	if ( ! isset( $req[ $cid ] ) || ! $c ) {
		usucger_back( usucger_admin_url( 'usucger-datafix', array( 'tab' => 'institutions' ) ), 'Already handled.' );
	}
	$r  = $req[ $cid ];
	$ok = 'approve' === ( isset( $_GET['do'] ) ? sanitize_key( $_GET['do'] ) : '' );
	$declined = (array) get_option( 'usucger_inst_declined', array() );
	if ( $ok ) {
		$wpdb->update( Usucger_DB::t( 'contacts' ), array( 'institution' => $r['new'], 'updated' => current_time( 'mysql' ) ), array( 'id' => $cid ) );
		if ( $c->user_id && usucger_core_opt( 'institution_meta' ) ) {
			update_user_meta( $c->user_id, usucger_core_opt( 'institution_meta' ), $r['new'] ); // so the daily sync agrees
		}
		unset( $declined[ $cid ] );
		usucger_bump_content_version();
		$e = function_exists( 'usucger_current_election' ) ? usucger_current_election() : null;
		if ( $e && ! in_array( usucger_election_phase( $e ), array( 'closed', 'certified', 'draft' ), true ) ) {
			usucger_election_build_roll( $e->id );
		}
	} else {
		$declined[ $cid ] = usucger_norm( $r['new'] ); // the store may still say the new name; do not ask again for it
	}
	update_option( 'usucger_inst_declined', $declined, false );
	delete_transient( 'usucger_datafix_counts' );
	unset( $req[ $cid ] );
	update_option( 'usucger_inst_requests', $req, false );
	Usucger_DB::log( $ok ? 'institution_change_approved' : 'institution_change_declined', 'contact:' . $cid, $r['old'] . ' → ' . $r['new'] );
	usucger_notify( $c->email, $ok ? 'Your institution is updated' : 'About your institution change', $ok ? '<p>Your USUCGER record now shows <strong>' . esc_html( $r['new'] ) . '</strong>.</p>' : '<p>We kept <strong>' . esc_html( $r['old'] ) . '</strong> as your institution for now. Please reply to ' . esc_html( usucger_core_opt( 'contact_email' ) ) . ' if it should change.</p>' );
	usucger_back( usucger_admin_url( 'usucger-datafix', array( 'tab' => 'institutions' ) ), $ok ? 'Approved.' : 'Declined.' );
} );

function usucger_datafix_bounced() {
	global $wpdb;
	$ct   = Usucger_DB::t( 'contacts' );
	$rows = $wpdb->get_results( "SELECT * FROM $ct WHERE bounced = 1 ORDER BY status = 'current' DESC, last_name LIMIT 300" ); // phpcs:ignore WordPress.DB
	$hook = rest_url( 'usucger/v1/bounce' );
	echo '<p class="usg-help">Your email service reports these addresses as undeliverable (or the person marked USUCGER mail as spam). They are skipped by every mailing, including ballots. Enter a corrected address, or clear the flag if the problem is fixed.' . ( usucger_core_opt( 'bounce_secret' ) ? '' : ' <strong>The bounce webhook is off</strong> — set a secret in <a href="' . esc_url( usucger_admin_url( 'usucger-settings' ) ) . '">Settings</a> and give your email service <code>' . esc_html( $hook ) . '?key=…</code>.' ) . '</p>';
	if ( ! $rows ) {
		echo '<div class="usg-card"><p><strong>No bounced addresses.</strong></p></div>';
		return;
	}
	echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="usucger_fix_bounced">';
	wp_nonce_field( 'usucger_fix_bounced' );
	echo '<table class="widefat striped"><thead><tr><th>Name</th><th>Address</th><th>Status</th><th>Reason</th><th>Corrected address</th><th>Clear flag</th></tr></thead><tbody>';
	foreach ( $rows as $r ) {
		echo '<tr><td>' . esc_html( trim( $r->first_name . ' ' . $r->last_name ) ? trim( $r->first_name . ' ' . $r->last_name ) : '(no name on file)' ) . '<br><span class="description">' . esc_html( $r->institution ) . '</span></td><td><code>' . esc_html( $r->email ) . '</code></td><td>' . usucger_pill( $r->status ) . '</td><td>' . esc_html( $r->bounce_note ) . '</td><td><input type="email" name="email[' . (int) $r->id . ']" style="width:100%" aria-label="' . esc_attr( 'Corrected address for ' . $r->email ) . '"></td><td><input type="checkbox" name="clear[' . (int) $r->id . ']" value="1" aria-label="' . esc_attr( 'Clear bounce flag for ' . $r->email ) . '"></td></tr>'; // phpcs:ignore
	}
	echo '</tbody></table><p><button class="button button-primary">Save</button> <span class="description">A corrected address that belongs to a membership account should also be changed in that person’s WordPress profile, or the next sync brings the old one back.</span></p></form>';
}

add_action( 'admin_post_usucger_fix_bounced', function () {
	usucger_check( 'usucger_fix_bounced', 'usucger_manage' );
	global $wpdb;
	$ct  = Usucger_DB::t( 'contacts' );
	$ems = (array) wp_unslash( isset( $_POST['email'] ) ? $_POST['email'] : array() ); // phpcs:ignore
	$clr = (array) wp_unslash( isset( $_POST['clear'] ) ? $_POST['clear'] : array() ); // phpcs:ignore
	$n   = 0;
	foreach ( array_unique( array_merge( array_keys( $ems ), array_keys( $clr ) ) ) as $id ) {
		$id = (int) $id;
		$em = strtolower( sanitize_email( isset( $ems[ $id ] ) ? $ems[ $id ] : '' ) );
		if ( is_email( $em ) ) {
			if ( $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $ct WHERE email = %s AND id <> %d", $em, $id ) ) ) {
				continue; // that address already has its own record
			}
			$old = $wpdb->get_var( $wpdb->prepare( "SELECT email FROM $ct WHERE id = %d", $id ) );
			$wpdb->update( $ct, array( 'email' => $em, 'bounced' => 0, 'bounce_note' => '', 'updated' => current_time( 'mysql' ) ), array( 'id' => $id ) );
			if ( $old ) { // delegates and alternates follow the corrected address
				$it = Usucger_DB::t( 'institutions' );
				$wpdb->query( $wpdb->prepare( "UPDATE $it SET contact_email = %s WHERE LOWER(contact_email) = %s", $em, strtolower( $old ) ) );
				$wpdb->query( $wpdb->prepare( "UPDATE $it SET alternate_email = %s WHERE LOWER(alternate_email) = %s", $em, strtolower( $old ) ) );
				$roll = true;
			}
			$n++;
		} elseif ( ! empty( $clr[ $id ] ) ) {
			$wpdb->update( $ct, array( 'bounced' => 0, 'bounce_note' => '', 'updated' => current_time( 'mysql' ) ), array( 'id' => $id ) );
			$n++;
		}
	}
	$e = function_exists( 'usucger_current_election' ) ? usucger_current_election() : null;
	if ( ! empty( $roll ) && $e && ! in_array( usucger_election_phase( $e ), array( 'closed', 'certified', 'draft' ), true ) ) {
		usucger_election_build_roll( $e->id );
	}
	delete_transient( 'usucger_datafix_counts' );
	Usucger_DB::log( 'bounces_fixed', '', $n );
	usucger_back( usucger_admin_url( 'usucger-datafix', array( 'tab' => 'bounced' ) ), sprintf( '%d address(es) updated.', $n ) );
} );

function usucger_datafix_pager( $tab, $pg, $total, $per ) {
	$pages = (int) ceil( $total / $per );
	if ( $pages < 2 ) {
		return '';
	}
	$o = 'Page: ';
	for ( $i = 1; $i <= $pages; $i++ ) {
		$o .= $i === $pg ? '<strong>' . $i . '</strong> ' : '<a href="' . esc_url( usucger_admin_url( 'usucger-datafix', array( 'tab' => $tab, 'pg' => $i ) ) ) . '">' . $i . '</a> ';
	}
	return $o;
}
