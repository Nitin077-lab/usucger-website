<?php
/**
 * wp-admin menu: USUCGER.
 *
 * @package usucger-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'admin_menu', function () {
	$pending = usucger_pending_counts();
	$badge   = $pending['total'] ? ' <span class="awaiting-mod"><span class="pending-count">' . (int) $pending['total'] . '</span></span>' : '';
	add_menu_page( 'USUCGER', 'USUCGER' . ( usucger_can_approve() ? $badge : '' ), 'edit_posts', 'usucger', 'usucger_page_dashboard', 'dashicons-admin-site-alt3', 3 );
	add_submenu_page( 'usucger', 'Dashboard', 'Dashboard', 'edit_posts', 'usucger', 'usucger_page_dashboard' );
	add_submenu_page( 'usucger', 'Review queue', 'Review queue' . ( usucger_can_approve() && $pending['content'] ? ' <span class="awaiting-mod">' . (int) $pending['content'] . '</span>' : '' ), 'edit_posts', 'usucger-review', 'usucger_page_review' );
	add_submenu_page( 'usucger', 'Members', 'Members', 'usucger_view_members', 'usucger-members', 'usucger_page_members' );
	add_submenu_page( 'usucger', 'Member universities', 'Universities', 'usucger_view_members', 'usucger-institutions', 'usucger_page_institutions' );
	add_submenu_page( 'usucger', 'Compose email', 'Compose email', 'usucger_compose', 'usucger-compose', 'usucger_page_compose' );
	add_submenu_page( 'usucger', 'Outbox', 'Outbox' . ( usucger_can_approve() && $pending['email'] ? ' <span class="awaiting-mod">' . (int) $pending['email'] . '</span>' : '' ), 'usucger_compose', 'usucger-outbox', 'usucger_page_outbox' );
	add_submenu_page( 'usucger', 'Email templates', 'Email templates', 'usucger_approve', 'usucger-templates', 'usucger_page_templates' );
	add_submenu_page( 'usucger', 'Renewals & cleanup', 'Renewals', 'usucger_manage', 'usucger-renewals', 'usucger_page_renewals' );
	add_submenu_page( 'usucger', 'Setup & import', 'Setup & import', 'manage_options', 'usucger-setup', 'usucger_page_setup' );
	add_submenu_page( 'usucger', 'USUCGER settings', 'Settings', 'manage_options', 'usucger-settings', 'usucger_page_settings' );
}, 9 );

function usucger_pending_counts() {
	global $wpdb;
	static $c = null;
	if ( null === $c ) {
		$bt      = Usucger_DB::t( 'batches' );
		$content = count( usucger_review_items() );
		$email   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $bt WHERE status = 'pending'" ); // phpcs:ignore WordPress.DB
		$c       = array( 'content' => $content, 'email' => $email, 'total' => $content + $email );
	}
	return $c;
}

add_action( 'admin_head', function () {
	$screen = get_current_screen();
	if ( ! $screen || false === strpos( $screen->id, 'usucger' ) ) {
		return;
	}
	?>
	<style>
	.usg-wrap{max-width:1180px}
	.usg-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;margin:14px 0 20px}
	.usg-stat{background:#fff;border:1px solid #dcdcde;border-radius:6px;padding:14px 16px;border-top:3px solid #C2410C}
	.usg-stat b{display:block;font-size:26px;line-height:1.1;color:#1d2327;font-weight:700}
	.usg-stat span{color:#50575e;font-size:12px}
	.usg-stat a{text-decoration:none}
	.usg-stat.warn{border-top-color:#dba617}.usg-stat.ok{border-top-color:#00a32a}.usg-stat.blue{border-top-color:#2271b1}
	.usg-cols{display:grid;grid-template-columns:1fr 1fr;gap:16px}
	@media(max-width:960px){.usg-cols{grid-template-columns:1fr}}
	.usg-card{background:#fff;border:1px solid #dcdcde;border-radius:6px;padding:14px 18px;margin-bottom:16px}
	.usg-card h2{margin:4px 0 10px;font-size:15px}
	.usg-card table{width:100%}
	.usg-pill{display:inline-block;padding:1px 8px;border-radius:10px;font-size:11px;font-weight:600;background:#f0f0f1;color:#50575e}
	.usg-pill.current,.usg-pill.done,.usg-pill.sent{background:#edfaef;color:#008a20}
	.usg-pill.lapsed,.usg-pill.pending,.usg-pill.queued{background:#fcf9e8;color:#996800}
	.usg-pill.former,.usg-pill.rejected,.usg-pill.failed,.usg-pill.cancelled{background:#fcf0f1;color:#b32d2e}
	.usg-pill.sending,.usg-pill.prospect,.usg-pill.draft{background:#f0f6fc;color:#2271b1}
	.usg-bars{display:flex;align-items:flex-end;gap:2px;height:60px;margin:6px 0}
	.usg-bars i{flex:1;background:#C2410C;opacity:.75;min-height:1px;border-radius:2px 2px 0 0}
	.usg-preview{border:1px solid #dcdcde;background:#F4F4F2;max-height:720px;overflow:auto}
	.usg-preview iframe{width:100%;height:700px;border:0;background:#F4F4F2}
	.usg-tags code{cursor:pointer;margin:2px;display:inline-block}
	.usg-filters{margin:10px 0}
	.usg-filters a{margin-right:10px}
	.usg-filters a.cur{font-weight:700;color:#1d2327}
	.usg-help{color:#50575e;max-width:820px}
	.usg-diff table.diff{width:100%}
	</style>
	<?php
} );

/** Shared: status pill. */
function usucger_pill( $s ) {
	return '<span class="usg-pill ' . esc_attr( $s ) . '">' . esc_html( $s ) . '</span>';
}
