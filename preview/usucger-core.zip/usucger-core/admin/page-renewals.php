<?php
/**
 * USUCGER → Renewals: reminder plan, lapsed-member cleanup, universities at risk.
 *
 * @package usucger-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function usucger_page_renewals() {
	$plan   = usucger_renewal_plan();
	$tpl    = usucger_email_templates();
	$c      = Usucger_Members::counts();
	$cands  = Usucger_Members::removal_candidates();
	$risk   = Usucger_Members::institutions_at_risk();
	$groups = array( 'not_renewed' => 'Not renewed', 'expiring' => 'Expiring soon' );
	?>
	<div class="wrap usg-wrap">
		<h1>Renewals &amp; cleanup</h1>
		<div class="usg-grid">
			<div class="usg-stat ok"><b><?php echo (int) $c['current']; ?></b><span>Current members</span></div>
			<div class="usg-stat warn"><a href="<?php echo esc_url( usucger_admin_url( 'usucger-members', array( 'status' => 'lapsed' ) ) ); ?>"><b><?php echo (int) $c['lapsed']; ?></b><span>Not renewed — reminder audience</span></a></div>
			<div class="usg-stat"><b><?php echo (int) count( $cands ); ?></b><span>Past the <?php echo (int) usucger_core_opt( 'grace_days' ); ?>-day grace period</span></div>
			<div class="usg-stat <?php echo $risk ? 'warn' : 'ok'; ?>"><b><?php echo (int) count( $risk ); ?></b><span>Universities with no paid member</span></div>
		</div>

		<div class="usg-card">
			<h2>1. Reminder plan</h2>
			<p class="usg-help">Each step creates an email on its date for the chosen group, using the template. Only people who still have not renewed on that day are included; anyone who opted out of renewal reminders is skipped. <?php echo usucger_core_opt( 'auto_queue_plan' ) ? '<strong>Scheduled reminders are sent automatically</strong> (Settings).' : 'Each scheduled reminder waits in the Outbox for your approval (you get an email).'; ?></p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="usucger_plan_save"><?php wp_nonce_field( 'usucger_plan_save' ); ?>
				<table class="widefat striped"><thead><tr><th>Date</th><th>Template</th><th>Group</th><th>Days (expiring)</th><th>Status</th><th>Remove</th></tr></thead><tbody>
				<?php foreach ( $plan as $i => $s ) : $done = ! empty( $s['batch'] ); ?>
					<tr>
						<td><input type="date" name="plan[<?php echo (int) $i; ?>][date]" value="<?php echo esc_attr( $s['date'] ); ?>" <?php disabled( $done ); ?>></td>
						<td><select name="plan[<?php echo (int) $i; ?>][template]" <?php disabled( $done ); ?>><?php foreach ( $tpl as $k => $t ) : ?><option value="<?php echo esc_attr( $k ); ?>" <?php selected( $s['template'], $k ); ?>><?php echo esc_html( $t['name'] ); ?></option><?php endforeach; ?></select></td>
						<td><select name="plan[<?php echo (int) $i; ?>][group]" <?php disabled( $done ); ?>><?php foreach ( $groups as $k => $l ) : ?><option value="<?php echo esc_attr( $k ); ?>" <?php selected( $s['group'], $k ); ?>><?php echo esc_html( $l ); ?></option><?php endforeach; ?></select></td>
						<td><input type="number" style="width:70px" name="plan[<?php echo (int) $i; ?>][days]" value="<?php echo (int) $s['days']; ?>" <?php disabled( $done ); ?>></td>
						<td><?php
						if ( $done ) {
							$b = usucger_batch( $s['batch'] );
							echo '<input type="hidden" name="plan[' . (int) $i . '][keep]" value="1">';
							echo $b ? '<a href="' . esc_url( usucger_admin_url( 'usucger-outbox', array( 'batch' => $b->id ) ) ) . '">' . usucger_pill( $b->status ) . ' ' . (int) $b->total . ' recipients</a>' : 'created'; // phpcs:ignore
						} else {
							echo 'Scheduled';
							echo ' · <a href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=usucger_plan_run&step=' . $i ), 'usucger_plan_run' ) ) . '">Create now</a>';
						}
						?></td>
						<td><input type="checkbox" name="plan[<?php echo (int) $i; ?>][remove]" value="1"></td>
					</tr>
				<?php endforeach; ?>
					<tr><td><input type="date" name="plan[new][date]"></td>
						<td><select name="plan[new][template]"><?php foreach ( $tpl as $k => $t ) : ?><option value="<?php echo esc_attr( $k ); ?>" <?php selected( 'renewal_reminder', $k ); ?>><?php echo esc_html( $t['name'] ); ?></option><?php endforeach; ?></select></td>
						<td><select name="plan[new][group]"><?php foreach ( $groups as $k => $l ) : ?><option value="<?php echo esc_attr( $k ); ?>"><?php echo esc_html( $l ); ?></option><?php endforeach; ?></select></td>
						<td><input type="number" style="width:70px" name="plan[new][days]" value="30"></td><td colspan="2"><em>Add a step</em></td></tr>
				</tbody></table>
				<p><button class="button button-primary">Save plan</button>
				<?php if ( ! $plan ) : ?> <button class="button" name="suggest" value="1">Use suggested plan (3 reminders, 30 days apart, starting next week)</button><?php endif; ?></p>
			</form>
		</div>

		<div class="usg-card" id="cleanup">
			<h2>2. Remove members who did not renew</h2>
			<p class="usg-help">People below were members in an earlier cycle, have not renewed, and their membership ended more than <?php echo (int) usucger_core_opt( 'grace_days' ); ?> days ago (change in Settings). Removing marks them as <em>former members</em>: they leave the public directory, the member map and member mailings. Their record, payment history in WooCommerce and email preferences are kept, and they return automatically if they pay again.</p>
			<?php if ( ! $cands ) : ?>
				<p><em>No one is past the grace period.</em></p>
			<?php else : ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return confirm('Remove the selected people from the directory and member mailings?')">
				<input type="hidden" name="action" value="usucger_cleanup"><?php wp_nonce_field( 'usucger_cleanup' ); ?>
				<table class="widefat striped"><thead><tr><td class="check-column"><input type="checkbox" checked onclick="document.querySelectorAll('.usg-rm').forEach(c=>c.checked=this.checked)"></td><th>Name</th><th>Email</th><th>Institution</th><th>Ended</th><th>Listed</th></tr></thead><tbody>
				<?php foreach ( $cands as $r ) : ?>
					<tr><th class="check-column"><input class="usg-rm" type="checkbox" name="ids[]" value="<?php echo (int) $r->id; ?>" checked></th><td><?php echo esc_html( trim( $r->first_name . ' ' . $r->last_name ) ); ?></td><td><?php echo esc_html( $r->email ); ?></td><td><?php echo esc_html( $r->institution ); ?></td><td><?php echo esc_html( $r->end_date ? $r->end_date : '—' ); ?></td><td><?php echo $r->in_directory ? 'Yes' : 'No'; ?></td></tr>
				<?php endforeach; ?>
				</tbody></table>
				<p><button class="button button-primary">Remove selected (<?php echo (int) count( $cands ); ?>)</button></p>
			</form>
			<?php endif; ?>
		</div>

		<div class="usg-card" id="risk">
			<h2>3. Member universities with no paid member</h2>
			<p class="usg-help">By-Laws Article III: each member institution must have a paid member serving as its contact person. These universities have no current member listed. Email the contact, or mark the university as former in <a href="<?php echo esc_url( usucger_admin_url( 'usucger-institutions' ) ); ?>">Universities</a>.</p>
			<?php if ( ! $risk ) : ?><p><em>All member universities have at least one current member.</em></p><?php else : ?>
			<table class="widefat striped"><thead><tr><th>University</th><th>State</th><th>Contact person</th><th>Contact email</th></tr></thead><tbody>
			<?php foreach ( $risk as $i ) : ?>
				<tr><td><a href="<?php echo esc_url( usucger_admin_url( 'usucger-institutions', array( 'edit' => $i->id ) ) ); ?>"><?php echo esc_html( $i->name ); ?></a></td><td><?php echo esc_html( $i->state ); ?></td><td><?php echo esc_html( $i->contact_name ); ?></td><td><?php echo esc_html( $i->contact_email ); ?></td></tr>
			<?php endforeach; ?>
			</tbody></table>
			<?php endif; ?>
		</div>
	</div>
	<?php
}

add_action( 'admin_post_usucger_plan_save', function () {
	usucger_check( 'usucger_plan_save', 'usucger_approve' );
	if ( ! empty( $_POST['suggest'] ) ) {
		usucger_renewal_plan_save( usucger_renewal_plan_suggest() );
		usucger_back( usucger_admin_url( 'usucger-renewals' ), 'Suggested plan added — adjust the dates if needed.' );
	}
	$old  = usucger_renewal_plan();
	$in   = isset( $_POST['plan'] ) ? (array) wp_unslash( $_POST['plan'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	$tpl  = usucger_email_templates();
	$plan = array();
	foreach ( $in as $i => $s ) {
		if ( ! empty( $s['remove'] ) ) {
			continue;
		}
		if ( 'new' !== $i && isset( $old[ $i ] ) && ! empty( $old[ $i ]['batch'] ) ) {
			$plan[] = $old[ $i ];
			continue;
		}
		if ( empty( $s['date'] ) || ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $s['date'] ) ) {
			continue;
		}
		$plan[] = array(
			'date'     => $s['date'],
			'template' => isset( $tpl[ $s['template'] ] ) ? $s['template'] : 'renewal_reminder',
			'group'    => 'expiring' === $s['group'] ? 'expiring' : 'not_renewed',
			'days'     => max( 1, (int) $s['days'] ),
			'batch'    => 0,
		);
	}
	usucger_renewal_plan_save( $plan );
	usucger_back( usucger_admin_url( 'usucger-renewals' ), 'Plan saved.' );
} );

add_action( 'admin_post_usucger_plan_run', function () {
	usucger_check( 'usucger_plan_run', 'usucger_approve' );
	$id = usucger_renewal_run_step( isset( $_GET['step'] ) ? (int) $_GET['step'] : -1 );
	usucger_back( $id ? usucger_admin_url( 'usucger-outbox', array( 'batch' => $id ) ) : usucger_admin_url( 'usucger-renewals' ), $id ? 'Reminder created.' : 'Could not create that step.' );
} );

add_action( 'admin_post_usucger_cleanup', function () {
	usucger_check( 'usucger_cleanup', 'usucger_manage' );
	$n = Usucger_Members::remove( isset( $_POST['ids'] ) ? (array) $_POST['ids'] : array(), 'lapsed_cleanup' ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	usucger_back( usucger_admin_url( 'usucger-renewals' ), sprintf( '%d people removed from the directory and member mailings.', $n ) );
} );
