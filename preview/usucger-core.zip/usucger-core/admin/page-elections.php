<?php
/**
 * USUCGER → Elections.
 *
 * @package usucger-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'admin_menu', function () {
	add_submenu_page( 'usucger', 'Elections', 'Elections', 'usucger_elections', 'usucger-elections', 'usucger_page_elections' );
	add_submenu_page( 'usucger', 'Email calendar', 'Email calendar', 'usucger_approve', 'usucger-calendar', 'usucger_page_calendar' );
}, 10 );

function usucger_check_icon( $lvl ) {
	return 'ok' === $lvl ? '<span style="color:#008a20">&#10004;</span>' : ( 'warn' === $lvl ? '<span style="color:#996800">&#9888;</span>' : '<span style="color:#b32d2e">&#10008;</span>' );
}

function usucger_page_elections() {
	$id = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0; // phpcs:ignore WordPress.Security.NonceVerification
	echo '<div class="wrap usg-wrap">';
	if ( isset( $_GET['new'] ) || ( $id && isset( $_GET['edit'] ) ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		usucger_election_form( $id ? usucger_election( $id ) : null );
	} elseif ( $id ) {
		usucger_election_detail( usucger_election( $id ) );
	} else {
		echo '<h1 class="wp-heading-inline">Elections</h1> <a class="page-title-action" href="' . esc_url( usucger_admin_url( 'usucger-elections', array( 'new' => 1 ) ) ) . '">New election</a>';
		echo '<p class="usg-help">Board elections follow the By-Laws: one ballot per paid member institution, cast by its delegate (or the one alternate the delegate names), with one junior and one senior vote. Use a "Yes / No question" for By-Law amendments (two-thirds of delegates voting) or dues changes.</p>';
		echo '<table class="widefat striped"><thead><tr><th>Election</th><th>Phase</th><th>Voting</th><th>Turnout</th></tr></thead><tbody>';
		$list = usucger_elections();
		if ( ! $list ) {
			echo '<tr><td colspan="4">No elections yet.</td></tr>';
		}
		foreach ( $list as $row ) {
			$e = usucger_election( $row->id );
			$t = usucger_turnout( $e->id );
			echo '<tr><td><strong><a href="' . esc_url( usucger_admin_url( 'usucger-elections', array( 'id' => $e->id ) ) ) . '">' . esc_html( $e->title ) . '</a></strong></td><td>' . esc_html( usucger_phase_labels()[ usucger_election_phase( $e ) ] ) . '</td><td>' . esc_html( usucger_fmt_date( $e->vote_open ) . ' – ' . usucger_fmt_date( $e->vote_close ) ) . '</td><td>' . (int) $t['voted'] . ' / ' . (int) $t['eligible'] . '</td></tr>';
		}
		echo '</tbody></table>';
	}
	echo '</div>';
}

function usucger_election_form( $e ) {
	$y = (int) wp_date( 'Y' );
	$e = $e ? $e : (object) array( 'id' => 0, 'title' => $y . ' Board of Directors Election', 'kind' => 'board', 'question' => '', 'nom_open' => $y . '-09-30', 'nom_close' => $y . '-10-30', 'vote_open' => $y . '-11-01', 'vote_close' => $y . '-12-01', 'status' => 'draft', 'settings' => array( 'threshold' => 'plurality', 'auto_send' => 0 ) );
	?>
	<h1><?php echo $e->id ? 'Edit election' : 'New election'; ?></h1>
	<p><a href="<?php echo esc_url( usucger_admin_url( 'usucger-elections' ) ); ?>">&larr; Elections</a></p>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="usucger_election_save"><input type="hidden" name="id" value="<?php echo (int) $e->id; ?>"><?php wp_nonce_field( 'usucger_election_save' ); ?>
		<table class="form-table"><tbody>
			<tr><th>Title</th><td><input class="regular-text" name="title" required value="<?php echo esc_attr( $e->title ); ?>"></td></tr>
			<tr><th>Type</th><td><label><input type="radio" name="kind" value="board" <?php checked( $e->kind, 'board' ); ?>> Board election (junior + senior seat)</label><br><label><input type="radio" name="kind" value="question" <?php checked( $e->kind, 'question' ); ?>> Yes / No question (By-Law amendment, dues change …)</label></td></tr>
			<tr><th>Question text</th><td><textarea class="large-text" rows="4" name="question"><?php echo esc_textarea( $e->question ); ?></textarea><p class="description">Only for Yes / No questions. Art. IX: amendments must be circulated at least 30 days before the vote and discussed at a Council meeting.</p></td></tr>
			<tr><th>Passes with</th><td><select name="threshold"><option value="plurality" <?php selected( $e->settings['threshold'], 'plurality' ); ?>>Most votes (Board seats)</option><option value="majority" <?php selected( $e->settings['threshold'], 'majority' ); ?>>Simple majority</option><option value="two_thirds" <?php selected( $e->settings['threshold'], 'two_thirds' ); ?>>Two-thirds of delegates voting (By-Laws, dues)</option></select></td></tr>
			<tr><th>Nominations open</th><td><input type="date" name="nom_open" value="<?php echo esc_attr( $e->nom_open ); ?>"> <span class="description">By-Laws: announced by September 30</span></td></tr>
			<tr><th>Nominations close</th><td><input type="date" name="nom_close" value="<?php echo esc_attr( $e->nom_close ); ?>"> <span class="description">By-Laws: October 30</span></td></tr>
			<tr><th>Candidate statements due</th><td><input type="date" name="packet_due" value="<?php echo esc_attr( isset( $e->settings['packet_due'] ) ? $e->settings['packet_due'] : $e->nom_close ); ?>"> <span class="description">Statement, headshot and two-page CV. The request goes out 3 weeks before, a reminder 3 days before.</span></td></tr>
			<tr><th>Voting opens</th><td><input type="date" name="vote_open" required value="<?php echo esc_attr( $e->vote_open ); ?>"></td></tr>
			<tr><th>Voting closes</th><td><input type="date" name="vote_close" required value="<?php echo esc_attr( $e->vote_close ); ?>"> <span class="description">By-Laws: votes by December 1</span></td></tr>
			<tr><th>Nominating Committee</th><td><textarea class="large-text" rows="3" name="committee" placeholder="Luis Arboleda from University of Central Florida, Julie Paprocki from University of New Hampshire, John McCartney from University of California San Diego, fellow Board member Lisa Star from California State University Long Beach, and myself"><?php echo esc_textarea( isset( $e->settings['committee'] ) ? $e->settings['committee'] : '' ); ?></textarea><p class="description">Fills <code>{nominating_committee}</code> in the slate announcement.</p></td></tr>
			<tr><th>Send nominations to</th><td><input class="large-text" name="nom_contacts" value="<?php echo esc_attr( isset( $e->settings['nom_contacts'] ) ? $e->settings['nom_contacts'] : '' ); ?>" placeholder="me (amart@ucdavis.edu) and Lisa Star (lisa.star@csulb.edu)"></td></tr>
			<tr><th>Nominating Committee chair signature</th><td><textarea class="large-text" rows="6" name="signature" placeholder="Thanks, on behalf of the Nominating Committee,&#10;Alejandro&#10;Alejandro Martínez, Ph.D.&#10;Professor, Civil and Environmental Engineering&#10;University of California Davis&#10;amart@ucdavis.edu"><?php echo esc_textarea( isset( $e->settings['signature'] ) ? $e->settings['signature'] : '' ); ?></textarea><p class="description">Used for the slate announcement and the candidate-statement emails (first line = closing). Leave empty to use the site signature.</p></td></tr>
			<tr><th>Nominees answer by</th><td><input type="date" name="accept_due" value="<?php echo esc_attr( isset( $e->settings['accept_due'] ) ? $e->settings['accept_due'] : gmdate( 'Y-m-d', strtotime( $e->nom_open . ' -5 days' ) ) ); ?>"> <span class="description">Used in the “would you be willing to be nominated?” email (committee asks before the slate is announced).</span></td></tr>
			<tr><th>Election officer signature</th><td><textarea class="large-text" rows="3" name="officer_signature" placeholder="Best,&#10;Lisa"><?php echo esc_textarea( isset( $e->settings['officer_signature'] ) ? $e->settings['officer_signature'] : '' ); ?></textarea><p class="description">Used for the “willing to be nominated?”, candidate-statement and reminder emails to nominees.</p></td></tr>
			<tr><th>Scheduled emails</th><td><label><input type="checkbox" name="auto_send" value="1" <?php checked( ! empty( $e->settings['auto_send'] ) ); ?>> Send the scheduled election emails automatically (otherwise each waits for your approval)</label></td></tr>
			<tr><th>Status</th><td><select name="status"><option value="draft" <?php selected( $e->status, 'draft' ); ?>>Draft — not visible, no emails</option><option value="active" <?php selected( $e->status, 'active' ); ?>>Active — runs on the dates above</option></select></td></tr>
		</tbody></table>
		<p><button class="button button-primary">Save</button></p>
	</form>
	<?php
}

add_action( 'admin_post_usucger_election_save', function () {
	usucger_check( 'usucger_election_save', 'usucger_elections' );
	$p   = wp_unslash( $_POST );
	$id  = (int) $p['id'];
	$old = $id ? usucger_election( $id ) : null;
	$d   = function ( $k ) use ( $p ) {
		return preg_match( '/^\d{4}-\d{2}-\d{2}$/', isset( $p[ $k ] ) ? $p[ $k ] : '' ) ? $p[ $k ] : null;
	};
	$settings              = $old ? $old->settings : array( 'seats' => array( 'junior' => 1, 'senior' => 1 ), 'steps_done' => array() );
	$settings['threshold'] = in_array( $p['threshold'], array( 'plurality', 'majority', 'two_thirds' ), true ) ? $p['threshold'] : 'plurality';
	$settings['auto_send'] = empty( $p['auto_send'] ) ? 0 : 1;
	$settings['packet_due'] = $d( 'packet_due' ) ? $d( 'packet_due' ) : $d( 'nom_close' );
	$settings['committee']    = sanitize_textarea_field( $p['committee'] );
	$settings['nom_contacts'] = sanitize_text_field( $p['nom_contacts'] );
	$settings['signature']    = sanitize_textarea_field( $p['signature'] );
	$settings['officer_signature'] = sanitize_textarea_field( $p['officer_signature'] );
	$settings['accept_due']   = $d( 'accept_due' );
	$kind                  = 'question' === $p['kind'] ? 'question' : 'board';
	$data                  = array(
		'title'      => sanitize_text_field( $p['title'] ),
		'kind'       => $kind,
		'question'   => wp_kses_post( $p['question'] ),
		'nom_open'   => $d( 'nom_open' ),
		'nom_close'  => $d( 'nom_close' ),
		'vote_open'  => $d( 'vote_open' ),
		'vote_close' => $d( 'vote_close' ),
		'status'     => $old && 'certified' === $old->status ? 'certified' : ( 'active' === $p['status'] ? 'active' : 'draft' ),
		'settings'   => $settings,
	);
	$id = usucger_election_save( $data, $id );
	if ( ! $old ) {
		global $wpdb;
		if ( 'question' === $kind ) {
			foreach ( array( 'Yes', 'No' ) as $i => $opt ) {
				$wpdb->insert( Usucger_DB::t( 'candidates' ), array( 'election_id' => $id, 'position' => 'question', 'name' => $opt, 'status' => 'approved', 'sort' => $i, 'created' => current_time( 'mysql' ) ) );
			}
		}
		usucger_election_build_roll( $id );
		usucger_ensure_system_pages();
	}
	Usucger_DB::log( 'election_saved', 'election:' . $id, $data['title'] );
	usucger_back( usucger_admin_url( 'usucger-elections', array( 'id' => $id ) ), 'Saved.' );
} );

function usucger_election_detail( $e ) {
	if ( ! $e ) {
		echo '<p>Not found.</p>';
		return;
	}
	$view  = isset( $_GET['view'] ) ? sanitize_key( $_GET['view'] ) : 'overview'; // phpcs:ignore WordPress.Security.NonceVerification
	$phase = usucger_election_phase( $e );
	$t     = usucger_turnout( $e->id );
	$base  = array( 'id' => $e->id );
	echo '<p><a href="' . esc_url( usucger_admin_url( 'usucger-elections' ) ) . '">&larr; Elections</a></p>';
	echo '<h1>' . esc_html( $e->title ) . ' <span class="usg-pill">' . esc_html( usucger_phase_labels()[ $phase ] ) . '</span></h1>';
	echo '<p><a class="button" href="' . esc_url( usucger_admin_url( 'usucger-elections', $base + array( 'edit' => 1 ) ) ) . '">Edit dates &amp; settings</a> <a class="button" href="' . esc_url( usucger_election_page_url() ) . '" target="_blank">Public election page</a></p>';
	echo '<h2 class="nav-tab-wrapper">';
	foreach ( array( 'overview' => 'Overview', 'candidates' => 'board' === $e->kind ? 'Nominees' : 'Options', 'roll' => 'Voter roll', 'emails' => 'Emails', 'results' => 'Results' ) as $k => $l ) {
		echo '<a class="nav-tab' . ( $k === $view ? ' nav-tab-active' : '' ) . '" href="' . esc_url( usucger_admin_url( 'usucger-elections', $base + array( 'view' => $k ) ) ) . '">' . esc_html( $l ) . '</a>';
	}
	echo '</h2>';
	$nonce = wp_create_nonce( 'usucger_el_' . $e->id );
	$act   = function ( $op, $extra = array() ) use ( $e, $nonce ) {
		return esc_url( add_query_arg( array_merge( array( 'action' => 'usucger_el', 'op' => $op, 'e' => $e->id, '_wpnonce' => $nonce ), $extra ), admin_url( 'admin-post.php' ) ) );
	};

	if ( 'overview' === $view ) {
		echo '<div class="usg-grid"><div class="usg-stat"><b>' . (int) $t['eligible'] . '</b><span>Institutions eligible to vote</span></div><div class="usg-stat blue"><b>' . (int) $t['voted'] . '</b><span>Have voted (' . (int) $t['pct'] . '%)</span></div><div class="usg-stat"><b>' . (int) count( usucger_candidates( $e->id, array( 'approved' ) ) ) . '</b><span>On the ballot</span></div><div class="usg-stat warn"><b>' . (int) count( usucger_candidates( $e->id, array( 'nominated', 'accepted' ) ) ) . '</b><span>Nominations to review</span></div></div>';
		echo '<div class="usg-card"><h2>By-Laws checklist</h2><table class="widefat striped"><tbody>';
		foreach ( usucger_election_checks( $e ) as $c ) {
			echo '<tr><td style="width:28px">' . usucger_check_icon( $c[0] ) . '</td><td>' . esc_html( $c[1] ) . '</td></tr>'; // phpcs:ignore
		}
		echo '</tbody></table></div>';
		echo '<div class="usg-card"><h2>Timeline</h2><table class="widefat"><tbody>';
		foreach ( array( 'Nominations open' => $e->nom_open, 'Nominations close' => $e->nom_close, 'Voting opens' => $e->vote_open, 'Voting closes' => $e->vote_close ) as $l => $d ) {
			echo '<tr><td style="width:200px">' . esc_html( $l ) . '</td><td>' . esc_html( $d ? usucger_fmt_date( $d, 'l, F j, Y' ) : '—' ) . '</td></tr>';
		}
		echo '</tbody></table></div>';
	}

	if ( 'candidates' === $view ) {
		$cands = usucger_candidates( $e->id );
		echo '<p class="usg-help">The Nominating Committee adds nominees here (and members can nominate on the election page). Nominees are asked “would you be willing to be nominated?” — they accept with one button in the email or in their member area — then send their candidate statement, photo and CV. Only <strong>approved</strong> nominees appear on the ballot. The checks below apply the By-Laws; they are advice — you decide.</p>';
		$not_asked = count( Usucger_Members::recipients( 'candidates_not_asked', array( 'election' => $e->id ), 'official' ) );
		$missing   = count( Usucger_Members::recipients( 'candidates_packet', array( 'election' => $e->id ), 'official' ) );
		if ( 'board' === $e->kind ) {
			echo '<div class="usg-card"><h2>Candidate statements</h2><p>Due <strong>' . esc_html( usucger_fmt_date( usucger_packet_due( $e ), 'F j, Y' ) ) . '</strong>. ' . (int) $missing . ' nominee(s) still missing a complete statement, photo or CV; ' . (int) $not_asked . ' not asked yet.</p>';
			if ( $not_asked ) {
				echo '<a class="button button-primary" href="' . $act( 'packet_ask' ) . '">Ask ' . (int) $not_asked . ' nominee(s) for their statement</a> '; // phpcs:ignore
			}
			$unconf = count( Usucger_Members::recipients( 'candidates_unconfirmed', array( 'election' => $e->id ), 'official' ) );
			if ( $unconf ) {
				echo '<a class="button" href="' . $act( 'accept_ask' ) . '">Ask ' . (int) $unconf . ' nominee(s) “willing to be nominated?”</a> '; // phpcs:ignore
			}
			if ( $missing ) {
				echo '<a class="button" href="' . $act( 'packet_remind' ) . '">Remind the ' . (int) $missing . ' still missing</a>'; // phpcs:ignore
			}
			echo '<p class="description">Creates the email (personal form link for each nominee) and opens it for your approval. Accepted nominees who have not been asked yet also show on the desk.</p></div>';
		}
		echo '<table class="widefat striped"><thead><tr><th>Nominee</th><th>Seat</th><th>Rank / institution</th><th>By-Laws checks</th><th>Status</th><th></th></tr></thead><tbody>';
		if ( ! $cands ) {
			echo '<tr><td colspan="6">No nominees yet.</td></tr>';
		}
		foreach ( $cands as $c ) {
			$checks = usucger_candidate_checks( $c, $e );
			$pdf = $c->packet_url ? $c->packet_url : $c->cv_url;
			echo '<tr><td>' . ( $c->photo ? '<img src="' . esc_url( $c->photo ) . '" alt="" style="width:44px;height:44px;border-radius:50%;object-fit:cover;float:left;margin-right:8px">' : '' ) . '<strong>' . esc_html( $c->name ) . '</strong><br><small>' . esc_html( $c->email ) . '</small>' . ( $c->title_line ? '<br><small>' . esc_html( $c->title_line . ', ' . $c->department ) . '</small>' : '' ) . ( $c->experience || $c->vision ? '<details><summary>Statement</summary><strong>Experience</strong><br>' . nl2br( esc_html( $c->experience ) ) . '<br><strong>Vision and goals</strong><br>' . nl2br( esc_html( $c->vision ) ) . '</details>' : ( $c->statement ? '<details><summary>Statement</summary>' . nl2br( esc_html( $c->statement ) ) . '</details>' : '' ) ) . ( $pdf ? '<br><a href="' . esc_url( $pdf ) . '" target="_blank">PDF</a>' : '' ) . ( 'question' !== $c->position ? ' · <a href="' . esc_url( usucger_packet_url( $c ) ) . '" target="_blank">Statement form</a>' : '' ) . ( $c->nominator_note ? '<br><small><em>Nominator: ' . esc_html( $c->nominator_note ) . '</em></small>' : '' ) . '</td>';
			echo '<td>' . esc_html( ucfirst( $c->position ) ) . '</td><td>' . esc_html( $c->rank_title ) . '<br>' . esc_html( $c->institution ) . '</td><td>';
			foreach ( $checks as $ck ) {
				echo usucger_check_icon( $ck[0] ) . ' ' . esc_html( $ck[1] ) . '<br>'; // phpcs:ignore
			}
			$cm = usucger_cand_meta( $c );
			echo '</td><td>' . usucger_pill( $c->status ) . ( ! empty( $cm['accept_asked'] ) ? '<br><small>asked ' . esc_html( usucger_fmt_date( $cm['accept_asked'], 'M j' ) ) . '</small>' : '' ) . ( ! empty( $cm['accepted_at'] ) ? '<br><small>accepted ' . esc_html( mysql2date( 'M j', $cm['accepted_at'] ) ) . '</small>' : '' ) . ( ! empty( $cm['declined_at'] ) ? '<br><small>declined ' . esc_html( mysql2date( 'M j', $cm['declined_at'] ) ) . '</small>' : '' ) . '</td><td style="white-space:nowrap">'; // phpcs:ignore
			if ( 'approved' !== $c->status ) {
				echo '<a class="button button-primary" href="' . $act( 'cand_approve', array( 'c' => $c->id ) ) . '">Put on ballot</a> '; // phpcs:ignore
			} else {
				echo '<a class="button" href="' . $act( 'cand_unapprove', array( 'c' => $c->id ) ) . '">Remove from ballot</a> '; // phpcs:ignore
			}
			if ( 'question' !== $c->position ) {
				echo '<a class="button-link-delete" href="' . $act( 'cand_ineligible', array( 'c' => $c->id ) ) . '">Mark ineligible</a>'; // phpcs:ignore
			}
			echo '</td></tr>';
		}
		echo '</tbody></table>';
		if ( 'board' === $e->kind ) {
			?>
			<div class="usg-card" style="margin-top:16px"><h2>Add a nominee (nominating committee)</h2>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="usucger_el"><input type="hidden" name="op" value="cand_add"><input type="hidden" name="e" value="<?php echo (int) $e->id; ?>"><input type="hidden" name="_wpnonce" value="<?php echo esc_attr( $nonce ); ?>">
			<table class="form-table"><tbody>
				<tr><th>Name</th><td><input class="regular-text" name="name" required></td></tr>
				<tr><th>Email</th><td><input class="regular-text" type="email" name="email" required></td></tr>
				<tr><th>Institution</th><td><input class="regular-text" name="institution" required></td></tr>
				<tr><th>Rank</th><td><select name="rank"><?php foreach ( usucger_ranks() as $r => $x ) : ?><option><?php echo esc_html( $r ); ?></option><?php endforeach; ?></select></td></tr>
				<tr><th>Seat</th><td><select name="position"><option value="junior">Junior</option><option value="senior">Senior</option></select></td></tr>
				<tr><th>Statement</th><td><textarea class="large-text" rows="3" name="statement"></textarea></td></tr>
				<tr><th></th><td><label><input type="checkbox" name="ask" value="1" checked> Ask the nominee to confirm (you review the email before it goes)</label></td></tr>
			</tbody></table><p><button class="button button-primary">Add nominee</button></p></form></div>
			<?php
		}
	}

	if ( 'roll' === $view ) {
		$voters = usucger_voters( $e->id );
		echo '<p><a class="button button-primary" href="' . $act( 'roll' ) . '">Rebuild from current membership</a> <span class="description">Rebuilt automatically before each ballot email. Institutions that already voted are never changed.</span> <a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=usucger_roll_csv&e=' . (int) $e->id ), 'usucger_roll_csv' ) ) . '">Download roll (CSV)</a></p>'; // phpcs:ignore
		echo '<p class="usg-help">An institution can vote when it has at least one paid member (Art. III §6) and a delegate on file who is a current paid member. Delegates and alternates are set in <a href="' . esc_url( usucger_admin_url( 'usucger-institutions' ) ) . '">Universities</a> (the delegate\'s email is matched by name if it is missing).</p>';
		echo '<table class="widefat striped"><thead><tr><th>Institution</th><th>Delegate</th><th>Alternate</th><th>Eligible</th><th>Voted</th></tr></thead><tbody>';
		foreach ( $voters as $v ) {
			echo '<tr><td>' . esc_html( $v->institution ) . '</td><td>' . esc_html( $v->delegate_name ) . '<br><small>' . esc_html( $v->delegate_email ) . '</small></td><td>' . esc_html( $v->alternate_name ) . '<br><small>' . esc_html( $v->alternate_email ) . '</small></td><td>' . ( $v->eligible ? '<span style="color:#008a20">Yes</span>' : '<span style="color:#b32d2e">No</span> — ' . esc_html( $v->reason ) ) . '</td><td>' . ( $v->voted_at ? esc_html( mysql2date( 'M j, g:i a', $v->voted_at ) ) . ' <small>(' . esc_html( strtok( $v->voted_by, ':' ) ) . ')</small>' : '—' ) . '</td></tr>';
		}
		echo '</tbody></table>';
	}

	if ( 'emails' === $view ) {
		echo '<p class="usg-help">These emails are created automatically on their dates and wait in the Outbox for approval' . ( ! empty( $e->settings['auto_send'] ) ? ' — <strong>auto-send is on</strong>' : '' ) . '. Reminders go only to delegates and alternates of institutions that have not voted, and are skipped for anyone whose institution votes before the message goes out. Ballot emails carry each delegate\'s personal ballot link. Edit the wording in Email templates.</p>';
		echo '<table class="widefat striped"><thead><tr><th>Date</th><th>Email</th><th>Status</th><th></th></tr></thead><tbody>';
		foreach ( usucger_election_steps( $e ) as $k => $s ) {
			$bid = isset( $e->settings['steps_done'][ $k ] ) ? (int) $e->settings['steps_done'][ $k ] : 0;
			$b   = $bid ? usucger_batch( $bid ) : null;
			echo '<tr><td>' . esc_html( usucger_fmt_date( $s[0] ) ) . '</td><td>' . esc_html( $s[3] ) . '</td><td>' . ( $b ? '<a href="' . esc_url( usucger_admin_url( 'usucger-outbox', array( 'batch' => $b->id ) ) ) . '">' . usucger_pill( $b->status ) . ' ' . (int) $b->sent . '/' . (int) $b->total . '</a>' : 'Scheduled' ) . '</td><td>' . ( ! $b && 'active' === $e->status ? '<a class="button" href="' . $act( 'step', array( 'k' => $k ) ) . '">Create now</a>' : '' ) . '</td></tr>'; // phpcs:ignore
		}
		echo '</tbody></table>';
		if ( 'certified' === $e->status ) {
			echo '<p>The results announcement draft is in the <a href="' . esc_url( usucger_admin_url( 'usucger-outbox', array( 'status' => 'draft' ) ) ) . '">Outbox drafts</a>.</p>';
		}
	}

	if ( 'results' === $view ) {
		if ( ! in_array( $phase, array( 'closed', 'certified' ), true ) ) {
			echo '<div class="usg-card"><h2>Results are hidden until voting closes</h2><p>Turnout so far: <strong>' . (int) $t['voted'] . ' of ' . (int) $t['eligible'] . '</strong> institutions (' . (int) $t['pct'] . '%). No one — including the webmaster — sees the count before ' . esc_html( usucger_fmt_date( $e->vote_close, 'F j, Y' ) ) . '.</p></div>';
		} else {
			$tally = 'certified' === $phase && is_array( $e->results ) ? $e->results['tally'] : usucger_tally( $e );
			foreach ( $tally as $r ) {
				echo '<div class="usg-card"><h2>' . esc_html( $r['label'] ) . ' — ' . esc_html( $r['winner'] ? $r['winner'] : ( $r['tie'] ? 'TIE' : 'no votes' ) ) . '</h2>';
				if ( $r['tie'] ) {
					echo '<div class="notice notice-warning inline"><p><strong>Tie.</strong> By-Laws Art. VI §2: ties are broken by a secret ballot of the Board of Directors.</p></div>';
				}
				echo '<table class="widefat striped"><tbody>';
				foreach ( $r['rows'] as $row ) {
					echo '<tr><td>' . esc_html( $row['name'] ) . '</td><td style="width:120px">' . (int) $row['votes'] . '</td></tr>';
				}
				echo '<tr><td><em>Abstained</em></td><td>' . (int) $r['abstain'] . '</td></tr></tbody></table></div>';
			}
			echo '<p>Turnout: ' . (int) $t['voted'] . ' of ' . (int) $t['eligible'] . ' institutions.</p>';
			if ( 'closed' === $phase ) {
				echo '<p><a class="button button-primary button-large" href="' . $act( 'certify' ) . '" onclick="return confirm(\'Certify and publish these results?\')">Certify &amp; publish results</a> <span class="description">Publishes the results on the election page and prepares the announcement email (for approval).</span></p>'; // phpcs:ignore
			}
		}
	}
}

add_action( 'admin_post_usucger_el', function () {
	$eid = isset( $_REQUEST['e'] ) ? (int) $_REQUEST['e'] : 0;
	check_admin_referer( 'usucger_el_' . $eid );
	if ( ! usucger_can_run_elections() ) {
		wp_die( 'Not allowed.' );
	}
	global $wpdb;
	$e   = usucger_election( $eid );
	$op  = sanitize_key( $_REQUEST['op'] );
	$ct  = Usucger_DB::t( 'candidates' );
	$cid = isset( $_REQUEST['c'] ) ? (int) $_REQUEST['c'] : 0;
	$go  = function ( $view, $msg, $type = 'success' ) use ( $eid ) {
		usucger_back( usucger_admin_url( 'usucger-elections', array( 'id' => $eid, 'view' => $view ) ), $msg, $type );
	};
	switch ( $op ) {
		case 'cand_approve':
			$wpdb->update( $ct, array( 'status' => 'approved' ), array( 'id' => $cid ) );
			Usucger_DB::log( 'nominee_approved', 'election:' . $eid, $cid );
			$go( 'candidates', 'On the ballot.' );
			break;
		case 'cand_unapprove':
			$wpdb->update( $ct, array( 'status' => 'accepted' ), array( 'id' => $cid ) );
			$go( 'candidates', 'Removed from the ballot.' );
			break;
		case 'cand_ineligible':
			$wpdb->update( $ct, array( 'status' => 'ineligible' ), array( 'id' => $cid ) );
			Usucger_DB::log( 'nominee_ineligible', 'election:' . $eid, $cid );
			$go( 'candidates', 'Marked ineligible.' );
			break;
		case 'cand_add':
			$p = wp_unslash( $_POST );
			$wpdb->insert( $ct, array(
				'election_id' => $eid,
				'position'    => 'senior' === $p['position'] ? 'senior' : 'junior',
				'name'        => sanitize_text_field( $p['name'] ),
				'email'       => strtolower( sanitize_email( $p['email'] ) ),
				'institution' => sanitize_text_field( $p['institution'] ),
				'rank_title'  => isset( usucger_ranks()[ $p['rank'] ] ) ? $p['rank'] : '',
				'statement'   => sanitize_textarea_field( $p['statement'] ),
				'status'      => empty( $p['ask'] ) ? 'accepted' : 'nominated',
				'nominated_by' => get_current_user_id(),
				'created'     => current_time( 'mysql' ),
			) );
			$c = usucger_candidate( $wpdb->insert_id );
			if ( ! empty( $p['ask'] ) && is_email( $c->email ) ) {
				$bid = usucger_queue_accept_requests( $e, true );
				if ( $bid ) {
					usucger_back( usucger_admin_url( 'usucger-compose', array( 'batch' => $bid, 'preview' => 1 ) ), 'Nominee added. Review the “please confirm” email, then click Approve &amp; send.' );
				}
			}
			$go( 'candidates', 'Nominee added.' );
			break;
		case 'accept_ask':
			$bid = usucger_queue_accept_requests( $e, true );
			usucger_back( usucger_admin_url( 'usucger-compose', array( 'batch' => $bid, 'preview' => 1 ) ), 'Draft ready — check it, then click Approve &amp; send.' );
			break;
		case 'packet_ask':
		case 'packet_remind':
			$tpls = usucger_email_templates();
			$tk   = 'packet_ask' === $op ? 'election_packet_request' : 'election_packet_reminder';
			$id   = usucger_batch_save( array( 'kind' => 'official', 'group_key' => 'packet_ask' === $op ? 'candidates_not_asked' : 'candidates_packet', 'args' => array( 'election' => $eid ), 'template_key' => $tk, 'subject' => $tpls[ $tk ]['subject'], 'body' => $tpls[ $tk ]['body'], 'source' => 'election' ) );
			usucger_back( usucger_admin_url( 'usucger-compose', array( 'batch' => $id, 'preview' => 1 ) ), 'Draft ready — check it, then click Approve &amp; send.' );
			break;
		case 'roll':
			$n = usucger_election_build_roll( $eid );
			$go( 'roll', sprintf( 'Voter roll updated: %d eligible, %d not eligible.', $n['eligible'], $n['ineligible'] ) );
			break;
		case 'step':
			$id = usucger_election_run_step( $e, sanitize_key( $_REQUEST['k'] ) );
			$go( 'emails', $id ? 'Email created — it is in the Outbox for approval.' : 'Could not create it.' );
			break;
		case 'certify':
			$r = usucger_election_certify( $eid );
			$go( 'results', is_wp_error( $r ) ? $r->get_error_message() : 'Results certified and published.', is_wp_error( $r ) ? 'error' : 'success' );
			break;
	}
	$go( 'overview', '' );
} );

/* ================================================================= calendar */

function usucger_page_calendar() {
	$items = usucger_cal_items();
	$tpls  = usucger_email_templates();
	$users = get_users( array( 'capability' => 'usucger_compose', 'fields' => array( 'ID', 'display_name' ) ) );
	$edit  = isset( $_GET['edit'] ) ? sanitize_key( $_GET['edit'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	echo '<div class="wrap usg-wrap">';
	if ( $edit ) {
		$it = isset( $items[ $edit ] ) ? $items[ $edit ] : array( 'title' => '', 'due' => usucger_today(), 'template' => 'announcement', 'group' => 'current', 'args' => array(), 'lead' => 7, 'repeat' => 'yearly', 'owner' => 0, 'active' => 1 );
		echo '<h1>' . ( isset( $items[ $edit ] ) ? 'Edit key email' : 'Add key email' ) . '</h1><p><a href="' . esc_url( usucger_admin_url( 'usucger-calendar' ) ) . '">&larr; Email calendar</a></p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="usucger_cal_save"><input type="hidden" name="key" value="' . esc_attr( 'new' === $edit ? '' : $edit ) . '">';
		wp_nonce_field( 'usucger_cal_save' );
		echo '<table class="form-table"><tbody><tr><th>Title</th><td><input class="regular-text" name="title" required value="' . esc_attr( $it['title'] ) . '"></td></tr>';
		echo '<tr><th>Send on</th><td><input type="date" name="due" required value="' . esc_attr( $it['due'] ) . '"> <select name="repeat"><option value="yearly"' . selected( $it['repeat'], 'yearly', false ) . '>every year</option><option value="6months"' . selected( $it['repeat'], '6months', false ) . '>every 6 months</option><option value="none"' . selected( $it['repeat'], 'none', false ) . '>once</option></select></td></tr>';
		echo '<tr><th>Prepare draft</th><td><input type="number" min="0" max="60" style="width:70px" name="lead" value="' . (int) $it['lead'] . '"> days before</td></tr>';
		echo '<tr><th>Template</th><td><select name="template">';
		foreach ( $tpls as $k => $t ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $it['template'], $k, false ) . '>' . esc_html( $t['name'] ) . '</option>';
		}
		echo '</select></td></tr><tr><th>Send to</th><td><select name="group">';
		foreach ( Usucger_Members::groups() as $k => $g ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $it['group'], $k, false ) . '>' . esc_html( $g[0] ) . '</option>';
		}
		echo '</select></td></tr><tr><th>Owner</th><td><select name="owner"><option value="0">Webmaster (approvers)</option>';
		foreach ( $users as $u ) {
			echo '<option value="' . (int) $u->ID . '"' . selected( (int) $it['owner'], (int) $u->ID, false ) . '>' . esc_html( $u->display_name ) . '</option>';
		}
		echo '</select><p class="description">The owner is reminded together with the webmaster if it is late.</p></td></tr>';
		echo '<tr><th>Active</th><td><label><input type="checkbox" name="active" value="1"' . checked( ! empty( $it['active'] ), true, false ) . '> On</label></td></tr></tbody></table><p><button class="button button-primary">Save</button></p></form>';
	} else {
		echo '<h1 class="wp-heading-inline">Email calendar</h1> <a class="page-title-action" href="' . esc_url( usucger_admin_url( 'usucger-calendar', array( 'edit' => 'new' ) ) ) . '">Add key email</a>';
		echo '<p class="usg-help">Every planned email in one place. Key emails get a draft automatically a few days before their date; anything not sent by its date is flagged <strong>Overdue</strong> and the owner and webmaster are reminded every two days. Election steps and renewal reminders are listed too (manage them in Elections and Renewals).</p>';
		echo '<table class="widefat striped"><thead><tr><th>Date</th><th>Email</th><th>From</th><th>Owner</th><th>Status</th><th></th></tr></thead><tbody>';
		foreach ( usucger_comm_rows() as $r ) {
			$owner = $r['owner'] && get_userdata( $r['owner'] ) ? get_userdata( $r['owner'] )->display_name : 'Webmaster';
			$link  = 'Key email' === $r['source'] ? '<a href="' . esc_url( usucger_admin_url( 'usucger-calendar', array( 'edit' => $r['key'] ) ) ) . '">Edit</a>' : '';
			if ( $r['batch'] ) {
				$link .= ( $link ? ' · ' : '' ) . '<a href="' . esc_url( usucger_admin_url( 'usucger-outbox', array( 'batch' => $r['batch'] ) ) ) . '">Open email</a>';
			} elseif ( 'Key email' === $r['source'] && 'upcoming' === $r['status'] ) {
				$link .= ' · <a href="' . esc_url( admin_url( 'admin-post.php?action=usucger_desk_cal&key=' . rawurlencode( $r['key'] ) . '&_wpnonce=' . wp_create_nonce( 'usucger_desk_cal' ) ) ) . '">Draft now</a>';
			}
			$pill = array( 'overdue' => 'failed', 'sent' => 'done', 'awaiting' => 'pending', 'sending' => 'sending', 'draft' => 'draft', 'upcoming' => 'prospect', 'paused' => 'cancelled', 'skipped' => 'cancelled' );
			echo '<tr><td>' . esc_html( usucger_fmt_date( $r['date'] ) ) . '</td><td><strong>' . esc_html( $r['title'] ) . '</strong>' . ( 'none' !== $r['repeat'] && 'Key email' === $r['source'] ? ' <small>(' . esc_html( 'yearly' === $r['repeat'] ? 'every year' : 'every 6 months' ) . ')</small>' : '' ) . '</td><td>' . esc_html( $r['source'] ) . '</td><td>' . esc_html( $owner ) . '</td><td><span class="usg-pill ' . esc_attr( isset( $pill[ $r['status'] ] ) ? $pill[ $r['status'] ] : '' ) . '">' . esc_html( usucger_cal_status_label( $r['status'] ) ) . '</span></td><td>' . $link . '</td></tr>'; // phpcs:ignore
		}
		echo '</tbody></table>';
	}
	echo '</div>';
}

add_action( 'admin_post_usucger_cal_save', function () {
	usucger_check( 'usucger_cal_save', 'usucger_approve' );
	$p     = wp_unslash( $_POST );
	$items = usucger_cal_items();
	$key   = sanitize_key( $p['key'] );
	if ( ! $key ) {
		$key = sanitize_key( sanitize_title( $p['title'] ) ) . '_' . wp_rand( 100, 999 );
	}
	$old           = isset( $items[ $key ] ) ? $items[ $key ] : array( 'batch' => 0, 'last_reminder' => '', 'history' => array(), 'args' => array() );
	$items[ $key ] = array_merge( $old, array(
		'title'    => sanitize_text_field( $p['title'] ),
		'due'      => preg_match( '/^\d{4}-\d{2}-\d{2}$/', $p['due'] ) ? $p['due'] : usucger_today(),
		'repeat'   => in_array( $p['repeat'], array( 'yearly', '6months', 'none' ), true ) ? $p['repeat'] : 'yearly',
		'lead'     => max( 0, min( 60, (int) $p['lead'] ) ),
		'template' => sanitize_key( $p['template'] ),
		'group'    => sanitize_key( $p['group'] ),
		'owner'    => (int) $p['owner'],
		'active'   => empty( $p['active'] ) ? 0 : 1,
	) );
	usucger_cal_save( $items );
	usucger_back( usucger_admin_url( 'usucger-calendar' ), 'Saved.' );
} );

/* Voter roll as CSV for the Board records (who could vote and whether the institution voted — never how). */
add_action( 'admin_post_usucger_roll_csv', function () {
	usucger_check( 'usucger_roll_csv', 'usucger_elections' );
	$e = usucger_election( isset( $_GET['e'] ) ? (int) $_GET['e'] : 0 );
	if ( ! $e ) {
		wp_die( 'Not found.' );
	}
	nocache_headers();
	header( 'Content-Type: text/csv; charset=utf-8' );
	header( 'Content-Disposition: attachment; filename="usucger-voter-roll-' . (int) $e->id . '-' . gmdate( 'Y-m-d' ) . '.csv"' );
	$out = fopen( 'php://output', 'w' );
	fwrite( $out, "\xEF\xBB\xBF" );
	fputcsv( $out, array( 'institution', 'delegate', 'delegate_email', 'alternate', 'alternate_email', 'eligible', 'reason', 'voted_at' ) );
	foreach ( usucger_voters( $e->id ) as $v ) {
		fputcsv( $out, array_map( 'usucger_csv_safe', array( $v->institution, $v->delegate_name, $v->delegate_email, $v->alternate_name, $v->alternate_email, $v->eligible ? 'yes' : 'no', $v->reason, (string) $v->voted_at ) ) );
	}
	fclose( $out ); // phpcs:ignore
	Usucger_DB::log( 'roll_exported', 'election:' . $e->id );
	exit;
} );
