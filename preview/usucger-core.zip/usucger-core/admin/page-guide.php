<?php
/**
 * USUCGER → Board guide: how to do the everyday jobs, in plain language.
 *
 * @package usucger-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'admin_menu', function () {
	add_submenu_page( 'usucger', 'Board guide', 'Board guide', 'edit_posts', 'usucger-guide', 'usucger_page_guide' );
}, 13 );

function usucger_guide_sections() {
	$desk = usucger_desk_url();
	return array(
		'start'     => array( 'Signing in', array(
			'Use the same sign-in as members: <strong>Member area</strong> at the top of every page, or <a href="' . esc_url( wp_login_url() ) . '">' . esc_html( wp_login_url() ) . '</a>.',
			'Board members, officers, the President and the webmaster get a <strong>6-digit code by email</strong> after the password. Tick “Trust this browser” on your own computer to skip it for 30 days.',
			'You land on your <a href="' . esc_url( $desk ) . '">dashboard</a> (Board, President, Webmaster, Election officer or Membership Coordinator — depending on your role).',
		) ),
		'pages'     => array( 'Changing a page, position, conference or minutes', array(
			'Open the item from the dashboard (or <em>Pages</em> in the admin) and click <strong>Suggest changes</strong>. You edit a private copy; the live page does not change.',
			'Press <strong>Submit for review</strong>. The webmaster or President gets an email, compares your version with the live one and approves it — or returns it with a note.',
			'New positions, conferences, deadlines and minutes work the same way: <em>Add new</em> → fill in the boxes → Submit for review.',
			'Nothing you do can break the live site; earlier versions are kept under <em>Revisions</em>.',
		) ),
		'email'     => array( 'Sending an email to members', array(
			'<a href="' . esc_url( usucger_admin_url( 'usucger-compose' ) ) . '">Compose email</a> → choose who it goes to (all members, not renewed, university contacts, Board, a list you paste…) and a template.',
			'Pick how it is signed (USUCGER, you, or a custom line) and attach PDFs if needed. Use the preview to check the letterhead.',
			'<strong>Submit for approval.</strong> It is sent from the Outbox after the webmaster or President approves (election emails: the election officer). People who opted out of announcements are skipped automatically.',
			'Key dates (award call, travel grants, renewals, elections) are on the <a href="' . esc_url( usucger_admin_url( 'usucger-calendar' ) ) . '">email calendar</a>, which reminds the owner when one is due.',
		) ),
		'members'   => array( 'Members and renewals', array(
			'Membership comes from WooCommerce Memberships and syncs every day. <a href="' . esc_url( usucger_admin_url( 'usucger-members' ) ) . '">Members</a> shows who is current, not renewed, or former.',
			'Renewal reminders go only to people who have <em>not</em> renewed. Set the dates on <a href="' . esc_url( usucger_admin_url( 'usucger-renewals' ) ) . '">Renewals</a>.',
			'After the grace period, “Remove members who did not renew” takes them out of the directory, map and member mailings (their record is kept; paying again brings them back).',
			'<a href="' . esc_url( usucger_admin_url( 'usucger-datafix' ) ) . '">Data cleanup</a> lists delegates without a usable email, imported names to merge, institution changes to confirm and bounced addresses.',
		) ),
		'forms'     => array( 'Nominations, travel grants and position listings', array(
			'Award nominations and travel-grant applications arrive under <a href="' . esc_url( usucger_admin_url( 'usucger-submissions' ) ) . '">Submissions</a>, with their PDFs (visible only to signed-in Board members).',
			'Set a status (shortlisted, awarded…) and add committee notes; download a CSV for scoring.',
			'Position listings from the public form wait in the Review queue; the person who submitted it is emailed when it goes live.',
			'Winners are added under <em>Award recipients</em>: name, award, year, institution; tick “Feature” for this year’s winners at the top of the awards page.',
		) ),
		'elections' => array( 'Elections (By-Laws Art. VI)', array(
			'The election officer runs <a href="' . esc_url( usucger_admin_url( 'usucger-elections' ) ) . '">Elections</a>: dates, nominees, the “willing to be nominated?” emails, statement packets, the slate, ballots, reminders and results.',
			'Each member university votes once, through its delegate (or the alternate the delegate names in the member area). Eligibility is checked automatically against paid membership.',
			'Reminders go only to universities that have not voted. Results are certified by the officer; ties are flagged for the Board.',
		) ),
		'help'      => array( 'Help', array(
			'Locked out or no sign-in code? Email the webmaster at <a href="mailto:' . esc_attr( usucger_core_opt( 'contact_email' ) ) . '">' . esc_html( usucger_core_opt( 'contact_email' ) ) . '</a>.',
			'Everything you approve, send or change is listed in the activity log, so mistakes can be traced and undone.',
		) ),
	);
}

function usucger_page_guide() {
	echo '<div class="wrap usg-wrap"><h1>Board guide</h1><p class="usg-help">The everyday jobs on the USUCGER website. Five minutes to read; bookmark it.</p><div class="usg-card"><strong>Contents:</strong> ';
	$s = usucger_guide_sections();
	$l = array();
	foreach ( $s as $k => $sec ) {
		$l[] = '<a href="#g-' . esc_attr( $k ) . '">' . esc_html( $sec[0] ) . '</a>';
	}
	echo implode( ' · ', $l ) . '</div>'; // phpcs:ignore
	foreach ( $s as $k => $sec ) {
		echo '<div class="usg-card" id="g-' . esc_attr( $k ) . '"><h2>' . esc_html( $sec[0] ) . '</h2><ol>';
		foreach ( $sec[1] as $step ) {
			echo '<li style="margin-bottom:.5em">' . wp_kses_post( $step ) . '</li>';
		}
		echo '</ol></div>';
	}
	echo '</div>';
}
