<?php
/**
 * USUCGER → Compose email, Outbox, Email templates.
 *
 * @package usucger-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function usucger_batch_visible( $b ) {
	return $b && ( usucger_can_approve() || (int) $b->created_by === get_current_user_id() || ( usucger_is_election_batch( $b ) && usucger_can_run_elections() ) );
}

/** Approvers approve anything; election officers approve election emails. */
function usucger_can_approve_batch( $b ) {
	return usucger_can_approve() || ( usucger_is_election_batch( $b ) && usucger_can_run_elections() );
}

function usucger_preview_iframe( $html, $height = 700 ) {
	return '<div class="usg-preview"><iframe sandbox="" style="height:' . (int) $height . 'px" srcdoc="' . esc_attr( $html ) . '"></iframe></div>';
}

function usucger_group_label( $b ) {
	$g = Usucger_Members::groups();
	$l = isset( $g[ $b->group_key ] ) ? $g[ $b->group_key ][0] : $b->group_key;
	if ( 'expiring' === $b->group_key ) {
		$l .= ' (' . (int) ( isset( $b->args['days'] ) ? $b->args['days'] : 30 ) . ' days)';
	}
	if ( 'tag' === $b->group_key ) {
		$l .= ': ' . ( isset( $b->args['tag'] ) ? $b->args['tag'] : '' );
	}
	return $l;
}

/* ================================================================== compose */

add_action( 'admin_enqueue_scripts', function ( $hook ) {
	if ( false !== strpos( $hook, 'usucger-compose' ) ) {
		wp_enqueue_media();
	}
} );

function usucger_page_compose() {
	$id  = isset( $_GET['batch'] ) ? (int) $_GET['batch'] : 0; // phpcs:ignore WordPress.Security.NonceVerification
	$b   = $id ? usucger_batch( $id ) : null;
	$tpl = usucger_email_templates();
	if ( $b && ( ! usucger_batch_visible( $b ) || ! in_array( $b->status, array( 'draft', 'rejected' ), true ) ) ) {
		wp_safe_redirect( usucger_admin_url( 'usucger-outbox', array( 'batch' => $id ) ) );
		echo '<script>location.href=' . wp_json_encode( usucger_admin_url( 'usucger-outbox', array( 'batch' => $id ) ) ) . '</script>';
		return;
	}
	if ( ! $b ) {
		$tk = isset( $_GET['tpl'] ) && isset( $tpl[ $_GET['tpl'] ] ) ? sanitize_key( $_GET['tpl'] ) : 'announcement'; // phpcs:ignore WordPress.Security.NonceVerification
		$t  = isset( $tpl[ $tk ] ) ? $tpl[ $tk ] : array( 'kind' => 'news', 'subject' => '', 'body' => '' );
		$b  = (object) array(
			'id'           => 0,
			'kind'         => $t['kind'],
			'group_key'    => isset( $_GET['group'] ) ? sanitize_key( $_GET['group'] ) : ( 'renewal' === $t['kind'] ? 'not_renewed' : 'current' ), // phpcs:ignore WordPress.Security.NonceVerification
			'args'         => array(),
			'template_key' => $tk,
			'subject'      => $t['subject'],
			'body'         => $t['body'],
			'status'       => 'draft',
			'note'         => '',
		);
		if ( ! empty( $_GET['from_members'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			$b->args['emails'] = (string) get_transient( 'usucger_compose_emails_' . get_current_user_id() );
		}
	}
	$groups  = Usucger_Members::groups();
	$preview = isset( $_GET['preview'] ) && $b->id; // phpcs:ignore WordPress.Security.NonceVerification
	?>
	<div class="wrap usg-wrap">
		<h1><?php echo $b->id ? 'Edit email draft' : 'Compose email'; ?></h1>
		<?php if ( 'rejected' === $b->status && $b->note ) : ?>
			<div class="notice notice-warning inline"><p><strong>Returned by the approver:</strong> <?php echo esc_html( $b->note ); ?></p></div>
		<?php endif; ?>
		<p class="usg-help">Each person gets their own copy, with their name and details filled in. People who unsubscribed are left out automatically. <?php echo usucger_can_approve() ? 'As an approver, you can send directly.' : 'When you submit, the webmaster reviews the email and recipient list before anything is sent.'; ?></p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="usgCompose">
			<input type="hidden" name="action" value="usucger_compose">
			<input type="hidden" name="batch" value="<?php echo (int) $b->id; ?>">
			<?php wp_nonce_field( 'usucger_compose' ); ?>
			<table class="form-table"><tbody>
				<tr><th>Start from template</th><td>
					<select name="template_key" id="usgTpl">
						<?php foreach ( $tpl as $k => $t ) : ?><option value="<?php echo esc_attr( $k ); ?>" <?php selected( $b->template_key, $k ); ?>><?php echo esc_html( $t['name'] ); ?></option><?php endforeach; ?>
					</select> <button type="button" class="button" id="usgTplLoad">Load template text</button>
				</td></tr>
				<tr><th>Type</th><td>
					<label><input type="radio" name="kind" value="news" <?php checked( $b->kind, 'news' ); ?>> Announcement</label> &nbsp;
					<label><input type="radio" name="kind" value="renewal" <?php checked( $b->kind, 'renewal' ); ?>> Membership / renewal notice</label> &nbsp;
					<?php if ( usucger_can_approve() || 'official' === $b->kind ) : ?><label><input type="radio" name="kind" value="official" <?php checked( $b->kind, 'official' ); ?>> Official governance notice (elections, annual meeting — sent even to people who unsubscribed from announcements)</label><?php endif; ?>
					<p class="description">Decides which opt-out applies and the footer ("Unsubscribe from announcements" vs "Stop renewal reminders").</p>
				</td></tr>
				<tr><th>Send to</th><td>
					<select name="group_key" id="usgGroup">
						<?php foreach ( $groups as $k => $g ) : ?><option value="<?php echo esc_attr( $k ); ?>" <?php selected( $b->group_key, $k ); ?>><?php echo esc_html( $g[0] ); ?></option><?php endforeach; ?>
					</select>
					<div class="usg-g usg-g-expiring" style="margin-top:6px">Ending within <input type="number" name="days" min="1" max="400" value="<?php echo (int) ( isset( $b->args['days'] ) ? $b->args['days'] : 30 ); ?>" style="width:70px"> days</div>
					<div class="usg-g usg-g-tag" style="margin-top:6px">Tag <input type="text" name="tag" value="<?php echo esc_attr( isset( $b->args['tag'] ) ? $b->args['tag'] : '' ); ?>"></div>
					<div class="usg-g usg-g-custom" style="margin-top:6px"><textarea name="emails" rows="4" class="large-text" placeholder="one email per line (or separated by commas)"><?php echo esc_textarea( isset( $b->args['emails'] ) ? $b->args['emails'] : '' ); ?></textarea></div>
				</td></tr>
				<tr><th>Subject</th><td><input type="text" class="large-text" name="subject" id="usgSubject" required value="<?php echo esc_attr( $b->subject ); ?>"></td></tr>
				<?php
				$sign  = isset( $b->args['sign'] ) ? $b->args['sign'] : 'site';
				$atts  = isset( $b->args['attachments'] ) ? array_filter( array_map( 'intval', (array) $b->args['attachments'] ) ) : array();
				?>
				<tr><th>Sign as</th><td>
					<select name="sign" id="usgSign" onchange="document.getElementById('usgSignText').style.display=this.value==='custom'?'':'none'">
						<option value="site" <?php selected( $sign, 'site' ); ?>><?php echo esc_html( usucger_core_opt( 'signer_name' ) . ', ' . usucger_core_opt( 'signer_title' ) ); ?> (default)</option>
						<option value="me" <?php selected( $sign, 'me' ); ?>>Me — <?php echo esc_html( wp_get_current_user()->display_name ); ?> (name, title, institution from my profile)</option>
						<option value="custom" <?php selected( $sign, 'custom' ); ?>>Custom signature…</option>
					</select>
					<textarea id="usgSignText" name="sign_text" rows="6" class="large-text" style="margin-top:6px;<?php echo 'custom' === $sign ? '' : 'display:none'; ?>" placeholder="Thanks, on behalf of the Nominating Committee,&#10;Alejandro&#10;Alejandro Martínez, Ph.D.&#10;Professor, Civil and Environmental Engineering&#10;University of California Davis&#10;amart@ucdavis.edu"><?php echo esc_textarea( isset( $b->args['sign_text'] ) ? $b->args['sign_text'] : '' ); ?></textarea>
					<p class="description">Fills the <code>{signature}</code> tag. Custom: first line is the closing (e.g. "Thanks,"), the rest prints small; emails and links become clickable.</p>
				</td></tr>
				<tr><th>Attachments</th><td>
					<input type="hidden" name="attachments" id="usgAtt" value="<?php echo esc_attr( implode( ',', $atts ) ); ?>">
					<span id="usgAttList"><?php foreach ( $atts as $aid ) { echo '<span class="usg-pill" style="margin-right:6px">' . esc_html( wp_basename( (string) get_attached_file( $aid ) ) ) . '</span>'; } ?></span>
					<button type="button" class="button" id="usgAttPick">Add / change files</button> <button type="button" class="button-link" onclick="document.getElementById('usgAtt').value='';document.getElementById('usgAttList').innerHTML=''">Remove all</button>
					<p class="description">e.g. the award call PDF. Keep the total under about 5 MB — every recipient receives a copy.</p>
				</td></tr>
				<tr><th>Message</th><td>
					<p class="usg-tags">Insert: <?php foreach ( usucger_merge_tags() as $tag => $label ) : ?><code title="<?php echo esc_attr( $label ); ?>" data-tag="<?php echo esc_attr( $tag ); ?>"><?php echo esc_html( $tag ); ?></code><?php endforeach; ?></p>
					<?php wp_editor( $b->body, 'usgbody', array( 'textarea_name' => 'body', 'textarea_rows' => 18, 'media_buttons' => true ) ); ?>
				</td></tr>
			</tbody></table>
			<p>
				<button class="button" name="op" value="save">Save draft</button>
				<button class="button" name="op" value="preview">Save &amp; preview</button>
				<button class="button" name="op" value="test">Send a test to me (<?php echo esc_html( wp_get_current_user()->user_email ); ?>)</button>
				<button class="button button-primary" name="op" value="submit" onclick="return confirm('<?php echo usucger_can_approve_batch( $b ) ? 'Approve and start sending now?' : 'Submit this email for approval?'; ?>')"><?php echo usucger_can_approve_batch( $b ) ? 'Approve &amp; send' : 'Submit for approval'; ?></button>
			</p>
		</form>
		<?php
		if ( $preview ) {
			$rec = usucger_batch_recipients( $b );
			echo '<h2>Preview — ' . count( $rec ) . ' recipient' . ( 1 === count( $rec ) ? '' : 's' ) . '</h2>';
			if ( $rec ) {
				list( $s, $h ) = usucger_render_email( $b->subject, $b->body, $rec[0], $b->kind, (array) $b->args );
				echo '<p><strong>Subject:</strong> ' . esc_html( $s ) . ' <span class="description">(shown as ' . esc_html( $rec[0]->email ) . ' will see it)</span></p>';
				echo usucger_preview_iframe( $h ); // phpcs:ignore
				echo '<details style="margin-top:10px"><summary>Recipient list</summary><p>' . esc_html( implode( ', ', array_map( function ( $r ) {
					return trim( $r->first_name . ' ' . $r->last_name ) . ' <' . $r->email . '>';
				}, array_slice( $rec, 0, 600 ) ) ) ) . '</p></details>';
			} else {
				echo '<p>No recipients in this group.</p>';
			}
		}
		?>
	</div>
	<script>
	(function(){
		var T=<?php echo wp_json_encode( $tpl ); ?>;
		function grp(){var v=document.getElementById('usgGroup').value;document.querySelectorAll('.usg-g').forEach(function(e){e.style.display=e.classList.contains('usg-g-'+v)?'':'none'});}
		document.getElementById('usgGroup').addEventListener('change',grp);grp();
		var ap=document.getElementById('usgAttPick');
		if(ap&&window.wp&&wp.media){ap.addEventListener('click',function(){var f=wp.media({title:'Attach files',multiple:true});f.on('select',function(){var s=f.state().get('selection').toJSON();document.getElementById('usgAtt').value=s.map(function(x){return x.id}).join(',');document.getElementById('usgAttList').innerHTML=s.map(function(x){return '<span class="usg-pill" style="margin-right:6px">'+x.filename+'</span>'}).join('');});f.open();});}
		document.getElementById('usgTplLoad').addEventListener('click',function(){
			var k=document.getElementById('usgTpl').value,t=T[k];if(!t)return;
			if(!confirm('Replace the subject and message with this template?'))return;
			document.getElementById('usgSubject').value=t.subject;
			document.querySelector('input[name=kind][value='+t.kind+']').checked=true;
			if(window.tinymce&&tinymce.get('usgbody')&&!tinymce.get('usgbody').isHidden()){tinymce.get('usgbody').setContent(t.body);}else{document.getElementById('usgbody').value=t.body;}
		});
		document.querySelectorAll('.usg-tags code').forEach(function(c){c.addEventListener('click',function(){
			var tag=c.dataset.tag;
			if(window.tinymce&&tinymce.get('usgbody')&&!tinymce.get('usgbody').isHidden()){tinymce.get('usgbody').execCommand('mceInsertContent',false,tag);}
			else{var ta=document.getElementById('usgbody');var p=ta.selectionStart||ta.value.length;ta.value=ta.value.slice(0,p)+tag+ta.value.slice(p);}
		});});
	})();
	</script>
	<?php
}

add_action( 'admin_post_usucger_compose', function () {
	usucger_check( 'usucger_compose', 'usucger_compose' );
	$p   = wp_unslash( $_POST );
	$id  = (int) $p['batch'];
	$old = $id ? usucger_batch( $id ) : null;
	if ( $old && ( ! usucger_batch_visible( $old ) || ! in_array( $old->status, array( 'draft', 'rejected' ), true ) ) ) {
		wp_die( 'This email can no longer be edited.' );
	}
	$groups = Usucger_Members::groups();
	$group  = isset( $groups[ $p['group_key'] ] ) ? $p['group_key'] : 'current';
	$body   = current_user_can( 'unfiltered_html' ) ? $p['body'] : wp_kses_post( $p['body'] );
	$data   = array(
		'kind'         => in_array( $p['kind'], array( 'renewal', 'official' ), true ) && ( 'official' !== $p['kind'] || usucger_can_approve() || ( $old && 'official' === $old->kind ) ) ? $p['kind'] : 'news',
		'group_key'    => $group,
		'args'         => array_merge( $old ? (array) $old->args : array(), array(
			'days'        => (int) $p['days'],
			'tag'         => sanitize_title( $p['tag'] ),
			'emails'      => sanitize_textarea_field( $p['emails'] ),
			'sign'        => in_array( $p['sign'], array( 'site', 'me', 'custom' ), true ) ? $p['sign'] : 'site',
			'sign_text'   => sanitize_textarea_field( $p['sign_text'] ),
			'sign_user'   => 'me' === $p['sign'] ? get_current_user_id() : ( $old && isset( $old->args['sign_user'] ) ? (int) $old->args['sign_user'] : 0 ),
			'attachments' => array_values( array_filter( array_map( 'intval', explode( ',', (string) $p['attachments'] ) ), function ( $id ) {
				return 'attachment' === get_post_type( $id );
			} ) ),
		) ),
		'template_key' => sanitize_key( $p['template_key'] ),
		'subject'      => sanitize_text_field( $p['subject'] ),
		'body'         => $body,
		'status'       => 'draft',
	);
	$id = usucger_batch_save( $data, $id );
	$op = sanitize_key( $p['op'] );
	if ( 'test' === $op ) {
		$ok = usucger_send_test( usucger_batch( $id ), wp_get_current_user()->user_email );
		usucger_back( usucger_admin_url( 'usucger-compose', array( 'batch' => $id ) ), $ok ? 'Test sent to ' . esc_html( wp_get_current_user()->user_email ) . '.' : 'The test could not be sent — check the email (SMTP) setup.', $ok ? 'success' : 'error' );
	}
	if ( 'submit' === $op ) {
		$r = usucger_batch_submit( $id );
		if ( is_wp_error( $r ) ) {
			usucger_back( usucger_admin_url( 'usucger-compose', array( 'batch' => $id, 'preview' => 1 ) ), $r->get_error_message(), 'error' );
		}
		$b = usucger_batch( $id );
		usucger_back( usucger_admin_url( 'usucger-outbox', array( 'batch' => $id ) ), 'sending' === $b->status ? 'Approved — sending has started (' . (int) $b->total . ' recipients).' : 'Submitted for approval. The webmaster has been notified.' );
	}
	usucger_back( usucger_admin_url( 'usucger-compose', array( 'batch' => $id, 'preview' => 'preview' === $op ? 1 : null ) ), 'Draft saved.' );
} );

/* =================================================================== outbox */

function usucger_page_outbox() {
	global $wpdb;
	$id = isset( $_GET['batch'] ) ? (int) $_GET['batch'] : 0; // phpcs:ignore WordPress.Security.NonceVerification
	if ( $id ) {
		usucger_outbox_detail( $id );
		return;
	}
	$bt     = Usucger_DB::t( 'batches' );
	$status = isset( $_GET['status'] ) ? sanitize_key( $_GET['status'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	$where  = '1=1';
	if ( $status ) {
		$where .= $wpdb->prepare( ' AND status = %s', $status );
	}
	if ( ! usucger_can_approve() ) {
		$where .= usucger_can_run_elections() ? $wpdb->prepare( " AND (created_by = %d OR source = 'election' OR group_key IN ('voters_all','voters_pending','candidates','candidates_packet','candidates_not_asked'))", get_current_user_id() ) : $wpdb->prepare( ' AND created_by = %d', get_current_user_id() );
	}
	$rows = $wpdb->get_results( "SELECT * FROM $bt WHERE $where ORDER BY id DESC LIMIT 200" ); // phpcs:ignore WordPress.DB
	?>
	<div class="wrap usg-wrap">
		<h1 class="wp-heading-inline">Outbox</h1> <a class="page-title-action" href="<?php echo esc_url( usucger_admin_url( 'usucger-compose' ) ); ?>">Compose</a>
		<?php if ( usucger_can_approve() ) : ?> <a class="page-title-action" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=usucger_tick_now' ), 'usucger_tick_now' ) ); ?>">Send next batch now</a><?php endif; ?>
		<p class="usg-help">Approved emails go out automatically, <?php echo (int) usucger_core_opt( 'batch_size' ); ?> per minute, so the mail server is not flooded. Failed sends are retried up to 3 times.</p>
		<div class="usg-filters">
			<?php foreach ( array( '' => 'All', 'pending' => 'Waiting for approval', 'sending' => 'Sending', 'done' => 'Sent', 'draft' => 'Drafts', 'rejected' => 'Returned', 'cancelled' => 'Cancelled' ) as $k => $l ) : ?>
				<a class="<?php echo $k === $status ? 'cur' : ''; ?>" href="<?php echo esc_url( usucger_admin_url( 'usucger-outbox', $k ? array( 'status' => $k ) : array() ) ); ?>"><?php echo esc_html( $l ); ?></a>
			<?php endforeach; ?>
		</div>
		<table class="widefat striped"><thead><tr><th>Subject</th><th>To</th><th>By</th><th>Created</th><th>Status</th><th>Sent / total</th></tr></thead><tbody>
		<?php if ( ! $rows ) : ?><tr><td colspan="6">Nothing here yet.</td></tr><?php endif; ?>
		<?php foreach ( $rows as $r ) : $r->args = (array) json_decode( (string) $r->group_args, true ); $u = get_userdata( $r->created_by ); ?>
			<tr>
				<td><strong><a href="<?php echo esc_url( usucger_admin_url( 'usucger-outbox', array( 'batch' => $r->id ) ) ); ?>"><?php echo esc_html( usucger_merge_static( $r->subject, $r->args ) ); ?></a></strong><?php echo 'renewal_plan' === $r->source ? ' <span class="usg-pill">scheduled</span>' : ''; ?></td>
				<td><?php echo esc_html( usucger_group_label( $r ) ); ?></td>
				<td><?php echo esc_html( $u ? $u->display_name : 'system' ); ?></td>
				<td><?php echo esc_html( mysql2date( 'M j, Y g:i a', $r->created ) ); ?></td>
				<td><?php echo usucger_pill( $r->status ); // phpcs:ignore ?></td>
				<td><?php echo (int) $r->sent . ' / ' . (int) $r->total . ( $r->failed ? ' <span style="color:#b32d2e">(' . (int) $r->failed . ' failed)</span>' : '' ); // phpcs:ignore ?></td>
			</tr>
		<?php endforeach; ?>
		</tbody></table>
	</div>
	<?php
}

function usucger_outbox_detail( $id ) {
	global $wpdb;
	$b = usucger_batch( $id );
	if ( ! usucger_batch_visible( $b ) ) {
		echo '<div class="wrap"><p>Not found.</p></div>';
		return;
	}
	$creator  = get_userdata( $b->created_by );
	$approver = $b->approved_by ? get_userdata( $b->approved_by ) : null;
	$ot       = Usucger_DB::t( 'outbox' );
	$nonce    = wp_create_nonce( 'usucger_batch_' . $id );
	$act      = function ( $op ) use ( $id, $nonce ) {
		return esc_url( admin_url( 'admin-post.php?action=usucger_batch&op=' . $op . '&batch=' . $id . '&_wpnonce=' . $nonce ) );
	};
	?>
	<div class="wrap usg-wrap">
		<p><a href="<?php echo esc_url( usucger_admin_url( 'usucger-outbox' ) ); ?>">&larr; Outbox</a></p>
		<h1><?php echo esc_html( usucger_merge_static( $b->subject, $b->args ) ); ?> <?php echo usucger_pill( $b->status ); // phpcs:ignore ?></h1>
		<table class="widefat" style="max-width:820px"><tbody>
			<tr><th style="width:170px">To</th><td><?php echo esc_html( usucger_group_label( $b ) ); ?></td></tr>
			<tr><th>Type</th><td><?php echo 'renewal' === $b->kind ? 'Membership / renewal notice' : ( 'official' === $b->kind ? 'Official governance notice' : 'Announcement' ); ?></td></tr>
			<tr><th>Written by</th><td><?php echo esc_html( $creator ? $creator->display_name : 'Renewal plan (automatic)' ); ?>, <?php echo esc_html( mysql2date( 'M j, Y g:i a', $b->created ) ); ?></td></tr>
			<?php if ( $approver ) : ?><tr><th>Approved by</th><td><?php echo esc_html( $approver->display_name . ( usucger_approver_label( $approver->ID ) ? ' (' . usucger_approver_label( $approver->ID ) . ')' : '' ) . ', ' . mysql2date( 'M j, Y g:i a', $b->approved_at ) ); ?></td></tr><?php endif; ?>
			<tr><th>Progress</th><td><?php echo (int) $b->sent; ?> sent of <?php echo (int) $b->total; ?><?php echo $b->failed ? ', <span style="color:#b32d2e">' . (int) $b->failed . ' failed</span>' : ''; ?></td></tr>
			<?php if ( $b->note ) : ?><tr><th>Note</th><td><?php echo esc_html( $b->note ); ?></td></tr><?php endif; ?>
		</tbody></table>
		<p style="margin-top:14px">
		<?php if ( in_array( $b->status, array( 'draft', 'rejected' ), true ) ) : ?>
			<a class="button button-primary" href="<?php echo esc_url( usucger_admin_url( 'usucger-compose', array( 'batch' => $id ) ) ); ?>">Edit</a>
		<?php endif; ?>
		<?php if ( 'pending' === $b->status && usucger_can_approve_batch( $b ) ) : ?>
			<a class="button button-primary" href="<?php echo $act( 'approve' ); // phpcs:ignore ?>" onclick="return confirm('Send to <?php echo (int) count( usucger_batch_recipients( $b ) ); ?> recipients?')">Approve &amp; send</a>
		<?php endif; ?>
		<?php if ( 'pending' === $b->status && usucger_can_approve_batch( $b ) ) : ?>
			<a class="button" href="<?php echo $act( 'edit' ); // phpcs:ignore ?>">Edit before approving</a>
		<?php endif; ?>
		<?php if ( in_array( $b->status, array( 'pending', 'sending' ), true ) && ( usucger_can_approve() || (int) $b->created_by === get_current_user_id() ) ) : ?>
			<a class="button" href="<?php echo $act( 'cancel' ); // phpcs:ignore ?>" onclick="return confirm('Stop this email? Messages already sent cannot be recalled.')">Cancel<?php echo 'sending' === $b->status ? ' remaining' : ''; ?></a>
		<?php endif; ?>
			<a class="button" href="<?php echo $act( 'test' ); // phpcs:ignore ?>">Send a test to me</a>
			<a class="button" href="<?php echo $act( 'duplicate' ); // phpcs:ignore ?>">Duplicate as new draft</a>
		</p>
		<?php if ( 'pending' === $b->status && usucger_can_approve_batch( $b ) ) : ?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="max-width:820px">
			<input type="hidden" name="action" value="usucger_batch"><input type="hidden" name="op" value="reject"><input type="hidden" name="batch" value="<?php echo (int) $id; ?>"><input type="hidden" name="_wpnonce" value="<?php echo esc_attr( $nonce ); ?>">
			<p><textarea name="note" rows="2" class="large-text" placeholder="Return to the author with a note (optional)"></textarea><button class="button">Return with note</button></p>
		</form>
		<?php endif; ?>

		<div class="usg-cols" style="margin-top:16px">
			<div>
				<h2>Preview</h2>
				<?php
				$sample = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $ot WHERE batch_id = %d ORDER BY id LIMIT 1", $id ) );
				if ( $sample ) {
					echo '<p>As sent to ' . esc_html( $sample->email ) . '</p>' . usucger_preview_iframe( $sample->body ); // phpcs:ignore
				} else {
					$rec = usucger_batch_recipients( $b );
					$c   = $rec ? $rec[0] : (object) array( 'first_name' => 'Pat', 'last_name' => 'Example', 'email' => 'pat@example.edu', 'institution' => 'Example University', 'category' => 'Member', 'status' => 'lapsed', 'token' => 'preview' );
					list( $s, $h ) = usucger_render_email( $b->subject, $b->body, $c, $b->kind, (array) $b->args );
					echo '<p>As ' . esc_html( $c->email ) . ' will see it — subject: <strong>' . esc_html( $s ) . '</strong></p>' . usucger_preview_iframe( $h ); // phpcs:ignore
				}
				?>
			</div>
			<div>
				<h2>Recipients</h2>
				<?php
				$rows = $wpdb->get_results( $wpdb->prepare( "SELECT email, name, status, error, sent_at FROM $ot WHERE batch_id = %d ORDER BY id LIMIT 1000", $id ) );
				if ( ! $rows && in_array( $b->status, array( 'draft', 'pending', 'rejected' ), true ) ) {
					$rows = array_map( function ( $r ) {
						return (object) array( 'email' => $r->email, 'name' => trim( $r->first_name . ' ' . $r->last_name ), 'status' => 'will receive', 'error' => '', 'sent_at' => '' );
					}, usucger_batch_recipients( $b ) );
					echo '<p class="description">Worked out now — anyone who renews or unsubscribes before approval is dropped automatically.</p>';
				}
				echo '<div style="max-height:720px;overflow:auto"><table class="widefat striped"><thead><tr><th>Name</th><th>Email</th><th>Status</th></tr></thead><tbody>';
				foreach ( $rows as $r ) {
					echo '<tr><td>' . esc_html( $r->name ) . '</td><td>' . esc_html( $r->email ) . '</td><td>' . usucger_pill( str_replace( ' ', '-', $r->status ) ) . ( $r->error ? '<br><small>' . esc_html( $r->error ) . '</small>' : '' ) . '</td></tr>'; // phpcs:ignore
				}
				echo '</tbody></table></div>';
				?>
			</div>
		</div>
	</div>
	<?php
}

add_action( 'admin_post_usucger_batch', function () {
	$id = isset( $_REQUEST['batch'] ) ? (int) $_REQUEST['batch'] : 0;
	check_admin_referer( 'usucger_batch_' . $id );
	$b  = usucger_batch( $id );
	$op = isset( $_REQUEST['op'] ) ? sanitize_key( $_REQUEST['op'] ) : '';
	if ( ! usucger_batch_visible( $b ) || ! current_user_can( 'usucger_compose' ) ) {
		wp_die( 'Not allowed.' );
	}
	$back = usucger_admin_url( 'usucger-outbox', array( 'batch' => $id ) );
	switch ( $op ) {
		case 'approve':
			if ( ! usucger_can_approve_batch( $b ) ) {
				wp_die( 'Only approvers can approve.' );
			}
			$r = usucger_batch_approve( $id );
			usucger_back( $back, is_wp_error( $r ) ? $r->get_error_message() : 'Approved — sending has started.', is_wp_error( $r ) ? 'error' : 'success' );
			break;
		case 'reject':
			if ( ! usucger_can_approve_batch( $b ) ) {
				wp_die( 'Only approvers can return emails.' );
			}
			usucger_batch_reject( $id, sanitize_textarea_field( wp_unslash( isset( $_POST['note'] ) ? $_POST['note'] : '' ) ) );
			usucger_back( $back, 'Returned to the author.' );
			break;
		case 'edit':
			if ( usucger_can_approve_batch( $b ) && 'pending' === $b->status ) {
				usucger_batch_save( array( 'status' => 'draft' ), $id );
			}
			wp_safe_redirect( usucger_admin_url( 'usucger-compose', array( 'batch' => $id ) ) );
			exit;
		case 'cancel':
			usucger_batch_cancel( $id );
			usucger_back( $back, 'Cancelled.' );
			break;
		case 'test':
			$ok = usucger_send_test( $b, wp_get_current_user()->user_email );
			usucger_back( $back, $ok ? 'Test sent.' : 'The test could not be sent — check the email (SMTP) setup.', $ok ? 'success' : 'error' );
			break;
		case 'duplicate':
			$new = usucger_batch_save( array( 'kind' => $b->kind, 'group_key' => $b->group_key, 'args' => $b->args, 'template_key' => $b->template_key, 'subject' => $b->subject, 'body' => $b->body ) );
			wp_safe_redirect( usucger_admin_url( 'usucger-compose', array( 'batch' => $new ) ) );
			exit;
	}
	usucger_back( $back );
} );

add_action( 'admin_post_usucger_tick_now', function () {
	usucger_check( 'usucger_tick_now', 'usucger_approve' );
	delete_option( 'usucger_tick_lock_at' );
	$n = usucger_outbox_tick();
	usucger_back( usucger_admin_url( 'usucger-outbox' ), sprintf( 'Sent %d emails.', $n ) );
} );

/* ================================================================ templates */

function usucger_page_templates() {
	$tpl  = usucger_email_templates();
	$edit = isset( $_GET['edit'] ) ? sanitize_key( $_GET['edit'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	echo '<div class="wrap usg-wrap">';
	if ( $edit ) {
		$t = isset( $tpl[ $edit ] ) ? $tpl[ $edit ] : array( 'name' => '', 'kind' => 'news', 'subject' => '', 'body' => '' );
		echo '<h1>' . ( isset( $tpl[ $edit ] ) ? 'Edit template' : 'New template' ) . '</h1><p><a href="' . esc_url( usucger_admin_url( 'usucger-templates' ) ) . '">&larr; Templates</a></p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="usucger_tpl_save">';
		wp_nonce_field( 'usucger_tpl_save' );
		echo '<table class="form-table"><tbody>';
		echo '<tr><th>Key</th><td><input name="key" class="regular-text" value="' . esc_attr( 'new' === $edit ? '' : $edit ) . '" ' . ( 'new' === $edit ? 'required pattern="[a-z0-9_]+"' : 'readonly' ) . '><p class="description">Lowercase letters, numbers, underscore.</p></td></tr>';
		echo '<tr><th>Name</th><td><input name="name" class="regular-text" required value="' . esc_attr( $t['name'] ) . '"></td></tr>';
		echo '<tr><th>Type</th><td><select name="kind"><option value="news"' . selected( $t['kind'], 'news', false ) . '>Announcement</option><option value="renewal"' . selected( $t['kind'], 'renewal', false ) . '>Membership / renewal notice</option><option value="official"' . selected( $t['kind'], 'official', false ) . '>Official governance notice</option></select></td></tr>';
		echo '<tr><th>Subject</th><td><input name="subject" class="large-text" required value="' . esc_attr( $t['subject'] ) . '"></td></tr><tr><th>Message</th><td>';
		echo '<p class="usg-tags">Merge tags: ';
		foreach ( usucger_merge_tags() as $tag => $label ) {
			echo '<code title="' . esc_attr( $label ) . '">' . esc_html( $tag ) . '</code>';
		}
		echo '</p>';
		wp_editor( $t['body'], 'usgtplbody', array( 'textarea_name' => 'body', 'textarea_rows' => 18 ) );
		echo '</td></tr></tbody></table><p><button class="button button-primary">Save template</button></p></form>';
		if ( isset( $tpl[ $edit ] ) ) {
			list( $s, $h ) = usucger_render_email( $t['subject'], $t['body'], (object) array( 'first_name' => 'Pat', 'last_name' => 'Example', 'email' => 'pat@example.edu', 'institution' => 'Example University', 'category' => 'U.S. University member', 'status' => 'lapsed', 'token' => 'preview', 'end_date' => usucger_core_opt( 'cycle_end' ) ), $t['kind'] );
			echo '<h2>Preview</h2><p><strong>Subject:</strong> ' . esc_html( $s ) . '</p>' . usucger_preview_iframe( $h ); // phpcs:ignore
		}
	} else {
		echo '<h1 class="wp-heading-inline">Email templates</h1> <a class="page-title-action" href="' . esc_url( usucger_admin_url( 'usucger-templates', array( 'edit' => 'new' ) ) ) . '">Add template</a>';
		echo '<p class="usg-help">Every email uses the USUCGER letterhead. Templates are a starting point — the text can be changed for each email before sending.</p>';
		echo '<table class="widefat striped"><thead><tr><th>Name</th><th>Type</th><th>Subject</th><th></th></tr></thead><tbody>';
		foreach ( $tpl as $k => $t ) {
			echo '<tr><td><strong><a href="' . esc_url( usucger_admin_url( 'usucger-templates', array( 'edit' => $k ) ) ) . '">' . esc_html( $t['name'] ) . '</a></strong></td><td>' . ( 'renewal' === $t['kind'] ? 'Renewal notice' : ( 'official' === $t['kind'] ? 'Official notice' : 'Announcement' ) ) . '</td><td>' . esc_html( $t['subject'] ) . '</td><td><a class="button" href="' . esc_url( usucger_admin_url( 'usucger-compose', array( 'tpl' => $k ) ) ) . '">Use</a> <a class="button-link-delete" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=usucger_tpl_delete&key=' . $k ), 'usucger_tpl_delete' ) ) . '" onclick="return confirm(\'Delete this template?\')">Delete</a></td></tr>';
		}
		echo '</tbody></table>';
	}
	echo '</div>';
}

add_action( 'admin_post_usucger_tpl_save', function () {
	usucger_check( 'usucger_tpl_save', 'usucger_approve' );
	$p   = wp_unslash( $_POST );
	$key = sanitize_key( $p['key'] );
	if ( ! $key ) {
		usucger_back( usucger_admin_url( 'usucger-templates' ), 'Missing key.', 'error' );
	}
	$tpl         = usucger_email_templates();
	$tpl[ $key ] = array(
		'name'    => sanitize_text_field( $p['name'] ),
		'kind'    => in_array( $p['kind'], array( 'renewal', 'official' ), true ) ? $p['kind'] : 'news',
		'subject' => sanitize_text_field( $p['subject'] ),
		'body'    => current_user_can( 'unfiltered_html' ) ? $p['body'] : wp_kses_post( $p['body'] ),
	);
	update_option( 'usucger_templates', $tpl, false );
	usucger_back( usucger_admin_url( 'usucger-templates', array( 'edit' => $key ) ), 'Template saved.' );
} );

add_action( 'admin_post_usucger_tpl_delete', function () {
	usucger_check( 'usucger_tpl_delete', 'usucger_approve' );
	$tpl = usucger_email_templates();
	unset( $tpl[ sanitize_key( isset( $_GET['key'] ) ? $_GET['key'] : '' ) ] );
	update_option( 'usucger_templates', $tpl, false );
	usucger_back( usucger_admin_url( 'usucger-templates' ), 'Deleted.' );
} );
