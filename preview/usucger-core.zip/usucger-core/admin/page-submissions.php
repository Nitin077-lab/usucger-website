<?php
/**
 * USUCGER → Submissions: award nominations and travel-grant applications from the online
 * forms (Board can read them; status and notes are shared), plus a link to positions
 * waiting in the review queue. CSV export for committee spreadsheets.
 *
 * @package usucger-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'admin_menu', function () {
	add_submenu_page( 'usucger', 'Submissions', 'Submissions', 'usucger_view_members', 'usucger-submissions', 'usucger_page_submissions' );
}, 11 );

function usucger_submission_types() {
	return array(
		'usucger_nomination' => array( 'Award nominations', array( 'nominee' => 'Nominee', 'nominee_inst' => 'Institution', 'nominee_email' => 'Nominee email', 'award' => 'Award', 'nominator' => 'Nominated by', 'nominator_email' => 'Nominator email', 'cycle' => 'Year' ) ),
		'usucger_tg_app'     => array( 'Travel grant applications', array( 'student' => 'Student', 'student_email' => 'Student email', 'university' => 'University', 'degree' => 'Degree', 'advisor' => 'Advisor', 'advisor_email' => 'Advisor email', 'advisor_member' => 'Advisor (member record)', 'conference' => 'Conference', 'conf_dates' => 'Dates', 'conf_location' => 'Location', 'presentation' => 'Presentation title', 'ptype' => 'Type', 'amount' => 'Requested ($)', 'other_funding' => 'Other funding', 'cycle' => 'Round' ) ),
	);
}

function usucger_submission_statuses() {
	return array( 'received' => 'Received', 'shortlisted' => 'Shortlisted', 'awarded' => 'Awarded', 'declined' => 'Not selected', 'withdrawn' => 'Withdrawn' );
}

function usucger_page_submissions() {
	$types = usucger_submission_types();
	$pt    = isset( $_GET['type'] ) && isset( $types[ $_GET['type'] ] ) ? sanitize_key( $_GET['type'] ) : 'usucger_nomination'; // phpcs:ignore WordPress.Security.NonceVerification
	$view  = isset( $_GET['view'] ) ? (int) $_GET['view'] : 0; // phpcs:ignore WordPress.Security.NonceVerification
	echo '<div class="wrap usg-wrap">';
	if ( $view ) {
		usucger_submission_view( $view );
		echo '</div>';
		return;
	}
	$pending_pos = get_posts( array( 'post_type' => 'usucger_position', 'post_status' => 'pending', 'posts_per_page' => 50, 'meta_key' => '_submitter', 'meta_compare' => 'EXISTS' ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
	echo '<h1>Submissions</h1><p class="usg-help">Entries from the online forms. Files are private: they open only for signed-in Board members and staff. Set a status and leave notes for the committee; export to a spreadsheet with the CSV button.</p>';
	echo '<p class="usg-filters">';
	foreach ( $types as $k => $t ) {
		$n = (int) wp_count_posts( $k )->private;
		echo '<a class="' . ( $k === $pt ? 'cur' : '' ) . '" href="' . esc_url( usucger_admin_url( 'usucger-submissions', array( 'type' => $k ) ) ) . '">' . esc_html( $t[0] ) . ' (' . $n . ')</a>';
	}
	echo '<a href="' . esc_url( usucger_admin_url( 'usucger-review' ) ) . '">Positions waiting for approval (' . count( $pending_pos ) . ')</a></p>';

	$status = isset( $_GET['st'] ) ? sanitize_key( $_GET['st'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	$cycle  = isset( $_GET['cycle'] ) ? sanitize_text_field( wp_unslash( $_GET['cycle'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	$items  = usucger_submissions( $pt, $status, $cycle );
	$cycles = array_unique( array_filter( array_map( function ( $p ) {
		return get_post_meta( $p->ID, 'cycle', true );
	}, usucger_submissions( $pt ) ) ) );
	echo '<form method="get" class="usg-filters"><input type="hidden" name="page" value="usucger-submissions"><input type="hidden" name="type" value="' . esc_attr( $pt ) . '">';
	echo '<label>Status <select name="st"><option value="">All</option>';
	foreach ( usucger_submission_statuses() as $k => $l ) {
		echo '<option value="' . esc_attr( $k ) . '"' . selected( $status, $k, false ) . '>' . esc_html( $l ) . '</option>';
	}
	echo '</select></label> <label>Year / round <select name="cycle"><option value="">All</option>';
	foreach ( $cycles as $c ) {
		echo '<option' . selected( $cycle, $c, false ) . '>' . esc_html( $c ) . '</option>';
	}
	echo '</select></label> <button class="button">Filter</button> <a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=usucger_submissions_csv&type=' . $pt . '&st=' . rawurlencode( $status ) . '&cycle=' . rawurlencode( $cycle ) ), 'usucger_submissions_csv' ) ) . '">Download CSV</a></form>';

	$cols = array_slice( $types[ $pt ][1], 0, 'usucger_nomination' === $pt ? 5 : 6, true );
	echo '<table class="widefat striped"><thead><tr><th>Received</th>';
	foreach ( $cols as $l ) {
		echo '<th>' . esc_html( $l ) . '</th>';
	}
	echo '<th>Files</th><th>Status</th></tr></thead><tbody>';
	if ( ! $items ) {
		echo '<tr><td colspan="' . ( count( $cols ) + 3 ) . '">Nothing yet. The form is at <a href="' . esc_url( usucger_core_url( 'usucger_nomination' === $pt ? 'nominate' : 'travel-grant-application' ) ) . '" target="_blank">' . esc_html( usucger_core_url( 'usucger_nomination' === $pt ? 'nominate' : 'travel-grant-application' ) ) . '</a>.</td></tr>';
	}
	$aw = usucger_award_types();
	foreach ( $items as $p ) {
		$st = (string) get_post_meta( $p->ID, '_status', true );
		echo '<tr><td><a href="' . esc_url( usucger_admin_url( 'usucger-submissions', array( 'view' => $p->ID ) ) ) . '"><strong>' . esc_html( wp_date( 'M j, Y', strtotime( $p->post_date_gmt . ' UTC' ) ) ) . '</strong></a></td>';
		foreach ( array_keys( $cols ) as $k ) {
			$v = (string) get_post_meta( $p->ID, $k, true );
			if ( 'award' === $k && isset( $aw[ $v ] ) ) {
				$v = $aw[ $v ]['name'];
			}
			echo '<td>' . esc_html( $v ) . '</td>';
		}
		echo '<td>' . count( (array) get_post_meta( $p->ID, '_files', true ) ) . '</td><td>' . usucger_pill( $st ? $st : 'received' ) . '</td></tr>'; // phpcs:ignore
	}
	echo '</tbody></table></div>';
}

function usucger_submissions( $pt, $status = '', $cycle = '' ) {
	$q = array( 'post_type' => $pt, 'post_status' => 'private', 'posts_per_page' => 500, 'orderby' => 'date', 'order' => 'DESC', 'no_found_rows' => true );
	$m = array();
	if ( $status ) {
		$m[] = array( 'key' => '_status', 'value' => $status );
	}
	if ( $cycle ) {
		$m[] = array( 'key' => 'cycle', 'value' => $cycle );
	}
	if ( $m ) {
		$q['meta_query'] = $m; // phpcs:ignore WordPress.DB.SlowDBQuery
	}
	return get_posts( $q );
}

function usucger_submission_view( $id ) {
	$p     = get_post( $id );
	$types = usucger_submission_types();
	if ( ! $p || ! isset( $types[ $p->post_type ] ) ) {
		echo '<p>Not found.</p>';
		return;
	}
	$aw = usucger_award_types();
	echo '<p><a href="' . esc_url( usucger_admin_url( 'usucger-submissions', array( 'type' => $p->post_type ) ) ) . '">&larr; ' . esc_html( $types[ $p->post_type ][0] ) . '</a></p><h1>' . esc_html( $p->post_title ) . '</h1>';
	echo '<div class="usg-cols"><div class="usg-card"><h2>Details</h2><table class="widefat striped"><tbody>';
	foreach ( $types[ $p->post_type ][1] as $k => $l ) {
		$v = (string) get_post_meta( $id, $k, true );
		if ( 'award' === $k && isset( $aw[ $v ] ) ) {
			$v = $aw[ $v ]['name'];
		}
		if ( '' === $v ) {
			continue;
		}
		echo '<tr><th style="width:38%">' . esc_html( $l ) . '</th><td>' . ( is_email( $v ) ? '<a href="mailto:' . esc_attr( $v ) . '">' . esc_html( $v ) . '</a>' : esc_html( $v ) ) . '</td></tr>';
	}
	echo '<tr><th>Received</th><td>' . esc_html( wp_date( 'F j, Y g:i a', strtotime( $p->post_date_gmt . ' UTC' ) ) ) . '</td></tr></tbody></table>';
	if ( $p->post_content ) {
		echo '<h2 style="margin-top:1em">Statement</h2><div style="white-space:pre-wrap">' . esc_html( $p->post_content ) . '</div>';
	}
	echo '</div><div><div class="usg-card"><h2>Files</h2><ul>';
	$labels = array( 'letter' => 'Nomination / support letter', 'cv' => 'CV', 'abstract' => 'Abstract or acceptance', 'support1' => 'Support letter 1', 'support2' => 'Support letter 2', 'support3' => 'Support letter 3' );
	foreach ( (array) get_post_meta( $id, '_files', true ) as $k => $rel ) {
		$label = isset( $labels[ $k ] ) ? $labels[ $k ] : 'File ' . ( is_int( $k ) ? $k + 1 : $k );
		echo '<li><a href="' . esc_url( usucger_private_file_url( $id, $rel ) ) . '" target="_blank">' . esc_html( $label ) . '</a> <span class="description">PDF</span></li>';
	}
	echo '</ul></div>';
	$st = (string) get_post_meta( $id, '_status', true );
	echo '<div class="usg-card"><h2>Committee</h2><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="usucger_submission_status"><input type="hidden" name="id" value="' . (int) $id . '">';
	wp_nonce_field( 'usucger_submission_' . $id );
	echo '<p><label>Status <select name="status">';
	foreach ( usucger_submission_statuses() as $k => $l ) {
		echo '<option value="' . esc_attr( $k ) . '"' . selected( $st ? $st : 'received', $k, false ) . '>' . esc_html( $l ) . '</option>';
	}
	echo '</select></label></p><p><textarea name="note" rows="3" class="large-text" placeholder="Add a note for the committee (scores, conflicts of interest…)"></textarea></p><p><button class="button button-primary">Save</button></p></form>';
	$notes = (array) get_post_meta( $id, '_notes', true );
	if ( array_filter( $notes ) ) {
		echo '<h3>Notes</h3><ul>';
		foreach ( array_reverse( array_filter( $notes ) ) as $n ) {
			echo '<li><strong>' . esc_html( $n['who'] ) . '</strong>, ' . esc_html( $n['at'] ) . ': ' . esc_html( $n['text'] ) . '</li>';
		}
		echo '</ul>';
	}
	echo '</div>';
	if ( current_user_can( 'usucger_manage' ) ) {
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" onsubmit="return confirm(\'Delete this submission and its files permanently?\')"><input type="hidden" name="action" value="usucger_submission_delete"><input type="hidden" name="id" value="' . (int) $id . '">';
		wp_nonce_field( 'usucger_submission_del_' . $id );
		echo '<p><button class="button-link button-link-delete">Delete submission and files</button></p></form>';
	}
	echo '</div></div>';
}

add_action( 'admin_post_usucger_submission_status', function () {
	$id = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;
	usucger_check( 'usucger_submission_' . $id, 'usucger_view_members' );
	$p = get_post( $id );
	if ( ! $p || ! isset( usucger_submission_types()[ $p->post_type ] ) ) {
		wp_die( 'Not found.' );
	}
	$st = sanitize_key( wp_unslash( $_POST['status'] ) );
	if ( isset( usucger_submission_statuses()[ $st ] ) ) {
		update_post_meta( $id, '_status', $st );
	}
	$note = sanitize_textarea_field( wp_unslash( isset( $_POST['note'] ) ? $_POST['note'] : '' ) );
	if ( $note ) {
		$notes   = array_filter( (array) get_post_meta( $id, '_notes', true ) );
		$notes[] = array( 'who' => wp_get_current_user()->display_name, 'at' => wp_date( 'M j, Y g:i a' ), 'text' => mb_substr( $note, 0, 2000 ) );
		update_post_meta( $id, '_notes', $notes );
	}
	Usucger_DB::log( 'submission_status', 'post:' . $id, $st );
	usucger_back( usucger_admin_url( 'usucger-submissions', array( 'view' => $id ) ), 'Saved.' );
} );

add_action( 'admin_post_usucger_submission_delete', function () {
	$id = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;
	usucger_check( 'usucger_submission_del_' . $id, 'usucger_manage' );
	$p = get_post( $id );
	if ( ! $p || ! isset( usucger_submission_types()[ $p->post_type ] ) ) {
		wp_die( 'Not found.' );
	}
	$up = wp_upload_dir();
	foreach ( (array) get_post_meta( $id, '_files', true ) as $rel ) {
		$path = $up['basedir'] . '/usucger-private/' . $rel;
		if ( $rel && false === strpos( $rel, '..' ) && file_exists( $path ) ) {
			wp_delete_file( $path );
		}
	}
	wp_delete_post( $id, true );
	Usucger_DB::log( 'submission_deleted', 'post:' . $id, $p->post_title );
	usucger_back( usucger_admin_url( 'usucger-submissions', array( 'type' => $p->post_type ) ), 'Deleted.' );
} );

add_action( 'admin_post_usucger_submissions_csv', function () {
	usucger_check( 'usucger_submissions_csv', 'usucger_view_members' );
	$types = usucger_submission_types();
	$pt    = isset( $_GET['type'] ) && isset( $types[ $_GET['type'] ] ) ? sanitize_key( $_GET['type'] ) : 'usucger_nomination';
	$items = usucger_submissions( $pt, sanitize_key( wp_unslash( isset( $_GET['st'] ) ? $_GET['st'] : '' ) ), sanitize_text_field( wp_unslash( isset( $_GET['cycle'] ) ? $_GET['cycle'] : '' ) ) );
	$aw    = usucger_award_types();
	nocache_headers();
	header( 'Content-Type: text/csv; charset=utf-8' );
	header( 'Content-Disposition: attachment; filename="usucger-' . ( 'usucger_nomination' === $pt ? 'nominations' : 'travel-grants' ) . '-' . gmdate( 'Y-m-d' ) . '.csv"' );
	$out = fopen( 'php://output', 'w' );
	fwrite( $out, "\xEF\xBB\xBF" ); // Excel: UTF-8
	fputcsv( $out, array_merge( array( 'Received' ), array_values( $types[ $pt ][1] ), array( 'Status', 'Statement', 'Link' ) ) );
	foreach ( $items as $p ) {
		$row = array( get_date_from_gmt( $p->post_date_gmt, 'Y-m-d H:i' ) );
		foreach ( array_keys( $types[ $pt ][1] ) as $k ) {
			$v     = (string) get_post_meta( $p->ID, $k, true );
			$row[] = usucger_csv_safe( 'award' === $k && isset( $aw[ $v ] ) ? $aw[ $v ]['name'] : $v );
		}
		$row[] = (string) get_post_meta( $p->ID, '_status', true );
		$row[] = usucger_csv_safe( $p->post_content );
		$row[] = usucger_admin_url( 'usucger-submissions', array( 'view' => $p->ID ) );
		fputcsv( $out, $row );
	}
	fclose( $out ); // phpcs:ignore
	exit;
} );
