<?php
/**
 * USUCGER → Members and → Universities.
 *
 * @package usucger-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ================================================================== members */

function usucger_page_members() {
	global $wpdb;
	$t      = Usucger_DB::t( 'contacts' );
	$edit   = isset( $_GET['edit'] ) ? sanitize_text_field( wp_unslash( $_GET['edit'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	$manage = current_user_can( 'usucger_manage' );
	if ( '' !== $edit && $manage ) {
		usucger_member_form( 'new' === $edit ? null : Usucger_Members::get( (int) $edit ) );
		return;
	}
	$status = isset( $_GET['status'] ) ? sanitize_key( $_GET['status'] ) : 'current'; // phpcs:ignore WordPress.Security.NonceVerification
	$s      = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	$paged  = max( 1, isset( $_GET['paged'] ) ? (int) $_GET['paged'] : 1 ); // phpcs:ignore WordPress.Security.NonceVerification
	$per    = 50;
	$where  = '1=1';
	$args   = array();
	if ( 'expiring' === $status ) {
		$where .= " AND status = 'current' AND end_date IS NOT NULL AND end_date <= %s";
		$args[] = gmdate( 'Y-m-d', strtotime( '+30 days' ) );
	} elseif ( 'noemail' === $status ) {
		$where .= " AND email = '' AND status IN ('current','lapsed')";
	} elseif ( 'all' !== $status ) {
		$where .= ' AND status = %s';
		$args[] = $status;
	}
	if ( $s ) {
		$like   = '%' . $wpdb->esc_like( $s ) . '%';
		$where .= ' AND (email LIKE %s OR first_name LIKE %s OR last_name LIKE %s OR institution LIKE %s OR tags LIKE %s)';
		array_push( $args, $like, $like, $like, $like, $like );
	}
	$sql_where = $args ? $wpdb->prepare( $where, $args ) : $where; // phpcs:ignore WordPress.DB
	$total     = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $t WHERE $sql_where" ); // phpcs:ignore WordPress.DB
	$rows      = $wpdb->get_results( "SELECT * FROM $t WHERE $sql_where ORDER BY last_name, first_name LIMIT " . ( ( $paged - 1 ) * $per ) . ", $per" ); // phpcs:ignore WordPress.DB
	$c         = Usucger_Members::counts();
	$tabs      = array( 'current' => 'Current', 'lapsed' => 'Not renewed', 'expiring' => 'Ending ≤30 days', 'prospect' => 'Mailing list only', 'former' => 'Former', 'noemail' => 'No email', 'all' => 'All' );
	$counts    = array( 'current' => $c['current'], 'lapsed' => $c['lapsed'], 'expiring' => $c['expiring'], 'prospect' => $c['prospect'], 'former' => $c['former'], 'noemail' => $c['no_email'] );
	?>
	<div class="wrap usg-wrap">
		<h1 class="wp-heading-inline">Members</h1>
		<?php if ( $manage ) : ?>
			<a class="page-title-action" href="<?php echo esc_url( usucger_admin_url( 'usucger-members', array( 'edit' => 'new' ) ) ); ?>">Add person</a>
		<?php endif; ?>
		<a class="page-title-action" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=usucger_members_csv&status=' . $status ), 'usucger_members_csv' ) ); ?>">Download CSV</a>
		<?php if ( $manage && Usucger_Members::wcm_active() ) : ?>
			<a class="page-title-action" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=usucger_sync' ), 'usucger_sync' ) ); ?>">Sync from WooCommerce Memberships now</a>
		<?php endif; ?>
		<p class="usg-help">Status comes from WooCommerce Memberships (synced daily and whenever a membership changes). <strong>Not renewed</strong> = was a member in an earlier cycle and has not paid for <?php echo esc_html( usucger_core_opt( 'cycle' ) ); ?>; these are the only people who receive renewal reminders. <strong>Former</strong> members are hidden from the directory and member mailings but kept for history.</p>
		<div class="usg-filters">
			<?php foreach ( $tabs as $k => $label ) : ?>
				<a class="<?php echo $k === $status ? 'cur' : ''; ?>" href="<?php echo esc_url( usucger_admin_url( 'usucger-members', array( 'status' => $k ) ) ); ?>"><?php echo esc_html( $label ); ?><?php echo isset( $counts[ $k ] ) ? ' (' . (int) $counts[ $k ] . ')' : ''; ?></a>
			<?php endforeach; ?>
		</div>
		<form method="get"><input type="hidden" name="page" value="usucger-members"><input type="hidden" name="status" value="<?php echo esc_attr( $status ); ?>">
			<p class="search-box"><input type="search" name="s" value="<?php echo esc_attr( $s ); ?>" placeholder="Name, email, institution, tag"> <button class="button">Search</button></p>
		</form>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="usucger_members_bulk">
			<?php wp_nonce_field( 'usucger_members_bulk' ); ?>
			<?php if ( $manage ) : ?>
			<div class="tablenav top"><select name="bulk"><option value="">Bulk actions</option><option value="former">Remove (mark as former member)</option><option value="current">Mark as current</option><option value="lapsed">Mark as not renewed</option><option value="hide">Hide from directory</option><option value="show">Show in directory</option><option value="tag">Add tag…</option><option value="email">Compose email to selected</option></select> <input type="text" name="tag" placeholder="tag (for Add tag)" style="width:140px"> <button class="button">Apply</button>
			<span style="float:right"><?php echo (int) $total; ?> people</span></div>
			<?php endif; ?>
			<table class="widefat striped">
				<thead><tr><td class="check-column"><input type="checkbox" onclick="document.querySelectorAll('.usg-cb').forEach(c=>c.checked=this.checked)"></td><th>Name</th><th>Email</th><th>Institution</th><th>Plan</th><th>Ends</th><th>Status</th><th>Directory</th><th>Emails</th></tr></thead>
				<tbody>
				<?php if ( ! $rows ) : ?><tr><td colspan="9">No one here.</td></tr><?php endif; ?>
				<?php foreach ( $rows as $r ) : ?>
					<tr>
						<th class="check-column"><input class="usg-cb" type="checkbox" name="ids[]" value="<?php echo (int) $r->id; ?>"></th>
						<td><strong><?php echo $manage ? '<a href="' . esc_url( usucger_admin_url( 'usucger-members', array( 'edit' => $r->id ) ) ) . '">' : ''; ?><?php echo esc_html( trim( $r->last_name . ', ' . $r->first_name, ', ' ) ); ?><?php echo $manage ? '</a>' : ''; ?></strong><?php echo $r->tags ? '<br><small>' . esc_html( $r->tags ) . '</small>' : ''; ?></td>
						<td><?php echo $r->email ? esc_html( $r->email ) : '<em style="color:#996800">none</em>'; ?></td>
						<td><?php echo esc_html( $r->institution ); ?></td>
						<td><?php echo esc_html( $r->category ); ?></td>
						<td><?php echo esc_html( $r->end_date ); ?></td>
						<td><?php echo usucger_pill( $r->status ) . ( ! empty( $r->bounced ) ? ' <span class="usg-pill failed" title="' . esc_attr( $r->bounce_note ) . '">bounced</span>' : '' ); // phpcs:ignore ?></td>
						<td><?php echo $r->in_directory ? 'Listed' : '—'; ?></td>
						<td><?php echo ( $r->unsub_news ? 'no news' : 'news' ) . ' · ' . ( $r->unsub_renewal ? 'no reminders' : 'reminders' ); ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</form>
		<?php
		$pages = (int) ceil( $total / $per );
		if ( $pages > 1 ) {
			echo '<div class="tablenav"><div class="tablenav-pages">' . paginate_links( array( 'base' => add_query_arg( 'paged', '%#%' ), 'current' => $paged, 'total' => $pages ) ) . '</div></div>'; // phpcs:ignore
		}
		if ( $manage ) :
			?>
		<div class="usg-card" style="margin-top:20px">
			<h2>Import people from CSV</h2>
			<p class="usg-help">Columns (header row required): <code>email, first_name, last_name, institution, status, category, tags</code>. Status is one of current, lapsed, former, prospect (default prospect). Existing emails are updated, new ones added. Use this for mailing lists or people who paid outside WooCommerce.</p>
			<form method="post" enctype="multipart/form-data" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="usucger_members_import"><?php wp_nonce_field( 'usucger_members_import' ); ?>
				<input type="file" name="csv" accept=".csv,text/csv" required> <button class="button">Import</button>
			</form>
		</div>
		<?php endif; ?>
	</div>
	<?php
}

function usucger_member_form( $r ) {
	$r = $r ? $r : (object) array( 'id' => 0, 'email' => '', 'first_name' => '', 'last_name' => '', 'institution' => '', 'category' => '', 'status' => 'current', 'end_date' => '', 'in_directory' => 1, 'is_uni_contact' => 0, 'tags' => '', 'unsub_news' => 0, 'unsub_renewal' => 0, 'notes' => '', 'source' => 'manual', 'user_id' => 0 );
	?>
	<div class="wrap usg-wrap">
		<h1><?php echo $r->id ? 'Edit person' : 'Add person'; ?></h1>
		<p><a href="<?php echo esc_url( usucger_admin_url( 'usucger-members' ) ); ?>">&larr; Members</a><?php echo $r->user_id ? ' · <a href="' . esc_url( get_edit_user_link( $r->user_id ) ) . '">WordPress account</a>' : ''; ?> · Source: <?php echo esc_html( $r->source ); ?></p>
		<?php if ( 'wcm' === $r->source ) : ?><div class="notice notice-info inline"><p>Status, plan and end date are synced from WooCommerce Memberships — change the membership there. Directory listing, tags and email preferences can be changed here.</p></div><?php endif; ?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="usucger_member_save"><input type="hidden" name="id" value="<?php echo (int) $r->id; ?>"><?php wp_nonce_field( 'usucger_member_save' ); ?>
			<table class="form-table"><tbody>
				<tr><th>First name</th><td><input class="regular-text" name="first_name" value="<?php echo esc_attr( $r->first_name ); ?>"></td></tr>
				<tr><th>Last name</th><td><input class="regular-text" name="last_name" value="<?php echo esc_attr( $r->last_name ); ?>"></td></tr>
				<tr><th>Email</th><td><input class="regular-text" type="email" name="email" value="<?php echo esc_attr( $r->email ); ?>"></td></tr>
				<tr><th>Institution</th><td><input class="regular-text" name="institution" value="<?php echo esc_attr( $r->institution ); ?>"></td></tr>
				<tr><th>Category / plan</th><td><input class="regular-text" name="category" value="<?php echo esc_attr( $r->category ); ?>"></td></tr>
				<tr><th>Status</th><td><select name="status"><?php foreach ( array( 'current', 'lapsed', 'former', 'prospect' ) as $s ) : ?><option <?php selected( $r->status, $s ); ?>><?php echo esc_html( $s ); ?></option><?php endforeach; ?></select></td></tr>
				<tr><th>Membership ends</th><td><input type="date" name="end_date" value="<?php echo esc_attr( $r->end_date ); ?>"></td></tr>
				<tr><th>Listing</th><td><label><input type="checkbox" name="in_directory" value="1" <?php checked( $r->in_directory, 1 ); ?>> Show in the public directory and map (when current)</label><br><label><input type="checkbox" name="is_uni_contact" value="1" <?php checked( $r->is_uni_contact, 1 ); ?>> University contact person (delegate)</label></td></tr>
				<tr><th>Tags</th><td><input class="regular-text" name="tags" value="<?php echo esc_attr( $r->tags ); ?>" placeholder="comma separated, e.g. awards-committee,2026-meeting"></td></tr>
				<?php if ( ! empty( $r->bounced ) ) : ?><tr><th>Delivery</th><td><span class="usg-pill failed">bounced</span> <?php echo esc_html( $r->bounce_note ); ?><br><label><input type="checkbox" name="clear_bounce" value="1"> The address is fixed — send to it again</label></td></tr><?php endif; ?>
				<tr><th>Emails</th><td><label><input type="checkbox" name="news" value="1" <?php checked( $r->unsub_news, 0 ); ?>> Announcements</label><br><label><input type="checkbox" name="renewal" value="1" <?php checked( $r->unsub_renewal, 0 ); ?>> Renewal reminders</label></td></tr>
				<tr><th>Notes</th><td><textarea class="large-text" rows="3" name="notes"><?php echo esc_textarea( $r->notes ); ?></textarea></td></tr>
			</tbody></table>
			<p><button class="button button-primary">Save</button></p>
		</form>
	</div>
	<?php
}

add_action( 'admin_post_usucger_member_save', function () {
	usucger_check( 'usucger_member_save', 'usucger_manage' );
	global $wpdb;
	$t  = Usucger_DB::t( 'contacts' );
	$id = (int) $_POST['id'];
	$p  = wp_unslash( $_POST );
	$d  = array(
		'first_name'     => sanitize_text_field( $p['first_name'] ),
		'last_name'      => sanitize_text_field( $p['last_name'] ),
		'email'          => strtolower( sanitize_email( $p['email'] ) ),
		'institution'    => sanitize_text_field( $p['institution'] ),
		'category'       => sanitize_text_field( $p['category'] ),
		'status'         => in_array( $p['status'], array( 'current', 'lapsed', 'former', 'prospect' ), true ) ? $p['status'] : 'prospect',
		'end_date'       => preg_match( '/^\d{4}-\d{2}-\d{2}$/', $p['end_date'] ) ? $p['end_date'] : null,
		'in_directory'   => empty( $p['in_directory'] ) ? 0 : 1,
		'is_uni_contact' => empty( $p['is_uni_contact'] ) ? 0 : 1,
		'tags'           => implode( ',', array_filter( array_map( 'sanitize_title', explode( ',', $p['tags'] ) ) ) ),
		'unsub_news'     => empty( $p['news'] ) ? 1 : 0,
		'bounced'        => empty( $p['clear_bounce'] ) && $id && ( $old = Usucger_Members::get( $id ) ) && ! empty( $old->bounced ) && strtolower( sanitize_email( $p['email'] ) ) === $old->email ? 1 : 0, // a new address clears the flag
		'unsub_renewal'  => empty( $p['renewal'] ) ? 1 : 0,
		'notes'          => sanitize_textarea_field( $p['notes'] ),
		'updated'        => current_time( 'mysql' ),
	);
	if ( $id ) {
		$wpdb->update( $t, $d, array( 'id' => $id ) );
	} else {
		$d['token']   = usucger_token();
		$d['source']  = 'manual';
		$d['created'] = current_time( 'mysql' );
		$wpdb->insert( $t, $d );
		$id = $wpdb->insert_id;
	}
	Usucger_DB::log( 'member_saved', 'contact:' . $id, $d['email'] );
	usucger_bump_content_version();
	usucger_back( usucger_admin_url( 'usucger-members', array( 'edit' => $id ) ), 'Saved.' );
} );

add_action( 'admin_post_usucger_members_bulk', function () {
	check_admin_referer( 'usucger_members_bulk' );
	$ids  = array_map( 'intval', isset( $_POST['ids'] ) ? (array) $_POST['ids'] : array() );
	$bulk = isset( $_POST['bulk'] ) ? sanitize_key( $_POST['bulk'] ) : '';
	$back = wp_get_referer() ? wp_get_referer() : usucger_admin_url( 'usucger-members' );
	if ( ! $ids || ! $bulk ) {
		usucger_back( $back, 'Select people and an action.', 'warning' );
	}
	if ( 'email' === $bulk ) {
		if ( ! current_user_can( 'usucger_compose' ) ) {
			wp_die( 'Not allowed.' );
		}
		$emails = array();
		foreach ( $ids as $id ) {
			$c = Usucger_Members::get( $id );
			if ( $c && $c->email ) {
				$emails[] = $c->email;
			}
		}
		set_transient( 'usucger_compose_emails_' . get_current_user_id(), implode( "\n", $emails ), HOUR_IN_SECONDS );
		wp_safe_redirect( usucger_admin_url( 'usucger-compose', array( 'group' => 'custom', 'from_members' => 1 ) ) );
		exit;
	}
	if ( ! current_user_can( 'usucger_manage' ) ) {
		wp_die( 'Not allowed.' );
	}
	global $wpdb;
	$t  = Usucger_DB::t( 'contacts' );
	$in = implode( ',', $ids );
	switch ( $bulk ) {
		case 'former':
			$n = Usucger_Members::remove( $ids, 'manual' );
			break;
		case 'current':
		case 'lapsed':
			$n = $wpdb->query( $wpdb->prepare( "UPDATE $t SET status = %s WHERE id IN ($in)", $bulk ) ); // phpcs:ignore WordPress.DB
			break;
		case 'hide':
		case 'show':
			$n = $wpdb->query( "UPDATE $t SET in_directory = " . ( 'show' === $bulk ? 1 : 0 ) . " WHERE id IN ($in)" ); // phpcs:ignore WordPress.DB
			break;
		case 'tag':
			$tag = sanitize_title( wp_unslash( isset( $_POST['tag'] ) ? $_POST['tag'] : '' ) );
			$n   = 0;
			if ( $tag ) {
				foreach ( $ids as $id ) {
					$c    = Usucger_Members::get( $id );
					$tags = array_filter( explode( ',', (string) $c->tags ) );
					if ( ! in_array( $tag, $tags, true ) ) {
						$tags[] = $tag;
						$wpdb->update( $t, array( 'tags' => implode( ',', $tags ) ), array( 'id' => $id ) );
						$n++;
					}
				}
			}
			break;
		default:
			$n = 0;
	}
	Usucger_DB::log( 'members_bulk', $bulk, $ids );
	usucger_bump_content_version();
	usucger_back( $back, sprintf( 'Updated %d people.', (int) $n ) );
} );

add_action( 'admin_post_usucger_sync', function () {
	usucger_check( 'usucger_sync', 'usucger_manage' );
	$r = Usucger_Members::sync();
	usucger_back( wp_get_referer() ? wp_get_referer() : usucger_admin_url( 'usucger-members' ), isset( $r['error'] ) ? $r['error'] : sprintf( 'Synced %d members: %d current, %d not renewed (%d new, %d updated).', $r['members'], $r['current'], $r['lapsed'], $r['new'], $r['updated'] ), isset( $r['error'] ) ? 'error' : 'success' );
} );

add_action( 'admin_post_usucger_members_csv', function () {
	usucger_check( 'usucger_members_csv', 'usucger_view_members' );
	global $wpdb;
	$t      = Usucger_DB::t( 'contacts' );
	$status = isset( $_GET['status'] ) ? sanitize_key( $_GET['status'] ) : 'all';
	$where  = in_array( $status, array( 'current', 'lapsed', 'former', 'prospect' ), true ) ? $wpdb->prepare( 'WHERE status = %s', $status ) : '';
	$rows   = $wpdb->get_results( "SELECT email, first_name, last_name, institution, status, category, end_date, in_directory, tags, unsub_news, unsub_renewal FROM $t $where ORDER BY last_name, first_name", ARRAY_A ); // phpcs:ignore WordPress.DB
	header( 'Content-Type: text/csv; charset=utf-8' );
	header( 'Content-Disposition: attachment; filename="usucger-members-' . $status . '-' . gmdate( 'Y-m-d' ) . '.csv"' );
	$out = fopen( 'php://output', 'w' );
	fputcsv( $out, array( 'email', 'first_name', 'last_name', 'institution', 'status', 'category', 'end_date', 'in_directory', 'tags', 'unsub_news', 'unsub_renewal' ) );
	foreach ( $rows as $r ) {
		fputcsv( $out, array_map( 'usucger_csv_safe', $r ) );
	}
	exit;
} );

add_action( 'admin_post_usucger_members_import', function () {
	usucger_check( 'usucger_members_import', 'usucger_manage' );
	if ( empty( $_FILES['csv']['tmp_name'] ) ) {
		usucger_back( usucger_admin_url( 'usucger-members' ), 'No file.', 'error' );
	}
	$fh   = fopen( $_FILES['csv']['tmp_name'], 'r' ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	$head = array_map( function ( $h ) {
		return sanitize_key( trim( $h, " \xEF\xBB\xBF" ) );
	}, (array) fgetcsv( $fh ) );
	$n    = 0;
	$u    = 0;
	while ( ( $row = fgetcsv( $fh ) ) !== false ) {
		$r     = array_combine( $head, array_pad( array_slice( $row, 0, count( $head ) ), count( $head ), '' ) );
		$email = strtolower( sanitize_email( isset( $r['email'] ) ? $r['email'] : '' ) );
		if ( ! is_email( $email ) ) {
			continue;
		}
		$c    = Usucger_Members::ensure_contact( $email, trim( ( isset( $r['first_name'] ) ? $r['first_name'] : '' ) . ' ' . ( isset( $r['last_name'] ) ? $r['last_name'] : '' ) ), sanitize_text_field( isset( $r['institution'] ) ? $r['institution'] : '' ) );
		$data = array( 'updated' => current_time( 'mysql' ) );
		foreach ( array( 'first_name', 'last_name', 'institution', 'category' ) as $k ) {
			if ( ! empty( $r[ $k ] ) ) {
				$data[ $k ] = sanitize_text_field( $r[ $k ] );
			}
		}
		if ( ! empty( $r['status'] ) && in_array( $r['status'], array( 'current', 'lapsed', 'former', 'prospect' ), true ) ) {
			$data['status']       = $r['status'];
			$data['in_directory'] = 'current' === $r['status'] ? 1 : 0;
		}
		if ( ! empty( $r['tags'] ) ) {
			$data['tags'] = implode( ',', array_unique( array_filter( array_merge( explode( ',', (string) $c->tags ), array_map( 'sanitize_title', explode( ',', $r['tags'] ) ) ) ) ) );
		}
		$data['source'] = 'wcm' === $c->source ? 'wcm' : 'import';
		$GLOBALS['wpdb']->update( Usucger_DB::t( 'contacts' ), $data, array( 'id' => $c->id ) );
		$n++;
	}
	fclose( $fh );
	Usucger_DB::log( 'members_csv_import', '', $n );
	usucger_bump_content_version();
	usucger_back( usucger_admin_url( 'usucger-members', array( 'status' => 'all' ) ), sprintf( 'Imported %d rows.', $n ) );
} );

/* ============================================================= institutions */

function usucger_page_institutions() {
	global $wpdb;
	$t      = Usucger_DB::t( 'institutions' );
	$manage = current_user_can( 'usucger_manage' );
	$edit   = isset( $_GET['edit'] ) ? sanitize_text_field( wp_unslash( $_GET['edit'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	if ( '' !== $edit && $manage ) {
		$r = 'new' === $edit ? (object) array( 'id' => 0, 'name' => '', 'state' => '', 'contact_name' => '', 'contact_email' => '', 'alternate_name' => '', 'alternate_email' => '', 'status' => 'member', 'aliases' => '', 'notes' => '' ) : $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $t WHERE id = %d", (int) $edit ) );
		?>
		<div class="wrap usg-wrap"><h1><?php echo $r->id ? 'Edit university' : 'Add university'; ?></h1>
		<p><a href="<?php echo esc_url( usucger_admin_url( 'usucger-institutions' ) ); ?>">&larr; Universities</a></p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="usucger_inst_save"><input type="hidden" name="id" value="<?php echo (int) $r->id; ?>"><?php wp_nonce_field( 'usucger_inst_save' ); ?>
		<table class="form-table"><tbody>
			<tr><th>Name</th><td><input class="regular-text" name="name" required value="<?php echo esc_attr( $r->name ); ?>"></td></tr>
			<tr><th>State</th><td><select name="state"><?php foreach ( usucger_state_names() as $k => $n ) : ?><option value="<?php echo esc_attr( $k ); ?>" <?php selected( $r->state, $k ); ?>><?php echo esc_html( $n ); ?></option><?php endforeach; ?></select></td></tr>
			<tr><th>Contact person (delegate)</th><td><input class="regular-text" name="contact_name" value="<?php echo esc_attr( $r->contact_name ); ?>" placeholder="Last, First"></td></tr>
			<tr><th>Contact email</th><td><input class="regular-text" type="email" name="contact_email" value="<?php echo esc_attr( $r->contact_email ); ?>"></td></tr>
			<tr><th>Alternate (optional)</th><td><input class="regular-text" name="alternate_name" value="<?php echo esc_attr( $r->alternate_name ); ?>" placeholder="Name"> <input class="regular-text" type="email" name="alternate_email" value="<?php echo esc_attr( $r->alternate_email ); ?>" placeholder="Email"><p class="description">One colleague at the same institution who may cast the institution's ballot if the delegate cannot (By-Laws Art. III §2). Must be a current paid member. Still one ballot per institution.</p></td></tr>
			<tr><th>Other names</th><td><input class="regular-text" name="aliases" value="<?php echo esc_attr( $r->aliases ); ?>" placeholder="separate with ;  e.g. MIT; Mass. Inst. of Technology"><p class="description">Used to match members' affiliations to this university on the map.</p></td></tr>
			<tr><th>Status</th><td><select name="status"><option value="member" <?php selected( $r->status, 'member' ); ?>>Member</option><option value="former" <?php selected( $r->status, 'former' ); ?>>Former member (hidden)</option></select></td></tr>
			<tr><th>Notes</th><td><textarea class="large-text" rows="3" name="notes"><?php echo esc_textarea( $r->notes ); ?></textarea></td></tr>
		</tbody></table><p><button class="button button-primary">Save</button></p></form></div>
		<?php
		return;
	}
	$status = isset( $_GET['status'] ) && 'former' === $_GET['status'] ? 'former' : 'member'; // phpcs:ignore WordPress.Security.NonceVerification
	$rows   = Usucger_Members::institutions( $status );
	$ct     = Usucger_DB::t( 'contacts' );
	$paid   = array();
	foreach ( $wpdb->get_results( "SELECT institution, COUNT(*) n FROM $ct WHERE status = 'current' GROUP BY institution" ) as $p ) { // phpcs:ignore WordPress.DB
		$paid[ usucger_norm( $p->institution ) ] = (int) $p->n;
	}
	?>
	<div class="wrap usg-wrap"><h1 class="wp-heading-inline">Member universities</h1>
	<?php if ( $manage ) : ?><a class="page-title-action" href="<?php echo esc_url( usucger_admin_url( 'usucger-institutions', array( 'edit' => 'new' ) ) ); ?>">Add university</a><?php endif; ?>
	<div class="usg-filters"><a class="<?php echo 'member' === $status ? 'cur' : ''; ?>" href="<?php echo esc_url( usucger_admin_url( 'usucger-institutions' ) ); ?>">Members</a><a class="<?php echo 'former' === $status ? 'cur' : ''; ?>" href="<?php echo esc_url( usucger_admin_url( 'usucger-institutions', array( 'status' => 'former' ) ) ); ?>">Former</a></div>
	<table class="widefat striped"><thead><tr><th>University</th><th>State</th><th>Delegate</th><th>Delegate email</th><th>Alternate</th><th>Current members</th></tr></thead><tbody>
	<?php foreach ( $rows as $r ) : $n = isset( $paid[ usucger_norm( $r->name ) ] ) ? $paid[ usucger_norm( $r->name ) ] : 0; ?>
		<tr><td><strong><?php echo $manage ? '<a href="' . esc_url( usucger_admin_url( 'usucger-institutions', array( 'edit' => $r->id ) ) ) . '">' : ''; ?><?php echo esc_html( $r->name ); ?><?php echo $manage ? '</a>' : ''; ?></strong></td><td><?php echo esc_html( $r->state ); ?></td><td><?php echo esc_html( $r->contact_name ); ?></td><td><?php echo esc_html( $r->contact_email ); ?></td><td><?php echo esc_html( $r->alternate_name ); ?></td><td><?php echo $n ? (int) $n : '<span style="color:#b32d2e">0 — no paid member</span>'; // phpcs:ignore ?></td></tr>
	<?php endforeach; ?>
	</tbody></table></div>
	<?php
}

add_action( 'admin_post_usucger_inst_save', function () {
	usucger_check( 'usucger_inst_save', 'usucger_manage' );
	global $wpdb;
	$t  = Usucger_DB::t( 'institutions' );
	$p  = wp_unslash( $_POST );
	$id = (int) $p['id'];
	$d  = array(
		'name'          => sanitize_text_field( $p['name'] ),
		'state'         => isset( usucger_state_names()[ $p['state'] ] ) ? $p['state'] : '',
		'contact_name'  => sanitize_text_field( $p['contact_name'] ),
		'contact_email' => sanitize_email( $p['contact_email'] ),
		'alternate_name'  => sanitize_text_field( $p['alternate_name'] ),
		'alternate_email' => sanitize_email( $p['alternate_email'] ),
		'aliases'       => sanitize_text_field( $p['aliases'] ),
		'status'        => 'former' === $p['status'] ? 'former' : 'member',
		'notes'         => sanitize_textarea_field( $p['notes'] ),
		'updated'       => current_time( 'mysql' ),
	);
	if ( $id ) {
		$wpdb->update( $t, $d, array( 'id' => $id ) );
	} else {
		$wpdb->insert( $t, $d );
		$id = $wpdb->insert_id;
	}
	Usucger_DB::log( 'institution_saved', 'institution:' . $id, $d['name'] );
	usucger_bump_content_version();
	usucger_back( usucger_admin_url( 'usucger-institutions' ), 'Saved.' );
} );
