<?php
/**
 * USUCGER → Activity log: who approved, sent, changed or voted-on what (never how anyone voted).
 *
 * @package usucger-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'admin_menu', function () {
	add_submenu_page( 'usucger', 'Activity log', 'Activity log', 'usucger_manage', 'usucger-log', 'usucger_page_log' );
}, 12 );

function usucger_log_query( $args, $limit = 100, $offset = 0 ) {
	global $wpdb;
	$t     = Usucger_DB::t( 'log' );
	$where = array( '1=1' );
	$vals  = array();
	if ( ! empty( $args['action'] ) ) {
		$where[] = 'action = %s';
		$vals[]  = $args['action'];
	}
	if ( ! empty( $args['user'] ) ) {
		$where[] = 'user_id = %d';
		$vals[]  = (int) $args['user'];
	}
	if ( ! empty( $args['from'] ) ) {
		$where[] = 'time >= %s';
		$vals[]  = $args['from'] . ' 00:00:00';
	}
	if ( ! empty( $args['to'] ) ) {
		$where[] = 'time <= %s';
		$vals[]  = $args['to'] . ' 23:59:59';
	}
	if ( ! empty( $args['q'] ) ) {
		$where[] = '(object LIKE %s OR detail LIKE %s)';
		$like    = '%' . $wpdb->esc_like( $args['q'] ) . '%';
		$vals[]  = $like;
		$vals[]  = $like;
	}
	$sql   = "FROM $t WHERE " . implode( ' AND ', $where );
	$total = (int) $wpdb->get_var( $vals ? $wpdb->prepare( "SELECT COUNT(*) $sql", $vals ) : "SELECT COUNT(*) $sql" ); // phpcs:ignore WordPress.DB
	$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT * $sql ORDER BY id DESC LIMIT %d OFFSET %d", array_merge( $vals, array( $limit, $offset ) ) ) ); // phpcs:ignore WordPress.DB
	return array( $rows, $total );
}

function usucger_log_args() {
	$g = function ( $k ) {
		return isset( $_GET[ $k ] ) ? sanitize_text_field( wp_unslash( $_GET[ $k ] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	};
	$a = array( 'action' => sanitize_key( $g( 'act' ) ), 'user' => (int) $g( 'u' ), 'from' => $g( 'from' ), 'to' => $g( 'to' ), 'q' => $g( 'q' ) );
	foreach ( array( 'from', 'to' ) as $k ) {
		if ( $a[ $k ] && ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $a[ $k ] ) ) {
			$a[ $k ] = '';
		}
	}
	return $a;
}

function usucger_log_detail( $d ) {
	$j = json_decode( (string) $d, true );
	if ( is_array( $j ) ) {
		$parts = array();
		foreach ( $j as $k => $v ) {
			$parts[] = ( is_int( $k ) ? '' : $k . ': ' ) . ( is_scalar( $v ) ? $v : wp_json_encode( $v ) );
		}
		return implode( ' · ', $parts );
	}
	return (string) $d;
}

function usucger_page_log() {
	global $wpdb;
	$a     = usucger_log_args();
	$page  = max( 1, isset( $_GET['paged'] ) ? (int) $_GET['paged'] : 1 ); // phpcs:ignore WordPress.Security.NonceVerification
	list( $rows, $total ) = usucger_log_query( $a, 100, ( $page - 1 ) * 100 );
	$t       = Usucger_DB::t( 'log' );
	$actions = $wpdb->get_col( "SELECT DISTINCT action FROM $t ORDER BY action" ); // phpcs:ignore WordPress.DB
	$uids    = $wpdb->get_col( "SELECT DISTINCT user_id FROM $t WHERE user_id > 0" ); // phpcs:ignore WordPress.DB
	echo '<div class="wrap usg-wrap"><h1>Activity log</h1><p class="usg-help">Every approval, email batch, membership sync, election step and data fix is recorded here with who did it. Ballot choices are never logged.</p>';
	echo '<form method="get" class="usg-filters"><input type="hidden" name="page" value="usucger-log">';
	echo '<select name="act" aria-label="Action"><option value="">All actions</option>';
	foreach ( $actions as $x ) {
		echo '<option value="' . esc_attr( $x ) . '"' . selected( $a['action'], $x, false ) . '>' . esc_html( usucger_log_label( $x ) ) . '</option>';
	}
	echo '</select> <select name="u" aria-label="Person"><option value="">Anyone</option>';
	foreach ( $uids as $uid ) {
		$u = get_userdata( $uid );
		echo '<option value="' . (int) $uid . '"' . selected( $a['user'], (int) $uid, false ) . '>' . esc_html( $u ? $u->display_name : '#' . $uid ) . '</option>';
	}
	echo '</select> <label>From <input type="date" name="from" value="' . esc_attr( $a['from'] ) . '"></label> <label>to <input type="date" name="to" value="' . esc_attr( $a['to'] ) . '"></label> <input type="search" name="q" aria-label="Search" value="' . esc_attr( $a['q'] ) . '" placeholder="Search object or detail"> <button class="button">Filter</button> ';
	echo '<a class="button" href="' . esc_url( wp_nonce_url( add_query_arg( array_filter( array( 'action' => 'usucger_log_csv', 'act' => $a['action'], 'u' => $a['user'], 'from' => $a['from'], 'to' => $a['to'], 'q' => $a['q'] ) ), admin_url( 'admin-post.php' ) ), 'usucger_log_csv' ) ) . '">Download CSV</a></form>';
	echo '<p class="description">' . (int) $total . ' entries</p><table class="widefat striped"><thead><tr><th style="width:150px">When</th><th style="width:140px">Who</th><th style="width:200px">What</th><th style="width:180px">Object</th><th>Detail</th></tr></thead><tbody>';
	if ( ! $rows ) {
		echo '<tr><td colspan="5">No entries.</td></tr>';
	}
	foreach ( $rows as $r ) {
		$u = $r->user_id ? get_userdata( $r->user_id ) : null;
		echo '<tr><td>' . esc_html( $r->time ) . '</td><td>' . esc_html( $u ? $u->display_name : ( $r->user_id ? '#' . $r->user_id : 'system' ) ) . '</td><td>' . esc_html( usucger_log_label( $r->action ) ) . '</td><td>' . usucger_log_object( $r->object ) . '</td><td>' . esc_html( wp_html_excerpt( usucger_log_detail( $r->detail ), 300, '…' ) ) . '</td></tr>';
	}
	echo '</tbody></table>';
	$pages = (int) ceil( $total / 100 );
	if ( $pages > 1 ) {
		echo '<p class="tablenav-pages" style="margin-top:10px">' . paginate_links( array( 'base' => add_query_arg( 'paged', '%#%' ), 'format' => '', 'current' => $page, 'total' => $pages ) ) . '</p>'; // phpcs:ignore
	}
	echo '</div>';
}

add_action( 'admin_post_usucger_log_csv', function () {
	usucger_check( 'usucger_log_csv', 'usucger_manage' );
	list( $rows ) = usucger_log_query( usucger_log_args(), 50000 );
	nocache_headers();
	header( 'Content-Type: text/csv; charset=utf-8' );
	header( 'Content-Disposition: attachment; filename="usucger-activity-' . gmdate( 'Y-m-d' ) . '.csv"' );
	$out = fopen( 'php://output', 'w' );
	fwrite( $out, "\xEF\xBB\xBF" );
	fputcsv( $out, array( 'time', 'user', 'action', 'object', 'detail' ) );
	foreach ( $rows as $r ) {
		$u = $r->user_id ? get_userdata( $r->user_id ) : null;
		fputcsv( $out, array( $r->time, $u ? $u->user_login : ( $r->user_id ? $r->user_id : 'system' ), $r->action, usucger_csv_safe( $r->object ), usucger_csv_safe( usucger_log_detail( $r->detail ) ) ) );
	}
	fclose( $out ); // phpcs:ignore
	exit;
} );

/* Keep the log for 3 years. */
add_action( 'usucger_daily', function () {
	global $wpdb;
	$t = Usucger_DB::t( 'log' );
	$wpdb->query( $wpdb->prepare( "DELETE FROM $t WHERE time < %s", gmdate( 'Y-m-d H:i:s', strtotime( '-3 years' ) ) ) );
} );

/** Plain words for log action keys (unknown keys are shown with spaces). */
function usucger_log_label( $k ) {
	$map = array(
		'wcm_sync'          => 'Membership sync from the store',
		'retention_purge'   => 'Old email text / ballot links cleared',
		'login_code_sent'   => 'Sign-in code emailed',
		'login_code_ok'     => 'Signed in with code',
		'login_code_locked' => 'Sign-in code: too many wrong tries',
		'login_code_blocked' => 'Sign-in blocked (too many wrong codes)',
		'login_link_used'   => 'Signed in with an email link',
		'ballot_cast'       => 'Institution ballot recorded',
		'voter_roll_built'  => 'Voter roll refreshed',
		'alternate_named'   => 'Delegate named an alternate',
		'email_bounced'     => 'Email address bounced',
		'email_complaint'   => 'Spam complaint received',
		'data_download'     => 'Member downloaded their data',
		'staging_mail_held' => 'Email held (staging copy)',
		'divi_pages_retired' => 'Old Divi pages moved to Draft',
	);
	return isset( $map[ $k ] ) ? $map[ $k ] : ucfirst( str_replace( '_', ' ', $k ) );
}

/** Object column: "post:12" → linked title, "user:3" → name, etc. */
function usucger_log_object( $o ) {
	if ( preg_match( '/^(post|user|batch|election|contact|institution):(\d+)$/', (string) $o, $m ) ) {
		$id = (int) $m[2];
		switch ( $m[1] ) {
			case 'post':
				$p = get_post( $id );
				return $p ? '<a href="' . esc_url( get_edit_post_link( $id ) ? get_edit_post_link( $id ) : usucger_admin_url( 'usucger-submissions', array( 'view' => $id ) ) ) . '">' . esc_html( $p->post_title ) . '</a>' : esc_html( $o );
			case 'user':
				$u = get_userdata( $id );
				return $u ? esc_html( $u->display_name ) : esc_html( $o );
			case 'batch':
				return '<a href="' . esc_url( usucger_admin_url( 'usucger-outbox', array( 'batch' => $id ) ) ) . '">Email #' . $id . '</a>';
			case 'election':
				$e = function_exists( 'usucger_election' ) ? usucger_election( $id ) : null;
				return $e ? '<a href="' . esc_url( usucger_admin_url( 'usucger-elections', array( 'id' => $id ) ) ) . '">' . esc_html( $e->title ) . '</a>' : esc_html( $o );
			case 'contact':
				$c = Usucger_Members::get( $id );
				return $c ? '<a href="' . esc_url( usucger_admin_url( 'usucger-members', array( 'edit' => $id ) ) ) . '">' . esc_html( trim( $c->first_name . ' ' . $c->last_name ) ? trim( $c->first_name . ' ' . $c->last_name ) : $c->email ) . '</a>' : esc_html( $o );
		}
	}
	return '<code>' . esc_html( $o ) . '</code>';
}
