<?php
/**
 * USUCGER → Review queue.
 *
 * @package usucger-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function usucger_page_review() {
	$diff = isset( $_GET['diff'] ) ? (int) $_GET['diff'] : 0; // phpcs:ignore WordPress.Security.NonceVerification
	echo '<div class="wrap usg-wrap">';
	if ( $diff ) {
		usucger_review_diff( $diff );
		echo '</div>';
		return;
	}
	echo '<h1>Review queue</h1><p class="usg-help">Board members edit drafts; nothing reaches the website until it is approved here. Approving changes to a live page keeps the previous version under <em>Revisions</em>, so it can always be restored.</p>';
	$items = usucger_review_items();
	if ( ! usucger_can_approve() ) {
		$items = get_posts( array( 'post_type' => usucger_reviewed_types(), 'post_status' => array( 'draft', 'pending' ), 'author' => get_current_user_id(), 'posts_per_page' => 100 ) );
		echo '<h2>Your drafts and submissions</h2>';
	} else {
		echo '<h2>Waiting for approval</h2>';
	}
	echo '<table class="widefat striped"><thead><tr><th>Title</th><th>Type</th><th>What</th><th>By</th><th>Updated</th><th>Status</th><th></th></tr></thead><tbody>';
	if ( ! $items ) {
		echo '<tr><td colspan="7">Nothing here.</td></tr>';
	}
	foreach ( $items as $p ) {
		$of   = (int) get_post_meta( $p->ID, '_usucger_cr_of', true );
		$u    = get_userdata( $p->post_author );
		$note = get_post_meta( $p->ID, '_usucger_review_note', true );
		echo '<tr><td><strong><a href="' . esc_url( get_edit_post_link( $p->ID ) ) . '">' . esc_html( $p->post_title ) . '</a></strong>' . ( $note ? '<br><em style="color:#996800">Returned: ' . esc_html( wp_trim_words( $note, 14 ) ) . '</em>' : '' ) . '</td>';
		echo '<td>' . esc_html( get_post_type_object( $p->post_type )->labels->singular_name ) . '</td>';
		echo '<td>' . ( $of ? 'Changes to a live item' : 'New' ) . '</td>';
		echo '<td>' . esc_html( usucger_post_by( $p ) ) . '</td>';
		echo '<td>' . esc_html( usucger_post_ago( $p ) ) . '</td>';
		echo '<td>' . usucger_pill( $p->post_status ) . '</td><td style="white-space:nowrap">'; // phpcs:ignore
		if ( $of ) {
			echo '<a class="button" href="' . esc_url( usucger_admin_url( 'usucger-review', array( 'diff' => $p->ID ) ) ) . '">Compare</a> ';
		}
		if ( usucger_can_approve() ) {
			echo '<a class="button button-primary" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=usucger_approve&post=' . $p->ID . '&back=' . rawurlencode( usucger_admin_url( 'usucger-review' ) ) ), 'usucger_approve_' . $p->ID ) ) . '">Approve</a>';
		}
		echo '</td></tr>';
	}
	echo '</tbody></table>';

	if ( usucger_can_approve() ) {
		$drafts = get_posts( array( 'post_type' => usucger_reviewed_types(), 'post_status' => 'draft', 'posts_per_page' => 30, 'author__not_in' => array( get_current_user_id() ), 'meta_key' => '_usucger_cr_of', 'meta_compare' => 'EXISTS' ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
		if ( $drafts ) {
			echo '<h2 style="margin-top:2em">Changes still being drafted by Board members</h2><ul>';
			foreach ( $drafts as $p ) {
				$u = get_userdata( $p->post_author );
				echo '<li><a href="' . esc_url( get_edit_post_link( $p->ID ) ) . '">' . esc_html( $p->post_title ) . '</a> — ' . esc_html( $u ? $u->display_name : '' ) . ', ' . esc_html( usucger_post_ago( $p ) ) . '</li>';
			}
			echo '</ul>';
		}
	}
	echo '</div>';
}

function usucger_review_diff( $id ) {
	$copy = get_post( $id );
	$of   = $copy ? (int) get_post_meta( $id, '_usucger_cr_of', true ) : 0;
	$orig = $of ? get_post( $of ) : null;
	if ( ! $copy || ! $orig || ! current_user_can( 'edit_post', $id ) && ! usucger_can_approve() ) {
		echo '<p>Nothing to compare.</p>';
		return;
	}
	echo '<h1>Proposed changes: ' . esc_html( $orig->post_title ) . '</h1>';
	echo '<p><a href="' . esc_url( usucger_admin_url( 'usucger-review' ) ) . '">&larr; Review queue</a> · <a href="' . esc_url( get_permalink( $orig ) ) . '" target="_blank">Live page</a> · <a href="' . esc_url( get_preview_post_link( $copy ) ) . '" target="_blank">Preview proposed version</a> · <a href="' . esc_url( get_edit_post_link( $copy->ID ) ) . '">Edit proposed version</a></p>';
	$pairs = array(
		'Title'   => array( $orig->post_title, $copy->post_title ),
		'Content' => array( $orig->post_content, $copy->post_content ),
	);
	$keys = array_unique( array_merge( array_keys( get_post_meta( $of ) ), array_keys( get_post_meta( $id ) ) ) );
	foreach ( $keys as $k ) {
		if ( in_array( $k, array( '_edit_lock', '_edit_last', '_usucger_cr_of', '_usucger_review_note', '_wp_old_slug' ), true ) ) {
			continue;
		}
		$a = get_post_meta( $of, $k, true );
		$b = get_post_meta( $id, $k, true );
		if ( $a !== $b ) {
			$pairs[ 'Setting: ' . $k ] = array( is_scalar( $a ) ? (string) $a : wp_json_encode( $a, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ), is_scalar( $b ) ? (string) $b : wp_json_encode( $b, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ) );
		}
	}
	$any = false;
	echo '<div class="usg-card usg-diff">';
	foreach ( $pairs as $label => $ab ) {
		$d = wp_text_diff( $ab[0], $ab[1], array( 'title_left' => 'Live now', 'title_right' => 'Proposed' ) );
		if ( $d ) {
			$any = true;
			echo '<h2>' . esc_html( $label ) . '</h2>' . $d; // phpcs:ignore
		}
	}
	if ( ! $any ) {
		echo '<p>No differences yet.</p>';
	}
	echo '</div>';
	if ( usucger_can_approve() ) {
		echo '<p><a class="button button-primary button-large" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=usucger_approve&post=' . $id . '&back=' . rawurlencode( usucger_admin_url( 'usucger-review' ) ) ), 'usucger_approve_' . $id ) ) . '">Approve changes &amp; update live page</a></p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="max-width:640px"><input type="hidden" name="action" value="usucger_return"><input type="hidden" name="post" value="' . (int) $id . '"><input type="hidden" name="back" value="' . esc_attr( usucger_admin_url( 'usucger-review' ) ) . '">';
		wp_nonce_field( 'usucger_return_' . $id );
		echo '<p><textarea name="note" rows="3" class="large-text" placeholder="Note to the author"></textarea></p><p><button class="button">Return with note</button></p></form>';
	}
}
