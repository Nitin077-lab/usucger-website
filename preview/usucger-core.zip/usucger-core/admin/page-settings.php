<?php
/**
 * USUCGER → Settings and → Setup & import.
 *
 * @package usucger-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function usucger_page_settings() {
	$o     = usucger_core_opts();
	$plans = Usucger_Members::plans();
	$map   = usucger_map_settings();
	$f     = function ( $k, $label, $type = 'text', $help = '' ) use ( $o ) {
		$v = isset( $o[ $k ] ) ? $o[ $k ] : '';
		echo '<tr><th><label for="usg_' . esc_attr( $k ) . '">' . esc_html( $label ) . '</label></th><td>';
		if ( 'checkbox' === $type ) {
			echo '<label><input type="checkbox" id="usg_' . esc_attr( $k ) . '" name="o[' . esc_attr( $k ) . ']" value="1"' . checked( $v, 1, false ) . '> ' . wp_kses_post( $help ) . '</label>';
		} else {
			echo '<input type="' . esc_attr( $type ) . '" class="regular-text" id="usg_' . esc_attr( $k ) . '" name="o[' . esc_attr( $k ) . ']" value="' . esc_attr( $v ) . '">';
			if ( $help ) {
				echo '<p class="description">' . wp_kses_post( $help ) . '</p>';
			}
		}
		echo '</td></tr>';
	};
	?>
	<div class="wrap usg-wrap">
		<h1>USUCGER settings</h1>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="usucger_settings"><?php wp_nonce_field( 'usucger_settings' ); ?>
			<h2 class="title">Contact</h2>
			<table class="form-table"><tbody>
				<?php
				$f( 'contact_email', 'Webmaster / contact email', 'email' );
				$f( 'board_email', 'Board email', 'email' );
				$f( 'credit', 'Footer credit line' );
				?>
			</tbody></table>

			<h2 class="title">Email sending</h2>
			<?php if ( ! class_exists( 'WPMailSMTP\\Core' ) && ! defined( 'POST_SMTP_VER' ) && ! class_exists( 'FluentMail\\App\\App' ) ) : ?>
				<div class="notice notice-warning inline"><p><strong>Recommended before sending to members:</strong> install an SMTP plugin (e.g. WP Mail SMTP) connected to an email service such as Amazon SES, Postmark, Brevo or Google Workspace, and add SPF/DKIM records for usucger.org. Without it, bulk email from the web server is likely to land in spam.</p></div>
			<?php endif; ?>
			<table class="form-table"><tbody>
				<?php
				$f( 'from_name', 'From name' );
				$f( 'from_email', 'From address', 'email', 'Must be an address on a domain your SMTP service is allowed to send for.' );
				$f( 'reply_to', 'Reply-to address', 'email' );
				$f( 'notify_emails', 'Send approval requests to', 'text', 'Comma-separated. Empty = every administrator.' );
				$f( 'batch_size', 'Emails per minute', 'number', 'Outbox sends this many per minute (default 20).' );
				$f( 'letter_color', 'Letterhead accent color', 'text', 'Hex, e.g. #C2410C (Core Sample orange).' );
				$f( 'signer_name', 'Signature name' );
				$f( 'signer_title', 'Signature title' );
				$f( 'mailing_address', 'Footer line' );
				$f( 'annual_meeting', 'Annual meeting (for emails)', 'text', 'Fills <code>{annual_meeting}</code>, e.g. "the USUCGER Annual Meeting at the ASCE Conference (ASCE2027) in Philadelphia".' );
				?>
			</tbody></table>

			<h2 class="title">Membership</h2>
			<table class="form-table"><tbody>
				<?php
				$f( 'cycle', 'Current cycle label', 'text', 'e.g. 2025–2027' );
				$f( 'cycle_end', 'Current cycle ends', 'date' );
				$f( 'dues', 'Dues label', 'text', 'e.g. $75' );
				$f( 'join_univ', 'Join/renew link — U.S. university members', 'url' );
				$f( 'join_assoc', 'Join/renew link — associate members', 'url' );
				$f( 'renew_url', 'Link used by the Renew button in emails', 'url', 'Empty = the university link.' );
				?>
				<tr><th>WooCommerce Memberships plans</th><td>
				<?php if ( $plans ) : ?>
					<table class="widefat" style="max-width:640px"><thead><tr><th>Plan</th><th>Current cycle</th><th>Earlier cycle (remind if not renewed)</th></tr></thead><tbody>
					<?php foreach ( $plans as $pid => $pn ) : ?>
						<tr><td><?php echo esc_html( $pn ); ?> <small>#<?php echo (int) $pid; ?></small></td>
						 <td><input type="checkbox" aria-label="<?php echo esc_attr( $pn . ': current cycle' ); ?>" name="o[current_plans][]" value="<?php echo (int) $pid; ?>" <?php checked( in_array( (int) $pid, array_map( 'intval', (array) $o['current_plans'] ), true ) ); ?>></td>
						<td><input type="checkbox" aria-label="<?php echo esc_attr( $pn . ': earlier cycle' ); ?>" name="o[previous_plans][]" value="<?php echo (int) $pid; ?>" <?php checked( in_array( (int) $pid, array_map( 'intval', (array) $o['previous_plans'] ), true ) ); ?>></td></tr>
					<?php endforeach; ?>
					</tbody></table>
					<p class="description">Tick the 2025–2027 plans as current and the 2022–2024 (and older) plans as earlier. If nothing is ticked, any active membership counts as current and any expired one as "not renewed".</p>
				<?php else : ?>
					<p class="description">No membership plans found (WooCommerce Memberships is not active here). Members are managed under USUCGER → Members.</p>
				<?php endif; ?>
				</td></tr>
				<?php
				$f( 'institution_meta', 'User field holding the institution', 'text', 'User meta key, default <code>billing_company</code> (the "Company" field at checkout).' );
				$f( 'grace_days', 'Grace period before removal (days)', 'number' );
				$f( 'auto_sync', 'Daily sync', 'checkbox', 'Sync from WooCommerce Memberships every day and whenever a membership changes' );
				$f( 'auto_queue_plan', 'Scheduled reminders', 'checkbox', 'Send scheduled renewal reminders without waiting for approval' );
				?>
			</tbody></table>

			<h2 class="title">Board editing</h2>
			<table class="form-table"><tbody>
				<?php
				$f( 'board_unfiltered', 'Full HTML for Board members', 'checkbox', 'Board members can keep the page layout HTML when they edit (their changes are still reviewed)' );
				$f( 'board_can_send', 'Skip approval for Board emails', 'checkbox', 'Emails composed by Board members are sent without approval' );
				$f( 'position_days', 'Keep positions listed for (days)', 'number' );
				$f( 'track_views', 'Page-view counter', 'checkbox', 'Count page views (no cookies, no IP addresses)' );
				$f( 'delete_on_uninstall', 'On plugin deletion', 'checkbox', 'Delete all USUCGER data (members, emails, elections) when the plugin is deleted. Leave off to keep data.' );
				?>
			</tbody></table>

			<h2 class="title">Online forms</h2>
			<table class="form-table"><tbody>
				<?php
				$f( 'form_positions', 'Post a position', 'checkbox', '“Post a position” buttons open the <a href="' . esc_url( usucger_core_url( 'post-a-position' ) ) . '">online form</a> (listing goes to the review queue) instead of an email' );
				$f( 'form_awards', 'Award nominations', 'checkbox', 'The awards page links to the <a href="' . esc_url( usucger_core_url( 'nominate' ) ) . '">online nomination form</a> (needs an open deadline whose name contains “award”)' );
				$f( 'form_travel', 'Travel grant applications', 'checkbox', 'Use the <a href="' . esc_url( usucger_core_url( 'travel-grant-application' ) ) . '">online application</a> instead of the Google Form (needs an open deadline whose name contains “travel”)' );
				?>
			</tbody></table>

			<h2 class="title">Staging copy (Board review)</h2>
			<table class="form-table"><tbody>
				<tr><th><label for="usg_staging_mode">Staging mode</label></th><td><select id="usg_staging_mode" name="o[staging_mode]"><?php foreach ( array( 'auto' => 'Automatic (on for staging addresses such as staging1.usucger.org)', 'on' => 'On', 'off' => 'Off' ) as $k => $l ) { echo '<option value="' . esc_attr( $k ) . '"' . selected( $o['staging_mode'], $k, false ) . '>' . esc_html( $l ) . '</option>'; } ?></select>
				<p class="description">Right now: <strong><?php echo usucger_is_staging() ? 'ON — emails go only to the addresses below; checkout is off' : 'off — this is treated as the live site'; ?></strong></p></td></tr>
				<tr><th><label for="usg_staging_allow">Also allow email to</label></th><td><textarea id="usg_staging_allow" name="o[staging_allow]" rows="3" class="large-text code"><?php echo esc_textarea( $o['staging_allow'] ); ?></textarea>
				<p class="description">Administrators, Board members, the Membership Coordinator, approvers and election officers are always allowed. Add anyone else who is testing (one address per line). Everything else is held and listed in the Activity log.</p></td></tr>
			</tbody></table>

			<h2 class="title">Security &amp; data</h2>
			<table class="form-table"><tbody>
				<?php
				$f( 'two_factor', 'Sign-in code', 'checkbox', 'Administrators, approvers, election officers, Board members and the Membership Coordinator get a 6-digit code by email when they sign in (a browser can be trusted for 30 days)' . ( defined( 'USUCGER_DISABLE_2FA' ) ? ' — <strong>currently switched off by USUCGER_DISABLE_2FA in wp-config.php</strong>' : '' ) );
				$f( 'bounce_secret', 'Bounce webhook secret', 'text', 'Paste this into your email service’s bounce/complaint webhook as <code>' . esc_html( rest_url( 'usucger/v1/bounce' ) ) . '?key=SECRET</code>. Empty = webhook off. Bounced addresses are skipped and listed under Data cleanup.' );
				$f( 'retention_days', 'Keep sent email text for (days)', 'number', 'After this, the body of each sent email is cleared from the outbox (who/when/subject are kept).' );
				$f( 'token_purge_days', 'Clear ballot links after certification (days)', 'number', 'Ballot links stop existing this long after results are certified; votes and receipts are kept.' );
				?>
			</tbody></table>

			<h2 class="title">Approvers</h2>
			<table class="form-table"><tbody>
				<tr><th>President and co-approvers</th><td>
				<?php
				$appr   = array_map( 'intval', (array) $o['approvers'] );
				$titles = (array) ( isset( $o['approver_titles'] ) ? $o['approver_titles'] : array() );
				foreach ( get_users( array( 'role__in' => array( 'usucger_board', 'editor', 'subscriber', 'customer' ), 'orderby' => 'display_name', 'number' => 400 ) ) as $au ) {
					if ( ! in_array( 'usucger_board', (array) $au->roles, true ) && ! in_array( (int) $au->ID, $appr, true ) ) {
						continue; // list Board members (and anyone already chosen)
					}
					echo '<label style="display:block;margin:3px 0"><input type="checkbox" name="o[approvers][]" value="' . (int) $au->ID . '"' . checked( in_array( (int) $au->ID, $appr, true ), true, false ) . '> ' . esc_html( $au->display_name . ' (' . $au->user_email . ')' ) . ' — title <input type="text" name="approver_titles[' . (int) $au->ID . ']" value="' . esc_attr( isset( $titles[ $au->ID ] ) ? $titles[ $au->ID ] : ( in_array( (int) $au->ID, $appr, true ) ? 'President' : '' ) ) . '" placeholder="e.g. President" aria-label="' . esc_attr( 'Title shown for ' . $au->display_name ) . '" style="width:140px"></label>';
				}
				?>
				<p class="description">Same approval authority as the webmaster: approve website changes and emails, manage members, run elections. They cannot change these settings, plugins or user accounts. Approvals only happen while signed in — approval notices link to the desk, never to a one-click link — and every approval is logged with the approver's name.</p></td></tr>
			</tbody></table>

			<h2 class="title">Elections</h2>
			<table class="form-table"><tbody>
				<tr><th>Election officer(s)</th><td>
				<?php
				$officers = array_map( 'intval', (array) $o['election_officers'] );
				foreach ( get_users( array( 'role__in' => array( 'administrator', 'usucger_board', 'editor' ), 'orderby' => 'display_name' ) ) as $eu ) {
					echo '<label style="display:block"><input type="checkbox" name="o[election_officers][]" value="' . (int) $eu->ID . '"' . checked( in_array( (int) $eu->ID, $officers, true ), true, false ) . '> ' . esc_html( $eu->display_name . ' (' . $eu->user_email . ')' ) . '</label>';
				}
				?>
				<p class="description">Officers manage nominees, request candidate statements, approve election emails, and certify results. They are notified of nominations and submissions.</p></td></tr>
			</tbody></table>

			<h2 class="title">Old website addresses (301 redirects)</h2>
			<table class="form-table"><tbody><tr><th>Redirects</th><td><textarea name="redirects" aria-label="Redirects" rows="8" class="large-text code"><?php foreach ( usucger_redirects() as $rf => $rt ) { echo esc_textarea( $rf . ' => ' . $rt ) . "\n"; } ?></textarea><p class="description">One per line: <code>/old-address/ => /new-address/</code>. Used only when the old address no longer exists, so search engines and bookmarks keep working.</p></td></tr></tbody></table>

			<h2 class="title">Member map</h2>
			<table class="form-table"><tbody>
				<tr><th>Affiliations placed in a state</th><td><textarea name="map_other" aria-label="Affiliations placed in a state" rows="6" class="large-text code"><?php
				foreach ( $map['other'] as $a => $st ) {
					echo esc_textarea( $a . ' | ' . $st ) . "\n";
				}
				?></textarea><p class="description">For members whose affiliation is not a member university: <code>Affiliation | ST</code> (use INTL for international).</p></td></tr>
				<tr><th>Affiliation aliases</th><td><textarea name="map_aliases" aria-label="Affiliation aliases" rows="4" class="large-text code"><?php
				foreach ( $map['aliases'] as $a => $u ) {
					echo esc_textarea( $a . ' = ' . $u ) . "\n";
				}
				?></textarea><p class="description"><code>Name as typed = Member university name</code></p></td></tr>
			</tbody></table>
			<p><button class="button button-primary">Save settings</button></p>
		</form>
	</div>
	<?php
}

add_action( 'admin_post_usucger_settings', function () {
	usucger_check( 'usucger_settings', 'manage_options' );
	$in  = isset( $_POST['o'] ) ? (array) wp_unslash( $_POST['o'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	$def = usucger_core_defaults();
	$new = array();
	foreach ( $def as $k => $d ) {
		$v = isset( $in[ $k ] ) ? $in[ $k ] : null;
		if ( is_array( $d ) ) {
			$new[ $k ] = array_map( 'intval', (array) $v );
		} elseif ( is_int( $d ) && in_array( $k, array( 'board_unfiltered', 'board_can_send', 'auto_sync', 'auto_queue_plan', 'track_views', 'delete_on_uninstall', 'form_positions', 'form_awards', 'form_travel', 'two_factor' ), true ) ) {
			$new[ $k ] = $v ? 1 : 0;
		} elseif ( is_int( $d ) ) {
			$new[ $k ] = max( 0, (int) $v );
		} elseif ( in_array( $k, array( 'join_univ', 'join_assoc', 'renew_url' ), true ) ) {
			$new[ $k ] = esc_url_raw( (string) $v );
		} elseif ( in_array( $k, array( 'contact_email', 'board_email', 'from_email', 'reply_to' ), true ) ) {
			$new[ $k ] = sanitize_email( (string) $v );
		} elseif ( 'staging_allow' === $k ) {
			$new[ $k ] = sanitize_textarea_field( (string) $v );
		} elseif ( 'staging_mode' === $k ) {
			$new[ $k ] = in_array( $v, array( 'auto', 'on', 'off' ), true ) ? $v : 'auto';
		} else {
			$new[ $k ] = sanitize_text_field( (string) $v );
		}
	}
	$new['batch_size'] = max( 1, min( 200, $new['batch_size'] ) );
	$titles = array();
	foreach ( (array) ( isset( $_POST['approver_titles'] ) ? wp_unslash( $_POST['approver_titles'] ) : array() ) as $uid => $t ) { // phpcs:ignore
		$titles[ (int) $uid ] = sanitize_text_field( $t );
	}
	$new['approver_titles'] = $titles;
	usucger_core_save_opts( $new );
	usucger_core_roles(); // re-apply Board capabilities

	$map = array( 'other' => array(), 'aliases' => array() );
	foreach ( preg_split( '/\r?\n/', (string) wp_unslash( isset( $_POST['map_other'] ) ? $_POST['map_other'] : '' ) ) as $line ) { // phpcs:ignore
		$p = array_map( 'trim', explode( '|', $line ) );
		if ( 2 === count( $p ) && $p[0] && isset( usucger_state_names()[ strtoupper( $p[1] ) ] ) ) {
			$map['other'][ sanitize_text_field( $p[0] ) ] = strtoupper( $p[1] );
		}
	}
	foreach ( preg_split( '/\r?\n/', (string) wp_unslash( isset( $_POST['map_aliases'] ) ? $_POST['map_aliases'] : '' ) ) as $line ) { // phpcs:ignore
		$p = array_map( 'trim', explode( '=', $line, 2 ) );
		if ( 2 === count( $p ) && $p[0] && $p[1] ) {
			$map['aliases'][ sanitize_text_field( $p[0] ) ] = sanitize_text_field( $p[1] );
		}
	}
	update_option( 'usucger_map', $map, false );
	$red = array();
	foreach ( preg_split( '/\r?\n/', (string) wp_unslash( isset( $_POST['redirects'] ) ? $_POST['redirects'] : '' ) ) as $line ) { // phpcs:ignore
		$p = array_map( 'trim', explode( '=>', $line, 2 ) );
		if ( 2 === count( $p ) && $p[0] && $p[1] ) {
			$red[ '/' . trim( sanitize_text_field( $p[0] ), '/' ) . '/' ] = esc_url_raw( $p[1] ) && preg_match( '#^https?://#', $p[1] ) ? esc_url_raw( $p[1] ) : '/' . trim( sanitize_text_field( $p[1] ), '/' ) . '/';
		}
	}
	update_option( 'usucger_redirects', $red, false );
	usucger_bump_content_version();
	usucger_back( usucger_admin_url( 'usucger-settings' ), 'Settings saved.' );
} );

/* ===================================================================== setup */

function usucger_page_setup() {
	$imp    = get_option( 'usucger_imported' );
	$theme  = wp_get_theme();
	$checks = array(
		array( 'USUCGER theme active', 'usucger' === get_template(), 'Appearance → Themes → USUCGER → Activate.' ),
		array( 'Pretty permalinks', (bool) get_option( 'permalink_structure' ), 'Settings → Permalinks → "Post name".' ),
		array( 'WooCommerce active', class_exists( 'WooCommerce' ), 'Needed for dues checkout.' ),
		array( 'WooCommerce Memberships active', Usucger_Members::wcm_active(), 'Needed for automatic member status.' ),
		array( 'Membership plans mapped', (bool) usucger_core_opt( 'current_plans' ), 'USUCGER → Settings → Membership: tick current and earlier plans.' ),
		array( 'SMTP plugin for email', class_exists( 'WPMailSMTP\\Core' ) || defined( 'POST_SMTP_VER' ) || class_exists( 'FluentMail\\App\\App' ), 'Install WP Mail SMTP (or similar) with SES/Postmark/Brevo; add SPF + DKIM.' ),
		array( 'Outbox timer scheduled', (bool) wp_next_scheduled( 'usucger_tick' ), 'Deactivate and reactivate the plugin.' ),
		array( 'Real cron (recommended)', defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON, 'On SiteGround: Devs → Cron Jobs → every minute: <code>wget -q -O - ' . esc_html( site_url( 'wp-cron.php?doing_wp_cron' ) ) . ' &gt;/dev/null 2&gt;&amp;1</code> and add <code>define(\'DISABLE_WP_CRON\', true);</code> to wp-config.php. Without it, emails send only when someone visits the site.' ),
	);
	?>
	<div class="wrap usg-wrap">
		<h1>Setup &amp; import</h1>
		<div class="usg-card">
			<h2>Checklist</h2>
			<table class="widefat striped"><tbody>
			<?php foreach ( $checks as $c ) : ?>
				<tr><td style="width:28px"><?php echo $c[1] ? '<span style="color:#008a20">&#10004;</span>' : '<span style="color:#b32d2e">&#10008;</span>'; ?></td><td><strong><?php echo esc_html( $c[0] ); ?></strong></td><td><?php echo $c[1] ? '' : wp_kses_post( $c[2] ); ?></td></tr>
			<?php endforeach; ?>
			</tbody></table>
		</div>
		<div class="usg-card">
			<h2>Import the redesigned site</h2>
			<p class="usg-help">Creates the 22 pages (Home, About, By-Laws, Board, Membership, Directory, Universities, Positions, Awards, Travel Grants, Minutes, Resources …) with their headers, plus positions, conferences, Board members, minutes, deadlines, the 331-member directory and 174 member universities. PDFs are added to the Media Library. Running it again is safe: existing items are kept unless you choose otherwise. <strong>Try it on a staging copy first</strong> (SiteGround → Staging).</p>
			<?php if ( $imp ) : ?><p><strong>Last import:</strong> <?php echo esc_html( $imp['time'] ); ?> — <code><?php echo esc_html( wp_json_encode( $imp['result'] ) ); ?></code></p><?php endif; ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return confirm('Run the import now?')">
				<input type="hidden" name="action" value="usucger_import"><?php wp_nonce_field( 'usucger_import' ); ?>
				<p><label><input type="radio" name="pages" value="skip" checked> Pages: create missing pages, <strong>leave existing pages with the same address alone</strong></label><br>
				<label><input type="radio" name="pages" value="replace"> Pages: also replace existing pages with the same address (old text stays in Revisions)</label></p>
				<p><label><input type="checkbox" name="data_replace" value="1"> Replace positions, conferences, Board, minutes, deadlines and imported directory data with the bundled copy</label></p>
				<p><label><input type="checkbox" name="retire" value="1" checked> Move the old Divi pages to Draft once the new pages exist (they would otherwise show raw Divi code under the new theme; their old addresses redirect to the new pages). Cart, Checkout, My account and Shop keep their address.</label></p>
				<p><button class="button button-primary">Run import</button></p>
			</form>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return confirm('Publish the old Divi pages again?')"><input type="hidden" name="action" value="usucger_restore_divi"><?php wp_nonce_field( 'usucger_restore_divi' ); ?>
				<p class="description">Rolling back to the Divi theme? <button class="button-link">Publish the old Divi pages again</button></p></form>
		</div>
	</div>
	<?php
}

add_action( 'admin_post_usucger_import', function () {
	usucger_check( 'usucger_import', 'manage_options' );
	$r = usucger_import_all( array(
		'pages'        => isset( $_POST['pages'] ) && 'replace' === $_POST['pages'] ? 'replace' : 'skip',
		'data_replace' => ! empty( $_POST['data_replace'] ),
		'retire'       => ! empty( $_POST['retire'] ),
	) );
	$msg = sprintf( 'Import finished: %d pages created, %d replaced%s.', $r['pages']['created'], $r['pages']['replaced'], $r['pages']['skipped'] ? ', skipped existing: ' . esc_html( implode( ', ', $r['pages']['skipped'] ) ) : '' );
	if ( ! empty( $r['retired'] ) ) {
		$msg .= sprintf( ' Old Divi pages moved to Draft: %d; system pages cleaned: %d.', count( $r['retired']['drafted'] ), count( $r['retired']['cleaned'] ) );
	}
	usucger_back( usucger_admin_url( 'usucger-setup' ), $msg );
} );

add_action( 'admin_post_usucger_restore_divi', function () {
	usucger_check( 'usucger_restore_divi', 'manage_options' );
	$n = usucger_restore_divi_pages();
	Usucger_DB::log( 'divi_pages_restored', '', $n );
	usucger_back( usucger_admin_url( 'usucger-setup' ), sprintf( '%d old pages published again.', $n ) );
} );
