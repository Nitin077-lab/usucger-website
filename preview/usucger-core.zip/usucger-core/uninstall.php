<?php
/**
 * Uninstall: data is KEPT unless the webmaster ticked "Delete all USUCGER data when the plugin
 * is deleted" in Settings (option usucger_core['delete_on_uninstall']).
 *
 * @package usucger-core
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}
$o = (array) get_option( 'usucger_core', array() );
if ( empty( $o['delete_on_uninstall'] ) ) {
	return;
}
global $wpdb;
foreach ( array( 'contacts', 'institutions', 'batches', 'outbox', 'views', 'log', 'attendance', 'elections', 'candidates', 'voters', 'ballots', 'receipts' ) as $t ) {
	$wpdb->query( 'DROP TABLE IF EXISTS ' . $wpdb->prefix . 'usucger_' . $t ); // phpcs:ignore WordPress.DB
}
foreach ( array( 'usucger_core', 'usucger_db_ver', 'usucger_templates', 'usucger_calendar', 'usucger_renewal_plan', 'usucger_map', 'usucger_redirects', 'usucger_imported', 'usucger_system_pages', 'usucger_last_sync', 'usucger_content_ver', 'usucger_last_tick', 'usucger_inst_requests', 'usucger_inst_declined', 'usucger_award_types' ) as $opt ) {
	delete_option( $opt );
}
remove_role( 'usucger_board' );
remove_role( 'usucger_coordinator' );
wp_clear_scheduled_hook( 'usucger_tick' );
wp_clear_scheduled_hook( 'usucger_daily' );
// form submissions, award recipients and their private files
foreach ( array( 'usucger_nomination', 'usucger_tg_app', 'usucger_recipient' ) as $pt ) {
	foreach ( get_posts( array( 'post_type' => $pt, 'post_status' => 'any', 'numberposts' => -1, 'fields' => 'ids' ) ) as $pid ) {
		wp_delete_post( $pid, true );
	}
}
$up = wp_upload_dir();
foreach ( array( 'usucger-private', 'usucger-elections' ) as $dir ) {
	$root = $up['basedir'] . '/' . $dir;
	if ( is_dir( $root ) ) {
		$it = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $root, FilesystemIterator::SKIP_DOTS ), RecursiveIteratorIterator::CHILD_FIRST );
		foreach ( $it as $f ) {
			$f->isDir() ? rmdir( $f->getPathname() ) : unlink( $f->getPathname() ); // phpcs:ignore
		}
		rmdir( $root ); // phpcs:ignore
	}
}
