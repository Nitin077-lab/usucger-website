# USUCGER for WordPress — theme + "USUCGER Core" plugin (v1.3)

Two parts:

- **usucger-theme.zip**: the look of the new site.
  - Navigation, page headers, footer bar and the 19 color themes (Core Sample is the default).
  - Includes the home-page theme picker. You can turn it off in Appearance → Customize → USUCGER.
- **usucger-core.zip**: everything that runs behind the site (content, approvals, membership, email).

## Install (do it on a SiteGround staging copy first)

1. Plugins → Add New → Upload, choose `usucger-core.zip`, then click Activate.
2. Appearance → Themes → Add New → Upload, choose `usucger-theme.zip`, then click Activate.
3. Settings → Permalinks: set it to "Post name".
4. USUCGER → Setup & import → **Run import**. This adds:
   - 22 pages
   - 12 positions
   - 22 conferences
   - 11 Board members
   - 54 minutes, with the PDFs going into the Media Library
   - 5 deadlines
   - the 331-person directory
   - 174 universities

   Pages that already exist with the same address are left alone unless you choose "replace".
5. USUCGER → Settings → Membership: tick the **2025–2027 plans** as *current* and the **2022–2024 (and older) plans** as *earlier*.
6. Members → Sync from WooCommerce Memberships. Members are matched to the imported directory by name.
7. Email delivery:
   - Install **WP Mail SMTP** and connect it to Amazon SES, Postmark, Brevo or Google Workspace.
   - Add SPF and DKIM records for usucger.org.
8. Real cron on SiteGround:
   - Go to Devs → Cron Jobs and add a job that runs every minute:
     `wget -q -O - https://usucger.org/wp-cron.php?doing_wp_cron >/dev/null 2>&1`
   - Add `define('DISABLE_WP_CRON', true);` to wp-config.php.
9. Users → give each Board member the **Board Member** role.

## Who can do what

**President (and any co-approvers).** Settings → Approvers: tick the President's account and set the title.
- They have the same approval authority as the webmaster: approve website changes and emails, manage members, and run elections.
- They cannot change settings, plugins or user accounts.
- Approvals only happen while signed in. Approval notices link to the desk, never to a one-click link.
- Each approval is logged with the person's name and title, for example "[President]".
- After signing in, they land on the **President's desk**.


| | Board Member | Webmaster (administrator) |
|---|---|---|
| Edit pages and data | Drafts and "Suggest changes" only | Directly |
| Publish / approve | – | Yes — webmaster and President (signed in) |
| Compose email | Yes, sent only after approval | Yes, can send directly |
| See members | Yes (read-only) | Yes, can edit, import and remove |

## Content: pages and data

- **Pages** keep the redesigned HTML. They open in the editor as "Custom HTML" blocks.
- **Page header**: the colored band is edited in the "USUCGER page header" box under the editor.
- **Data sections** are live shortcodes:
  - `[usucger_positions]` and `[usucger_positions kind="industry"]`
  - `[usucger_positions_module]`
  - `[usucger_conferences]`
  - `[usucger_board]`
  - `[usucger_minutes]`
  - `[usucger_deadlines]`
  - `[usucger_directory]`
  - `[usucger_universities]`
  - `[usucger_member_map]`
  - `[usucger_count of="members|institutions|positions|states"]`
  - `[usucger_my_membership]`
- **Positions** drop off after 365 days or on their closing date.
- **Conferences** drop off the day after they end.

## Approval workflow

**New content**

1. A Board member adds an item.
2. They click **Submit for Review**.
3. The webmaster is emailed.
4. The webmaster approves the item.
5. The author is emailed.

**Changes to a live page**

1. The Board member clicks **Suggest changes**. This creates a private working copy; the live page stays as it is.
2. They submit the copy for review.
3. The webmaster opens **Compare** and then **Approve**. The live page is updated and the old version stays in Revisions.
4. If changes are needed, the webmaster uses **Return with note** instead.

## Email

**Compose** with these settings:

- Template
- Type:
  - *Announcement*: the footer says "Unsubscribe from announcements".
  - *Renewal notice*: the footer says "Stop renewal reminders".
- Group:
  - Not renewed
  - Expiring soon
  - Current members
  - Everyone
  - University contacts
  - Board
  - Tag
  - Pasted list

**Merge tags**

- `{first_name}`
- `{institution}`
- `{membership_box}`
- `{renew_button}`
- `{expires}`
- `{cycle}`
- `{dues}`
- `{signature}`
- …

**What you can do with a draft:** preview it, send a test to yourself, then submit it.

**After approval**

- Each recipient gets an individual copy from the outbox, 20 per minute.
- Failed messages are retried up to 3 times.
- Every message has a one-click unsubscribe link.

**Renewal reminders** go only to people whose status is *Not renewed*, meaning they paid in an earlier cycle and not in the current one. People who have opted out of reminders are skipped.

**Renewals → Reminder plan**

- Each step is a dated reminder.
- On its date, the reminder is created and sent to you for approval. You can also choose to let scheduled reminders go out automatically.
- Anyone who renews before the reminder is approved drops out automatically.

## Membership tracking

- Status is synced from WooCommerce Memberships:
  - every day
  - whenever a membership changes
  - when you click the sync button
- Statuses:
  - **Current**: paid for this cycle; shown in the directory and on the map.
  - **Not renewed**: gets reminders.
  - **Former**: removed.
  - **Mailing list**: never a member.
- **Renewals → Remove members who did not renew** lists not-renewed members who are past the grace period (default 60 days).
  - Removing them takes them off the directory, the map and member mailings.
  - Their records and WooCommerce history are kept.
  - If they pay again, they come back automatically.
- **Universities at risk**: member universities with no paid member (By-Laws Art. III).
- Members manage their own listing and email preferences in **My Account → USUCGER membership**.

## Tracking

- **Dashboard**:
  - members by status
  - approvals waiting
  - outbox and sent counts
  - page views for 30 days and the top pages (no cookies, no IP addresses; editors and bots are not counted)
  - recent activity log
- **Audit log**: every approval, send, removal and import is recorded.

## Member area — usucger.org/members/

**Signing in**
- Members can ask for a one-time link by email (no password needed), or use their password.
- The link works once and expires after 20 minutes.

**Home**
- Membership status, with a Renew button if they have not renewed.
- A nomination banner with **Accept / Decline** buttons, and a "your ballot is open" banner during voting.
- What has changed since their last visit.
- Their upcoming events, and which colleagues are going to the same events.
- New academic positions and upcoming deadlines.
- How complete their profile is.
- New members, plus shortcuts.

**My profile**
- Photo, rank, and title/department.
- Expertise: tags picked from a list, plus their own.
- A research summary.
- Links to Scholar, ORCID, a website and LinkedIn.
- A switch for whether other members can see the profile.

**Find an expert** (signed-in current members only)
- Search by keyword, by expertise tag or by state.
- Each person has a profile page.
- A **Contact** form emails them. Their address stays private, and members can send up to 10 messages a day.

**Where I'll be**
- Members choose a listed conference, or add another event, and say whether they are attending, presenting or organizing.
- On the public conference list, each event shows "N USUCGER members attending".
- Only signed-in members see who is going.

**Elections**
- The member's own nomination and ballot status, and the full election page.

**Membership**
- Directory listing, email preferences, and links to receipts and billing.

## Elections — usucger.org/elections/ (By-Laws Art. III, VI, IX)

**Election officer**
- Choose the officer(s) in Settings → Elections.
- Officers set up the election, manage nominees, approve every election email, and certify the results.
- They do not need to be administrators.

**Election settings**
- Dates: nominations open and close, the date nominees should answer by, when candidate statements are due, and when voting opens and closes.
- Nominating Committee: who is on it, and who nominations should be sent to.
- Two signatures:
  - the committee chair's, for the slate announcement;
  - the officer's, for emails to nominees.

**Who can vote**
- Each member institution with paid dues gets one ballot.
- The ballot is cast by the institution's delegate, or by the one alternate the delegate names.
- One vote for the junior seat and one for the senior seat.
- No proxies.
- The voter roll is built automatically from paid membership. It is rebuilt before every ballot email, and institutions that have already voted are never changed.

**Rule checks on each nominee**
- Rank: junior seats are for Assistant Professors; senior seats for Associate or Full Professors.
- The nominee is a current paid member.
- Their institution is a member institution and can vote.
- They are the institution's delegate on file.
- Only one Board member per institution.
- They are currently on the Board (a reminder about term limits).
- At least two nominees per seat.
- Their candidate statement is complete.

**How an election runs** — every email waits for the officer's approval:
1. The committee adds its nominees. Each nominee receives **"Would you be willing to be nominated?"** with a personal **Yes, I accept** button. Nominees can also accept in their member area, and their status shows as **Accepted** right away.
2. The **slate announcement and call for more nominations** goes to all members. Members can nominate others or themselves online.
3. A **request for candidate statements** goes to nominees who have accepted. They fill in an online form that follows the template:
   - name, title, department and institution
   - summary of experience
   - vision and goals
   - headshot
   - two-page CV as a PDF, plus the combined LastName_FirstName.pdf if they have one

   A reminder goes 3 days before the due date to anyone still missing their statement.
4. The officer clicks **Put on ballot**.
5. When voting opens, two emails go out:
   - the **ballot email to delegates and alternates**, each with their own ballot link;
   - **"Meet the candidates"** to all members, with photos and links to statements and CVs.
6. **Reminders** go out 14, 7 and 1 days before voting closes, only to institutions that have not voted. Anyone whose institution votes before the reminder is sent is skipped. The desk also has a **Remind non-voters now** button.
7. **Secret ballot**
   - Ballots are stored with random IDs, no timestamps, and no link to the institution.
   - Each voter gets a receipt code they can use to check their ballot was counted.
   - The roll records only *that* an institution voted, not how.
8. **Results**
   - Results are hidden until voting closes.
   - Ties are flagged for the Board's secret ballot.
   - The officer clicks **Certify** to publish the results and prepare the results announcement email.
   - Yes/no questions (By-Law amendments, dues) need two-thirds of the delegates who vote.

## Key email calendar — USUCGER → Email calendar

- Each recurring key email has a date, an owner and a template:
  - travel grant calls and deadline reminders (both cycles)
  - award nominations call and last call
  - annual meeting notice
  - minutes posted
- A draft is created a few days before each date and waits for approval.
- If an email is late, it is marked **Overdue**, and the owner and webmaster get a reminder every 2 days.
- The same list also shows the election steps and renewal reminders, so every planned email appears in one place.

## Webmaster desk — usucger.org/webmaster/ (on the website, works on a phone)

- Key numbers at a glance.
- **Needs your approval**, with Preview / Approve & send (emails) and Compare / Approve (website changes).
- The key-email calendar for the next 75 days, including anything overdue.
- An election card with turnout and the institutions that have not voted, plus buttons:
  - Ask nominees if they are willing to serve
  - Ask nominees for their candidate statements
  - Remind non-voters
- Membership health, website visits, and recent activity.
- Board members see a lighter **Board desk** showing their own submissions.

## Email extras

**Sign as.** Choose who each email is signed by:
- the site signer;
- **Me** (filled in from my profile);
- a **custom** signature — for example "- Diane / Diane Moug, Ph.D. … / dmoug@pdx.edu". Email addresses and links become clickable.

**Attachments.** Attach files from the Media Library (for example the awards call PDF). Every recipient receives a copy.

**Ready-made templates**

| Template | Based on |
|---|---|
| Award nominations call | Diane's wording. Fills in `{award_deadline}` from the Deadlines list and `{annual_meeting}` from Settings. |
| Would you be willing to be nominated? | Lisa's wording, with the Accept button |
| Nominating Committee slate + call for nominations | Alejandro's wording. `{nominees_list}` is filled from the nominees, plus `{nominating_committee}` and `{nomination_contacts}`. |
| Candidate statement request and reminder | Lisa's wording, with the personal form button |
| Ballot to delegates | |
| Non-voter reminder | |
| Meet the candidates | |
| Results | |
| Travel grants | |
| Annual meeting | |
| Minutes posted | |
| Renewal reminders | |

**Official governance notices**
- Election and annual-meeting emails are sent as official notices.
- They reach members even if they unsubscribed from announcements.
- They carry no unsubscribe link.

## Dashboards by role (same login as members)

Everyone signs in at **/members/**. People with extra roles see their own dashboard as the first tab:

| Role | Dashboard tab |
|---|---|
| Webmaster (administrator) | **Webmaster dashboard** — everything, including site settings |
| President / co-approvers | **President dashboard** — the same approvals as the webmaster, but no site settings |
| Election officer | **Board dashboard · Election officer** — election tools, and approval of election emails |
| Membership Coordinator (new role) | **Membership Coordinator dashboard** — members, renewals and lapsed-member cleanup; emails still need approval |
| Board member | **Board dashboard** — their own submissions, the key-email calendar, election status, and Board resources (post a position, upload minutes, suggest page changes, compose email, By-Laws, minutes) |

The old /webmaster/ address still works.

## Hardening added after review (v1.2)

**Elections**
- Ballot, statement-form and accept links are never shown in previews, test sends or stored emails. They are added only at the moment each email is sent.
- In the member area, a delegate never sees their ballot link on screen. They get an "Email me my ballot link" button, which sends it to the delegate address on file.
- Receipt codes are no longer stored next to voter tokens.
- When a delegate is replaced, the old ballot link stops working. Alternate links are tied to the alternate's email address.
- Eligibility is frozen once voting opens.
- Each vote is saved in a single database transaction.
- If two elections are active, the correct one is treated as current.
- Scheduled election emails are not all sent at once if an election is activated late.

**Email outbox**
- Only one sender runs at a time, and each email is claimed before sending, so no one receives duplicates.
- An email can be approved only once.
- The default rate is now 8 emails per minute, to stay within SiteGround's limits.
- If the outbox stops sending, a "stalled" warning appears.

**Membership**
- Members who renewed early (status *delayed* in WooCommerce Memberships) count as current members.
- Memberships deleted in WooCommerce are now marked as lapsed.
- The import no longer skips the directory if a sync has already run.
- A logged-in member is matched to the member list by their account or email only, never by name.

**Website changes**
- Pressing Publish on a working copy now submits it for review instead.
- If the live page changed after the copy was made, a warning appears before approving.
- Board members can make working copies of published pages only.

**Email sign-in links**
- Opening the link shows a "Continue" button first, so university email scanners don't use up the one-time link.
- Administrators and approvers must sign in with their password.

**Site-wide**
- Member pages, ballots and personal links are never cached (DONOTCACHEPAGE).
- 301 redirects from old usucger.org addresses (editable in Settings).
- Privacy data export and erase tools, plus suggested privacy policy text.
- The plugin removes its data on uninstall only if you turn that on in Settings.
- The daily job cannot run twice at the same time.

## New in v1.3

### Online forms (replace "email the webmaster")

| Page | What it does | Where entries go |
|---|---|---|
| /post-a-position/ | Employers and members submit a listing (link to the official posting, closing date) | Pending **Position** in the Review queue; the submitter is emailed when it goes live |
| /nominate/ | Award nomination with the letter (PDF, required), CV and up to 3 support letters | **USUCGER → Submissions** (Board can read; status + committee notes; CSV) |
| /travel-grant-application/ | Student application; the advisor must be a current member (matched by the advisor's member email) | **USUCGER → Submissions**; the advisor is asked for a letter if none was uploaded |

- **Switches (Settings → Online forms):** each form can be turned on or off. Award and travel forms only accept entries while a deadline whose name contains "award" or "travel" is open. When a switch is on, the old email and Google-Form links on the pages (including the page-header buttons) point to the form automatically.
- **Uploaded PDFs:** stored in `uploads/usucger-private/` with random names. They are never linked publicly and open only for signed-in Board members and staff.
- **On nginx** (not SiteGround's Apache), add `location ^~ /wp-content/uploads/usucger-private/ { deny all; }`.
- **Spam protection:** a hidden field, a signed timer and a limit of 8 submissions per connection per day. Form pages are never cached.

### Data cleanup (USUCGER → Data cleanup)

- **Delegates:** lists member universities whose delegate cannot get a ballot, with the reason. It suggests a member record with the same name *at the same university*. You can tick the suggestion or type an email; the voter roll refreshes if an election is open.
- **Imported names:** old-directory rows that no membership account matched.
  - **Merge** them into a member record or site account; the member's own directory choice is kept.
  - **Add an email:** the person then counts as a member only once WooCommerce Memberships shows a payment.
  - **Remove** them from the directory.
- **Institution changes:** a current member's institution decides which university they vote with. Changes made in the member area, or arriving from the store's "Company" field, wait here for approval. Approving updates the store field too, so the daily sync agrees.
- **Bounced emails:** addresses your email service reported as undeliverable. They are skipped by every mailing until you correct or clear them. A corrected address is copied to any university delegate or alternate slot that used the old one.

### Members

- **Expert finder is opt-in.** Profiles stay hidden until the member says yes, and the member-area home asks them once.
- **Download my data** (member area → Shortcuts) gives a JSON file with the profile, membership, events, emails received and election roles.
- **Printable membership confirmation** (member area → Membership) is a one-page letter with the dates and payment, which members can print or save as PDF.
- **Delegates name their alternate** in member area → Elections. The alternate must be a current paid member from the same university, and the officer is told. Changing the alternate is locked once the university has voted.
- After signing in, members land in the member area, not the WordPress profile screen.

### Security & privacy

- **Sign-in code (Settings → Security & data).** Administrators, approvers (President), election officers, Board members and the Membership Coordinator get a 6-digit code by email after their password.
  - No login cookie is sent until the code is entered.
  - "Trust this browser" skips the code for 30 days.
  - XML-RPC is switched off, and application passwords are not available to these accounts.
  - Members are not affected.
  - **Locked out?** Add `define( 'USUCGER_DISABLE_2FA', true );` to `wp-config.php` (SiteGround → File Manager), sign in, fix email, then remove the line.
- **Email address changes:** the WooCommerce "Account details" form can no longer change the email. Members use their WordPress profile, which confirms the new address by email first. Ballots, delegate and nominee roles follow the email, so it must be proven.
- **Ballot receipts** are stored apart from the ballots. A receipt proves "counted" but can never show how anyone voted.
- **Data retention:** the text of sent emails is cleared after 400 days (who, when and subject are kept). Ballot links are deleted 60 days after results are certified. The activity log keeps 3 years. A public **/privacy/** page explains all of this and is linked in the footer.
- **Signed messages:** status messages after a form or vote are signed, so a crafted link cannot make the site display other text.

### Bounce webhook

- **Set up:** in Settings → Security & data, set a **Bounce webhook secret** (16+ characters). Then give your email service `https://usucger.org/wp-json/usucger/v1/bounce?key=SECRET`.
- **Supported payloads:** Amazon SES (via SNS, auto-confirmed), Postmark, Mailgun, SendGrid and Brevo, plus a plain `{"email": "...", "type": "hard"}`.
- **What each event does:**
  - **Hard bounce:** marks the contact as bounced.
  - **Spam complaint:** opts the person out of announcements; ballots and governance notices still go.
  - **Soft bounce or temporary block:** only logged.

### Other additions

- **Activity log** (USUCGER → Activity log): filter by action, person, dates or text, see the action in plain words with linked objects, and export to CSV. Ballot choices are never logged.
- **Board guide** (USUCGER → Board guide, also linked from every dashboard): the everyday jobs in plain language.
- **Calendar feed:** `https://usucger.org/?usucger_ical=1` lists deadlines and conferences for Outlook, Google or Apple Calendar. The `[usucger_ical_link]` shortcode prints a "Subscribe" link.
- **Search engines:** Organization and Event structured data (Schema.org JSON-LD) on the home and conferences pages.
- **Accessibility:** the public pages and every member-area tab pass axe-core WCAG 2.1 AA with 0 violations. Fixes covered contrast, tab roles and landmarks; layouts also fit 390px phones.
- **Translations:** text domain `usucger` (`languages/`).

## Self-tests

Run on staging, never on the live site:

```
php wp-content/plugins/usucger-core/tests/run-tests.php /path/to/wp-load.php
```

37 checks cover:
- **Elections:** the tally (plurality, ties, abstentions, majority and two-thirds questions) and By-Laws eligibility (paid member, current delegate, alternate rules).
- **Ballots:** a ballot can be cast, the receipt can be checked, the institution cannot vote twice, and ballots cannot be linked to voters.
- **Renewals:** the reminder audiences (non-renewed only, opt-outs, bounces, removed members).
- **Parsers:** bounce payloads, CSV formula injection and iCal escaping.

The script creates throw-away rows and deletes them.

## Email service (do this before the first mailing)

SiteGround's own mail server limits hourly sending and lands in spam at university filters. Use a transactional email service:

1. **Pick one.**
   - **Amazon SES:** cheapest; needs AWS.
   - **Postmark:** best delivery; ~$15/month for 10k.
   - **Brevo:** free tier of 300/day.
   - **Google Workspace SMTP:** if usucger.org mail is already on Google; 2,000/day.
2. **Verify usucger.org** in the service and add the DNS records it gives you (SiteGround → Domain → DNS Zone Editor):
   - **SPF:** `v=spf1 include:<service> ~all`. Merge it with any existing SPF; only one SPF record is allowed.
   - **DKIM:** the 2–3 CNAME or TXT records the service gives you.
   - **DMARC:** `_dmarc` TXT `v=DMARC1; p=none; rua=mailto:webmaster@usucger.org`. Move to `p=quarantine` after a month of clean reports.
3. **Install WP Mail SMTP** (free) → choose the service → paste the API key. Send a test to a Gmail and an @university.edu address, and check "SPF/DKIM: PASS" in the headers.
4. **Settings → Email sending:**
   - Set **From address** to an address on the verified domain (`webmaster@usucger.org`).
   - Raise **Emails per minute** to what the service allows (Postmark/SES: 60+; Brevo free: 5).
5. **Set up the bounce webhook** (above), so dead addresses stop costing reputation.
6. **SiteGround cron:** add a real cron job (Site Tools → Devs → Cron Jobs), every 5 minutes: `wget -q -O - https://usucger.org/wp-cron.php?doing_wp_cron >/dev/null 2>&1`. Then add `define( 'DISABLE_WP_CRON', true );` to `wp-config.php`. The dashboard warns if the outbox has not run for 15 minutes.

## Staging runbook (SiteGround)

1. **Create staging:** Site Tools → WordPress → Staging → **Create Staging Copy**. You get `staging#.usucger.org`, a full copy, password-protected.
2. **Protect real inboxes:** on staging, before anything else, install a mail catcher so test emails do not reach members. For example, enable the "Disable Emails" plugin, or set WP Mail SMTP to "Do not send".
3. **Install the theme and plugin:** Plugins → Add New → Upload `usucger-core.zip` → Activate, and Appearance → Themes → Upload `usucger-theme.zip` → Activate.
4. **Import:** USUCGER → Setup & import → **Run import** (pages, positions, conferences, Board, minutes, deadlines, award recipients, directory). Then check every page against the current site.
5. **Membership:**
   - Settings → Membership: tick the current-cycle and earlier-cycle WooCommerce Memberships plans.
   - USUCGER → Members → **Sync from WooCommerce Memberships now**. Compare the "current" count with WooCommerce → Memberships.
6. **Data cleanup:** work through Delegates, then Imported names. This decides who can vote.
7. **People:**
   - Create Board accounts (role "USUCGER Board"), the Membership Coordinator (role "USUCGER Coordinator"), and the election officer (Settings → Elections officers).
   - Set the President under Settings → Approvers.
   - Sign in as each one to confirm the sign-in code arrives.
8. **Run the self-tests** (above), then walk through the Board guide once: suggest a page change → approve; compose an email → approve → see it in the Outbox; a test election with two staff as delegates.
9. **Go live:** Staging → **Push to Live** (choose "Full deploy"). Then on live:
   - Settings → Permalinks → Save (refreshes addresses).
   - Re-enable real email.
   - Check the 301 redirects from the old Divi addresses (Settings → Redirects).
   - Submit the sitemap in Google Search Console.
10. **Roll back:** if something is wrong after go-live, Site Tools → Security → Backups → Restore the backup taken just before the push.

## Backup plan

- **Daily automatic backups:** SiteGround keeps 30 days (Site Tools → Security → Backups). Before any big change (plugin update, import, election setup), click **Create Backup** first. It takes about a minute.
- **Monthly off-site copy:** download a backup, or use UpdraftPlus (free) to send a weekly database and uploads copy to the USUCGER Google Drive or Dropbox. Keep 12 months. That way the data survives even if the hosting account is lost.
- **Before each election:**
  - Take a backup when voting opens.
  - Download the voter roll (Elections → the election → Voter roll → **Download roll (CSV)**) and keep it with the Board records.
  - After certification, save the results page as PDF in the minutes.
- **Exports worth keeping each cycle:**
  - Members CSV (USUCGER → Members → Download CSV).
  - Submissions CSVs.
  - Activity log CSV (once a year).
- **Test a restore once a year:** restore the latest backup into a staging copy and open the site. A backup that has never been restored is a hope, not a plan.
- **Accounts:**
  - At least two people should hold administrator access to the SiteGround account and to WordPress: the webmaster and the President.
  - Record where the email-service account and the domain registrar login live (Board shared drive).


## Board review on a staging copy (before go-live)

Everyone reviews with their own usual account, on a full copy of the site:

1. **SiteGround → Site Tools → WordPress → Staging → Create Staging Copy.** You get e.g. `staging1.usucger.org` with every user, membership and page copied.
2. On the copy: upload and activate **usucger-core.zip**, then **usucger-theme.zip**.
   - **Staging mode switches on by itself** on a `staging…` address (red banner on every page). While it is on:
     - email goes only to administrators, Board members, the Membership Coordinator, approvers, election officers, and anyone added under Settings → Staging copy;
     - everything else is held and listed in the Activity log;
     - checkout is blocked;
     - search engines are kept out.
3. **Settings → General → Timezone → Chicago** (the live site is on UTC today, so every deadline and reminder time would be 5–6 hours off).
4. **USUCGER → Setup & import → Run import** with these options:
   - "replace existing pages" — Books, Conferences, Workshops, Photos, Funding Tips and Teaching Aids share an address with the new pages;
   - "Move the old Divi pages to Draft" ticked. Cart, Checkout, My account and Shop are kept and lose only their Divi wrapper. Old addresses such as `/usucger-by-laws/` or `/login/` redirect to the new pages.
5. **USUCGER → Members → Sync from WooCommerce Memberships now.**
   - **Plans:** the 2025–2027 plans (US Universities #2547, Associate #2626) are pre-selected as current; check Settings → Membership.
   - **Team purchases:** a buyer who never assigned themselves a seat (about 90 of the current teams) is counted as a member, with the institution taken from the team name.
   - **Institutions** come from the "University Name" asked at checkout when there is no team.
6. Work through **Data cleanup**, add the Board as users with the "USUCGER Board" role, and set the President (Settings → Approvers).
7. **The Board reviews** with the Board guide as the checklist, for 1–2 weeks.
8. **Go live:** re-sync and re-import on the copy (to pick up anything changed on usucger.org meanwhile), then **Staging → Push to Live**.
   - On live, staging mode is off automatically. Check Settings → Staging copy says "off".
   - If anything goes wrong: **Setup & import → "Publish the old Divi pages again"**, switch back to the Divi theme, or restore SiteGround's pre-push backup.

**Fix on the current site now (unrelated to the redesign):** the page `/member-directory/` (Dynamic User Directory plugin) shows every member's email address publicly. Make it members-only or unpublish it.
