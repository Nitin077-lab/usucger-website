<?php
/**
 * USUCGER Core self-tests. Run on a staging copy (never production):
 *
 *   php wp-content/plugins/usucger-core/tests/run-tests.php /path/to/wp-load.php
 *   (or: wp eval-file wp-content/plugins/usucger-core/tests/run-tests.php)
 *
 * Covers: vote tally (plurality, ties, abstentions, majority and two-thirds questions),
 * voter eligibility (By-Laws Art. III), renewal-reminder audiences, bounce parsing,
 * CSV and iCal escaping. Creates throw-away rows and removes them afterwards.
 *
 * @package usucger-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	if ( empty( $argv[1] ) || ! file_exists( $argv[1] ) ) {
		fwrite( STDERR, "usage: php run-tests.php /path/to/wp-load.php\n" );
		exit( 2 );
	}
	$_SERVER['HTTP_HOST']   = isset( $_SERVER['HTTP_HOST'] ) ? $_SERVER['HTTP_HOST'] : 'localhost';
	$_SERVER['REQUEST_URI'] = '/';
	require $argv[1];
}

global $wpdb, $usg_t;
$usg_t = array( 'pass' => 0, 'fail' => 0 );
function usg_ok( $cond, $label ) {
	global $usg_t;
	$usg_t[ $cond ? 'pass' : 'fail' ]++;
	echo ( $cond ? "  ok    " : "  FAIL  " ) . $label . "\n";
}
function usg_section( $s ) {
	echo "\n" . $s . "\n";
}

$tag     = 'usgtest' . wp_rand( 1000, 9999 );
$cleanup = array( 'elections' => array(), 'contacts' => array(), 'institutions' => array() );
$ct      = Usucger_DB::t( 'contacts' );
$it      = Usucger_DB::t( 'institutions' );
$bt      = Usucger_DB::t( 'ballots' );
$cn      = Usucger_DB::t( 'candidates' );
$vt      = Usucger_DB::t( 'voters' );

$add_contact = function ( $email, $status, $inst, $extra = array() ) use ( $wpdb, $ct, &$cleanup ) {
	$wpdb->insert( $ct, array_merge( array( 'email' => $email, 'first_name' => 'T', 'last_name' => 'Tester', 'institution' => $inst, 'status' => $status, 'source' => 'manual', 'created' => current_time( 'mysql' ) ), $extra ) );
	$cleanup['contacts'][] = $wpdb->insert_id;
	return $wpdb->insert_id;
};

try {
	/* ------------------------------------------------------------ tally */
	usg_section( 'Vote tally' );
	$eid                     = usucger_election_save( array( 'title' => $tag . ' board', 'kind' => 'board', 'status' => 'closed', 'vote_open' => '2000-01-01', 'vote_close' => '2000-01-10', 'settings' => array( 'threshold' => 'majority' ) ) );
	$cleanup['elections'][] = $eid;
	$cand                    = array();
	foreach ( array( 'A' => 'junior', 'B' => 'junior', 'C' => 'senior', 'D' => 'senior' ) as $n => $pos ) {
		$wpdb->insert( $cn, array( 'election_id' => $eid, 'position' => $pos, 'name' => 'Cand ' . $n, 'status' => 'approved', 'created' => current_time( 'mysql' ) ) );
		$cand[ $n ] = $wpdb->insert_id;
	}
	$vote = function ( $pos, $cid, $n ) use ( $wpdb, $bt, $eid ) {
		for ( $i = 0; $i < $n; $i++ ) {
			$wpdb->insert( $bt, array( 'election_id' => $eid, 'position' => $pos, 'candidate_id' => $cid, 'receipt_hash' => wp_generate_password( 20, false ) ) );
		}
	};
	$vote( 'junior', $cand['A'], 5 );
	$vote( 'junior', $cand['B'], 3 );
	$vote( 'junior', 0, 2 ); // abstentions
	$vote( 'senior', $cand['C'], 4 );
	$vote( 'senior', $cand['D'], 4 );
	$r = usucger_tally( usucger_election( $eid ) );
	usg_ok( 'Cand A' === $r['junior']['winner'], 'plurality winner (5–3) is A' );
	usg_ok( 8 === $r['junior']['cast'] && 2 === $r['junior']['abstain'], 'abstentions counted separately (8 cast, 2 abstain)' );
	usg_ok( $r['senior']['tie'] && null === $r['senior']['winner'], '4–4 is reported as a tie with no winner' );

	usg_section( 'Questions (By-Laws amendments need two-thirds)' );
	foreach ( array( array( 'two_thirds', 6, 3, 'Passed' ), array( 'two_thirds', 5, 3, 'Not passed' ), array( 'majority', 5, 4, 'Passed' ), array( 'majority', 4, 4, 'Not passed' ) ) as $case ) {
		$q                       = usucger_election_save( array( 'title' => $tag . ' q', 'kind' => 'question', 'status' => 'closed', 'vote_open' => '2000-01-01', 'vote_close' => '2000-01-10', 'settings' => array( 'threshold' => $case[0] ) ) );
		$cleanup['elections'][] = $q;
		$wpdb->insert( $cn, array( 'election_id' => $q, 'position' => 'question', 'name' => 'Yes', 'status' => 'approved' ) );
		$yes = $wpdb->insert_id;
		$wpdb->insert( $cn, array( 'election_id' => $q, 'position' => 'question', 'name' => 'No', 'status' => 'approved' ) );
		$no = $wpdb->insert_id;
		for ( $i = 0; $i < $case[1]; $i++ ) {
			$wpdb->insert( $bt, array( 'election_id' => $q, 'position' => 'question', 'candidate_id' => $yes ) );
		}
		for ( $i = 0; $i < $case[2]; $i++ ) {
			$wpdb->insert( $bt, array( 'election_id' => $q, 'position' => 'question', 'candidate_id' => $no ) );
		}
		$t = usucger_tally( usucger_election( $q ) );
		usg_ok( $case[3] === $t['question']['winner'], sprintf( '%s: %d yes / %d no → %s', $case[0], $case[1], $case[2], $case[3] ) );
	}

	/* ------------------------------------------------------- eligibility */
	usg_section( 'Voter eligibility (Art. III)' );
	$insts = array(
		'ok'      => array( 'paid' => true, 'del' => 'current' ),
		'nopaid'  => array( 'paid' => false, 'del' => 'none' ),
		'lapsed'  => array( 'paid' => true, 'del' => 'lapsed' ),
		'noemail' => array( 'paid' => true, 'del' => 'noemail' ),
	);
	$ids = array();
	foreach ( $insts as $k => $cfg ) {
		$name = $tag . ' University ' . $k;
		$del  = $k . '.' . $tag . '@example.test';
		$wpdb->insert( $it, array( 'name' => $name, 'status' => 'member', 'contact_name' => 'Del ' . $k, 'contact_email' => 'noemail' === $cfg['del'] ? '' : $del, 'alternate_email' => 'ok' === $k ? 'alt.' . $tag . '@example.test' : '' ) );
		$ids[ $k ]                 = $wpdb->insert_id;
		$cleanup['institutions'][] = $wpdb->insert_id;
		if ( $cfg['paid'] ) {
			$add_contact( 'paid.' . $k . '.' . $tag . '@example.test', 'current', $name );
		}
		if ( in_array( $cfg['del'], array( 'current', 'lapsed' ), true ) ) {
			$add_contact( $del, $cfg['del'], $name );
		}
	}
	$add_contact( 'alt.' . $tag . '@example.test', 'lapsed', $tag . ' University ok' ); // alternate not paid
	$re                     = usucger_election_save( array( 'title' => $tag . ' roll', 'kind' => 'board', 'status' => 'voting', 'vote_open' => '2999-01-01', 'vote_close' => '2999-02-01', 'settings' => array() ) );
	$cleanup['elections'][] = $re;
	usucger_election_build_roll( $re );
	$row = function ( $k ) use ( $wpdb, $vt, $re, $ids ) {
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $vt WHERE election_id = %d AND institution_id = %d", $re, $ids[ $k ] ) );
	};
	usg_ok( 1 === (int) $row( 'ok' )->eligible, 'paid institution with a current delegate can vote' );
	usg_ok( '' === $row( 'ok' )->alternate_email, 'an alternate who is not a paid member is dropped' );
	usg_ok( 0 === (int) $row( 'nopaid' )->eligible && false !== stripos( $row( 'nopaid' )->reason, 'paid member' ), 'institution with no paid member cannot vote' );
	usg_ok( 0 === (int) $row( 'lapsed' )->eligible && false !== stripos( $row( 'lapsed' )->reason, 'not a current' ), 'delegate who has not renewed cannot vote' );
	usg_ok( 0 === (int) $row( 'noemail' )->eligible, 'delegate with no email on file cannot vote' );
	usg_ok( strlen( $row( 'ok' )->token ) >= 20, 'eligible delegate gets a ballot link' );
	$old = $row( 'ok' )->token;
	$wpdb->update( $it, array( 'contact_email' => 'paid.ok.' . $tag . '@example.test' ), array( 'id' => $ids['ok'] ) );
	usucger_election_build_roll( $re );
	usg_ok( $row( 'ok' )->token !== $old, 'changing the delegate replaces the ballot link' );
	$wpdb->update( $it, array( 'alternate_email' => 'nobody.' . $tag . '@example.test' ), array( 'id' => $ids['ok'] ) );
	usucger_election_build_roll( $re );
	usg_ok( '' === $row( 'ok' )->alternate_email, 'an alternate with no member record is dropped' );
	usg_ok( null === usucger_contact_by_name( 'Tester' ), 'a last name alone never matches a member' );
	list( $none ) = usucger_voter_by_token( $re, '' );

	usg_section( 'Casting a ballot' );
	$wpdb->update( Usucger_DB::t( 'elections' ), array( 'status' => 'active', 'nom_open' => '2000-01-01', 'nom_close' => '2000-01-02', 'vote_open' => gmdate( 'Y-m-d', strtotime( '-1 day' ) ), 'vote_close' => gmdate( 'Y-m-d', strtotime( '+5 days' ) ) ), array( 'id' => $re ) );
	$wpdb->insert( $cn, array( 'election_id' => $re, 'position' => 'junior', 'name' => 'J', 'status' => 'approved' ) );
	$jid  = $wpdb->insert_id;
	$rc   = usucger_cast_ballot( usucger_election( $re ), $row( 'ok' ), array( 'junior' => $jid ), 'delegate:test' );
	usg_ok( is_string( $rc ) && preg_match( '/^[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$/', $rc ), 'a ballot returns a receipt code' );
	usg_ok( 1 === (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . Usucger_DB::t( 'receipts' ) . ' WHERE receipt_hash = %s', hash( 'sha256', (string) $rc ) ) ), 'the receipt can be checked' );
	usg_ok( 0 === (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $bt WHERE election_id = %d AND receipt_hash <> ''", $re ) ), 'ballot rows carry no receipt (cannot be linked to the voter)' );
	usg_ok( is_wp_error( usucger_cast_ballot( usucger_election( $re ), $row( 'ok' ), array( 'junior' => $jid ), 'alternate:test' ) ), 'a second ballot from the same institution is refused' );
	usg_ok( is_wp_error( usucger_cast_ballot( usucger_election( $re ), $row( 'nopaid' ), array( 'junior' => $jid ), 'delegate:x' ) ), 'an ineligible institution cannot vote' );
	usg_ok( null === $none, 'an empty (purged) ballot link never matches' );

	/* -------------------------------------------------------- renewals */
	usg_section( 'Renewal reminder audiences' );
	$add_contact( 'cur.' . $tag . '@example.test', 'current', 'X', array( 'end_date' => gmdate( 'Y-m-d', strtotime( '+400 days' ) ) ) );
	$add_contact( 'soon.' . $tag . '@example.test', 'current', 'X', array( 'end_date' => gmdate( 'Y-m-d', strtotime( '+10 days' ) ) ) );
	$add_contact( 'lap.' . $tag . '@example.test', 'lapsed', 'X' );
	$add_contact( 'lapout.' . $tag . '@example.test', 'lapsed', 'X', array( 'unsub_renewal' => 1 ) );
	$add_contact( 'lapbounce.' . $tag . '@example.test', 'lapsed', 'X', array( 'bounced' => 1 ) );
	$add_contact( 'former.' . $tag . '@example.test', 'former', 'X' );
	$emails = function ( $rows ) use ( $tag ) {
		return array_values( array_filter( wp_list_pluck( $rows, 'email' ), function ( $e ) use ( $tag ) {
			return false !== strpos( $e, $tag ) && 0 !== strpos( $e, 'paid.' ) && 0 !== strpos( $e, 'alt.' ) && false === strpos( $e, 'University' );
		} ) );
	};
	$nr = $emails( Usucger_Members::recipients( 'not_renewed', array(), 'renewal' ) );
	usg_ok( in_array( 'lap.' . $tag . '@example.test', $nr, true ), 'not-renewed member gets the reminder' );
	usg_ok( ! in_array( 'cur.' . $tag . '@example.test', $nr, true ), 'renewed (current) member does not' );
	usg_ok( ! in_array( 'lapout.' . $tag . '@example.test', $nr, true ), 'someone who opted out of reminders does not' );
	usg_ok( ! in_array( 'lapbounce.' . $tag . '@example.test', $nr, true ), 'a bounced address is skipped' );
	usg_ok( ! in_array( 'former.' . $tag . '@example.test', $nr, true ), 'a removed (former) member does not' );
	$ex = $emails( Usucger_Members::recipients( 'expiring', array( 'days' => 30 ), 'renewal' ) );
	usg_ok( in_array( 'soon.' . $tag . '@example.test', $ex, true ) && ! in_array( 'cur.' . $tag . '@example.test', $ex, true ), '"expiring in 30 days" picks only memberships ending soon' );

	/* -------------------------------------------------------- helpers */
	usg_section( 'Parsers and escaping' );
	$b = usucger_bounce_parse( array( 'RecordType' => 'Bounce', 'Type' => 'HardBounce', 'Email' => 'a@b.test' ) );
	usg_ok( 'hard' === $b[0][1], 'Postmark hard bounce' );
	$b = usucger_bounce_parse( array( 'Type' => 'Notification', 'Message' => wp_json_encode( array( 'notificationType' => 'Bounce', 'bounce' => array( 'bounceType' => 'Transient', 'bouncedRecipients' => array( array( 'emailAddress' => 'a@b.test' ) ) ) ) ) ) );
	usg_ok( 'soft' === $b[0][1], 'Amazon SES transient bounce is soft (logged only)' );
	$b = usucger_bounce_parse( array( array( 'event' => 'spamreport', 'email' => 'a@b.test' ) ) );
	usg_ok( 'complaint' === $b[0][1], 'SendGrid spam report is a complaint' );
	$b = usucger_bounce_parse( array( 'event' => 'bounce', 'type' => 'blocked', 'email' => 'a@b.test' ) );
	usg_ok( 'soft' === $b[0][1], 'SendGrid temporary block is soft' );
	usg_ok( array() === usucger_bounce_parse( array( 'event' => 'dropped', 'reason' => 'Unsubscribed Address', 'email' => 'a@b.test' ) ), 'SendGrid drop for an unsubscribed address is ignored' );
	$b = usucger_bounce_parse( array( 'event' => 'bounced', 'recipient' => 'a@b.test' ) );
	usg_ok( 'hard' === $b[0][1], 'Mailgun legacy "bounced" is hard' );
	usg_ok( 'Texas Tech University' === Usucger_Members::clean_team_name( 'Texas Tech University “Texas Tech” is a member' ), 'team names are reduced to the institution' );
	$red = usucger_redirects();
	usg_ok( isset( $red['/usucger-history-and-mission/'], $red['/login/'], $red['/usucger-membership-overview/'] ), 'old Divi addresses are in the redirect list' );
	usg_ok( ! isset( $red['/industry-positions/'] ) || '/industry-positions/' !== $red['/industry-positions/'], 'no redirect points to itself' );
		usg_ok( "'=SUM(A1)" === usucger_csv_safe( '=SUM(A1)' ) && 'Smith' === usucger_csv_safe( 'Smith' ), 'CSV formula injection is neutralised' );
	usg_ok( 'a\, b\;\nc' === usucger_ical_escape( "a, b;\nc" ), 'iCal text escaping' );
	$fold = usucger_ical_fold( 'SUMMARY:' . str_repeat( 'é', 60 ) );
	usg_ok( max( array_map( 'strlen', explode( "\r\n", $fold ) ) ) <= 75 && mb_check_encoding( str_replace( "\r\n ", '', $fold ), 'UTF-8' ), 'iCal lines fold at 75 octets without splitting characters' );
} catch ( Throwable $e ) {
	usg_ok( false, 'exception: ' . $e->getMessage() . ' @ ' . basename( $e->getFile() ) . ':' . $e->getLine() );
}

/* cleanup */
foreach ( $cleanup['elections'] as $id ) {
	$wpdb->delete( Usucger_DB::t( 'elections' ), array( 'id' => $id ) );
	$wpdb->delete( $bt, array( 'election_id' => $id ) );
	$wpdb->delete( $cn, array( 'election_id' => $id ) );
	$wpdb->delete( $vt, array( 'election_id' => $id ) );
	$wpdb->delete( Usucger_DB::t( 'receipts' ), array( 'election_id' => $id ) );
}
foreach ( $cleanup['contacts'] as $id ) {
	$wpdb->delete( $ct, array( 'id' => $id ) );
}
foreach ( $cleanup['institutions'] as $id ) {
	$wpdb->delete( $it, array( 'id' => $id ) );
}

echo "\n" . $usg_t['pass'] . ' passed, ' . $usg_t['fail'] . " failed\n";
if ( defined( 'WP_CLI' ) ) {
	return;
}
exit( $usg_t['fail'] ? 1 : 0 );
