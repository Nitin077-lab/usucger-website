<?php
/**
 * Plugin Name:       USUCGER Core
 * Plugin URI:        https://usucger.org/
 * Description:       Site engine for USUCGER: positions, conferences, Board, minutes and deadlines; Board-member editing with webmaster approval; membership tracking from WooCommerce Memberships; email compose → approval → outbox with renewal reminders that go only to members who have not renewed; lapsed-member cleanup; page-view tracking; content importer for the redesigned site.
 * Version:           1.3.1
 * Requires at least: 6.2
 * Requires PHP:      7.4
 * Author:            Dr. Nitin Tiwari, Southern Illinois University Carbondale
 * License:           GPL-2.0-or-later
 * Text Domain:       usucger
 *
 * @package usucger-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'USUCGER_CORE_VER', '1.3.1' );
define( 'USUCGER_CORE_DB_VER', '8' );
define( 'USUCGER_CORE_FILE', __FILE__ );
define( 'USUCGER_CORE_DIR', plugin_dir_path( __FILE__ ) );
define( 'USUCGER_CORE_URL', plugin_dir_url( __FILE__ ) );

foreach ( array(
	'options', 'db', 'util', 'cpt', 'members', 'shortcodes', 'map', 'workflow', 'email', 'renewals',
	'tracking', 'search', 'account', 'importer', 'profiles', 'attendance', 'portal', 'elections', 'election-packets', 'calendar', 'frontdesk', 'hardening', 'awards', 'forms', 'extras', 'twofactor', 'bounces', 'staging',
) as $usg_mod ) {
	require_once USUCGER_CORE_DIR . 'includes/' . $usg_mod . '.php';
}
if ( is_admin() ) {
	foreach ( array( 'menu', 'page-dashboard', 'page-review', 'page-members', 'page-email', 'page-renewals', 'page-settings', 'page-elections', 'page-submissions', 'page-datafix', 'page-log', 'page-guide' ) as $usg_mod ) {
		require_once USUCGER_CORE_DIR . 'admin/' . $usg_mod . '.php';
	}
}

register_activation_hook( __FILE__, 'usucger_core_activate' );
register_deactivation_hook( __FILE__, 'usucger_core_deactivate' );

function usucger_core_activate() {
	Usucger_DB::install();
	usucger_core_roles();
	usucger_register_cpts();
	usucger_email_seed_templates();
	if ( ! wp_next_scheduled( 'usucger_tick' ) ) {
		wp_schedule_event( time() + 60, 'usucger_minute', 'usucger_tick' );
	}
	if ( ! wp_next_scheduled( 'usucger_daily' ) ) {
		wp_schedule_event( strtotime( 'tomorrow 06:10' ), 'daily', 'usucger_daily' );
	}
	flush_rewrite_rules();
}

function usucger_core_deactivate() {
	wp_clear_scheduled_hook( 'usucger_tick' );
	wp_clear_scheduled_hook( 'usucger_daily' );
	flush_rewrite_rules();
}

add_filter( 'cron_schedules', function ( $s ) {
	$s['usucger_minute'] = array( 'interval' => 60, 'display' => 'Every minute (USUCGER outbox)' );
	return $s;
} );

/* Upgrade tables / re-seed roles when the plugin is updated in place. */
add_action( 'plugins_loaded', function () {
	if ( get_option( 'usucger_db_ver' ) !== USUCGER_CORE_DB_VER ) {
		Usucger_DB::install();
		usucger_core_roles();
		usucger_email_seed_templates();
	}
	if ( ! wp_next_scheduled( 'usucger_tick' ) ) {
		wp_schedule_event( time() + 60, 'usucger_minute', 'usucger_tick' );
	}
	if ( ! wp_next_scheduled( 'usucger_daily' ) ) {
		wp_schedule_event( strtotime( 'tomorrow 06:10' ), 'daily', 'usucger_daily' );
	}
} );

add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), function ( $links ) {
	array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=usucger' ) ) . '">Dashboard</a>', '<a href="' . esc_url( admin_url( 'admin.php?page=usucger-settings' ) ) . '">Settings</a>' );
	return $links;
} );
