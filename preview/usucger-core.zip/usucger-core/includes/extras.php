<?php
/**
 * Smaller member-facing features:
 *  - translations, privacy page, iCal feed, Schema.org JSON-LD
 *  - "download my data" (portal), printable membership receipt
 *  - delegates name their institution's alternate from the portal
 *  - institution changes by current members wait for approval (they affect voting)
 *  - expert-finder visibility is opt-in, with a one-time prompt
 *  - data retention: old email bodies and post-certification ballot links are cleared
 *
 * @package usucger-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'init', function () {
	load_plugin_textdomain( 'usucger', false, dirname( plugin_basename( USUCGER_CORE_FILE ) ) . '/languages' );
}, 1 );

/* ============================================================== privacy page */

add_shortcode( 'usucger_privacy', function () {
	$c = esc_html( usucger_core_opt( 'contact_email' ) );
	$h = function ( $t ) {
		return '<h2 class="h-section" style="font-size:1.35rem;margin:2rem 0 .6rem">' . esc_html( $t ) . '</h2>';
	};
	return '<section class="section bg-white"><div class="wrap" style="max-width:820px">'
		. '<p>USUCGER (United States Universities Council on Geotechnical Education and Research) runs this website for its members. We keep as little personal information as we can, and we never sell it or use advertising trackers.</p>'
		. $h( 'What we keep' )
		. '<ul><li><strong>Membership</strong> — name, email, institution, membership dates and plan, from your WooCommerce membership purchase. Card payments are handled by the payment provider; we never see card numbers.</li>'
		. '<li><strong>Your member profile</strong> — rank, title, expertise, summary, links and photo, only if you add them. Other signed-in members see your profile only if you choose to be listed in the expert finder.</li>'
		. '<li><strong>Conference plans</strong> you add under “Where I’ll be”.</li>'
		. '<li><strong>Email records</strong> — what we sent you and when, and your email preferences. The text of sent emails is cleared after ' . (int) usucger_core_opt( 'retention_days' ) . ' days.</li>'
		. '<li><strong>Elections</strong> — the voter roll (each member institution’s delegate and alternate), whether an institution has voted, and the anonymous ballots. Ballots are stored without any link to the voter; ballot links are deleted ' . (int) usucger_core_opt( 'token_purge_days' ) . ' days after results are certified.</li>'
		. '<li><strong>Forms</strong> — position listings, award nominations and travel-grant applications you submit, with any PDFs, visible only to the Board.</li>'
		. '<li><strong>Page counts</strong> — the number of views per page per day. No cookies, no IP addresses, nothing that identifies you.</li></ul>'
		. $h( 'Who can see it' )
		. '<p>The webmaster, the President, the Membership Coordinator and the Board, for running USUCGER. The public directory and member map show only current members who have chosen to be listed (name and institution).</p>'
		. $h( 'Cookies' )
		. '<p>Only the sign-in cookies WordPress needs once you log in, and a cookie that remembers a trusted browser for staff sign-in codes. No analytics or advertising cookies.</p>'
		. $h( 'Your choices' )
		. '<ul><li>Change your directory listing and email preferences under <a href="' . esc_url( usucger_portal_url( 'membership' ) ) . '">Member area → Membership</a>.</li>'
		. '<li>Download everything we hold about you from the <a href="' . esc_url( usucger_portal_url() ) . '">Member area</a> (“Download my data”).</li>'
		. '<li>Ask us to correct or delete your information: email <a href="mailto:' . $c . '">' . $c . '</a>. Records we must keep for USUCGER governance (for example that your institution voted in an election) are kept but stripped of anything not needed.</li></ul>'
		. '<p class="usg-muted" style="margin-top:2rem">Last updated ' . esc_html( wp_date( 'F Y' ) ) . '.</p>'
		. '</div></section>';
} );

add_action( 'admin_init', function () {
	if ( function_exists( 'wp_add_privacy_policy_content' ) ) {
		wp_add_privacy_policy_content( 'USUCGER Core', '<p>See the USUCGER Privacy page created by the plugin (shortcode <code>[usucger_privacy]</code>).</p>' );
	}
} );

/* ================================================================== iCal feed */

function usucger_ical_url() {
	return add_query_arg( 'usucger_ical', '1', home_url( '/' ) );
}

function usucger_ical_escape( $s ) {
	return str_replace( array( '\\', ';', ',', "\r\n", "\n" ), array( '\\\\', '\;', '\,', '\n', '\n' ), wp_strip_all_tags( html_entity_decode( (string) $s, ENT_QUOTES, 'UTF-8' ) ) );
}

function usucger_ical_fold( $line ) {
	$out = '';
	while ( strlen( $line ) > 74 ) {
		$cut  = 74;
		while ( $cut > 0 && ( ord( $line[ $cut ] ) & 0xC0 ) === 0x80 ) { // do not split a UTF-8 character
			$cut--;
		}
		$out .= substr( $line, 0, $cut ) . "\r\n ";
		$line = substr( $line, $cut );
	}
	return $out . $line . "\r\n";
}

function usucger_ical_events() {
	$ev = array();
	foreach ( usucger_items( 'usucger_deadline' ) as $d ) {
		if ( ! empty( $d['date'] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $d['date'] ) ) {
			$href = (string) $d['href'];
			$ev[] = array(
				'uid'   => 'deadline-' . $d['id'],
				'start' => $d['date'],
				'end'   => $d['date'],
				'title' => 'USUCGER deadline: ' . $d['title'],
				'desc'  => (string) $d['detail'],
				'url'   => $href ? ( preg_match( '#^https?://#', $href ) ? $href : usucger_core_url( $href ) ) : '',
				'where' => '',
			);
		}
	}
	foreach ( usucger_items( 'usucger_conference' ) as $c ) {
		if ( ! empty( $c['start'] ) && empty( $c['year_only'] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $c['start'] ) ) {
			$ev[] = array(
				'uid'   => 'conference-' . $c['id'],
				'start' => $c['start'],
				'end'   => preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $c['end'] ) ? $c['end'] : $c['start'],
				'title' => $c['title'],
				'desc'  => (string) $c['note'],
				'url'   => (string) $c['url'],
				'where' => (string) $c['location'],
			);
		}
	}
	return $ev;
}

add_action( 'template_redirect', function () {
	if ( empty( $_GET['usucger_ical'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		return;
	}
	$host = (string) wp_parse_url( home_url(), PHP_URL_HOST );
	$out  = "BEGIN:VCALENDAR\r\nVERSION:2.0\r\nPRODID:-//USUCGER//Deadlines and conferences//EN\r\nCALSCALE:GREGORIAN\r\nMETHOD:PUBLISH\r\n" . usucger_ical_fold( 'X-WR-CALNAME:USUCGER deadlines & conferences' ) . "X-PUBLISHED-TTL:PT12H\r\n";
	$now  = gmdate( 'Ymd\THis\Z' );
	foreach ( usucger_ical_events() as $e ) {
		$out .= "BEGIN:VEVENT\r\n";
		$out .= 'UID:' . $e['uid'] . '@' . $host . "\r\n";
		$out .= 'DTSTAMP:' . $now . "\r\n";
		$out .= 'DTSTART;VALUE=DATE:' . str_replace( '-', '', $e['start'] ) . "\r\n";
		$out .= 'DTEND;VALUE=DATE:' . gmdate( 'Ymd', strtotime( $e['end'] . ' +1 day' ) ) . "\r\n";
		$out .= usucger_ical_fold( 'SUMMARY:' . usucger_ical_escape( $e['title'] ) );
		if ( $e['desc'] ) {
			$out .= usucger_ical_fold( 'DESCRIPTION:' . usucger_ical_escape( $e['desc'] ) );
		}
		if ( $e['where'] ) {
			$out .= usucger_ical_fold( 'LOCATION:' . usucger_ical_escape( $e['where'] ) );
		}
		if ( $e['url'] ) {
			$out .= usucger_ical_fold( 'URL:' . esc_url_raw( $e['url'] ) );
		}
		$out .= "TRANSP:TRANSPARENT\r\nEND:VEVENT\r\n";
	}
	$out .= "END:VCALENDAR\r\n";
	header( 'Content-Type: text/calendar; charset=utf-8' );
	header( 'Content-Disposition: inline; filename="usucger.ics"' );
	header( 'Cache-Control: public, max-age=3600' );
	echo $out; // phpcs:ignore WordPress.Security.EscapeOutput
	exit;
}, 1 );

add_action( 'wp_head', function () {
	echo '<link rel="alternate" type="text/calendar" title="USUCGER deadlines &amp; conferences" href="' . esc_url( usucger_ical_url() ) . "\">\n";
}, 3 );

add_shortcode( 'usucger_ical_link', function () {
	$https = usucger_ical_url();
	$webcal = preg_replace( '#^https?://#', 'webcal://', $https );
	return '<p class="usg-ical"><a href="' . esc_url( $webcal, array( 'webcal', 'http', 'https' ) ) . '">Subscribe to deadlines &amp; conferences in your calendar</a> · <a href="' . esc_url( $https ) . '">download .ics</a></p>';
} );

/* ============================================================== JSON-LD */

add_action( 'wp_head', function () {
	$graph = array();
	if ( is_front_page() ) {
		$graph[] = array(
			'@type'       => 'Organization',
			'@id'         => home_url( '/#org' ),
			'name'        => 'United States Universities Council on Geotechnical Education and Research',
			'alternateName' => 'USUCGER',
			'url'         => home_url( '/' ),
			'email'       => usucger_core_opt( 'contact_email' ),
			'description' => 'A council of U.S. universities that promotes geotechnical engineering education and research.',
		);
	}
	if ( is_page( array( 'conferences', 'calendar' ) ) || is_front_page() ) {
		foreach ( usucger_ical_events() as $e ) {
			if ( 0 !== strpos( $e['uid'], 'conference-' ) || $e['end'] < usucger_today() ) {
				continue;
			}
			$ev = array(
				'@type'               => 'Event',
				'name'                => $e['title'],
				'startDate'           => $e['start'],
				'endDate'             => $e['end'],
				'eventAttendanceMode' => 'https://schema.org/OfflineEventAttendanceMode',
				'eventStatus'         => 'https://schema.org/EventScheduled',
			);
			if ( $e['where'] ) {
				$ev['location'] = array( '@type' => 'Place', 'name' => $e['where'], 'address' => $e['where'] );
			}
			if ( $e['url'] ) {
				$ev['url'] = $e['url'];
			}
			$graph[] = $ev;
		}
	}
	if ( $graph ) {
		echo '<script type="application/ld+json">' . wp_json_encode( array( '@context' => 'https://schema.org', '@graph' => $graph ), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG ) . "</script>\n";
	}
}, 5 );

/* ======================================================= download my data */

function usucger_user_data( $uid ) {
	global $wpdb;
	$u = get_userdata( $uid );
	if ( ! $u ) {
		return array();
	}
	$email = strtolower( $u->user_email );
	$p     = usucger_profile( $uid );
	$c     = $p ? $p->contact : null;
	$data  = array(
		'generated' => gmdate( 'c' ),
		'account'   => array( 'login' => $u->user_login, 'email' => $u->user_email, 'name' => $p ? $p->name : '', 'registered' => $u->user_registered ),
		'profile'   => $p ? array(
			'rank'        => $p->rank,
			'title'       => $p->title,
			'institution' => $p->institution,
			'expertise'   => $p->expertise,
			'summary'     => $p->summary,
			'links'       => $p->links,
			'photo'       => $p->photo,
			'listed_in_expert_finder' => $p->visible,
		) : array(),
		'membership' => $c ? array(
			'status'        => $c->status,
			'category'      => $c->category,
			'institution'   => $c->institution,
			'start'         => $c->start_date,
			'end'           => $c->end_date,
			'in_directory'  => (bool) $c->in_directory,
			'announcements' => ! $c->unsub_news,
			'renewal_reminders' => ! $c->unsub_renewal,
		) : null,
		'events'     => array(),
		'emails'     => array(),
		'elections'  => array(),
	);
	foreach ( usucger_my_events( $uid ) as $r ) {
		$data['events'][] = array( 'event' => $r->event_name, 'start' => $r->event_start, 'end' => $r->event_end, 'location' => $r->location, 'role' => $r->role );
	}
	$ot = Usucger_DB::t( 'outbox' );
	foreach ( $wpdb->get_results( $wpdb->prepare( "SELECT subject, status, sent_at FROM $ot WHERE email = %s ORDER BY id DESC LIMIT 500", $email ) ) as $r ) {
		$data['emails'][] = array( 'subject' => $r->subject, 'status' => $r->status, 'sent' => $r->sent_at );
	}
	$vt = Usucger_DB::t( 'voters' );
	foreach ( $wpdb->get_results( $wpdb->prepare( "SELECT election_id, institution, IF(delegate_email = %s, 'delegate', 'alternate') role, voted_at FROM $vt WHERE delegate_email = %s OR alternate_email = %s", $email, $email, $email ) ) as $r ) {
		$e                   = usucger_election( $r->election_id );
		$data['elections'][] = array( 'election' => $e ? $e->title : $r->election_id, 'institution' => $r->institution, 'role' => $r->role, 'institution_voted' => $r->voted_at ? true : false );
	}
	$cn = Usucger_DB::t( 'candidates' );
	foreach ( $wpdb->get_results( $wpdb->prepare( "SELECT election_id, position, status, title_line, department, institution, experience, vision FROM $cn WHERE email = %s", $email ) ) as $r ) {
		$e                   = usucger_election( $r->election_id );
		$data['candidacies'][] = array( 'election' => $e ? $e->title : $r->election_id ) + (array) $r;
	}
	return $data;
}

add_action( 'admin_post_usucger_my_data', function () {
	check_admin_referer( 'usucger_my_data' );
	$uid = get_current_user_id();
	Usucger_DB::log( 'data_download', 'user:' . $uid );
	nocache_headers();
	header( 'Content-Type: application/json; charset=utf-8' );
	header( 'Content-Disposition: attachment; filename="usucger-my-data-' . gmdate( 'Y-m-d' ) . '.json"' );
	echo wp_json_encode( usucger_user_data( $uid ), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ); // phpcs:ignore
	exit;
} );

/* ================================================= printable membership receipt */

function usucger_receipt_url() {
	return wp_nonce_url( admin_url( 'admin-post.php?action=usucger_receipt' ), 'usucger_receipt' );
}

add_action( 'admin_post_usucger_receipt', function () {
	check_admin_referer( 'usucger_receipt' );
	$u = wp_get_current_user();
	$c = usucger_my_contact();
	if ( ! $c || ! in_array( $c->status, array( 'current', 'lapsed', 'former' ), true ) ) {
		wp_die( 'No membership is on file for this account. Write to ' . esc_html( usucger_core_opt( 'contact_email' ) ) . '.' );
	}
	$plan  = $c->plan_id ? get_the_title( $c->plan_id ) : '';
	$order = null;
	if ( function_exists( 'wc_memberships_get_user_memberships' ) ) {
		foreach ( (array) wc_memberships_get_user_memberships( $u->ID ) as $um ) {
			if ( ( ! $c->plan_id || (int) $um->get_plan_id() === (int) $c->plan_id ) && method_exists( $um, 'get_order' ) && $um->get_order() ) {
				$order = $um->get_order();
				break;
			}
		}
	}
	if ( ! $order && function_exists( 'wc_get_orders' ) && ! function_exists( 'wc_memberships_get_user_memberships' ) ) {
		$orders = wc_get_orders( array( 'customer_id' => $u->ID, 'status' => array( 'wc-completed', 'wc-processing' ), 'limit' => 1, 'orderby' => 'date', 'order' => 'DESC' ) );
		$order  = $orders ? $orders[0] : null;
	}
	$name  = trim( $c->first_name . ' ' . $c->last_name );
	$color = sanitize_hex_color( usucger_core_opt( 'letter_color' ) );
	$row   = function ( $k, $v ) {
		return $v ? '<tr><th>' . esc_html( $k ) . '</th><td>' . esc_html( $v ) . '</td></tr>' : '';
	};
	Usucger_DB::log( 'receipt_viewed', 'contact:' . $c->id );
	nocache_headers();
	?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>USUCGER membership confirmation</title>
	<style>body{font:15px/1.55 Georgia,serif;color:#1d2327;background:#f4f4f2;margin:0;padding:2rem 1rem}.sheet{max-width:680px;margin:0 auto;background:#fff;padding:2.5rem 2.75rem;border-top:6px solid <?php echo esc_html( $color ? $color : '#C2410C' ); ?>;box-shadow:0 1px 3px rgba(0,0,0,.08)}h1{font-size:1.5rem;margin:0 0 .2rem}.sub{color:#50575e;margin:0 0 1.8rem;font-family:system-ui,sans-serif;font-size:.85rem;letter-spacing:.04em;text-transform:uppercase}table{width:100%;border-collapse:collapse;margin:1rem 0 1.6rem}th,td{text-align:left;padding:.55rem .4rem;border-bottom:1px solid #e5e5e5;vertical-align:top}th{width:38%;font-weight:600;font-family:system-ui,sans-serif;font-size:.9rem;color:#50575e}.foot{font-size:.85rem;color:#50575e}.bar{max-width:680px;margin:0 auto 1rem;text-align:right;font-family:system-ui,sans-serif}.bar button{font:inherit;padding:.45rem 1rem;border:1px solid #1d2327;background:#fff;cursor:pointer;border-radius:4px}@media print{body{background:#fff;padding:0}.sheet{box-shadow:none}.bar{display:none}}</style></head><body>
	<div class="bar"><button type="button" onclick="window.print()">Print or save as PDF</button></div>
	<main class="sheet"><h1>United States Universities Council on Geotechnical Education and Research</h1><p class="sub">Membership confirmation</p>
	<p>This confirms that the person named below <?php echo 'current' === $c->status ? 'is a member' : 'was a member'; ?> of USUCGER.</p>
	<table><?php
	echo $row( 'Member', $name ); // phpcs:ignore
	echo $row( 'Email', $c->email ); // phpcs:ignore
	echo $row( 'Institution', $c->institution ); // phpcs:ignore
	echo $row( 'Membership', $plan ? $plan : $c->category ); // phpcs:ignore
	echo $row( 'Cycle', usucger_core_opt( 'cycle' ) ); // phpcs:ignore
	echo $row( 'Valid from', $c->start_date ? usucger_fmt_date( $c->start_date, 'F j, Y' ) : '' ); // phpcs:ignore
	echo $row( 'Valid through', $c->end_date ? usucger_fmt_date( $c->end_date, 'F j, Y' ) : '' ); // phpcs:ignore
	echo $row( 'Status on ' . wp_date( 'F j, Y' ), 'current' === $c->status ? 'Active' : 'Not renewed' ); // phpcs:ignore
	if ( $order ) {
		echo $row( 'Order', '#' . $order->get_order_number() . ' — ' . wp_date( 'F j, Y', $order->get_date_created()->getTimestamp() ) ); // phpcs:ignore
		echo $row( 'Amount paid', html_entity_decode( wp_strip_all_tags( wc_price( $order->get_total(), array( 'currency' => $order->get_currency() ) ) ) ) ); // phpcs:ignore
	} else {
		echo $row( 'Dues', usucger_core_opt( 'dues' ) . ' per person for the cycle' ); // phpcs:ignore
	}
	?></table>
	<p class="foot"><?php echo esc_html( usucger_core_opt( 'signer_name' ) ); ?><br><?php echo esc_html( usucger_core_opt( 'signer_title' ) ); ?><br><?php echo esc_html( usucger_core_opt( 'contact_email' ) ); ?> · <?php echo esc_html( preg_replace( '#^https?://#', '', home_url() ) ); ?></p>
	<?php $acct = function_exists( 'wc_get_page_id' ) && wc_get_page_id( 'myaccount' ) > 0 ? wc_get_endpoint_url( 'orders', '', wc_get_page_permalink( 'myaccount' ) ) : ''; ?>
	<p class="foot">USUCGER is a non-profit council of universities. For a tax receipt from the payment, use the order confirmation email<?php echo $acct ? ' or <a href="' . esc_url( $acct ) . '">My account → Orders</a>' : ''; ?>.</p></main></body></html>
	<?php
	exit;
} );

/* ========================================= delegate names the alternate (portal) */

/** Member institution(s) for which the signed-in user is the delegate. */
function usucger_my_delegations() {
	global $wpdb;
	$u = wp_get_current_user();
	if ( ! $u->ID ) {
		return array();
	}
	$it = Usucger_DB::t( 'institutions' );
	return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $it WHERE status = 'member' AND LOWER(contact_email) = %s", strtolower( $u->user_email ) ) );
}

function usucger_alternate_box() {
	$out = '';
	foreach ( usucger_my_delegations() as $i ) {
		$e      = function_exists( 'usucger_current_election' ) ? usucger_current_election() : null;
		$locked = false;
		if ( $e && in_array( usucger_election_phase( $e ), array( 'voting' ), true ) ) {
			$v      = $GLOBALS['wpdb']->get_row( $GLOBALS['wpdb']->prepare( 'SELECT voted_at FROM ' . Usucger_DB::t( 'voters' ) . ' WHERE election_id = %d AND institution_id = %d', $e->id, $i->id ) );
			$locked = $v && $v->voted_at;
		}
		$out .= '<div class="usg-card" id="alternate"><div class="usg-card-h"><h3>Delegate for ' . esc_html( $i->name ) . '</h3></div>'
			. '<p class="usg-muted">You cast your institution’s ballot in USUCGER elections (By-Laws Art. III). You may name one alternate — another current, paid member from ' . esc_html( $i->name ) . ' — who can vote if you cannot. Only one ballot per institution counts.</p><p><strong>Alternate on file:</strong> ' . ( $i->alternate_email ? esc_html( trim( $i->alternate_name . ' <' . $i->alternate_email . '>' ) ) : 'none' ) . '</p>';
		if ( usucger_flash_read( 'alt_saved' ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			$out .= '<div class="usg-notice usg-ok">' . esc_html( usucger_flash_read( 'alt_saved' ) ) . '</div>'; // phpcs:ignore
		}
		if ( $locked ) {
			$out .= '<p><strong>Your institution has already voted</strong> in the current election, so the alternate cannot be changed until it closes.</p></div>';
			continue;
		}
		$out .= '<form method="post" class="usg-form" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">' . wp_nonce_field( 'usucger_alternate_' . $i->id, '_wpnonce', true, false ) . '<input type="hidden" name="action" value="usucger_alternate"><input type="hidden" name="inst" value="' . (int) $i->id . '">'
			. '<div class="usg-row2"><div><label for="altn' . (int) $i->id . '">Alternate’s name</label><input id="altn' . (int) $i->id . '" name="alt_name" value="' . esc_attr( $i->alternate_name ) . '" maxlength="190"></div>'
			. '<div><label for="alte' . (int) $i->id . '">Alternate’s email</label><input id="alte' . (int) $i->id . '" type="email" name="alt_email" value="' . esc_attr( $i->alternate_email ) . '" maxlength="190"></div></div>'
			. '<button class="btn btn-cobalt btn-sm" type="submit">Save alternate</button>' . ( $i->alternate_email ? ' <button class="btn btn-ghost btn-sm" type="submit" name="clear" value="1">Remove alternate</button>' : '' ) . '</form></div>';
	}
	return $out;
}

add_action( 'admin_post_usucger_alternate', function () {
	global $wpdb;
	$iid = isset( $_POST['inst'] ) ? (int) $_POST['inst'] : 0;
	check_admin_referer( 'usucger_alternate_' . $iid );
	$mine = wp_list_pluck( usucger_my_delegations(), 'id' );
	$back = add_query_arg( 'tab', 'vote', usucger_portal_url() );
	if ( ! in_array( (string) $iid, array_map( 'strval', $mine ), true ) ) {
		wp_die( 'Only the delegate of record can name the alternate.' );
	}
	$it    = Usucger_DB::t( 'institutions' );
	$inst  = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $it WHERE id = %d", $iid ) );
	$name  = sanitize_text_field( wp_unslash( isset( $_POST['alt_name'] ) ? $_POST['alt_name'] : '' ) );
	$email = strtolower( sanitize_email( wp_unslash( isset( $_POST['alt_email'] ) ? $_POST['alt_email'] : '' ) ) );
	if ( ! empty( $_POST['clear'] ) ) {
		$name  = '';
		$email = '';
	} else {
		if ( ! is_email( $email ) ) {
			wp_safe_redirect( add_query_arg( usucger_flash_arg( 'alt_saved', 'Please enter a valid email address.' ), $back ) . '#alternate' );
			exit;
		}
		if ( strtolower( $inst->contact_email ) === $email ) {
			wp_safe_redirect( add_query_arg( usucger_flash_arg( 'alt_saved', 'The alternate must be a different person from the delegate.' ), $back ) . '#alternate' );
			exit;
		}
		$ct = Usucger_DB::t( 'contacts' );
		$c  = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $ct WHERE email = %s", $email ) );
		$names = array_map( 'usucger_norm', array_merge( array( $inst->name ), array_filter( array_map( 'trim', explode( ';', (string) $inst->aliases ) ) ) ) );
		if ( $c && $c->institution && ! in_array( usucger_norm( $c->institution ), $names, true ) ) {
			wp_safe_redirect( add_query_arg( usucger_flash_arg( 'alt_saved', 'The alternate must be a member from ' . $inst->name . ' (our records list ' . $email . ' at ' . $c->institution . '). Ask the Membership Coordinator if that is out of date.' ), $back ) . '#alternate' );
			exit;
		}
		if ( ! $c || 'current' !== $c->status ) {
			wp_safe_redirect( add_query_arg( usucger_flash_arg( 'alt_saved', 'Not saved: ' . $email . ' is not a current paid USUCGER member. The alternate must be a paid member from ' . $inst->name . ' (By-Laws Art. III); they can renew, then you can name them here.' ), $back ) . '#alternate' );
			exit;
		}
	}
	$wpdb->update( $it, array( 'alternate_name' => $name, 'alternate_email' => $email, 'updated' => current_time( 'mysql' ) ), array( 'id' => $iid ) );
	Usucger_DB::log( 'alternate_named', 'institution:' . $iid, ( $email ? $name . ' <' . $email . '>' : 'removed' ) );
	$e = function_exists( 'usucger_current_election' ) ? usucger_current_election() : null;
	if ( $e && in_array( usucger_election_phase( $e ), array( 'nominations', 'review', 'voting', 'scheduled' ), true ) ) {
		usucger_election_build_roll( $e->id );
		$to = usucger_election_notify_to();
		usucger_notify( $to, 'Alternate updated: ' . $inst->name, '<p>' . esc_html( wp_get_current_user()->display_name ) . ' (delegate) ' . ( $email ? 'named <strong>' . esc_html( $name . ' <' . $email . '>' ) . '</strong> as alternate' : 'removed the alternate' ) . ' for ' . esc_html( $inst->name ) . '. The voter roll was refreshed. If voting is open, use “Resend ballot” on the election page to send the alternate a link.</p>' );
	}
	{
		wp_safe_redirect( add_query_arg( usucger_flash_arg( 'alt_saved', $email ? 'Alternate saved.' : 'Alternate removed.' ), $back ) . '#alternate' );
	}
	exit;
} );

/* ===================================== institution changes need approval */

function usucger_inst_requests() {
	$r = get_option( 'usucger_inst_requests', array() );
	return is_array( $r ) ? $r : array();
}

/**
 * Apply or queue an institution change. Current members' institution decides voting
 * eligibility, the directory and the map, so a change away from a non-empty institution
 * waits for the Membership Coordinator / webmaster. Returns 'applied' | 'queued' | 'same'.
 */
function usucger_change_institution( $c, $new ) {
	global $wpdb;
	$new = trim( sanitize_text_field( $new ) );
	if ( ! $c || '' === $new || usucger_norm( $new ) === usucger_norm( $c->institution ) ) {
		return 'same';
	}
	if ( 'current' !== $c->status || '' === trim( (string) $c->institution ) ) {
		$wpdb->update( Usucger_DB::t( 'contacts' ), array( 'institution' => $new, 'updated' => current_time( 'mysql' ) ), array( 'id' => $c->id ) );
		return 'applied';
	}
	$r            = usucger_inst_requests();
	$r[ $c->id ]  = array( 'old' => $c->institution, 'new' => $new, 'at' => current_time( 'mysql' ), 'uid' => get_current_user_id() );
	update_option( 'usucger_inst_requests', $r, false );
	delete_transient( 'usucger_datafix_counts' );
	Usucger_DB::log( 'institution_change_requested', 'contact:' . $c->id, $c->institution . ' → ' . $new );
	$to = array();
	foreach ( get_users( array( 'role__in' => array( 'usucger_coordinator' ), 'fields' => array( 'user_email' ) ) ) as $u ) {
		$to[] = $u->user_email;
	}
	usucger_notify( array_unique( array_merge( $to, usucger_approver_emails() ) ), 'Institution change: ' . trim( $c->first_name . ' ' . $c->last_name ), '<p>' . esc_html( trim( $c->first_name . ' ' . $c->last_name ) ) . ' asked to change their institution from <strong>' . esc_html( $c->institution ) . '</strong> to <strong>' . esc_html( $new ) . '</strong>.</p><p><a href="' . esc_url( usucger_admin_url( 'usucger-datafix', array( 'tab' => 'institutions' ) ) ) . '">Approve or decline</a> (sign-in required)</p>' );
	return 'queued';
}

/* ============================== expert-finder visibility: opt-in + one-time prompt */

function usucger_visibility_prompt() {
	$uid = get_current_user_id();
	if ( ! $uid || '' !== (string) get_user_meta( $uid, 'usg_visible', true ) ) {
		return '';
	}
	return '<div class="usg-card usg-prompt" id="findable"><h3>Be findable by colleagues?</h3><p>Signed-in members can search the expert finder by topic (e.g. “liquefaction”) and see who is going to which conference. Your profile is <strong>hidden until you choose</strong>. Your email address is never shown.</p>'
		. '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="usg-inline">' . wp_nonce_field( 'usucger_visibility', '_wpnonce', true, false ) . '<input type="hidden" name="action" value="usucger_visibility">'
		. '<button class="btn btn-cobalt btn-sm" name="v" value="1">Yes, list me for other members</button> <button class="btn btn-ghost btn-sm" name="v" value="0">Not now</button></form></div>';
}

add_action( 'admin_post_usucger_visibility', function () {
	check_admin_referer( 'usucger_visibility' );
	update_user_meta( get_current_user_id(), 'usg_visible', empty( $_POST['v'] ) ? '0' : '1' );
	usucger_bump_content_version();
	wp_safe_redirect( add_query_arg( 'tab', empty( $_POST['v'] ) ? 'home' : 'profile', usucger_portal_url() ) );
	exit;
} );

/* ============================================================ data retention */

function usucger_retention_purge() {
	global $wpdb;
	$ot   = Usucger_DB::t( 'outbox' );
	$days = max( 30, (int) usucger_core_opt( 'retention_days' ) );
	$cut  = function ( $d ) {
		return wp_date( 'Y-m-d H:i:s', time() - $d * DAY_IN_SECONDS ); // rows are stored in site time
	};
	$n1   = $wpdb->query( $wpdb->prepare( "UPDATE $ot SET body = '' WHERE status IN ('sent','failed','skipped','cancelled') AND body <> '' AND created < %s", $cut( $days ) ) );
	$n2   = 0;
	$et   = Usucger_DB::t( 'elections' );
	$vt   = Usucger_DB::t( 'voters' );
	$tdays = max( 7, (int) usucger_core_opt( 'token_purge_days' ) );
	foreach ( $wpdb->get_col( $wpdb->prepare( "SELECT id FROM $et WHERE status = 'certified' AND certified_at IS NOT NULL AND certified_at < %s", $cut( $tdays ) ) ) as $eid ) {
		$n2 += (int) $wpdb->query( $wpdb->prepare( "UPDATE $vt SET token = '' WHERE election_id = %d AND token <> ''", $eid ) );
	}
	if ( $n1 || $n2 ) {
		Usucger_DB::log( 'retention_purge', 'daily', array( 'email_bodies' => (int) $n1, 'ballot_links' => $n2 ) );
	}
	return array( (int) $n1, $n2 );
}
add_action( 'usucger_daily', 'usucger_retention_purge' );
