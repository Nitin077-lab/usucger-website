<?php
/**
 * Webmaster / Board desk on the public site: [usucger_webmaster] on /webmaster/.
 * Approvers see everything that needs action with one-click buttons; Board members see
 * their own submissions, the email calendar and election turnout.
 *
 * @package usucger-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Dashboards live in the member area (same login); /webmaster/ still works as a shortcut. */
function usucger_desk_url( $args = array() ) {
	return add_query_arg( array_merge( array( 'tab' => 'desk' ), $args ), usucger_portal_url() );
}

function usucger_desk_btn( $url, $label, $cls = 'btn-outline', $confirm = '' ) {
	return '<a class="btn ' . esc_attr( $cls ) . ' btn-sm" href="' . esc_url( $url ) . '"' . ( $confirm ? ' onclick="return confirm(\'' . esc_attr( $confirm ) . '\')"' : '' ) . '>' . $label . '</a>';
}

add_shortcode( 'usucger_webmaster', function () {
	if ( ! is_user_logged_in() ) {
		return '<section class="section bg-white usg-portal"><div class="wrap"><div class="usg-login"><div class="usg-card"><h2>Sign in</h2><p>The desk is for the webmaster and Board members.</p>' . wp_login_form( array( 'echo' => false, 'redirect' => usucger_desk_url() ) ) . '</div></div></div></section>';
	}
	if ( ! current_user_can( 'usucger_compose' ) ) {
		return '<section class="section bg-white usg-portal"><div class="wrap"><div class="usg-card"><h2>Not available</h2><p>This page is for the webmaster and Board members. <a href="' . esc_url( usucger_portal_url() ) . '">Go to the member area &rarr;</a></p></div></div></section>';
	}
	return '<section class="section bg-white usg-portal usg-desk"><div class="wrap">' . usucger_desk_inner() . '</div></section>';
} );

/** Which dashboard this person gets: webmaster / president (or other approver title) / election officer / board. */
function usucger_desk_kind() {
	if ( ! is_user_logged_in() || ! current_user_can( 'usucger_compose' ) ) {
		return '';
	}
	if ( usucger_can_approve() ) {
		return 'Webmaster' === usucger_approver_label() || ! usucger_approver_label() ? 'webmaster' : 'president';
	}
	if ( current_user_can( 'usucger_elections' ) ) {
		return 'officer';
	}
	return in_array( 'usucger_coordinator', (array) wp_get_current_user()->roles, true ) ? 'coordinator' : 'board';
}

function usucger_desk_label() {
	switch ( usucger_desk_kind() ) {
		case 'webmaster':
			return 'Webmaster dashboard';
		case 'president':
			return usucger_approver_label() . ' dashboard';
		case 'officer':
			return 'Board dashboard · Election officer';
		case 'coordinator':
			return 'Membership Coordinator dashboard';
		case 'board':
			return 'Board dashboard';
	}
	return '';
}

/** Board resources card shared by every dashboard. */
function usucger_desk_resources() {
	$board = esc_attr( usucger_core_opt( 'board_email' ) );
	$links = array(
		array( admin_url( 'post-new.php?post_type=usucger_position' ), 'Post a position' ),
		array( admin_url( 'post-new.php?post_type=usucger_conference' ), 'Add a conference' ),
		array( admin_url( 'post-new.php?post_type=usucger_deadline' ), 'Add a deadline' ),
		array( admin_url( 'post-new.php?post_type=usucger_minutes' ), 'Upload minutes' ),
		array( admin_url( 'edit.php?post_type=page' ), 'Suggest a page change' ),
		array( usucger_admin_url( 'usucger-compose' ), 'Compose an email' ),
		array( usucger_admin_url( 'usucger-members' ), 'Member list' ),
		array( usucger_admin_url( 'usucger-guide' ), 'Board guide' ),
		array( usucger_core_url( 'bylaws' ), 'By-Laws' ),
		array( usucger_core_url( 'minutes' ), 'Meeting minutes' ),
		array( 'mailto:' . $board, 'Email the whole Board' ),
	);
	$o = '<div class="usg-card"><h3>Board resources</h3><div class="usg-shortcuts">';
	foreach ( $links as $l ) {
		$o .= '<a href="' . esc_url( $l[0] ) . '">' . esc_html( $l[1] ) . '</a>';
	}
	$o .= '</div>';
	if ( ! usucger_can_approve() ) {
		$o .= '<p class="usg-small">Your changes are saved as drafts and go live after the webmaster or President approves them.</p>';
	}
	return $o . '</div>';
}

function usucger_desk_inner() {
	global $wpdb;
	$approver = usucger_can_approve();
	$u        = wp_get_current_user();
	$bt       = Usucger_DB::t( 'batches' );
	$ot       = Usucger_DB::t( 'outbox' );
	$counts   = Usucger_Members::counts();
	$views    = usucger_daily_views( 30 );
	$sent30   = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $ot WHERE status = 'sent' AND sent_at >= %s", gmdate( 'Y-m-d', strtotime( '-30 days' ) ) ) );
	$msg      = isset( $_GET['done'] ) ? sanitize_text_field( wp_unslash( $_GET['done'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	$n        = get_transient( 'usucger_notice_' . get_current_user_id() );
	if ( $n ) {
		delete_transient( 'usucger_notice_' . get_current_user_id() );
		$msg = $n[0];
	}
	$back = rawurlencode( usucger_desk_url() );

	$o  = '';
	$o .= '<div class="usg-desk-head"><div><div class="eyebrow"><span class="eyebrow-line"></span>' . esc_html( usucger_desk_label() ) . ' · ' . esc_html( wp_date( 'l, F j' ) ) . '</div><h2>Hello, ' . esc_html( $u->first_name ? $u->first_name : $u->display_name ) . '</h2></div><div class="usg-desk-links"><span class="usg-muted">Signed in as ' . esc_html( $u->display_name ) . ' · <a href="' . esc_url( wp_logout_url( home_url( '/' ) ) ) . '">Sign out</a></span><a href="' . esc_url( admin_url( 'admin.php?page=usucger' ) ) . '">Full admin</a><a href="' . esc_url( usucger_admin_url( 'usucger-compose' ) ) . '">Compose email</a><a href="' . esc_url( usucger_portal_url() ) . '">Member area</a></div></div>';
	if ( $msg ) {
		$o .= '<div class="usg-notice"><strong>' . wp_kses_post( $msg ) . '</strong></div>';
	}
	if ( $approver && usucger_cron_health() ) {
		$o .= '<div class="usg-notice" style="border-left-color:#b32d2e"><strong>Outbox stalled.</strong> ' . esc_html( usucger_cron_health() ) . '</div>';
	}

	// KPI tiles
	$e = usucger_current_election();
	$t = $e ? usucger_turnout( $e->id ) : null;
	$o .= '<div class="usg-kpis">'
		. '<div class="usg-kpi"><b>' . (int) $counts['current'] . '</b><span>Current members</span></div>'
		. '<div class="usg-kpi warn"><b>' . (int) $counts['lapsed'] . '</b><span>Not renewed</span></div>'
		. '<div class="usg-kpi"><b>' . (int) count( Usucger_Members::institutions() ) . '</b><span>Member universities</span></div>'
		. ( $t && $e && in_array( usucger_election_phase( $e ), array( 'voting', 'closed' ), true ) ? '<div class="usg-kpi blue"><b>' . (int) $t['voted'] . '/' . (int) $t['eligible'] . '</b><span>Institutions voted</span></div>' : '' )
		. '<div class="usg-kpi"><b>' . (int) $sent30 . '</b><span>Emails sent (30 days)</span></div>'
		. '<div class="usg-kpi"><b>' . (int) array_sum( $views ) . '</b><span>Page views (30 days)</span></div></div>';

	$o .= '<div class="usg-grid2"><div>';

	// ---- needs attention
	$content = $approver ? usucger_review_items() : get_posts( array( 'post_type' => usucger_reviewed_types(), 'post_status' => array( 'draft', 'pending' ), 'author' => get_current_user_id(), 'posts_per_page' => 20 ) );
	$emails  = $approver ? $wpdb->get_results( "SELECT * FROM $bt WHERE status = 'pending' ORDER BY id" ) : $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $bt WHERE created_by = %d AND status IN ('draft','pending','rejected','sending') ORDER BY id DESC LIMIT 10", get_current_user_id() ) ); // phpcs:ignore WordPress.DB
	if ( ! $approver && usucger_can_run_elections() ) {
		$emails = array_merge( $emails, $wpdb->get_results( "SELECT * FROM $bt WHERE status = 'pending' AND (source = 'election' OR group_key IN ('voters_all','voters_pending','candidates','candidates_packet','candidates_not_asked')) AND created_by <> " . (int) get_current_user_id() ) ); // phpcs:ignore WordPress.DB
	}
	$drafts  = $approver ? $wpdb->get_results( "SELECT * FROM $bt WHERE status = 'draft' AND (source LIKE 'calendar:%' OR source = 'election') ORDER BY id" ) : array(); // phpcs:ignore WordPress.DB
	$o .= '<div class="usg-card"><div class="usg-card-h"><h3>' . ( $approver ? 'Needs your approval' : 'My submissions' ) . '</h3><span class="usg-pill">' . (int) ( count( $content ) + count( $emails ) + count( $drafts ) ) . '</span></div>';
	if ( ! $content && ! $emails && ! $drafts ) {
		$o .= '<p class="usg-muted">All clear — nothing waiting.</p>';
	}
	if ( $content ) {
		$o .= '<h4>Website changes</h4><ul class="usg-list usg-actions">';
		foreach ( $content as $p ) {
			$of = (int) get_post_meta( $p->ID, '_usucger_cr_of', true );
			$au = get_userdata( $p->post_author );
			$o .= '<li><div><strong>' . esc_html( $p->post_title ) . '</strong><span>' . esc_html( ( $of ? 'Changes to live ' : 'New ' ) . strtolower( get_post_type_object( $p->post_type )->labels->singular_name ) . ' · ' . usucger_post_by( $p ) . ' · ' . usucger_post_ago( $p ) . ' · ' . $p->post_status ) . '</span></div><div class="usg-btns">';
			if ( $of ) {
				$o .= usucger_desk_btn( usucger_admin_url( 'usucger-review', array( 'diff' => $p->ID ) ), 'Compare' );
			} else {
				$o .= usucger_desk_btn( get_preview_post_link( $p ), 'Preview' );
			}
			if ( $approver && 'pending' === $p->post_status ) {
				$o .= usucger_desk_btn( wp_nonce_url( admin_url( 'admin-post.php?action=usucger_approve&post=' . $p->ID . '&back=' . $back ), 'usucger_approve_' . $p->ID ), 'Approve', 'btn-cobalt', 'Publish this change?' );
			} else {
				$o .= usucger_desk_btn( get_edit_post_link( $p->ID, 'raw' ), 'Edit' );
			}
			$o .= '</div></li>';
		}
		$o .= '</ul>';
	}
	if ( $emails || $drafts ) {
		$o   .= '<h4>Emails</h4><ul class="usg-list usg-actions">';
		$same = array();
		foreach ( $emails as $b ) {
			$k          = $b->subject . '|' . $b->group_key . '|' . $b->group_args;
			$same[ $k ] = isset( $same[ $k ] ) ? $same[ $k ] + 1 : 1;
		}
		foreach ( array_merge( $emails, $drafts ) as $b ) {
			$dupn    = isset( $same[ $b->subject . '|' . $b->group_key . '|' . $b->group_args ] ) ? $same[ $b->subject . '|' . $b->group_key . '|' . $b->group_args ] : 0;
			$b->args = (array) json_decode( (string) $b->group_args, true );
			$au      = get_userdata( $b->created_by );
			$nrec    = 'pending' === $b->status ? (int) $b->total : count( usucger_batch_recipients( $b ) );
			$nonce   = wp_create_nonce( 'usucger_batch_' . $b->id );
			$o      .= '<li><div><strong>' . esc_html( usucger_merge_static( $b->subject, $b->args ) ) . '</strong><span>' . esc_html( usucger_group_label_plain( $b ) . ' · ' . usucger_n( $nrec, 'recipient', 'recipients' ) . ' · ' . ( $au ? $au->display_name : 'scheduled' ) . ' · #' . (int) $b->id . ', ' . ( $b->created ? mysql2date( 'M j, g:i a', $b->created ) : '' ) . ' · ' . ( 'draft' === $b->status ? 'draft ready' : $b->status ) ) . '</span>' . ( 'pending' === $b->status && $dupn > 1 ? '<span class="usg-warn">The same email to the same people is waiting ' . (int) $dupn . ' times — approve one and discard the others.</span>' : '' ) . '</div><div class="usg-btns">'
				. usucger_desk_btn( usucger_admin_url( 'usucger-outbox', array( 'batch' => $b->id ) ), 'Preview' );
			if ( ( $approver || ( usucger_is_election_batch( $b ) && usucger_can_run_elections() ) ) && in_array( $b->status, array( 'pending', 'draft' ), true ) ) {
				$o .= usucger_desk_btn( admin_url( 'admin-post.php?action=usucger_desk_send&batch=' . $b->id . '&_wpnonce=' . wp_create_nonce( 'usucger_desk_send_' . $b->id ) ), 'Approve &amp; send', 'btn-cobalt', 'Send #' . (int) $b->id . ' to ' . usucger_n( $nrec, 'recipient', 'recipients' ) . '?' );
			} elseif ( in_array( $b->status, array( 'draft', 'rejected' ), true ) ) {
				$o .= usucger_desk_btn( usucger_admin_url( 'usucger-compose', array( 'batch' => $b->id ) ), 'Edit' );
			}
			$o .= '</div></li>';
		}
		$o .= '</ul>';
	}
	$o .= '</div>';

	// ---- email calendar
	$rows  = usucger_comm_rows();
	$today = usucger_today();
	$soon  = gmdate( 'Y-m-d', strtotime( '+75 days' ) );
	$o    .= '<div class="usg-card"><div class="usg-card-h"><h3>Key emails</h3>' . ( $approver ? '<a href="' . esc_url( usucger_admin_url( 'usucger-calendar' ) ) . '">Edit calendar &rarr;</a>' : '' ) . '</div><table class="usg-table usg-cal"><tbody>';
	$shown = 0;
	foreach ( $rows as $r ) {
		$late = 'overdue' === $r['status'];
		if ( ! $late && ( $r['date'] > $soon || ( $r['date'] < $today && in_array( $r['status'], array( 'sent', 'skipped' ), true ) && usucger_days_between( $r['date'], $today ) > 14 ) ) ) {
			continue;
		}
		$shown++;
		$act = '';
		if ( $approver && 'Key email' === $r['source'] && 'upcoming' === $r['status'] ) {
			$act = usucger_desk_btn( admin_url( 'admin-post.php?action=usucger_desk_cal&key=' . rawurlencode( $r['key'] ) . '&_wpnonce=' . wp_create_nonce( 'usucger_desk_cal' ) ), 'Draft now' );
		} elseif ( $r['batch'] && in_array( $r['status'], array( 'draft', 'awaiting', 'overdue' ), true ) ) {
			$act = usucger_desk_btn( usucger_admin_url( 'usucger-outbox', array( 'batch' => $r['batch'] ) ), 'Open' );
		}
		$o .= '<tr class="' . ( $late ? 'late' : '' ) . '"><td class="d">' . esc_html( usucger_fmt_date( $r['date'], 'M j' ) ) . '</td><td><strong>' . esc_html( $r['title'] ) . '</strong><span>' . esc_html( $r['source'] ) . '</span></td><td><span class="usg-st ' . esc_attr( $r['status'] ) . '">' . esc_html( usucger_cal_status_label( $r['status'] ) ) . '</span></td><td class="a">' . $act . '</td></tr>';
	}
	if ( ! $shown ) {
		$o .= '<tr><td colspan="4" class="usg-muted">Nothing due in the next 75 days.</td></tr>';
	}
	$o .= '</tbody></table></div>';
	$o .= '</div><div>';

	// ---- election card
	if ( $e ) {
		$phase = usucger_election_phase( $e );
		$o    .= '<div class="usg-card"><div class="usg-card-h"><h3>' . esc_html( $e->title ) . '</h3><span class="usg-st ' . esc_attr( $phase ) . '">' . esc_html( usucger_phase_labels()[ $phase ] ) . '</span></div>';
		$o    .= '<p class="usg-muted">Nominations ' . esc_html( usucger_fmt_date( $e->nom_open, 'M j' ) . '–' . usucger_fmt_date( $e->nom_close, 'M j' ) ) . ' · Voting ' . esc_html( usucger_fmt_date( $e->vote_open, 'M j' ) . '–' . usucger_fmt_date( $e->vote_close, 'M j, Y' ) ) . '</p>';
		if ( in_array( $phase, array( 'voting', 'closed' ), true ) ) {
			$o .= '<div class="usg-turnout"><div class="usg-meter"><i style="width:' . (int) $t['pct'] . '%"></i></div><span><strong>' . (int) $t['voted'] . '</strong> of ' . (int) $t['eligible'] . ' institutions (' . (int) $t['pct'] . '%)</span></div>';
			$pending = usucger_voters( $e->id, 'AND eligible = 1 AND voted_at IS NULL' );
			if ( $pending && 'voting' === $phase ) {
				$o .= '<details><summary>' . count( $pending ) . ' institutions have not voted</summary><ul class="usg-list usg-list-tight">';
				foreach ( array_slice( $pending, 0, 60 ) as $v ) {
					$o .= '<li><strong>' . esc_html( $v->institution ) . '</strong><span>' . esc_html( $v->delegate_name ) . '</span></li>';
				}
				$o .= '</ul></details>';
				if ( usucger_can_run_elections() ) {
					$o .= '<p>' . usucger_desk_btn( admin_url( 'admin-post.php?action=usucger_desk_remind&e=' . $e->id . '&_wpnonce=' . wp_create_nonce( 'usucger_desk_remind' ) ), 'Remind non-voters now', 'btn-amber', 'Email a reminder to the delegates and alternates of ' . count( $pending ) . ' institutions that have not voted?' ) . '</p>';
				}
			}
		} elseif ( 'nominations' === $phase || 'review' === $phase ) {
			$cs = usucger_candidates( $e->id );
			$by = array();
			foreach ( $cs as $c ) {
				$by[ $c->status ] = isset( $by[ $c->status ] ) ? $by[ $c->status ] + 1 : 1;
			}
			$o .= '<p>' . (int) count( $cs ) . ' nominations';
			foreach ( $by as $s => $k ) {
				$o .= ' · ' . (int) $k . ' ' . esc_html( $s );
			}
			$o .= '</p>';
		}
		if ( usucger_can_run_elections() && 'board' === $e->kind && in_array( $phase, array( 'scheduled', 'nominations', 'review' ), true ) ) {
			$na = count( Usucger_Members::recipients( 'candidates_not_asked', array( 'election' => $e->id ), 'official' ) );
			$ms = count( Usucger_Members::recipients( 'candidates_packet', array( 'election' => $e->id ), 'official' ) );
			$o .= '<p class="usg-muted">Candidate statements due ' . esc_html( usucger_fmt_date( usucger_packet_due( $e ), 'M j' ) ) . ': ' . (int) $ms . ' missing.</p>';
			$en = wp_create_nonce( 'usucger_el_' . $e->id );
			$uc = count( Usucger_Members::recipients( 'candidates_unconfirmed', array( 'election' => $e->id ), 'official' ) );
			if ( $uc ) {
				$o .= '<p>' . usucger_desk_btn( admin_url( 'admin-post.php?action=usucger_el&op=accept_ask&e=' . $e->id . '&_wpnonce=' . $en ), 'Ask ' . $uc . ' nominee' . ( 1 === $uc ? '' : 's' ) . ' if willing to serve', 'btn-outline' ) . '</p>';
			}
			if ( $na ) {
				$o .= '<p>' . usucger_desk_btn( admin_url( 'admin-post.php?action=usucger_el&op=packet_ask&e=' . $e->id . '&_wpnonce=' . $en ), 'Ask ' . $na . ' new nominee' . ( 1 === $na ? '' : 's' ) . ' for statements', 'btn-cobalt' ) . '</p>';
			}
		}
		if ( usucger_can_run_elections() ) {
			$o .= '<p class="usg-small"><a href="' . esc_url( usucger_admin_url( 'usucger-elections', array( 'id' => $e->id ) ) ) . '">Manage election &rarr;</a></p>';
		}
		$o .= '</div>';
	} elseif ( $approver ) {
		$o .= '<div class="usg-card"><h3>Elections</h3><p class="usg-muted">No election is set up. The By-Laws timeline: nominations by Sept 30, close Oct 30, votes by Dec 1.</p><a class="btn btn-outline btn-sm" href="' . esc_url( usucger_admin_url( 'usucger-elections', array( 'new' => 1 ) ) ) . '">Set up this year’s election</a></div>';
	}

	// ---- membership health
	if ( $approver ) {
		$cands = count( Usucger_Members::removal_candidates() );
		$risk  = count( Usucger_Members::institutions_at_risk() );
		$next  = null;
		foreach ( usucger_renewal_plan() as $s ) {
			if ( empty( $s['batch'] ) ) {
				$next = $s;
				break;
			}
		}
		$o .= '<div class="usg-card"><h3>Membership</h3><ul class="usg-list usg-list-tight">'
			. '<li><strong>Next renewal reminder</strong><span>' . ( $next ? esc_html( usucger_fmt_date( $next['date'], 'F j' ) ) . ' — to ' . (int) count( Usucger_Members::recipients( $next['group'], array( 'days' => $next['days'] ), 'renewal' ) ) . ' people' : 'none scheduled' ) . '</span></li>'
			. '<li><strong>Past the grace period</strong><span>' . (int) $cands . ' not-renewed members can be removed</span></li>'
			. '<li><strong>Universities with no paid member</strong><span>' . (int) $risk . '</span></li></ul>'
			. '<p class="usg-small"><a href="' . esc_url( usucger_admin_url( 'usucger-renewals' ) ) . '">Renewals &amp; cleanup &rarr;</a> · <a href="' . esc_url( usucger_admin_url( 'usucger-members' ) ) . '">Members &rarr;</a></p></div>';
	}

	$o .= usucger_desk_resources();

	// ---- visits
	$max = max( 1, max( $views ) );
	$o  .= '<div class="usg-card"><h3>Website visits</h3><div class="usg-bars">';
	foreach ( $views as $d => $v ) {
		$o .= '<i style="height:' . (int) round( 100 * $v / $max ) . '%" title="' . esc_attr( $d . ': ' . $v ) . '"></i>';
	}
	$o .= '</div><ul class="usg-list usg-list-tight">';
	foreach ( usucger_top_pages( 30, 6 ) as $r ) {
		$o .= '<li><strong>' . esc_html( $r->path ) . '</strong><span>' . (int) $r->v . ' views</span></li>';
	}
	$o .= '</ul></div>';

	// ---- activity
	if ( $approver ) {
		$lt = Usucger_DB::t( 'log' );
		$o .= '<div class="usg-card"><h3>Recent activity</h3><ul class="usg-list usg-list-tight">';
		foreach ( $wpdb->get_results( "SELECT * FROM $lt ORDER BY id DESC LIMIT 8" ) as $l ) { // phpcs:ignore WordPress.DB
			$lu = $l->user_id ? get_userdata( $l->user_id ) : null;
			$o .= '<li><strong>' . esc_html( ucfirst( str_replace( '_', ' ', $l->action ) ) ) . '</strong><span>' . esc_html( ( $lu ? $lu->display_name : 'system' ) . ' · ' . mysql2date( 'M j, g:i a', $l->time ) ) . '</span></li>';
		}
		$o .= '</ul></div>';
	}
	return $o . '</div></div>';
}

function usucger_group_label_plain( $b ) {
	$g = Usucger_Members::groups();
	$l = isset( $g[ $b->group_key ] ) ? $g[ $b->group_key ][0] : $b->group_key;
	return preg_replace( '/\s+—.*$/u', '', $l );
}

/* ----------------------------------------------------------------- actions */

add_action( 'admin_post_usucger_desk_send', function () {
	$id = isset( $_GET['batch'] ) ? (int) $_GET['batch'] : 0;
	check_admin_referer( 'usucger_desk_send_' . $id );
	$b = usucger_batch( $id );
	if ( ! usucger_can_approve() && ! ( usucger_is_election_batch( $b ) && usucger_can_run_elections() ) ) {
		wp_die( 'Only approvers can send.' );
	}
	if ( $b && 'draft' === $b->status ) {
		$r = usucger_batch_submit( $id ); // approvers: submit = approve
	} else {
		$r = usucger_batch_approve( $id );
	}
	usucger_back( usucger_desk_url(), is_wp_error( $r ) ? $r->get_error_message() : 'Approved — sending has started.', is_wp_error( $r ) ? 'error' : 'success' );
} );

add_action( 'admin_post_usucger_desk_cal', function () {
	check_admin_referer( 'usucger_desk_cal' );
	if ( ! usucger_can_approve() ) {
		wp_die( 'Not allowed.' );
	}
	$id = usucger_cal_create_draft( sanitize_key( wp_unslash( $_GET['key'] ) ) );
	usucger_back( $id ? usucger_admin_url( 'usucger-compose', array( 'batch' => $id ) ) : usucger_desk_url(), $id ? 'Draft created — check the dates and links, then send.' : 'Could not create the draft.' );
} );

add_action( 'admin_post_usucger_desk_remind', function () {
	check_admin_referer( 'usucger_desk_remind' );
	if ( ! usucger_can_run_elections() ) {
		wp_die( 'Not allowed.' );
	}
	$e    = usucger_election( (int) $_GET['e'] );
	$tpls = usucger_email_templates();
	if ( ! $e || 'voting' !== usucger_election_phase( $e ) || empty( $tpls['election_reminder'] ) ) {
		usucger_back( usucger_desk_url(), 'Voting is not open.', 'error' );
	}
	usucger_election_build_roll( $e->id );
	$id = usucger_batch_save( array( 'kind' => 'official', 'group_key' => 'voters_pending', 'args' => array( 'election' => $e->id ), 'template_key' => 'election_reminder', 'subject' => $tpls['election_reminder']['subject'], 'body' => $tpls['election_reminder']['body'], 'source' => 'election' ) );
	$r  = usucger_batch_submit( $id );
	usucger_back( usucger_desk_url(), is_wp_error( $r ) ? $r->get_error_message() : 'Reminder is going out to delegates who have not voted.' );
} );
