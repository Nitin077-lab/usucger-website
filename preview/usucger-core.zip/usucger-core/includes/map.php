<?php
/**
 * Member map: US states shaded by number of current members.
 * Members are matched to member institutions by normalised affiliation name;
 * affiliations that are not member institutions can be pinned to a state in
 * USUCGER → Settings → Map ("Affiliation | ST"), and aliases ("Short name = Institution").
 *
 * @package usucger-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function usucger_state_names() {
	return array( 'AK' => 'Alaska', 'AL' => 'Alabama', 'AR' => 'Arkansas', 'AZ' => 'Arizona', 'CA' => 'California', 'CO' => 'Colorado', 'CT' => 'Connecticut', 'DC' => 'District of Columbia', 'DE' => 'Delaware', 'FL' => 'Florida', 'GA' => 'Georgia', 'HI' => 'Hawaii', 'IA' => 'Iowa', 'ID' => 'Idaho', 'IL' => 'Illinois', 'IN' => 'Indiana', 'KS' => 'Kansas', 'KY' => 'Kentucky', 'LA' => 'Louisiana', 'MA' => 'Massachusetts', 'MD' => 'Maryland', 'ME' => 'Maine', 'MI' => 'Michigan', 'MN' => 'Minnesota', 'MO' => 'Missouri', 'MS' => 'Mississippi', 'MT' => 'Montana', 'NC' => 'North Carolina', 'ND' => 'North Dakota', 'NE' => 'Nebraska', 'NH' => 'New Hampshire', 'NJ' => 'New Jersey', 'NM' => 'New Mexico', 'NV' => 'Nevada', 'NY' => 'New York', 'OH' => 'Ohio', 'OK' => 'Oklahoma', 'OR' => 'Oregon', 'PA' => 'Pennsylvania', 'PR' => 'Puerto Rico', 'RI' => 'Rhode Island', 'SC' => 'South Carolina', 'SD' => 'South Dakota', 'TN' => 'Tennessee', 'TX' => 'Texas', 'UT' => 'Utah', 'VA' => 'Virginia', 'VT' => 'Vermont', 'WA' => 'Washington', 'WI' => 'Wisconsin', 'WV' => 'West Virginia', 'WY' => 'Wyoming', 'INTL' => 'International' );
}

function usucger_map_settings() {
	$d = get_option( 'usucger_map', array() );
	return wp_parse_args( is_array( $d ) ? $d : array(), array(
		'aliases' => array(
			'University of Arkansas Fayetteville'          => 'University of Arkansas',
			'MIT'                                          => 'Massachusetts Institute of Technology',
			'California State University of Los Angeles'   => 'California State University-Los Angeles',
			'Marian University, Indianapolis'              => 'Marian University',
		),
		'other'   => array(
			'Deep Foundations Institute'                         => 'NJ',
			'Portland State University'                          => 'OR',
			'AGR, LLC / Turner-Fairbank Highway Research Center' => 'VA',
			'Brigham Young University – Idaho'                   => 'ID',
			'GRL Engineers, Inc.'                                => 'OH',
			'Geosetta'                                           => 'MD',
			'Menard USA'                                         => 'PA',
			'Terracon Consultants, Inc.'                         => 'KS',
			'West Virginia University Institute of Technology'   => 'WV',
			'University of British Columbia'                     => 'INTL',
			'University of Technology Sydney'                    => 'INTL',
			'Wuhan University'                                   => 'INTL',
		),
	) );
}

/** Build per-state data (cached until content changes). */
function usucger_map_data() {
	$ver   = get_option( 'usucger_content_ver', 0 );
	$cache = get_transient( 'usucger_map_data' );
	if ( $cache && isset( $cache['ver'] ) && $cache['ver'] == $ver ) { // phpcs:ignore Universal.Operators.StrictComparisons
		return $cache;
	}
	$names = usucger_state_names();
	$cfg   = usucger_map_settings();
	$S     = array();
	foreach ( $names as $st => $n ) {
		$S[ $st ] = array( 'unis' => array(), 'other' => array() );
	}
	$by_norm = array();
	foreach ( Usucger_Members::institutions() as $i ) {
		$st = isset( $S[ $i->state ] ) ? $i->state : 'INTL';
		$S[ $st ]['unis'][ $i->name ] = array();
		$by_norm[ usucger_norm( $i->name ) ] = array( $i->name, $st );
		foreach ( array_filter( array_map( 'trim', explode( ';', (string) $i->aliases ) ) ) as $al ) {
			$by_norm[ usucger_norm( $al ) ] = array( $i->name, $st );
		}
	}
	$members    = Usucger_Members::directory_rows();
	$unassigned = 0;
	foreach ( $members as $m ) {
		$full = trim( $m[0] . ' ' . $m[1] );
		$aff  = $m[2];
		$a    = isset( $cfg['aliases'][ $aff ] ) ? $cfg['aliases'][ $aff ] : $aff;
		$key  = usucger_norm( $a );
		if ( isset( $by_norm[ $key ] ) ) {
			list( $u, $st )             = $by_norm[ $key ];
			$S[ $st ]['unis'][ $u ][] = $full;
		} elseif ( isset( $cfg['other'][ $aff ] ) && isset( $S[ $cfg['other'][ $aff ] ] ) ) {
			$S[ $cfg['other'][ $aff ] ]['other'][ $aff ][] = $full;
		} else {
			$unassigned++;
		}
	}
	$data  = array();
	$count = array();
	foreach ( $names as $st => $nm ) {
		$n = 0;
		foreach ( $S[ $st ]['unis'] as $ms ) {
			$n += count( $ms );
		}
		foreach ( $S[ $st ]['other'] as $ms ) {
			$n += count( $ms );
		}
		$count[ $st ] = $n;
		$d            = array( 'name' => $nm, 'n' => $n, 'unis' => array(), 'other' => array() );
		foreach ( array( 'unis', 'other' ) as $k ) {
			$list = $S[ $st ][ $k ];
			uksort( $list, function ( $a, $b ) use ( $list ) {
				$c = count( $list[ $b ] ) - count( $list[ $a ] );
				return $c ? $c : strcmp( $a, $b );
			} );
			foreach ( $list as $u => $ms ) {
				usort( $ms, function ( $x, $y ) {
					$px = explode( ' ', $x );
					$py = explode( ' ', $y );
					return strcmp( end( $px ), end( $py ) );
				} );
				$d[ $k ][] = array( 'n' => $u, 'm' => $ms );
			}
		}
		$data[ $st ] = $d;
	}
	$top = $count;
	unset( $top['INTL'] );
	uksort( $top, function ( $a, $b ) use ( $top ) {
		return $top[ $b ] - $top[ $a ] ? $top[ $b ] - $top[ $a ] : strcmp( $b, $a );
	} );
	$out = array(
		'ver'        => $ver,
		'data'       => $data,
		'count'      => $count,
		'unis'       => array_map( function ( $s ) {
			return count( $s['unis'] );
		}, $S ),
		'placed'     => count( $members ) - $unassigned,
		'n_states'   => count( array_filter( $top ) ),
		'n_unis'     => count( Usucger_Members::institutions() ),
		'top'        => array_slice( $top, 0, 4, true ),
	);
	set_transient( 'usucger_map_data', $out, DAY_IN_SECONDS );
	return $out;
}

function usucger_map_level( $n ) {
	return 0 === $n ? 0 : ( $n <= 3 ? 1 : ( $n <= 8 ? 2 : ( $n <= 15 ? 3 : 4 ) ) );
}

add_shortcode( 'usucger_member_map', function () {
	$geo = json_decode( (string) file_get_contents( USUCGER_CORE_DIR . 'data/us-states.json' ), true );
	if ( ! $geo ) {
		return '';
	}
	$M     = usucger_map_data();
	$names = usucger_state_names();
	$small = array( 'CT', 'RI', 'DE', 'DC', 'MD', 'NJ', 'NH', 'VT', 'MA' );
	$paths = '';
	$lbls  = '';
	foreach ( $geo['states'] as $st => $g ) {
		$n  = isset( $M['count'][ $st ] ) ? $M['count'][ $st ] : 0;
		$nu = isset( $M['unis'][ $st ] ) ? $M['unis'][ $st ] : 0;
		$lv = usucger_map_level( $n );
		$paths .= '<path class="st l' . $lv . '" d="' . esc_attr( $g['d'] ) . '" data-st="' . esc_attr( $st ) . '" tabindex="0" role="button" aria-label="' . esc_attr( sprintf( '%s: %d member%s at %d institution%s', $names[ $st ], $n, 1 === $n ? '' : 's', $nu, 1 === $nu ? '' : 's' ) ) . '"/>';
		if ( ! in_array( $st, $small, true ) ) {
			$dark  = $lv >= 3 ? ' on-dark' : '';
			$lbls .= '<text class="st-lbl' . $dark . '" x="' . (int) $g['c'][0] . '" y="' . ( (int) $g['c'][1] + 4 ) . '">' . esc_html( $st ) . '</text>';
			if ( $n ) {
				$lbls .= '<text class="st-n' . $dark . '" x="' . (int) $g['c'][0] . '" y="' . ( (int) $g['c'][1] + 16 ) . '">' . (int) $n . '</text>';
			}
		}
	}
	$chips = '';
	foreach ( array( 'PR', 'INTL' ) as $st ) {
		$n      = $M['count'][ $st ];
		$chips .= '<button type="button" class="chip l' . usucger_map_level( $n ) . '" data-st="' . $st . '">' . esc_html( $names[ $st ] ) . ' <b>' . (int) $n . '</b></button>';
	}
	$top = array();
	foreach ( $M['top'] as $st => $n ) {
		$top[] = esc_html( $names[ $st ] ) . ' (' . (int) $n . ')';
	}
	return '<div class="map-wrap"><div class="map-stage"><svg class="usmap" viewBox="0 0 ' . (int) $geo['w'] . ' ' . (int) $geo['h'] . '" role="group" aria-label="USUCGER members by state"><g class="states">' . $paths . '</g><g class="labels" aria-hidden="true">' . $lbls . '</g></svg>'
		. '<div class="map-chips">' . $chips . '</div>'
		. '<div class="map-legend"><span><i class="l0"></i>no members</span><span><i class="l1"></i>1&ndash;3</span><span><i class="l2"></i>4&ndash;8</span><span><i class="l3"></i>9&ndash;15</span><span><i class="l4"></i>16+</span></div></div>'
		. '<div class="map-panel" id="mapPanel"><div class="mp-head"><div class="mp-title" id="mpTitle">' . (int) $M['placed'] . ' members &middot; ' . (int) $M['n_states'] . ' states</div><div class="mp-sub" id="mpSub">' . (int) $M['n_unis'] . ' member institutions &middot; hover or tap a state</div></div>'
		. '<div class="mp-body" id="mpBody"><p class="mp-hint">Shading shows how many USUCGER members are in each state. Leading states: ' . implode( ', ', $top ) . '. Click a state to pin it and expand an institution to see its members.</p></div>'
		. '<div class="mp-foot"><a href="' . usucger_u( 'directory' ) . '">Full membership directory &rarr;</a><a href="' . usucger_u( 'universities' ) . '">Member universities &amp; contacts &rarr;</a></div></div></div>'
		. '<script>window.USUCGER_MAP=' . wp_json_encode( $M['data'] ) . ';</script>';
} );
