<?php
/**
 * Membership model.
 *
 * Source of truth for who has paid is WooCommerce Memberships (user memberships are
 * posts of type "wc_user_membership": post_author = member, post_parent = plan,
 * post_status = wcm-active / wcm-expired / …, meta _start_date / _end_date).
 * A daily sync copies that into the contacts table, which also holds people who
 * have no WordPress account (imported lists, university contacts) and each
 * person's email preferences. Everything else — directory, map, email groups,
 * renewal reminders, lapsed cleanup — reads the contacts table.
 *
 * Contact status:
 *   current  – paid for the current cycle (shown in the directory)
 *   lapsed   – was a member in an earlier cycle (or membership expired) and has not renewed
 *   former   – removed after the grace period / by the webmaster (kept for history)
 *   prospect – on the mailing list but never a member
 *
 * @package usucger-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Usucger_Members {

	const ACTIVE_STATUSES = array( 'wcm-active', 'wcm-complimentary', 'wcm-free_trial', 'wcm-pending', 'wcm-delayed' ); // delayed = paid, starts later (renewed early)

	public static function wcm_active() {
		return post_type_exists( 'wc_user_membership' ) || function_exists( 'wc_memberships' );
	}

	/** Membership plans (id => name). */
	public static function plans() {
		$out = array();
		foreach ( get_posts( array( 'post_type' => 'wc_membership_plan', 'post_status' => 'any', 'posts_per_page' => -1, 'orderby' => 'title', 'order' => 'ASC' ) ) as $p ) {
			$out[ $p->ID ] = $p->post_title;
		}
		return $out;
	}

	/* ------------------------------------------------------------ sync */

	/**
	 * Copy WooCommerce Memberships into contacts. Returns summary counts.
	 */
	public static function sync() {
		global $wpdb;
		$t = Usucger_DB::t( 'contacts' );
		if ( ! self::wcm_active() && ! $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = %s", 'wc_user_membership' ) ) ) {
			return array( 'error' => 'WooCommerce Memberships is not active; contacts are managed manually.' );
		}
		$current_plans  = array_map( 'intval', (array) usucger_core_opt( 'current_plans' ) );
		$previous_plans = array_map( 'intval', (array) usucger_core_opt( 'previous_plans' ) );
		$plans          = self::plans();
		$inst_key       = usucger_core_opt( 'institution_meta' );

		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT ID, post_author, post_parent, post_status FROM {$wpdb->posts} WHERE post_type = %s AND post_status NOT IN ('trash','auto-draft')",
			'wc_user_membership'
		) );
		$by_user = array();
		foreach ( $rows as $r ) {
			$by_user[ (int) $r->post_author ][] = $r;
		}
		$stats = array( 'members' => 0, 'current' => 0, 'lapsed' => 0, 'prospect' => 0, 'new' => 0, 'updated' => 0 );
		foreach ( $by_user as $uid => $ms ) {
			$user = get_userdata( $uid );
			if ( ! $user ) {
				continue;
			}
			$best = null; // the membership that decides status
			$is_current = false;
			$was_member = false;
			foreach ( $ms as $m ) {
				$plan   = (int) $m->post_parent;
				$active = in_array( $m->post_status, self::ACTIVE_STATUSES, true );
				$end    = get_post_meta( $m->ID, '_end_date', true );
				$m->end   = $end ? substr( $end, 0, 10 ) : null;
				$m->start = substr( (string) get_post_meta( $m->ID, '_start_date', true ), 0, 10 );
				// a mapped current plan, or any active membership that still runs (some 2025–27 team
				// purchases are attached to an older plan in the store)
				$in_cur = $current_plans ? ( in_array( $plan, $current_plans, true ) || ( $m->end && $m->end >= usucger_today() ) ) : true;
				if ( $active && $in_cur ) {
					$is_current = true;
					if ( ! $best || empty( $best->_cur ) || ( $best->end && ( ! $m->end || $m->end > $best->end ) ) ) { // no end date = unlimited
						$m->_cur = true;
						$best    = $m;
					}
				} else {
					if ( ( $previous_plans && in_array( $plan, $previous_plans, true ) ) || ! $previous_plans ) {
						$was_member = true;
					}
					if ( ( ! $best || empty( $best->_cur ) ) && ( ! $best || ( $m->end && ( ! $best->end || $m->end > $best->end ) ) ) ) {
						$best = $m;
					}
				}
			}
			if ( ! $best ) {
				continue;
			}
			$status = $is_current ? 'current' : ( $was_member ? 'lapsed' : 'prospect' );
			$first  = $user->first_name ? $user->first_name : get_user_meta( $uid, 'billing_first_name', true );
			$last   = $user->last_name ? $user->last_name : get_user_meta( $uid, 'billing_last_name', true );
			$inst   = $inst_key ? (string) get_user_meta( $uid, $inst_key, true ) : '';
			if ( '' === trim( $inst ) ) {
				$inst = self::membership_institution( $best->ID ); // team name or the "University Name" asked at checkout
			}
			$data   = array(
				'email'      => strtolower( $user->user_email ),
				'first_name' => (string) $first,
				'last_name'  => (string) $last,
				'user_id'    => $uid,
				'source'     => 'wcm',
				'plan_id'    => (int) $best->post_parent,
				'category'   => isset( $plans[ $best->post_parent ] ) ? $plans[ $best->post_parent ] : '',
				'start_date' => $best->start ? $best->start : null,
				'end_date'   => $best->end,
				'updated'    => current_time( 'mysql' ),
			);
			if ( $inst ) {
				$data['institution'] = $inst;
			}
			$existing = self::find_for_user( $uid, $data['email'], $first, $last, true );
			if ( $existing && $inst && 'current' === $existing->status && '' !== trim( (string) $existing->institution ) && usucger_norm( $inst ) !== usucger_norm( $existing->institution ) ) {
				// a current member's institution decides their vote: a change from the store waits for approval
				unset( $data['institution'] );
				$declined = (array) get_option( 'usucger_inst_declined', array() );
				$pending  = function_exists( 'usucger_inst_requests' ) ? usucger_inst_requests() : array();
				if ( function_exists( 'usucger_change_institution' ) && ! isset( $pending[ $existing->id ] ) && ( ! isset( $declined[ $existing->id ] ) || usucger_norm( $inst ) !== $declined[ $existing->id ] ) ) {
					usucger_change_institution( $existing, $inst );
				}
			}
			if ( $existing && strtolower( (string) $existing->email ) !== $data['email'] ) {
				$data['bounced']     = 0; // a new address gets a fresh start
				$data['bounce_note'] = '';
			}
			if ( $existing ) {
				// never resurrect someone the webmaster removed unless they paid again
				if ( 'former' !== $existing->status || 'current' === $status ) {
					$data['status'] = $status;
				}
				if ( 'current' === $status && 'former' === $existing->status ) {
					$data['in_directory'] = 1;
				}
				$wpdb->update( $t, $data, array( 'id' => $existing->id ) );
				$stats['updated']++;
			} else {
				$data['status']  = $status;
				$data['token']   = usucger_token();
				$data['created'] = current_time( 'mysql' );
				$wpdb->insert( $t, $data );
				$stats['new']++;
			}
			$stats['members']++;
			$stats[ $status ]++;
		}
		// team purchases whose buyer never took a seat: they paid, so they count as members
		$owners = self::sync_team_owners( array_keys( $by_user ), $stats );
		// members whose membership/account disappeared from WooCommerce Memberships: no longer current
		$seen = array_merge( array_map( 'intval', array_keys( $by_user ) ), $owners );
		if ( $seen ) {
			$stats['demoted'] = (int) $wpdb->query( "UPDATE $t SET status = 'lapsed', updated = '" . esc_sql( current_time( 'mysql' ) ) . "' WHERE source = 'wcm' AND status = 'current' AND user_id NOT IN (" . implode( ',', $seen ) . ')' ); // phpcs:ignore WordPress.DB
		}
		$stats['unmatched_imported'] = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $t WHERE source = 'import' AND status = 'current' AND email = ''" ); // phpcs:ignore WordPress.DB
		update_option( 'usucger_last_sync', array( 'time' => current_time( 'mysql' ), 'stats' => $stats ), false );
		Usucger_DB::log( 'wcm_sync', '', $stats );
		usucger_bump_content_version();
		return $stats;
	}

	/** Match a WP user to a contact: user_id, then email, then name on an imported row without email. */
	/** Institution for a membership: its team's name, else the "University Name" field on the order. */
	public static function membership_institution( $membership_id ) {
		$team_id = (int) get_post_meta( $membership_id, '_team_id', true );
		if ( $team_id && get_post( $team_id ) ) {
			return self::clean_team_name( get_the_title( $team_id ) );
		}
		$order_id = (int) get_post_meta( $membership_id, '_order_id', true );
		return $order_id ? self::order_institution( $order_id ) : '';
	}

	public static function order_institution( $order_id ) {
		if ( ! function_exists( 'wc_get_order' ) ) {
			return '';
		}
		$o = wc_get_order( $order_id );
		if ( ! $o ) {
			return '';
		}
		foreach ( $o->get_items() as $item ) {
			foreach ( $item->get_meta_data() as $md ) {
				$d = $md->get_data();
				if ( is_string( $d['value'] ) && preg_match( '/^(university|institution|organization|company)( name)?$/i', trim( (string) $d['key'] ) ) && trim( $d['value'] ) ) {
					return sanitize_text_field( $d['value'] );
				}
			}
		}
		return (string) $o->get_billing_company();
	}

	/** Teams are named like: Texas Tech University “Texas Tech …” — keep the institution part. */
	public static function clean_team_name( $name ) {
		$name = html_entity_decode( (string) $name, ENT_QUOTES, 'UTF-8' );
		return trim( preg_replace( '/\s*[“"].*$/u', '', $name ) );
	}

	/**
	 * Teams for WooCommerce Memberships: a buyer who never assigned themselves a seat has no
	 * user membership. If the team is paid and still running, record the buyer as a current
	 * member (and an expired team as "not renewed"). Returns the owners' user IDs.
	 */
	public static function sync_team_owners( $have_membership, &$stats ) {
		global $wpdb;
		if ( ! post_type_exists( 'wc_memberships_team' ) && ! $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'wc_memberships_team'" ) ) { // phpcs:ignore WordPress.DB
			return array();
		}
		$t       = Usucger_DB::t( 'contacts' );
		$have    = array_flip( array_map( 'intval', $have_membership ) );
		$owners  = array();
		$stats['team_owners'] = 0;
		$best    = array();
		foreach ( get_posts( array( 'post_type' => 'wc_memberships_team', 'post_status' => 'any', 'posts_per_page' => -1, 'no_found_rows' => true ) ) as $team ) {
			$owner = (int) ( get_post_meta( $team->ID, '_owner_id', true ) ? get_post_meta( $team->ID, '_owner_id', true ) : $team->post_author );
			$end   = substr( (string) get_post_meta( $team->ID, '_membership_end_date', true ), 0, 10 );
			$order = (int) get_post_meta( $team->ID, '_order_id', true );
			if ( function_exists( 'wc_memberships_for_teams_get_team' ) ) {
				$obj = wc_memberships_for_teams_get_team( $team->ID );
				if ( $obj ) {
					$owner = method_exists( $obj, 'get_owner_id' ) ? (int) $obj->get_owner_id() : $owner;
					if ( method_exists( $obj, 'get_membership_end_date' ) ) {
						$end = substr( (string) $obj->get_membership_end_date( 'mysql' ), 0, 10 );
					}
					$order = method_exists( $obj, 'get_order_id' ) ? (int) $obj->get_order_id() : $order;
				}
			}
			if ( ! $owner || isset( $have[ $owner ] ) ) {
				continue; // the owner has their own membership; the main sync handled them
			}
			$paid = true;
			if ( $order && function_exists( 'wc_get_order' ) ) {
				$o    = wc_get_order( $order );
				$paid = $o && $o->is_paid();
			}
			if ( ! $paid ) {
				continue;
			}
			$cur = ! $end || $end >= usucger_today();
			// keep the best team per owner (a running one beats an expired one)
			if ( ! isset( $best[ $owner ] ) || ( $cur && ! $best[ $owner ]['cur'] ) || ( $cur === $best[ $owner ]['cur'] && $end > $best[ $owner ]['end'] ) ) {
				$best[ $owner ] = array( 'cur' => $cur, 'end' => $end, 'team' => $team, 'order' => $order );
			}
		}
		foreach ( $best as $owner => $b ) {
			$user = get_userdata( $owner );
			if ( ! $user ) {
				continue;
			}
			$inst     = self::clean_team_name( $b['team']->post_title );
			$data     = array(
				'email'      => strtolower( $user->user_email ),
				'first_name' => (string) ( $user->first_name ? $user->first_name : get_user_meta( $owner, 'billing_first_name', true ) ),
				'last_name'  => (string) ( $user->last_name ? $user->last_name : get_user_meta( $owner, 'billing_last_name', true ) ),
				'user_id'    => $owner,
				'source'     => 'wcm',
				'plan_id'    => (int) get_post_meta( $b['team']->ID, '_membership_plan_id', true ),
				'category'   => 'Team purchase (seat not assigned)',
				'end_date'   => $b['end'] ? $b['end'] : null,
				'updated'    => current_time( 'mysql' ),
			);
			$status   = $b['cur'] ? 'current' : 'lapsed';
			$existing = self::find_for_user( $owner, $data['email'], $data['first_name'], $data['last_name'], true );
			if ( $existing ) {
				if ( 'former' !== $existing->status || 'current' === $status ) {
					$data['status'] = $status;
				}
				if ( '' === trim( (string) $existing->institution ) && $inst ) {
					$data['institution'] = $inst;
				}
				$wpdb->update( $t, $data, array( 'id' => $existing->id ) );
			} else {
				$data['status']      = $status;
				$data['institution'] = $inst;
				$data['token']       = usucger_token();
				$data['created']     = current_time( 'mysql' );
				$wpdb->insert( $t, $data );
			}
			$owners[] = (int) $owner;
			$stats['team_owners']++;
			$stats[ $status ]++;
		}
		return $owners;
	}

	public static function find_for_user( $uid, $email, $first, $last, $allow_name = false ) {
		global $wpdb;
		$t = Usucger_DB::t( 'contacts' );
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $t WHERE user_id = %d LIMIT 1", $uid ) );
		if ( ! $row && $email ) {
			$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $t WHERE email = %s LIMIT 1", $email ) );
		}
		if ( ! $row && $allow_name && $first && $last ) {
			$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $t WHERE email = '' AND LOWER(first_name) = %s AND LOWER(last_name) = %s LIMIT 1", strtolower( $first ), strtolower( $last ) ) );
		}
		return $row;
	}

	/* ------------------------------------------------------------ queries */

	public static function get( $id ) {
		global $wpdb;
		$t = Usucger_DB::t( 'contacts' );
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $t WHERE id = %d", $id ) );
	}

	public static function counts() {
		global $wpdb;
		$t   = Usucger_DB::t( 'contacts' );
		$out = array( 'current' => 0, 'lapsed' => 0, 'former' => 0, 'prospect' => 0 );
		foreach ( $wpdb->get_results( "SELECT status, COUNT(*) n FROM $t GROUP BY status" ) as $r ) { // phpcs:ignore WordPress.DB
			$out[ $r->status ] = (int) $r->n;
		}
		$out['no_email'] = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $t WHERE email = '' AND status IN ('current','lapsed')" ); // phpcs:ignore WordPress.DB
		$soon            = gmdate( 'Y-m-d', strtotime( '+30 days' ) );
		$out['expiring'] = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE status = 'current' AND end_date IS NOT NULL AND end_date <= %s", $soon ) );
		return $out;
	}

	/** Directory rows: [first, last, affiliation] for current members who are listed. */
	public static function directory_rows() {
		global $wpdb;
		$t = Usucger_DB::t( 'contacts' );
		$rows = $wpdb->get_results( "SELECT first_name, last_name, institution FROM $t WHERE status = 'current' AND in_directory = 1 ORDER BY last_name, first_name", ARRAY_N ); // phpcs:ignore WordPress.DB
		return $rows ? $rows : array();
	}

	public static function institutions( $status = 'member' ) {
		global $wpdb;
		$t = Usucger_DB::t( 'institutions' );
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $t WHERE status = %s ORDER BY name", $status ) );
	}

	/* ------------------------------------------------------------ email groups */

	public static function groups() {
		return array(
			'not_renewed'  => array( 'Not renewed — past members who have not paid for the current cycle', 'renewal' ),
			'expiring'     => array( 'Expiring soon — current members whose membership ends within N days', 'renewal' ),
			'current'      => array( 'Current members (paid this cycle)', 'news' ),
			'all'          => array( 'Everyone on the list (current + not renewed + mailing list)', 'news' ),
			'uni_contacts' => array( 'University contact persons (delegates)', 'news' ),
			'board'        => array( 'Board members (website accounts with the Board role)', 'news' ),
			'tag'          => array( 'Contacts with a tag', 'news' ),
			'custom'       => array( 'Pasted list of email addresses', 'news' ),
		) + apply_filters( 'usucger_email_groups', array() );
	}

	/**
	 * Resolve a group into recipients. $kind news|renewal decides which opt-out applies.
	 * Each recipient: contact_id, email, first_name, last_name, institution, category, end_date, token, status.
	 */
	public static function recipients( $group, $args = array(), $kind = 'news' ) {
		global $wpdb;
		$t     = Usucger_DB::t( 'contacts' );
		$unsub = 'renewal' === $kind ? 'unsub_renewal' : ( 'official' === $kind ? 'id' : 'unsub_news' );
		$base  = 'official' === $kind ? "SELECT * FROM $t WHERE email <> ''" : "SELECT * FROM $t WHERE email <> '' AND $unsub = 0";
		switch ( $group ) {
			case 'not_renewed':
				$rows = $wpdb->get_results( "$base AND status = 'lapsed'" ); // phpcs:ignore WordPress.DB
				break;
			case 'expiring':
				$days = max( 1, (int) ( isset( $args['days'] ) ? $args['days'] : 30 ) );
				$rows = $wpdb->get_results( $wpdb->prepare( "$base AND status = 'current' AND end_date IS NOT NULL AND end_date <= %s", gmdate( 'Y-m-d', strtotime( "+$days days" ) ) ) ); // phpcs:ignore WordPress.DB
				break;
			case 'current':
				$rows = $wpdb->get_results( "$base AND status = 'current'" ); // phpcs:ignore WordPress.DB
				break;
			case 'all':
				$rows = $wpdb->get_results( "$base AND status IN ('current','lapsed','prospect')" ); // phpcs:ignore WordPress.DB
				break;
			case 'uni_contacts':
				$rows = $wpdb->get_results( "$base AND is_uni_contact = 1 AND status <> 'former'" ); // phpcs:ignore WordPress.DB
				$it   = Usucger_DB::t( 'institutions' );
				foreach ( $wpdb->get_results( "SELECT name, contact_name, contact_email FROM $it WHERE status = 'member' AND contact_email <> ''" ) as $i ) { // phpcs:ignore WordPress.DB
					$rows[] = self::ensure_contact( $i->contact_email, $i->contact_name, $i->name, array( 'is_uni_contact' => 1 ) );
				}
				break;
			case 'board':
				$rows = array();
				foreach ( get_users( array( 'role__in' => array( 'usucger_board' ) ) ) as $u ) {
					$rows[] = self::ensure_contact( $u->user_email, trim( $u->first_name . ' ' . $u->last_name ) ? trim( $u->first_name . ' ' . $u->last_name ) : $u->display_name, '', array( 'user_id' => $u->ID ) );
				}
				break;
			case 'tag':
				$tag  = sanitize_text_field( isset( $args['tag'] ) ? $args['tag'] : '' );
				$rows = $tag ? $wpdb->get_results( $wpdb->prepare( "$base AND CONCAT(',', tags, ',') LIKE %s", '%,' . $wpdb->esc_like( $tag ) . ',%' ) ) : array(); // phpcs:ignore WordPress.DB
				break;
			case 'custom':
				$rows = array();
				preg_match_all( '/[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}/i', (string) ( isset( $args['emails'] ) ? $args['emails'] : '' ), $m );
				foreach ( array_unique( array_map( 'strtolower', $m[0] ) ) as $e ) {
					$rows[] = self::ensure_contact( $e, '', '', array( 'status' => 'prospect' ) );
				}
				break;
			default:
				$rows = (array) apply_filters( 'usucger_recipients', array(), $group, $args, $kind );
		}
		// de-duplicate by email and drop anyone who opted out
		$seen = array();
		$out  = array();
		foreach ( (array) $rows as $r ) {
			if ( ! $r || ! is_email( $r->email ) || isset( $seen[ $r->email ] ) || ! empty( $r->bounced ) || ( 'official' !== $kind && ! empty( $r->$unsub ) ) ) {
				continue;
			}
			$seen[ $r->email ] = true;
			$out[]             = $r;
		}
		return $out;
	}

	/** Find or create a contact by email (used for custom lists, Board, institution contacts). */
	public static function ensure_contact( $email, $name = '', $institution = '', $extra = array() ) {
		global $wpdb;
		$t     = Usucger_DB::t( 'contacts' );
		$email = strtolower( trim( $email ) );
		if ( ! is_email( $email ) ) {
			return null;
		}
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $t WHERE email = %s LIMIT 1", $email ) );
		if ( $row ) {
			return $row;
		}
		$parts = preg_split( '/\s+/', trim( $name ) );
		$last  = count( $parts ) > 1 ? array_pop( $parts ) : '';
		$wpdb->insert( $t, array_merge( array(
			'email'        => $email,
			'first_name'   => implode( ' ', $parts ),
			'last_name'    => $last,
			'institution'  => $institution,
			'source'       => 'manual',
			'status'       => 'prospect',
			'in_directory' => 0,
			'token'        => usucger_token(),
			'created'      => current_time( 'mysql' ),
			'updated'      => current_time( 'mysql' ),
		), $extra ) );
		return self::get( $wpdb->insert_id );
	}

	/* ------------------------------------------------------------ lapsed cleanup */

	/** Lapsed contacts whose last membership ended more than grace_days ago. */
	public static function removal_candidates() {
		global $wpdb;
		$t      = Usucger_DB::t( 'contacts' );
		$cutoff = gmdate( 'Y-m-d', strtotime( '-' . (int) usucger_core_opt( 'grace_days' ) . ' days' ) );
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $t WHERE status = 'lapsed' AND (end_date IS NULL OR end_date < %s) ORDER BY last_name, first_name", $cutoff ) );
	}

	/** Mark contacts as former members: off the directory and member mailings. History is kept. */
	public static function remove( $ids, $why = 'lapsed' ) {
		global $wpdb;
		$t   = Usucger_DB::t( 'contacts' );
		$ids = array_filter( array_map( 'intval', (array) $ids ) );
		if ( ! $ids ) {
			return 0;
		}
		$in = implode( ',', $ids );
		$n  = $wpdb->query( $wpdb->prepare( "UPDATE $t SET status = 'former', in_directory = 0, updated = %s WHERE id IN ($in)", current_time( 'mysql' ) ) ); // phpcs:ignore WordPress.DB
		Usucger_DB::log( 'members_removed', $why, $ids );
		usucger_bump_content_version();
		return (int) $n;
	}

	/** Member institutions whose contact person is not a current member (By-Laws Art. III). */
	public static function institutions_at_risk() {
		global $wpdb;
		$ct   = Usucger_DB::t( 'contacts' );
		$paid = array();
		foreach ( $wpdb->get_col( "SELECT institution FROM $ct WHERE status = 'current'" ) as $inst ) { // phpcs:ignore WordPress.DB
			$paid[ usucger_norm( $inst ) ] = true;
		}
		$out = array();
		foreach ( self::institutions() as $i ) {
			$names = array_merge( array( $i->name ), array_filter( array_map( 'trim', explode( ';', (string) $i->aliases ) ) ) );
			$ok    = false;
			foreach ( $names as $n ) {
				$ok = $ok || isset( $paid[ usucger_norm( $n ) ] );
			}
			if ( ! $ok ) {
				$i->reason = 'No current member listed at this institution';
				$out[]     = $i;
			}
		}
		return $out;
	}
}

/* Daily sync with WooCommerce Memberships. */
add_action( 'usucger_daily', function () {
	if ( usucger_core_opt( 'auto_sync' ) && Usucger_Members::wcm_active() ) {
		Usucger_Members::sync();
	}
} );

/* Real-time: when a membership changes status (payment, expiry, cancellation), resync. */
add_action( 'wc_memberships_user_membership_status_changed', function () {
	if ( ! wp_next_scheduled( 'usucger_sync_soon' ) ) {
		wp_schedule_single_event( time() + 30, 'usucger_sync_soon' );
	}
} );
add_action( 'wc_memberships_user_membership_saved', function () {
	if ( ! wp_next_scheduled( 'usucger_sync_soon' ) ) {
		wp_schedule_single_event( time() + 30, 'usucger_sync_soon' );
	}
} );
add_action( 'usucger_sync_soon', array( 'Usucger_Members', 'sync' ) );
