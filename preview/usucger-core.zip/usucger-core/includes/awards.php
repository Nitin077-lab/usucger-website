<?php
/**
 * Awards: recipients are a content type (USUCGER → Award recipients), so adding next year's
 * winners is a form, not HTML. Renders the awards-page timeline and the featured winners grid.
 *
 *   [usucger_award_list]     timeline of all recipients (filter tabs + search keep working)
 *   [usucger_award_winners]  featured recipients (tick "Feature on the awards page")
 *   [usucger_count of="recipients"]
 *
 * @package usucger-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function usucger_award_types() {
	$t = get_option( 'usucger_award_types', null );
	if ( null === $t ) {
		$t    = array();
		$seed = usucger_seed_json( 'awards.json' );
		foreach ( isset( $seed['awards'] ) ? $seed['awards'] : array() as $a ) {
			$t[ $a['key'] ] = array( 'name' => $a['name'], 'active' => ! empty( $a['active'] ) );
		}
		if ( ! $t ) {
			$t = array(
				'ecr' => array( 'name' => 'Early Career Researcher Award', 'active' => true ),
				'ece' => array( 'name' => 'Early Career Educator Award', 'active' => true ),
				'dsa' => array( 'name' => 'Distinguished Service Award', 'active' => true ),
				'dei' => array( 'name' => 'Diversity, Equity & Inclusion Award', 'active' => true ),
			);
		}
		update_option( 'usucger_award_types', $t, false );
	}
	return $t;
}

add_action( 'init', function () {
	register_post_type( 'usucger_recipient', array(
		'labels'          => array( 'name' => 'Award recipients', 'singular_name' => 'Award recipient', 'add_new_item' => 'Add award recipient', 'edit_item' => 'Edit award recipient', 'menu_name' => 'Award recipients' ),
		'public'          => false,
		'show_ui'         => true,
		'show_in_menu'    => 'usucger',
		'show_in_rest'    => false,
		'supports'        => array( 'title', 'thumbnail' ),
		'capability_type' => 'post',
		'map_meta_cap'    => true,
	) );
} );

function usucger_recipient_fields() {
	$types = array();
	foreach ( usucger_award_types() as $k => $t ) {
		$types[ $k ] = $t['name'] . ( $t['active'] ? '' : ' (no longer awarded)' );
	}
	return array(
		'award'       => array( 'Award', 'select', $types ),
		'year'        => array( 'Year', 'number', 'required' => true ),
		'institution' => array( 'Institution', 'text' ),
		'photo'       => array( 'Photo', 'media', 'help' => 'Or set a featured image. Square headshots look best.' ),
		'featured'    => array( 'Awards page', 'checkbox', 'Feature in the “recipients” grid at the top of the awards page (this year’s winners)' ),
		'crop'        => array( 'Photo crop', 'select', array( '' => 'Normal photo', 'left' => 'Left half of a two-person photo', 'right' => 'Right half of a two-person photo' ) ),
	);
}

add_action( 'add_meta_boxes', function () {
	add_meta_box( 'usg_fields', 'Recipient details', function ( $post ) {
		usucger_fields_box( $post, usucger_recipient_fields(), 'usg_usucger_recipient' );
	}, 'usucger_recipient', 'normal', 'high' );
} );
add_action( 'save_post_usucger_recipient', function ( $id ) {
	usucger_fields_save( $id, usucger_recipient_fields(), 'usg_usucger_recipient' );
	usucger_bump_content_version();
} );
add_filter( 'enter_title_here', function ( $t, $post ) {
	return 'usucger_recipient' === $post->post_type ? 'Recipient name' : $t;
}, 10, 2 );
add_filter( 'usucger_reviewed_types', function ( $t ) {
	$t[] = 'usucger_recipient';
	return $t;
} );
add_filter( 'manage_usucger_recipient_posts_columns', function ( $c ) {
	unset( $c['date'] );
	return array_merge( $c, array( 'award' => 'Award', 'year' => 'Year', 'institution' => 'Institution', 'featured' => 'Featured' ) );
} );
add_action( 'manage_usucger_recipient_posts_custom_column', function ( $col, $id ) {
	$v = get_post_meta( $id, $col, true );
	if ( 'award' === $col ) {
		$t = usucger_award_types();
		$v = isset( $t[ $v ] ) ? $t[ $v ]['name'] : $v;
	}
	echo esc_html( 'featured' === $col ? ( $v ? 'Yes' : '' ) : $v );
}, 10, 2 );

function usucger_recipients() {
	$out = array();
	foreach ( get_posts( array( 'post_type' => 'usucger_recipient', 'post_status' => 'publish', 'posts_per_page' => -1, 'no_found_rows' => true ) ) as $p ) {
		$thumb = get_the_post_thumbnail_url( $p->ID, 'medium' );
		$out[] = array(
			'id'          => $p->ID,
			'name'        => $p->post_title,
			'award'       => get_post_meta( $p->ID, 'award', true ),
			'year'        => (int) get_post_meta( $p->ID, 'year', true ),
			'institution' => get_post_meta( $p->ID, 'institution', true ),
			'photo'       => $thumb ? $thumb : get_post_meta( $p->ID, 'photo', true ),
			'featured'    => (bool) get_post_meta( $p->ID, 'featured', true ),
			'crop'        => get_post_meta( $p->ID, 'crop', true ),
		);
	}
	$types = usucger_award_types();
	usort( $out, function ( $a, $b ) use ( $types ) {
		if ( $a['year'] !== $b['year'] ) {
			return $b['year'] - $a['year'];
		}
		$na = isset( $types[ $a['award'] ] ) ? $types[ $a['award'] ]['name'] : '';
		$nb = isset( $types[ $b['award'] ] ) ? $types[ $b['award'] ]['name'] : '';
		return strcmp( $na, $nb ) ? strcmp( $na, $nb ) : strcmp( $a['name'], $b['name'] );
	} );
	return $out;
}

add_shortcode( 'usucger_award_list', function () {
	$types = usucger_award_types();
	$o     = '<div class="tl" id="awList">';
	$year  = 0;
	foreach ( usucger_recipients() as $r ) {
		if ( $r['year'] !== $year ) {
			$year = $r['year'];
			$o   .= '<div class="tl-year" data-year="' . (int) $year . '">' . (int) $year . '</div>';
		}
		$t      = isset( $types[ $r['award'] ] ) ? $types[ $r['award'] ] : array( 'name' => $r['award'], 'active' => true );
		$legacy = empty( $t['active'] );
		$o     .= '<div class="tl-item aw-row' . ( $legacy ? ' legacy' : '' ) . '" data-award="' . esc_attr( $r['award'] ) . '" data-year="' . (int) $r['year'] . '" data-name="' . esc_attr( mb_strtolower( $r['name'] ) ) . '"><span class="tl-date">' . esc_html( $r['name'] ) . '</span><span class="tl-kind">' . esc_html( $t['name'] ) . ( $legacy ? ' &dagger;' : '' ) . '</span>' . ( $r['institution'] ? '<span class="tl-inst">' . esc_html( $r['institution'] ) . '</span>' : '' ) . '</div>';
	}
	return $o . '</div>';
} );

add_shortcode( 'usucger_award_winners', function () {
	$types = usucger_award_types();
	$o     = '';
	$feat  = array_values( array_filter( usucger_recipients(), function ( $r ) {
		return $r['featured'];
	} ) );
	usort( $feat, function ( $a, $b ) {
		return (int) get_post_meta( $a['id'], 'feature_order', true ) - (int) get_post_meta( $b['id'], 'feature_order', true );
	} );
	foreach ( $feat as $r ) {
		$ini = usucger_initials( $r['name'] );
		if ( $r['photo'] && $r['crop'] ) {
			$img = '<img class="composite" src="' . esc_url( $r['photo'] ) . '" alt="' . esc_attr( $r['name'] ) . '" loading="lazy" style="' . ( 'left' === $r['crop'] ? 'left:-4.5%;top:-4.5%' : 'left:-113%;top:-4.5%' ) . '" onerror="this.style.display=\'none\';this.parentNode.insertAdjacentHTML(\'beforeend\',\'<span class=init>' . esc_attr( $ini ) . '</span>\')">';
		} elseif ( $r['photo'] ) {
			$img = '<img src="' . esc_url( $r['photo'] ) . '" alt="' . esc_attr( $r['name'] ) . '" loading="lazy" onerror="this.style.display=\'none\';this.parentNode.insertAdjacentHTML(\'beforeend\',\'<span class=init>' . esc_attr( $ini ) . '</span>\')">';
		} else {
			$img = '<span class="init">' . esc_html( $ini ) . '</span>';
		}
		$o .= '<div class="winner-card"><div class="win-photo ">' . $img . '</div><div class="winner-body"><div class="winner-year">' . (int) $r['year'] . ' recipient</div><div class="winner-name">' . esc_html( $r['name'] ) . '</div><div class="winner-award">' . esc_html( isset( $types[ $r['award'] ] ) ? $types[ $r['award'] ]['name'] : $r['award'] ) . '</div><div class="winner-inst">' . esc_html( $r['institution'] ) . '</div></div></div>';
	}
	return $o ? '<div class="winner-grid rv">' . $o . '</div>' : '';
} );

add_filter( 'usucger_count_value', function ( $v, $of ) {
	return 'recipients' === $of ? (string) count( usucger_recipients() ) : $v;
}, 10, 2 );

/** Importer: recipients from awards.json (once). */
function usucger_import_recipients( $replace = false ) {
	$have = get_posts( array( 'post_type' => 'usucger_recipient', 'post_status' => 'any', 'numberposts' => -1, 'fields' => 'ids' ) );
	if ( $have && ! $replace ) {
		return 'kept ' . count( $have );
	}
	foreach ( $have as $id ) {
		wp_delete_post( $id, true );
	}
	$seed = usucger_seed_json( 'awards.json' );
	$feat = array();
	foreach ( isset( $seed['featured'] ) ? $seed['featured'] : array() as $i => $f ) {
		$f['order']         = $i;
		$feat[ $f['name'] ] = $f;
	}
	$n = 0;
	foreach ( isset( $seed['awards'] ) ? $seed['awards'] : array() as $a ) {
		foreach ( $a['recipients'] as $r ) {
			$id = wp_insert_post( array( 'post_type' => 'usucger_recipient', 'post_status' => 'publish', 'post_title' => $r[0] ) );
			update_post_meta( $id, 'award', $a['key'] );
			update_post_meta( $id, 'year', (int) $r[1] );
			update_post_meta( $id, 'institution', isset( $r[2] ) ? $r[2] : '' );
			if ( isset( $feat[ $r[0] ] ) && (int) $r[1] === (int) $seed['featured_year'] ) {
				update_post_meta( $id, 'featured', '1' );
				update_post_meta( $id, 'photo', $feat[ $r[0] ]['composite'] );
				update_post_meta( $id, 'crop', $feat[ $r[0] ]['crop'] );
				update_post_meta( $id, 'feature_order', $feat[ $r[0] ]['order'] );
			}
			$n++;
		}
	}
	return $n;
}
