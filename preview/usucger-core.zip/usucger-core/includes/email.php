<?php
/**
 * Email: letterhead, merge tags, templates, batches (compose → approval → outbox),
 * the per-minute sender, and one-click unsubscribe.
 *
 * Every recipient gets an individual copy (no CC/BCC). Two separate opt-outs:
 * "announcements" (news) and "renewal reminders" (renewal). Opting out of one does
 * not stop the other.
 *
 * Batch status: draft → pending (waiting for approval) → sending → done
 *                      ↘ rejected            ↘ cancelled
 *
 * @package usucger-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ================================================================ letterhead */

function usucger_email_letter( $inner, $footer = '', $preheader = '' ) {
	$c    = sanitize_hex_color( usucger_core_opt( 'letter_color' ) );
	$c    = $c ? $c : '#C2410C';
	$addr = esc_html( usucger_core_opt( 'mailing_address' ) );
	return '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>USUCGER</title>'
		. '<style>@media only screen and (max-width:480px){.px{padding-left:18px!important;padding-right:18px!important}.btn a{display:block!important}}body{margin:0}a{color:' . $c . '}</style></head>'
		. '<body style="margin:0;padding:0;background:#F4F4F2">'
		. ( $preheader ? '<div style="display:none;max-height:0;overflow:hidden;opacity:0">' . esc_html( $preheader ) . '</div>' : '' )
		. '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#F4F4F2"><tr><td align="center" style="padding:24px 12px">'
		. '<table role="presentation" width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;background:#FFFFFF;border-top:4px solid ' . $c . '">'
		. '<tr><td class="px" style="padding:22px 32px 10px"><table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr>'
		. '<td style="font-family:Georgia,\'Times New Roman\',serif;font-size:28px;font-weight:700;letter-spacing:1px;color:#1A1A1A">USUCGER</td>'
		. '<td align="right" style="font-family:Arial,Helvetica,sans-serif;font-size:11px;line-height:1.4;color:#686460">United States Universities Council on<br>Geotechnical Education and Research</td>'
		. '</tr></table></td></tr>'
		. '<tr><td class="px" style="padding:14px 32px 6px;font-family:Arial,Helvetica,sans-serif;font-size:15px;line-height:1.6;color:#1F2328">' . $inner . '</td></tr>'
		. '<tr><td class="px" style="padding:14px 32px 18px;font-family:Arial,Helvetica,sans-serif;font-size:11px;line-height:1.5;color:#8A9099;border-top:1px solid #EEEEEE">' . $footer . ( $footer ? '<br>' : '' ) . $addr . '</td></tr>'
		. '</table></td></tr></table></body></html>';
}

/** Inline styles for paragraphs/lists that come from the editor. */
function usucger_email_inline( $html ) {
	$html = preg_replace( '/<p(?![^>]*style=)([^>]*)>/i', '<p$1 style="margin:0 0 14px">', $html );
	$html = preg_replace( '/<(ul|ol)(?![^>]*style=)([^>]*)>/i', '<$1$2 style="margin:0 0 14px;padding-left:22px">', $html );
	$html = preg_replace( '/<h2(?![^>]*style=)([^>]*)>/i', '<h2$1 style="font-family:Georgia,serif;font-size:20px;margin:18px 0 8px;color:#1A1A1A">', $html );
	$html = preg_replace( '/<h3(?![^>]*style=)([^>]*)>/i', '<h3$1 style="font-family:Georgia,serif;font-size:17px;margin:16px 0 6px;color:#1A1A1A">', $html );
	return $html;
}

/** System notifications (approvals etc.) in the letterhead. */
function usucger_notify( $to, $subject, $body ) {
	$to = array_filter( (array) $to, 'is_email' );
	if ( ! $to ) {
		return false;
	}
	$html    = usucger_email_letter( usucger_email_inline( $body ), 'Automatic notice from the USUCGER website.' );
	$subject = html_entity_decode( wp_strip_all_tags( $subject ), ENT_QUOTES, 'UTF-8' );
	$ok   = true;
	foreach ( $to as $addr ) {
		$ok = wp_mail( $addr, '[USUCGER] ' . $subject, $html, usucger_mail_headers() ) && $ok;
	}
	return $ok;
}

function usucger_mail_headers( $extra = array() ) {
	$h = array(
		'Content-Type: text/html; charset=UTF-8',
		'From: ' . wp_specialchars_decode( usucger_core_opt( 'from_name' ), ENT_QUOTES ) . ' <' . usucger_core_opt( 'from_email' ) . '>',
	);
	if ( is_email( usucger_core_opt( 'reply_to' ) ) ) {
		$h[] = 'Reply-To: ' . usucger_core_opt( 'reply_to' );
	}
	return array_merge( $h, $extra );
}

/* ================================================================ merge tags */

function usucger_merge_tags() {
	return array(
		'{first_name}'      => 'First name',
		'{last_name}'       => 'Last name',
		'{name}'            => 'Full name',
		'{email}'           => 'Email address',
		'{institution}'     => 'Institution',
		'{membership_type}' => 'Membership plan / category',
		'{expires}'         => 'Membership end date',
		'{cycle}'           => 'Current cycle (e.g. 2025–2027)',
		'{dues}'            => 'Dues (e.g. $75)',
		'{renew_url}'       => 'Renewal checkout link',
		'{renew_button}'    => 'Big "Renew" button',
		'{membership_box}'  => 'Status box (name, institution, category, status)',
		'{account_url}'     => 'My Account link',
		'{signature}'       => 'Signature (Settings → Email)',
	) + apply_filters( 'usucger_merge_tag_help', array() );
}

function usucger_merge( $text, $c, $kind = 'news' ) {
	$c       = (object) $c;
	$first   = isset( $c->first_name ) && $c->first_name ? $c->first_name : '';
	$last    = isset( $c->last_name ) ? $c->last_name : '';
	$name    = trim( $first . ' ' . $last );
	$col     = sanitize_hex_color( usucger_core_opt( 'letter_color' ) );
	$col     = $col ? $col : '#C2410C';
	$cycle   = usucger_core_opt( 'cycle' );
	$renew   = usucger_renew_url();
	$status  = isset( $c->status ) ? $c->status : '';
	$stxt    = 'current' === $status ? 'Active through ' . ( ! empty( $c->end_date ) ? usucger_fmt_date( $c->end_date, 'F j, Y' ) : 'the end of the ' . $cycle . ' cycle' ) : 'Not yet renewed for ' . $cycle;
	$box     = '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#F7F7F6;border:1px solid #E3E3E2;margin:6px 0 18px"><tr><td style="padding:14px 16px;font-family:Arial,Helvetica,sans-serif;font-size:14px;line-height:1.7;color:#343434">'
		. '<strong style="color:#1A1A1A">Your membership</strong><br>Name: ' . esc_html( $name ? $name : ( isset( $c->email ) ? $c->email : '' ) ) . '<br>'
		. ( ! empty( $c->institution ) ? 'Institution: ' . esc_html( $c->institution ) . '<br>' : '' )
		. ( ! empty( $c->category ) ? 'Category: ' . esc_html( $c->category ) . '<br>' : '' )
		. 'Status: <strong style="color:' . ( 'current' === $status ? '#166534' : '#9A3412' ) . '">' . esc_html( $stxt ) . '</strong></td></tr></table>';
	$button  = '<table role="presentation" cellpadding="0" cellspacing="0" class="btn" style="margin:0 0 18px"><tr><td style="background:' . $col . ';border-radius:4px"><a href="' . esc_url( $renew ) . '" style="display:inline-block;padding:12px 22px;font-family:Arial,Helvetica,sans-serif;font-size:15px;font-weight:700;color:#FFFFFF;text-decoration:none">Renew for ' . esc_html( usucger_core_opt( 'dues' ) ) . ' (' . esc_html( $cycle ) . ') &rarr;</a></td></tr></table>';
	$sig     = '<p style="margin:20px 0 4px">Best regards,</p><p style="margin:0 0 6px"><strong>' . esc_html( usucger_core_opt( 'signer_name' ) ) . '</strong><br><span style="font-size:13px;color:#686460">' . esc_html( usucger_core_opt( 'signer_title' ) ) . '<br><a href="mailto:' . esc_attr( usucger_core_opt( 'reply_to' ) ) . '" style="color:' . $col . '">' . esc_html( usucger_core_opt( 'reply_to' ) ) . '</a> &middot; <a href="' . esc_url( home_url( '/' ) ) . '" style="color:' . $col . '">' . esc_html( wp_parse_url( home_url(), PHP_URL_HOST ) ) . '</a></span></p>';
	$account = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : wp_login_url();
	$map     = array(
		'{first_name}'      => esc_html( $first ? $first : 'colleague' ),
		'{last_name}'       => esc_html( $last ),
		'{name}'            => esc_html( $name ? $name : 'colleague' ),
		'{email}'           => esc_html( isset( $c->email ) ? $c->email : '' ),
		'{institution}'     => esc_html( isset( $c->institution ) ? $c->institution : '' ),
		'{membership_type}' => esc_html( isset( $c->category ) ? $c->category : '' ),
		'{expires}'         => esc_html( ! empty( $c->end_date ) ? usucger_fmt_date( $c->end_date, 'F j, Y' ) : '' ),
		'{cycle}'           => esc_html( $cycle ),
		'{dues}'            => esc_html( usucger_core_opt( 'dues' ) ),
		'{renew_url}'       => esc_url( $renew ),
		'{renew_button}'    => $button,
		'{membership_box}'  => $box,
		'{account_url}'     => esc_url( $account ),
		'{signature}'       => usucger_signature_html( $sig ),
	);
	$map = apply_filters( 'usucger_merge_map', $map, $c, $kind, $text );
	return strtr( $text, $map );
}

/**
 * Personal links (ballot, candidate form, accept) are never put into previews, test sends or
 * stored outbox bodies — only a placeholder. The real link is inserted at the moment of sending.
 */
function usucger_personal_placeholder( $tag ) {
	if ( ! empty( $GLOBALS['usucger_sending'] ) ) {
		return null;
	}
	$labels = array( 'ballot_button' => 'personal ballot button', 'packet_button' => 'personal candidate-statement button', 'accept_button' => 'personal “accept nomination” button' );
	return '<span data-usg="' . esc_attr( $tag ) . '" style="display:inline-block;margin:0 0 14px;padding:10px 14px;border:1px dashed #C2410C;color:#9A3412;font-size:13px">[' . esc_html( isset( $labels[ $tag ] ) ? $labels[ $tag ] : $tag ) . ' — added for each recipient when the email is sent]</span>';
}

function usucger_fill_personal( $body, $c, $b ) {
	if ( false === strpos( $body, 'data-usg="' ) || ! $c ) {
		return $body;
	}
	$GLOBALS['usucger_sending']     = true;
	$GLOBALS['usucger_render_args'] = $b ? (array) $b->args : array();
	$body = preg_replace_callback( '#<span data-usg="([a-z_]+)"[^>]*>.*?</span>#s', function ( $m ) use ( $c, $b ) {
		return usucger_merge( '{' . $m[1] . '}', $c, $b ? $b->kind : 'official' );
	}, $body );
	$GLOBALS['usucger_sending'] = false;
	return $body;
}

/** Fill the tags that are the same for everyone (used in admin screens and notices). */
function usucger_merge_static( $text, $args = array() ) {
	$GLOBALS['usucger_render_args'] = (array) $args;
	$text = strtr( (string) $text, array( '{cycle}' => usucger_core_opt( 'cycle' ), '{dues}' => usucger_core_opt( 'dues' ) ) );
	return false === strpos( $text, '{' ) ? $text : html_entity_decode( wp_strip_all_tags( usucger_merge( $text, (object) array( 'first_name' => 'Colleague' ), 'official' ) ), ENT_QUOTES, 'UTF-8' );
}

/**
 * {signature}: site signer (default), the person sending ("me"), or a custom block,
 * chosen per email in Compose ("Sign as").
 */
function usucger_signature_html( $site_sig ) {
	$a    = isset( $GLOBALS['usucger_render_args'] ) ? (array) $GLOBALS['usucger_render_args'] : array();
	$mode = isset( $a['sign'] ) ? $a['sign'] : 'site';
	if ( 'custom' === $mode && ! empty( $a['sign_text'] ) ) {
		$lines = array_map( 'esc_html', preg_split( '/\r?\n/', trim( $a['sign_text'] ) ) );
		$first = array_shift( $lines );
		$lines = array_map( function ( $l ) {
			return preg_replace( '#(https?://\S+)#', '<a href="$1" style="color:#686460">$1</a>', preg_replace( '/([A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,})/i', '<a href="mailto:$1" style="color:#686460">$1</a>', $l ) );
		}, $lines );
		return '<p style="margin:20px 0 6px">' . $first . '</p><p style="margin:0 0 6px;font-size:13px;line-height:1.5;color:#686460">' . implode( '<br>', $lines ) . '</p>';
	}
	if ( 'me' === $mode && ! empty( $a['sign_user'] ) ) {
		$u = get_userdata( (int) $a['sign_user'] );
		if ( $u ) {
			$p     = function_exists( 'usucger_profile' ) ? usucger_profile( $u->ID ) : null;
			$name  = trim( $u->first_name . ' ' . $u->last_name ) ? trim( $u->first_name . ' ' . $u->last_name ) : $u->display_name;
			$web   = $p && ! empty( $p->links['web'] ) ? $p->links['web'] : '';
			$lines = array_filter( array( $p ? $p->title : '', $p ? $p->institution : '', '<a href="mailto:' . esc_attr( $u->user_email ) . '" style="color:#686460">' . esc_html( $u->user_email ) . '</a>', $web ? '<a href="' . esc_url( $web ) . '" style="color:#686460">' . esc_html( $web ) . '</a>' : '' ) );
			return '<p style="margin:20px 0 4px">Best regards,</p><p style="margin:0 0 6px"><strong>' . esc_html( $name ) . '</strong><br><span style="font-size:13px;line-height:1.5;color:#686460">' . implode( '<br>', array_map( function ( $l ) {
				return 0 === strpos( $l, '<a ' ) ? $l : esc_html( $l );
			}, $lines ) ) . '</span></p>';
		}
	}
	return $site_sig;
}

/** Media Library files attached to a batch (ids in args['attachments']) → local paths. */
function usucger_batch_attachment_paths( $b ) {
	$out = array();
	foreach ( $b && ! empty( $b->args['attachments'] ) ? (array) $b->args['attachments'] : array() as $aid ) {
		$f = get_attached_file( (int) $aid );
		if ( $f && file_exists( $f ) ) {
			$out[] = $f;
		}
	}
	return $out;
}

function usucger_unsub_url( $c, $kind ) {
	return add_query_arg( array( 'usucger_unsub' => isset( $c->token ) ? $c->token : '', 't' => $kind ), home_url( '/' ) );
}

function usucger_email_footer( $c, $kind ) {
	$account = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : wp_login_url();
	if ( 'official' === $kind ) {
		return 'This is an official USUCGER governance notice (By-Laws) sent to members and member-institution delegates.<br><a href="' . esc_url( $account ) . '" style="color:#8A9099">Update my details</a>';
	}
	if ( 'renewal' === $kind ) {
		return 'You are receiving this because you were a USUCGER member in a previous cycle. This is a membership notice, not a newsletter.<br><a href="' . esc_url( usucger_unsub_url( $c, 'renewal' ) ) . '" style="color:#8A9099">Stop renewal reminders</a> &middot; <a href="' . esc_url( $account ) . '" style="color:#8A9099">Update my details</a>';
	}
	return 'You are receiving this as a member or contact of USUCGER.<br><a href="' . esc_url( usucger_unsub_url( $c, 'news' ) ) . '" style="color:#8A9099">Unsubscribe from USUCGER announcements</a> &middot; <a href="' . esc_url( $account ) . '" style="color:#8A9099">Update my details</a>';
}

/** Render a full email (subject, html) for one contact. */
function usucger_render_email( $subject, $body, $c, $kind, $args = array() ) {
	$GLOBALS['usucger_render_args'] = (array) $args;
	$c       = (object) $c;
	$subject = wp_strip_all_tags( html_entity_decode( usucger_merge( $subject, $c, $kind ), ENT_QUOTES, 'UTF-8' ) );
	$auto    = preg_replace( '#<p>\s*(\{(?:[a-z_]+_(?:list|button|box|cards)|signature|results)\})\s*(?:<br\s*/?>)?\s*</p>#', '$1', wpautop( $body ) );
	$auto    = preg_replace( '#(\{(?:[a-z_]+_(?:list|button|box|cards)|signature|results)\})<br\s*/?>#', '$1', $auto );
	$inner   = usucger_email_inline( usucger_merge( $auto, $c, $kind ) );
	return array( $subject, usucger_email_letter( $inner, usucger_email_footer( $c, $kind ), wp_trim_words( wp_strip_all_tags( $inner ), 18 ) ) );
}

/* ================================================================ templates */

function usucger_email_templates() {
	$t = get_option( 'usucger_templates', array() );
	return is_array( $t ) ? $t : array();
}

function usucger_email_seed_templates() {
	$have = usucger_email_templates();
	$seed = array(
		'renewal_reminder' => array(
			'name'    => 'Renewal reminder (not renewed)',
			'kind'    => 'renewal',
			'subject' => 'Your USUCGER membership for {cycle} has not been renewed yet',
			'body'    => "<p>Dear {first_name},</p>\n<p>Our records show that your USUCGER membership for the <strong>{cycle} cycle</strong> has not been renewed yet. Renewing keeps you on the membership directory and the USUCGER email list, and lets your students apply for travel grants.</p>\n{membership_box}\n{renew_button}\n<p style=\"font-size:14px;color:#343434\">Dues are {dues} per person for the full three-year cycle and are not prorated. The button opens a secure checkout. After you pay, your membership updates on the website right away.</p>\n<p style=\"font-size:14px;color:#343434\">If you have already renewed, or you have retired or moved, just reply to this email and we will update our records.</p>\n{signature}",
		),
		'renewal_second' => array(
			'name'    => 'Renewal — second reminder',
			'kind'    => 'renewal',
			'subject' => 'Reminder: renew your USUCGER membership ({cycle})',
			'body'    => "<p>Dear {first_name},</p>\n<p>A quick follow-up: we have not yet received your USUCGER dues for the {cycle} cycle. Members are listed in the directory and on the member map, vote through their institution's delegate, and their students are eligible for USUCGER travel grants.</p>\n{renew_button}\n<p>If the checkout gives you any trouble, or your university needs an invoice, reply to this email and we will help.</p>\n{signature}",
		),
		'renewal_final' => array(
			'name'    => 'Renewal — final notice before removal',
			'kind'    => 'renewal',
			'subject' => 'Final notice: your USUCGER listing will be removed',
			'body'    => "<p>Dear {first_name},</p>\n<p>This is our last reminder about your USUCGER membership for {cycle}. Unless you renew, your name will be removed from the membership directory and the member email list in the next update.</p>\n{membership_box}\n{renew_button}\n<p>If you would like to stay in touch without renewing, reply and let us know.</p>\n{signature}",
		),
		'renewal_expiring' => array(
			'name'    => 'Membership ending soon (current members)',
			'kind'    => 'renewal',
			'subject' => 'Your USUCGER membership ends on {expires}',
			'body'    => "<p>Dear {first_name},</p>\n<p>Thank you for being a USUCGER member. Your current membership ends on <strong>{expires}</strong>. You can renew for the next cycle at any time using the button below.</p>\n{renew_button}\n{signature}",
		),
		'thanks' => array(
			'name'    => 'Thank you for renewing',
			'kind'    => 'news',
			'subject' => 'Thank you for renewing your USUCGER membership',
			'body'    => "<p>Dear {first_name},</p>\n<p>Thank you for renewing your USUCGER membership for {cycle}. Your listing in the membership directory is up to date.</p>\n{membership_box}\n<p>You can review your details at any time in <a href=\"{account_url}\">your account</a>.</p>\n{signature}",
		),
		'announcement' => array(
			'name'    => 'General announcement',
			'kind'    => 'news',
			'subject' => 'USUCGER announcement',
			'body'    => "<p>Dear {first_name},</p>\n<p>[Write the announcement here.]</p>\n{signature}",
		),
		'travel_grants' => array(
			'name'    => 'Call: student travel grants',
			'kind'    => 'news',
			'subject' => 'USUCGER student travel grants — applications open',
			'body'    => "<p>Dear {first_name},</p>\n<p>USUCGER student travel grant applications are open for the next two cycles. Grants of up to \$1,000 per student support travel to present at geotechnical conferences.</p>\n<p>Details, deadlines and the online application are on the <a href=\"" . esc_url( home_url( '/travel-grants/' ) ) . "\">travel grants page</a>. Please share this with your students.</p>\n{signature}",
		),
	);
	$changed = false;
	foreach ( $seed as $k => $v ) {
		if ( ! isset( $have[ $k ] ) ) {
			$have[ $k ] = $v;
			$changed    = true;
		}
	}
	if ( $changed ) {
		update_option( 'usucger_templates', $have, false );
	}
}

/* ================================================================ batches */

function usucger_batch( $id ) {
	global $wpdb;
	$t = Usucger_DB::t( 'batches' );
	$b = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $t WHERE id = %d", $id ) );
	if ( $b ) {
		$b->args = json_decode( (string) $b->group_args, true );
		$b->args = is_array( $b->args ) ? $b->args : array();
	}
	return $b;
}

function usucger_batch_save( $data, $id = 0 ) {
	global $wpdb;
	$t = Usucger_DB::t( 'batches' );
	if ( isset( $data['args'] ) ) {
		$data['group_args'] = wp_json_encode( $data['args'] );
		unset( $data['args'] );
	}
	if ( $id ) {
		$wpdb->update( $t, $data, array( 'id' => $id ) );
		return $id;
	}
	$data = array_merge( array( 'created' => current_time( 'mysql' ), 'created_by' => get_current_user_id(), 'status' => 'draft' ), $data );
	$wpdb->insert( $t, $data );
	return (int) $wpdb->insert_id;
}

function usucger_batch_recipients( $b ) {
	return Usucger_Members::recipients( $b->group_key, $b->args, $b->kind );
}

/** Submit for approval (or approve straight away when allowed). */
function usucger_batch_submit( $id ) {
	$b = usucger_batch( $id );
	if ( ! $b || ! in_array( $b->status, array( 'draft', 'rejected' ), true ) ) {
		return new WP_Error( 'state', 'This email is not a draft.' );
	}
	$n = count( usucger_batch_recipients( $b ) );
	if ( ! $n ) {
		return new WP_Error( 'empty', 'No recipients in that group (people who opted out are excluded).' );
	}
	usucger_batch_save( array( 'status' => 'pending', 'submitted' => current_time( 'mysql' ), 'total' => $n ), $id );
	Usucger_DB::log( 'email_submitted', 'batch:' . $id, $b->subject . ' (' . $n . ')' );
	if ( usucger_can_approve() || ( usucger_core_opt( 'board_can_send' ) && 'compose' === $b->source ) || ( function_exists( 'usucger_is_election_batch' ) && usucger_is_election_batch( $b ) && usucger_can_run_elections() ) ) {
		return usucger_batch_approve( $id );
	}
	$who = wp_get_current_user();
	usucger_notify( function_exists( 'usucger_is_election_batch' ) && usucger_is_election_batch( $b ) ? usucger_election_notify_to() : usucger_approver_emails(), 'Email for approval: ' . usucger_merge_static( $b->subject, $b->args ),
		'<p><strong>' . esc_html( $who->display_name ) . '</strong> submitted an email for approval.</p>'
		. '<p><strong>Subject:</strong> ' . esc_html( $b->subject ) . '<br><strong>Recipients:</strong> ' . (int) $n . ' (' . esc_html( Usucger_Members::groups()[ $b->group_key ][0] ) . ')</p>'
		. '<p><a href="' . esc_url( usucger_admin_url( 'usucger-outbox', array( 'batch' => $id ) ) ) . '">Preview and approve</a></p>' );
	return true;
}

/** Approve: render one email per recipient into the outbox; the cron sends them. */
function usucger_batch_approve( $id ) {
	global $wpdb;
	$b = usucger_batch( $id );
	if ( ! $b || 'pending' !== $b->status ) {
		return new WP_Error( 'state', 'Only emails waiting for approval can be approved.' );
	}
	// claim the batch first so a double click or a second approver cannot queue it twice
	if ( 1 !== (int) $wpdb->query( $wpdb->prepare( 'UPDATE ' . Usucger_DB::t( 'batches' ) . " SET status = 'approving' WHERE id = %d AND status = 'pending'", $id ) ) ) {
		return new WP_Error( 'state', 'This email is already being approved.' );
	}
	$wpdb->delete( Usucger_DB::t( 'outbox' ), array( 'batch_id' => $id ) );
	$rec = usucger_batch_recipients( $b );
	$ot  = Usucger_DB::t( 'outbox' );
	$now = current_time( 'mysql' );
	foreach ( $rec as $c ) {
		if ( ! $c->token ) {
			$c->token = usucger_token();
			$wpdb->update( Usucger_DB::t( 'contacts' ), array( 'token' => $c->token ), array( 'id' => $c->id ) );
		}
		list( $subj, $html ) = usucger_render_email( $b->subject, $b->body, $c, $b->kind, $b->args );
		$wpdb->insert( $ot, array(
			'batch_id'   => $id,
			'contact_id' => $c->id,
			'email'      => $c->email,
			'name'       => trim( $c->first_name . ' ' . $c->last_name ),
			'subject'    => $subj,
			'body'       => $html,
			'status'     => 'queued',
			'created'    => $now,
		) );
	}
	usucger_batch_save( array( 'status' => 'sending', 'approved_by' => get_current_user_id(), 'approved_at' => $now, 'total' => count( $rec ) ), $id );
	Usucger_DB::log( 'email_approved', 'batch:' . $id, $b->subject . ' (' . count( $rec ) . ')' );
	if ( (int) $b->created_by !== get_current_user_id() ) {
		$u = get_userdata( $b->created_by );
		if ( $u ) {
			usucger_notify( $u->user_email, 'Approved: ' . usucger_merge_static( $b->subject, $b->args ), '<p>Your email <strong>' . esc_html( $b->subject ) . '</strong> was approved and is being sent to ' . count( $rec ) . ' recipients (about ' . max( 1, (int) usucger_core_opt( 'batch_size' ) ) . ' per minute).</p>' );
		}
	}
	return true;
}

function usucger_batch_reject( $id, $note ) {
	$b = usucger_batch( $id );
	if ( ! $b || 'pending' !== $b->status ) {
		return;
	}
	usucger_batch_save( array( 'status' => 'rejected', 'note' => $note ), $id );
	Usucger_DB::log( 'email_rejected', 'batch:' . $id, $note );
	$u = get_userdata( $b->created_by );
	if ( $u && $u->ID !== get_current_user_id() ) {
		usucger_notify( $u->user_email, 'Returned: ' . usucger_merge_static( $b->subject, $b->args ), '<p>Your email <strong>' . esc_html( $b->subject ) . '</strong> was returned with this note:</p><blockquote style="border-left:3px solid #ccc;margin:0;padding:4px 12px">' . nl2br( esc_html( $note ) ) . '</blockquote><p><a href="' . esc_url( usucger_admin_url( 'usucger-compose', array( 'batch' => $id ) ) ) . '">Edit and resubmit</a></p>' );
	}
}

function usucger_batch_cancel( $id ) {
	global $wpdb;
	$wpdb->update( Usucger_DB::t( 'outbox' ), array( 'status' => 'cancelled' ), array( 'batch_id' => $id, 'status' => 'queued' ) );
	usucger_batch_save( array( 'status' => 'cancelled' ), $id );
	Usucger_DB::log( 'email_cancelled', 'batch:' . $id );
}

/* ================================================================ sender */

add_action( 'wp_mail_failed', function ( $err ) {
	$GLOBALS['usucger_mail_error'] = $err->get_error_message();
} );

function usucger_outbox_tick() {
	global $wpdb;
	// atomic lock: add_option fails if another tick holds it (stale locks expire after 5 minutes)
	$lock = get_option( 'usucger_tick_lock_at' );
	if ( $lock && time() - (int) $lock > 300 ) {
		delete_option( 'usucger_tick_lock_at' );
	}
	if ( ! add_option( 'usucger_tick_lock_at', time(), '', 'no' ) ) {
		return 0;
	}
	$ot   = Usucger_DB::t( 'outbox' );
	$bt   = Usucger_DB::t( 'batches' );
	$size = max( 1, min( 200, (int) usucger_core_opt( 'batch_size' ) ) );
	// release rows claimed by a tick that died more than 10 minutes ago
	$wpdb->query( $wpdb->prepare( "UPDATE $ot SET status = 'queued', error = '' WHERE status = 'sending' AND error LIKE %s AND error < %s", 'claim:%', 'claim:' . ( time() - 600 ) ) );
	// claim this tick's rows so no other process can send them
	$claim = 'claim:' . time() . ':' . wp_generate_password( 6, false, false );
	$ids   = $wpdb->get_col( $wpdb->prepare( "SELECT o.id FROM $ot o JOIN $bt b ON b.id = o.batch_id WHERE o.status = 'queued' AND b.status = 'sending' ORDER BY o.id LIMIT %d", $size ) );
	$rows  = array();
	if ( $ids ) {
		$wpdb->query( $wpdb->prepare( "UPDATE $ot SET status = 'sending', error = %s WHERE status = 'queued' AND id IN (" . implode( ',', array_map( 'intval', $ids ) ) . ')', $claim ) ); // phpcs:ignore WordPress.DB
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $ot WHERE status = 'sending' AND error = %s ORDER BY id", $claim ) );
	}
	update_option( 'usucger_last_tick', time(), false );
	$sent = 0;
	foreach ( $rows as $r ) {
		$GLOBALS['usucger_mail_error'] = '';
		$b     = usucger_batch( $r->batch_id );
		$c     = Usucger_Members::get( $r->contact_id );
		$extra = array();
		if ( apply_filters( 'usucger_outbox_skip', false, $r, $b ) ) {
			$wpdb->update( $ot, array( 'status' => 'skipped', 'error' => 'No longer needed (e.g. already voted)' ), array( 'id' => $r->id ) );
			continue;
		}
		if ( $c && $c->token && ( ! $b || 'official' !== $b->kind ) ) {
			$u       = usucger_unsub_url( $c, $b ? $b->kind : 'news' );
			$extra[] = 'List-Unsubscribe: <' . $u . '>';
			$extra[] = 'List-Unsubscribe-Post: List-Unsubscribe=One-Click';
		}
		$ok = wp_mail( $r->email, $r->subject, usucger_fill_personal( $r->body, $c, $b ), usucger_mail_headers( $extra ), usucger_batch_attachment_paths( $b ) );
		if ( $ok ) {
			$wpdb->update( $ot, array( 'status' => 'sent', 'sent_at' => current_time( 'mysql' ), 'attempts' => $r->attempts + 1, 'error' => '' ), array( 'id' => $r->id ) );
			$sent++;
		} else {
			$att = $r->attempts + 1;
			$wpdb->update( $ot, array( 'status' => $att >= 3 ? 'failed' : 'queued', 'attempts' => $att, 'error' => substr( (string) $GLOBALS['usucger_mail_error'], 0, 250 ) ), array( 'id' => $r->id ) );
		}
	}
	// close finished batches and refresh counters
	foreach ( $wpdb->get_col( "SELECT id FROM $bt WHERE status = 'sending'" ) as $bid ) { // phpcs:ignore WordPress.DB
		$s = $wpdb->get_row( $wpdb->prepare( "SELECT SUM(status='sent') sent, SUM(status='failed') failed, SUM(status IN ('queued','sending')) queued FROM $ot WHERE batch_id = %d", $bid ) );
		$d = array( 'sent' => (int) $s->sent, 'failed' => (int) $s->failed );
		if ( ! (int) $s->queued ) {
			$d['status'] = 'done';
			Usucger_DB::log( 'email_done', 'batch:' . $bid, $d );
		}
		usucger_batch_save( $d, (int) $bid );
	}
	delete_option( 'usucger_tick_lock_at' );
	return $sent;
}
add_action( 'usucger_tick', 'usucger_outbox_tick' );

/** Send a preview copy to one address (rendered for the first recipient, or a sample). */
function usucger_send_test( $b, $to ) {
	$rec = usucger_batch_recipients( $b );
	$c   = $rec ? $rec[0] : (object) array( 'first_name' => 'Pat', 'last_name' => 'Example', 'email' => $to, 'institution' => 'Example University', 'category' => 'U.S. University member', 'status' => 'lapsed', 'token' => 'preview', 'end_date' => '' );
	list( $s, $h ) = usucger_render_email( $b->subject, $b->body, $c, $b->kind, (array) $b->args );
	return wp_mail( $to, '[TEST] ' . $s, $h, usucger_mail_headers(), usucger_batch_attachment_paths( $b ) );
}

/* ================================================================ unsubscribe */

add_action( 'template_redirect', function () {
	if ( empty( $_REQUEST['usucger_unsub'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		return;
	}
	global $wpdb;
	$token = sanitize_text_field( wp_unslash( $_REQUEST['usucger_unsub'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
	$kind  = isset( $_REQUEST['t'] ) && 'renewal' === $_REQUEST['t'] ? 'renewal' : 'news'; // phpcs:ignore WordPress.Security.NonceVerification
	$t     = Usucger_DB::t( 'contacts' );
	$c     = strlen( $token ) >= 20 ? $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $t WHERE token = %s", $token ) ) : null;
	$col   = 'renewal' === $kind ? 'unsub_renewal' : 'unsub_news';
	$what  = 'renewal' === $kind ? 'membership renewal reminders' : 'USUCGER announcements';
	$done  = false;
	$undo  = false;
	if ( $c && 'POST' === $_SERVER['REQUEST_METHOD'] ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$undo = ! empty( $_POST['resubscribe'] ); // phpcs:ignore WordPress.Security.NonceVerification
		$wpdb->update( $t, array( $col => $undo ? 0 : 1, 'updated' => current_time( 'mysql' ) ), array( 'id' => $c->id ) );
		Usucger_DB::log( $undo ? 'resubscribed' : 'unsubscribed', 'contact:' . $c->id, $kind );
		$done = true;
		// RFC 8058 one-click: mail clients POST without a browser
		if ( isset( $_POST['List-Unsubscribe'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			status_header( 200 );
			exit( 'OK' );
		}
	}
	nocache_headers();
	$GLOBALS['usucger_no_cta'] = true;
	$body = '';
	if ( ! $c ) {
		$body = '<p>This link is not valid any more. To change your email preferences, write to <a href="mailto:' . esc_attr( usucger_core_opt( 'contact_email' ) ) . '">' . esc_html( usucger_core_opt( 'contact_email' ) ) . '</a>.</p>';
	} elseif ( $done && ! $undo ) {
		$body = '<p><strong>Done.</strong> ' . esc_html( $c->email ) . ' will no longer receive ' . esc_html( $what ) . '.</p><form method="post"><input type="hidden" name="resubscribe" value="1"><button class="btn btn-outline" type="submit">Undo</button></form>';
	} elseif ( $done && $undo ) {
		$body = '<p><strong>You are subscribed again</strong> to ' . esc_html( $what ) . '.</p>';
	} else {
		$body = '<p>Stop sending <strong>' . esc_html( $what ) . '</strong> to <strong>' . esc_html( $c->email ) . '</strong>?</p><form method="post"><button class="btn btn-cobalt" type="submit">Yes, stop these emails</button></form>'
			. ( 'renewal' === $kind ? '<p style="margin-top:1rem;font-size:.9rem">If you have retired or moved, reply to any USUCGER email and we will update the directory.</p>' : '' );
	}
	if ( function_exists( 'usucger_phero' ) ) {
		add_filter( 'pre_get_document_title', function () {
			return 'Email preferences — USUCGER';
		} );
		get_header();
		echo usucger_phero( array( 'eyebrow' => 'Email preferences', 'h1' => 'Email preferences', 'crumbs' => array( array( 'Email preferences', null ) ) ) ); // phpcs:ignore
		echo '<section class="section bg-white"><div class="wrap wp-prose"><div class="usg-notice">' . $body . '</div></div></section>'; // phpcs:ignore
		get_footer();
	} else {
		wp_die( $body, 'Email preferences', array( 'response' => 200 ) ); // phpcs:ignore
	}
	exit;
}, 1 );
