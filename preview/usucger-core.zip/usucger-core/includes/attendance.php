<?php
/**
 * "Where I'll be": members mark conferences/workshops they will attend or present at.
 * Counts are public on the conference list ("12 members attending"); names are shown
 * only to logged-in members, and only for members whose profile is visible.
 *
 * @package usucger-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function usucger_attendance_roles() {
	return array( 'attending' => 'Attending', 'presenting' => 'Presenting', 'organizing' => 'Organizing / chairing', 'exhibiting' => 'Exhibiting' );
}

function usucger_my_events( $uid ) {
	global $wpdb;
	$t    = Usucger_DB::t( 'attendance' );
	$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $t WHERE user_id = %d ORDER BY event_start, id", $uid ) );
	foreach ( $rows as $r ) {
		usucger_attendance_fill( $r );
	}
	return $rows;
}

/** Fill name/dates from the linked conference. */
function usucger_attendance_fill( $r ) {
	if ( $r->conference_id ) {
		$r->event_name  = get_the_title( $r->conference_id );
		$r->event_start = get_post_meta( $r->conference_id, 'start', true );
		$r->event_end   = get_post_meta( $r->conference_id, 'end', true );
		$r->location    = get_post_meta( $r->conference_id, 'location', true );
		$r->url         = get_post_meta( $r->conference_id, 'url', true );
	} else {
		$r->url = '';
	}
	$r->past = ( $r->event_end ? $r->event_end : $r->event_start ) < usucger_today();
	return $r;
}

function usucger_attendance_count( $conference_id ) {
	global $wpdb;
	static $cache = null;
	if ( null === $cache ) {
		$t     = Usucger_DB::t( 'attendance' );
		$cache = array();
		foreach ( $wpdb->get_results( "SELECT conference_id, COUNT(DISTINCT user_id) n FROM $t WHERE conference_id > 0 GROUP BY conference_id" ) as $r ) { // phpcs:ignore WordPress.DB
			$cache[ (int) $r->conference_id ] = (int) $r->n;
		}
	}
	return isset( $cache[ (int) $conference_id ] ) ? $cache[ (int) $conference_id ] : 0;
}

/** Visible attendees of a conference (profiles + role). */
function usucger_attendees( $conference_id ) {
	global $wpdb;
	$t   = Usucger_DB::t( 'attendance' );
	$out = array();
	foreach ( $wpdb->get_results( $wpdb->prepare( "SELECT user_id, role, note FROM $t WHERE conference_id = %d", $conference_id ) ) as $r ) {
		$p = usucger_profile( $r->user_id );
		if ( $p && $p->visible ) {
			$p->role = $r->role;
			$p->note = $r->note;
			$out[]   = $p;
		}
	}
	return $out;
}

/** Upcoming events with at least one member attending (for the member feed). */
function usucger_events_with_members( $limit = 8 ) {
	global $wpdb;
	$t    = Usucger_DB::t( 'attendance' );
	$rows = $wpdb->get_results( "SELECT conference_id, COUNT(DISTINCT user_id) n FROM $t WHERE conference_id > 0 GROUP BY conference_id ORDER BY n DESC" ); // phpcs:ignore WordPress.DB
	$out  = array();
	foreach ( $rows as $r ) {
		$p = get_post( $r->conference_id );
		if ( $p && usucger_is_listed( $p ) ) {
			$out[] = (object) array( 'id' => $p->ID, 'title' => $p->post_title, 'start' => get_post_meta( $p->ID, 'start', true ), 'location' => get_post_meta( $p->ID, 'location', true ), 'n' => (int) $r->n );
		}
	}
	usort( $out, function ( $a, $b ) {
		return strcmp( $a->start, $b->start );
	} );
	return array_slice( $out, 0, $limit );
}

add_action( 'admin_post_usucger_attend', function () {
	check_admin_referer( 'usucger_attend' );
	global $wpdb;
	$t   = Usucger_DB::t( 'attendance' );
	$uid = get_current_user_id();
	$p   = wp_unslash( $_POST );
	if ( ! empty( $p['remove'] ) ) {
		$wpdb->delete( $t, array( 'id' => (int) $p['remove'], 'user_id' => $uid ) );
	} else {
		$cid   = (int) $p['conference_id'];
		$roles = usucger_attendance_roles();
		$row   = array(
			'user_id'       => $uid,
			'conference_id' => $cid,
			'role'          => isset( $roles[ $p['role'] ] ) ? $p['role'] : 'attending',
			'note'          => mb_substr( sanitize_text_field( $p['note'] ), 0, 200 ),
			'created'       => current_time( 'mysql' ),
		);
		if ( ! $cid ) {
			$row['event_name']  = sanitize_text_field( $p['event_name'] );
			$row['event_start'] = preg_match( '/^\d{4}-\d{2}-\d{2}$/', $p['event_start'] ) ? $p['event_start'] : null;
			$row['event_end']   = preg_match( '/^\d{4}-\d{2}-\d{2}$/', $p['event_end'] ) ? $p['event_end'] : null;
			$row['location']    = sanitize_text_field( $p['location'] );
			if ( ! $row['event_name'] || ! $row['event_start'] ) {
				wp_safe_redirect( add_query_arg( array( 'tab' => 'events', 'err' => 1 ), usucger_portal_url() ) );
				exit;
			}
		} elseif ( $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $t WHERE user_id = %d AND conference_id = %d", $uid, $cid ) ) ) {
			$wpdb->update( $t, array( 'role' => $row['role'], 'note' => $row['note'] ), array( 'user_id' => $uid, 'conference_id' => $cid ) );
			wp_safe_redirect( add_query_arg( array( 'tab' => 'events', 'saved' => 1 ), usucger_portal_url() ) );
			exit;
		}
		$wpdb->insert( $t, $row );
		Usucger_DB::log( 'attendance_added', 'user:' . $uid, $cid ? 'conference ' . $cid : $row['event_name'] );
	}
	wp_safe_redirect( add_query_arg( array( 'tab' => 'events', 'saved' => 1 ), usucger_portal_url() ) );
	exit;
} );
