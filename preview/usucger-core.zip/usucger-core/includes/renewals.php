<?php
/**
 * Renewal reminder plan: dated steps that each create an email for a group
 * ("Not renewed" or "Expiring soon") from a template. On the step's date the daily
 * job creates the email and puts it in the approval queue (or approves it, if
 * "auto-approve scheduled reminders" is on). Members who renew in the meantime drop
 * out automatically because the group is evaluated when the email is approved.
 *
 * @package usucger-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function usucger_renewal_plan() {
	$p = get_option( 'usucger_renewal_plan', array() );
	return is_array( $p ) ? $p : array();
}

function usucger_renewal_plan_save( $plan ) {
	usort( $plan, function ( $a, $b ) {
		return strcmp( $a['date'], $b['date'] );
	} );
	update_option( 'usucger_renewal_plan', array_values( $plan ), false );
}

/** Suggested three-step plan starting next week. */
function usucger_renewal_plan_suggest() {
	$d = function ( $days ) {
		return gmdate( 'Y-m-d', strtotime( '+' . $days . ' days' ) );
	};
	return array(
		array( 'date' => $d( 7 ), 'template' => 'renewal_reminder', 'group' => 'not_renewed', 'days' => 30, 'batch' => 0 ),
		array( 'date' => $d( 37 ), 'template' => 'renewal_second', 'group' => 'not_renewed', 'days' => 30, 'batch' => 0 ),
		array( 'date' => $d( 67 ), 'template' => 'renewal_final', 'group' => 'not_renewed', 'days' => 30, 'batch' => 0 ),
	);
}

/** Create the email for a plan step. Returns batch id. */
function usucger_renewal_run_step( $i ) {
	$plan = usucger_renewal_plan();
	if ( ! isset( $plan[ $i ] ) || ! empty( $plan[ $i ]['batch'] ) ) {
		return 0;
	}
	$step = $plan[ $i ];
	$tpls = usucger_email_templates();
	if ( empty( $tpls[ $step['template'] ] ) ) {
		return 0;
	}
	$tpl = $tpls[ $step['template'] ];
	$id  = usucger_batch_save( array(
		'kind'         => 'renewal',
		'group_key'    => $step['group'],
		'args'         => array( 'days' => (int) $step['days'] ),
		'template_key' => $step['template'],
		'subject'      => $tpl['subject'],
		'body'         => $tpl['body'],
		'source'       => 'renewal_plan',
		'created_by'   => get_current_user_id(),
	) );
	$plan[ $i ]['batch'] = $id;
	usucger_renewal_plan_save( $plan );
	$b = usucger_batch( $id );
	$n = count( usucger_batch_recipients( $b ) );
	if ( ! $n ) {
		usucger_batch_save( array( 'status' => 'done', 'note' => 'Nobody left to remind on ' . usucger_today() . '.' ), $id );
		return $id;
	}
	usucger_batch_save( array( 'status' => 'pending', 'submitted' => current_time( 'mysql' ), 'total' => $n ), $id );
	if ( usucger_core_opt( 'auto_queue_plan' ) ) {
		usucger_batch_approve( $id );
	} else {
		usucger_notify( usucger_approver_emails(), 'Scheduled renewal reminder ready: ' . usucger_merge_static( $tpl['subject'] ),
			'<p>The renewal reminder scheduled for ' . esc_html( usucger_fmt_date( $step['date'], 'F j, Y' ) ) . ' is ready to send to <strong>' . (int) $n . '</strong> people who have not renewed.</p><p><a href="' . esc_url( usucger_admin_url( 'usucger-outbox', array( 'batch' => $id ) ) ) . '">Preview and approve</a></p>' );
	}
	Usucger_DB::log( 'renewal_step', 'batch:' . $id, $step );
	return $id;
}

add_action( 'usucger_daily', function () {
	$today = usucger_today();
	foreach ( usucger_renewal_plan() as $i => $step ) {
		if ( empty( $step['batch'] ) && $step['date'] <= $today ) {
			usucger_renewal_run_step( $i );
		}
	}
}, 20 ); // after the membership sync (priority 10)
