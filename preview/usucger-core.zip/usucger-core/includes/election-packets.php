<?php
/**
 * Candidate packets and the election officer.
 *
 * Mirrors the USUCGER "Board Candidate Statement" template:
 *   Candidate name · Title · Department and Institution · Summary of Experience ·
 *   Vision and Goals · headshot photo · two-page CV (PDF)
 * Optionally the candidate may also upload the merged three-page PDF (LastName_FirstName.pdf).
 *
 * Flow
 *  1. Nominee accepts (or the committee adds them).
 *  2. "Request candidate statements" email is created for nominees who have not sent a packet
 *     (scheduled 3 weeks before nominations close, or on demand). The election officer approves it.
 *     Each nominee gets a personal link to an online form — no login needed.
 *  3. Nominee fills in the form, uploads photo + CV; the officer is notified. They can edit until the due date.
 *  4. A reminder goes to anyone still missing 3 days before the due date (approval required).
 *  5. The officer puts complete nominees on the ballot; the ballot and the election page show the
 *     packet (photo, title, statement, CV link). "Meet the candidates" goes to all members when voting opens.
 *
 * @package usucger-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ============================================================ election officer */

/** Election officers (Settings → Elections) get the election tools without being administrators. */
add_filter( 'user_has_cap', function ( $allcaps, $caps, $args, $user ) {
	$officers = array_map( 'intval', (array) usucger_core_opt( 'election_officers' ) );
	if ( $user && in_array( (int) $user->ID, $officers, true ) ) {
		foreach ( array( 'read', 'edit_posts', 'usucger_elections', 'usucger_compose', 'usucger_view_members', 'upload_files' ) as $c ) {
			$allcaps[ $c ] = true;
		}
	}
	// President / co-approvers: the webmaster's approval authority — but not site settings,
	// plugins or users. Every approval happens while signed in (nonces + login on each action).
	$approvers = array_map( 'intval', (array) usucger_core_opt( 'approvers' ) );
	if ( $user && in_array( (int) $user->ID, $approvers, true ) ) {
		foreach ( array( 'read', 'edit_posts', 'edit_pages', 'edit_others_posts', 'edit_others_pages', 'edit_published_posts', 'edit_published_pages', 'publish_posts', 'publish_pages', 'upload_files', 'unfiltered_html', 'usucger_approve', 'usucger_compose', 'usucger_view_members', 'usucger_manage', 'usucger_elections' ) as $c ) {
			$allcaps[ $c ] = true;
		}
	}
	if ( ! empty( $allcaps['manage_options'] ) ) {
		$allcaps['usucger_elections'] = true;
	}
	return $allcaps;
}, 10, 4 );

function usucger_can_run_elections() {
	return usucger_can_approve() || current_user_can( 'usucger_elections' );
}

/** Emails for election notices: officers first, then approvers. */
function usucger_election_notify_to() {
	$to = array();
	foreach ( (array) usucger_core_opt( 'election_officers' ) as $uid ) {
		$u = get_userdata( (int) $uid );
		if ( $u ) {
			$to[] = $u->user_email;
		}
	}
	return array_values( array_unique( array_merge( $to, usucger_approver_emails() ) ) );
}

/** Is this batch an election email (officer may approve)? */
function usucger_is_election_batch( $b ) {
	return $b && ( ( isset( $b->source ) && 'election' === $b->source ) || in_array( isset( $b->group_key ) ? $b->group_key : '', array( 'voters_all', 'voters_pending', 'candidates', 'candidates_packet', 'candidates_not_asked' ), true ) );
}

/* ================================================================ packet data */

function usucger_cand_meta( $c ) {
	$m = json_decode( (string) $c->checks, true );
	return is_array( $m ) ? $m : array();
}

function usucger_cand_meta_set( $c, $k, $v ) {
	$m       = usucger_cand_meta( $c );
	$m[ $k ] = $v;
	$GLOBALS['wpdb']->update( Usucger_DB::t( 'candidates' ), array( 'checks' => wp_json_encode( $m ) ), array( 'id' => $c->id ) );
}

/** Packet completeness: [complete bool, missing list]. */
function usucger_packet_status( $c ) {
	$need = array(
		'title'      => array( $c->title_line, 'title' ),
		'department' => array( $c->department, 'department and institution' ),
		'experience' => array( $c->experience, 'summary of experience' ),
		'vision'     => array( $c->vision, 'vision and goals' ),
		'photo'      => array( $c->photo, 'headshot photo' ),
		'cv'         => array( $c->cv_url || $c->packet_url, 'two-page CV (PDF)' ),
	);
	$missing = array();
	foreach ( $need as $n ) {
		if ( ! $n[0] ) {
			$missing[] = $n[1];
		}
	}
	return array( ! $missing, $missing );
}

function usucger_packet_due( $e ) {
	return ! empty( $e->settings['packet_due'] ) ? $e->settings['packet_due'] : $e->nom_close;
}

function usucger_packet_url( $c ) {
	return add_query_arg( array( 'usg_packet' => $c->id, 'k' => usucger_candidate_token( $c ) ), usucger_election_page_url() );
}

/* Checks shown to the officer. */
add_filter( 'usucger_candidate_checks', function ( $out, $c ) {
	if ( 'question' === $c->position ) {
		return $out;
	}
	list( $ok, $missing ) = usucger_packet_status( $c );
	$out[] = $ok ? array( 'ok', 'Candidate statement, photo and CV received' . ( $c->packet_at ? ' (' . mysql2date( 'M j', $c->packet_at ) . ')' : '' ) . '.' ) : array( 'warn', 'Statement packet incomplete — missing ' . implode( ', ', $missing ) . '.' );
	return $out;
}, 10, 2 );

/* ============================================================= email support */

add_filter( 'usucger_email_groups', function ( $g ) {
	$g['candidates_packet']    = array( 'Election: nominees who have not sent their statement packet', 'official' );
	$g['candidates_not_asked'] = array( 'Election: nominees not yet asked for their statement packet', 'official' );
	return $g;
} );

add_filter( 'usucger_recipients', function ( $rows, $group, $args ) {
	if ( ! in_array( $group, array( 'candidates_packet', 'candidates_not_asked' ), true ) ) {
		return $rows;
	}
	$e = ! empty( $args['election'] ) ? usucger_election( (int) $args['election'] ) : usucger_current_election();
	if ( ! $e ) {
		return array();
	}
	$out = array();
	foreach ( usucger_candidates( $e->id, array( 'accepted', 'approved' ) ) as $c ) {
		if ( 'question' === $c->position || ! is_email( $c->email ) ) {
			continue;
		}
		list( $ok ) = usucger_packet_status( $c );
		$m          = usucger_cand_meta( $c );
		if ( ( 'candidates_packet' === $group && ! $ok ) || ( 'candidates_not_asked' === $group && empty( $m['asked'] ) && ! $ok ) ) {
			$out[] = Usucger_Members::ensure_contact( $c->email, $c->name, $c->institution );
		}
	}
	return $out;
}, 10, 3 );

/* Mark nominees as asked when the request email is approved. */
add_filter( 'usucger_outbox_skip', function ( $skip, $row, $b ) {
	if ( $skip || ! $b || ! in_array( $b->group_key, array( 'candidates_packet', 'candidates_not_asked' ), true ) ) {
		return $skip;
	}
	$e = ! empty( $b->args['election'] ) ? usucger_election( (int) $b->args['election'] ) : usucger_current_election();
	foreach ( $e ? usucger_candidates( $e->id ) : array() as $c ) {
		if ( strtolower( $c->email ) === strtolower( $row->email ) ) {
			usucger_cand_meta_set( $c, 'asked', usucger_today() );
			list( $ok ) = usucger_packet_status( $c );
			return $ok && 'candidates_packet' === $b->group_key; // reminder not needed once complete
		}
	}
	return $skip;
}, 20, 3 );

add_filter( 'usucger_merge_tag_help', function ( $t ) {
	return $t + array(
		'{packet_button}'   => 'Personal "Submit my candidate statement" button (nominees)',
		'{packet_due}'      => 'Candidate statement due date',
		'{candidate_cards}' => 'Nominees with photo, title and statement links (for "Meet the candidates")',
		'{officer_name}'    => 'Election officer name',
	);
} );

add_filter( 'usucger_merge_map', function ( $map, $c, $kind, $text ) {
	if ( false === strpos( $text, '{packet' ) && false === strpos( $text, '{candidate_cards' ) && false === strpos( $text, '{officer' ) ) {
		return $map;
	}
	$e = ( ! empty( $GLOBALS['usucger_render_args']['election'] ) ? usucger_election( (int) $GLOBALS['usucger_render_args']['election'] ) : usucger_current_election() );
	if ( ! $e ) {
		return $map;
	}
	$col                  = sanitize_hex_color( usucger_core_opt( 'letter_color' ) );
	$col                  = $col ? $col : '#C2410C';
	$map['{packet_due}']  = esc_html( usucger_fmt_date( usucger_packet_due( $e ), 'l, F j' ) );
	$officers             = array_filter( array_map( 'get_userdata', array_map( 'intval', (array) usucger_core_opt( 'election_officers' ) ) ) );
	$map['{officer_name}'] = esc_html( $officers ? reset( $officers )->display_name : usucger_core_opt( 'signer_name' ) );
	// default signature for officer emails when none chosen
	if ( ! empty( $e->settings['officer_signature'] ) && ( empty( $GLOBALS['usucger_render_args']['sign'] ) || 'site' === $GLOBALS['usucger_render_args']['sign'] ) && false !== strpos( $text, '{packet_button}' ) ) {
		$GLOBALS['usucger_render_args']['sign']      = 'custom';
		$GLOBALS['usucger_render_args']['sign_text'] = $e->settings['officer_signature'];
	}
	$map['{packet_button}'] = '';
	$email = isset( $c->email ) ? strtolower( $c->email ) : '';
	foreach ( usucger_candidates( $e->id ) as $cd ) {
		if ( $email && strtolower( $cd->email ) === $email ) {
			$ph                     = usucger_personal_placeholder( 'packet_button' );
			$map['{packet_button}'] = null !== $ph ? $ph : '<table role="presentation" cellpadding="0" cellspacing="0" style="margin:0 0 18px"><tr><td style="background:' . $col . ';border-radius:4px"><a href="' . esc_url( usucger_packet_url( $cd ) ) . '" style="display:inline-block;padding:12px 22px;font-family:Arial,Helvetica,sans-serif;font-size:15px;font-weight:700;color:#FFFFFF;text-decoration:none">Submit my candidate statement &rarr;</a></td></tr></table><p style="font-size:12px;color:#686460;margin:-8px 0 14px">This link is personal to you. You can come back and edit until the due date.</p>';
		}
	}
	$cards = '';
	foreach ( usucger_candidates( $e->id, array( 'approved' ) ) as $cd ) {
		if ( 'question' === $cd->position ) {
			continue;
		}
		$pdf    = $cd->packet_url ? $cd->packet_url : $cd->cv_url;
		$cards .= '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border:1px solid #E3E3E2;margin:0 0 12px"><tr>'
			. ( $cd->photo ? '<td width="84" style="padding:12px 0 12px 12px;vertical-align:top"><img src="' . esc_url( $cd->photo ) . '" width="72" height="72" alt="" style="border-radius:50%;display:block;object-fit:cover"></td>' : '' )
			. '<td style="padding:12px;font-family:Arial,Helvetica,sans-serif;font-size:14px;line-height:1.5;color:#343434"><strong style="font-size:15px;color:#1A1A1A">' . esc_html( $cd->name ) . '</strong> &middot; ' . esc_html( ucfirst( $cd->position ) ) . ' seat<br>'
			. esc_html( trim( $cd->title_line . ( $cd->department ? ', ' . $cd->department : ( $cd->institution ? ', ' . $cd->institution : '' ) ), ', ' ) ) . '<br>'
			. '<a href="' . esc_url( usucger_election_page_url() ) . '#cand-' . (int) $cd->id . '" style="color:' . $col . '">Read statement</a>' . ( $pdf ? ' &middot; <a href="' . esc_url( $pdf ) . '" style="color:' . $col . '">Statement &amp; CV (PDF)</a>' : '' ) . '</td></tr></table>';
	}
	$map['{candidate_cards}'] = $cards;
	return $map;
}, 10, 4 );

/* ============================================================ packet form */

/** Public page section for ?usg_packet=ID&k=TOKEN */
function usucger_packet_form_html( $c ) {
	$e = usucger_election( $c->election_id );
	if ( ! $e ) {
		return '';
	}
	$due    = usucger_packet_due( $e );
	$closed = usucger_today() > $due && ! usucger_can_run_elections();
	list( $ok, $missing ) = usucger_packet_status( $c );
	$o = '<div class="usg-card usg-packet"><div class="eyebrow"><span class="eyebrow-line"></span>Candidate statement · due ' . esc_html( usucger_fmt_date( $due, 'F j, Y' ) ) . '</div>';
	$o .= '<h2>' . esc_html( $c->name ) . ' — ' . esc_html( ucfirst( $c->position ) ) . ' Director nominee</h2>';
	if ( isset( $_GET['saved'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		$o .= '<div class="usg-notice usg-ok">' . ( $ok ? '<strong>Thank you — your statement is complete.</strong> The election officer has been notified. You can still make changes until ' . esc_html( usucger_fmt_date( $due, 'F j' ) ) . '.' : '<strong>Saved.</strong> Still needed: ' . esc_html( implode( ', ', $missing ) ) . '.' ) . '</div>';
	} elseif ( usucger_flash_read( 'perr' ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		$o .= '<div class="usg-notice">' . esc_html( usucger_flash_read( 'perr' ) ) . '</div>'; // phpcs:ignore WordPress.Security.NonceVerification
	}
	$o .= '<p>Thank you for your willingness to serve on the USUCGER Board. This information will be shared with the membership as part of the election, exactly as entered. Please keep the two statement sections to about one page together (roughly 500 words).</p>';
	if ( $closed ) {
		return $o . '<p><strong>The due date has passed.</strong> Please contact the election officer if you need to make a change.</p></div>';
	}
	$f   = function ( $v ) {
		return esc_attr( (string) $v );
	};
	// prefill from the nominee's member profile when they have one
	$pu = get_user_by( 'email', $c->email );
	if ( $pu && function_exists( 'usucger_profile' ) ) {
		$pp = usucger_profile( $pu->ID );
		if ( ! $c->title_line && $pp->title ) {
			$c->title_line = $pp->title;
		}
		if ( ! $c->experience && ! $c->statement && $pp->summary ) {
			$c->experience = $pp->summary;
		}
	}
	$o  .= '<form class="usg-form" method="post" enctype="multipart/form-data" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">'
		. '<input type="hidden" name="action" value="usucger_packet"><input type="hidden" name="cand" value="' . (int) $c->id . '"><input type="hidden" name="k" value="' . esc_attr( usucger_candidate_token( $c ) ) . '">'
		. '<input type="hidden" name="_usgp" value="' . esc_attr( wp_create_nonce( 'usucger_packet_' . $c->id ) ) . '">'
		. '<div class="usg-row2"><div><label for="pn">Candidate name</label><input id="pn" name="name" required value="' . $f( $c->name ) . '"></div>'
		. '<div><label for="pt">Title <span class="usg-small">(e.g., Assistant Professor, Professor)</span></label><input id="pt" name="title_line" required value="' . $f( $c->title_line ? $c->title_line : $c->rank_title ) . '"></div></div>'
		. '<label for="pd">Department and Institution</label><input id="pd" name="department" required value="' . $f( $c->department ? $c->department : $c->institution ) . '" placeholder="Department of Civil and Environmental Engineering, University of …">'
		. '<label for="pe">Summary of Experience</label><p class="usg-small" style="margin-top:0">Your experience as it relates to the mission of USUCGER. This may include a brief biography — members will also have your two-page CV.</p><textarea id="pe" name="experience" rows="8" required data-words>' . esc_textarea( (string) ( $c->experience ? $c->experience : $c->statement ) ) . '</textarea>'
		. '<label for="pv">Vision and Goals</label><p class="usg-small" style="margin-top:0">Your vision for the future of USUCGER and the goals you hope to accomplish as a member of the Board.</p><textarea id="pv" name="vision" rows="8" required data-words>' . esc_textarea( (string) $c->vision ) . '</textarea>'
		. '<p class="usg-small" id="pwc"></p>'
		. '<div class="usg-row2"><div><label for="pp">Headshot photo <span class="usg-small">(JPG/PNG, up to 5 MB)</span></label>' . ( $c->photo ? '<img src="' . esc_url( $c->photo ) . '" alt="" class="usg-av usg-av-xl" style="display:block;margin-bottom:.5rem">' : '' ) . '<input id="pp" type="file" name="photo" accept="image/jpeg,image/png"' . ( $c->photo ? '' : ' required' ) . '></div>'
		. '<div><label for="pc">Two-page CV <span class="usg-small">(PDF, up to 10 MB)</span></label>' . ( $c->cv_url ? '<p class="usg-small" style="margin-top:0"><a href="' . esc_url( $c->cv_url ) . '" target="_blank">Current file</a> — upload again to replace</p>' : '' ) . '<input id="pc" type="file" name="cv" accept="application/pdf"' . ( $c->cv_url || $c->packet_url ? '' : ' required' ) . '></div></div>'
		. '<label for="pk">Optional: your combined three-page PDF <span class="usg-small">(statement page + CV, named LastName_FirstName.pdf)</span></label>' . ( $c->packet_url ? '<p class="usg-small" style="margin-top:0"><a href="' . esc_url( $c->packet_url ) . '" target="_blank">Current file</a></p>' : '' ) . '<input id="pk" type="file" name="packet" accept="application/pdf">'
		. '<p class="usg-small">If you skip the combined PDF, members will see your statement on the website and your CV as a PDF.</p>'
		. '<button class="btn btn-cobalt" type="submit">' . ( $c->packet_at ? 'Update my statement' : 'Submit my statement' ) . '</button></form>'
		. '<script>(function(){var t=document.querySelectorAll("[data-words]"),o=document.getElementById("pwc");function u(){var n=0;t.forEach(function(x){n+=(x.value.trim().match(/\\S+/g)||[]).length});o.textContent=n+" words in the two sections"+(n>550?" — please shorten to about one page":"");o.style.color=n>550?"#b32d2e":""}t.forEach(function(x){x.addEventListener("input",u)});u()})();</script>';
	return $o . '</div>';
}

/** Store uploads in uploads/usucger-elections/<year>/ with an unguessable suffix. */
function usucger_packet_upload( $field, $types, $max_mb, $base ) {
	if ( empty( $_FILES[ $field ]['name'] ) || ! empty( $_FILES[ $field ]['error'] ) ) {
		return '';
	}
	if ( (int) $_FILES[ $field ]['size'] > $max_mb * MB_IN_BYTES ) {
		return new WP_Error( 'size', 'File too large: ' . $field );
	}
	require_once ABSPATH . 'wp-admin/includes/file.php';
	$check = wp_check_filetype_and_ext( $_FILES[ $field ]['tmp_name'], $_FILES[ $field ]['name'] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	$allowed = array();
	foreach ( array_keys( $types ) as $k ) {
		$allowed = array_merge( $allowed, explode( '|', $k ) );
	}
	if ( empty( $check['ext'] ) || ! in_array( strtolower( $check['ext'] ), $allowed, true ) ) {
		return new WP_Error( 'type', 'Wrong file type for ' . $field . '.' );
	}
	$dir = function ( $d ) {
		$sub         = '/usucger-elections/' . wp_date( 'Y' );
		$d['path']   = $d['basedir'] . $sub;
		$d['url']    = $d['baseurl'] . $sub;
		$d['subdir'] = $sub;
		return $d;
	};
	$_FILES[ $field ]['name'] = sanitize_file_name( $base ) . '-' . strtolower( wp_generate_password( 6, false, false ) ) . '.' . $check['ext'];
	add_filter( 'upload_dir', $dir );
	$r = wp_handle_upload( $_FILES[ $field ], array( 'test_form' => false, 'mimes' => $types ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	remove_filter( 'upload_dir', $dir );
	return isset( $r['url'] ) ? $r['url'] : new WP_Error( 'upload', isset( $r['error'] ) ? $r['error'] : 'Upload failed.' );
}

add_action( 'admin_post_usucger_packet', 'usucger_handle_packet' );
add_action( 'admin_post_nopriv_usucger_packet', 'usucger_handle_packet' );
function usucger_handle_packet() {
	$c = usucger_candidate( (int) $_POST['cand'] );
	if ( ! $c || ! hash_equals( usucger_candidate_token( $c ), (string) wp_unslash( $_POST['k'] ) ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_usgp'] ) ), 'usucger_packet_' . $c->id ) ) {
		wp_die( 'This link has expired. Please open the link from your email again.' );
	}
	$e    = usucger_election( $c->election_id );
	$back = usucger_packet_url( $c );
	if ( usucger_today() > usucger_packet_due( $e ) && ! usucger_can_run_elections() ) {
		wp_safe_redirect( add_query_arg( usucger_flash_arg( 'perr', 'The due date has passed.' ), $back ) );
		exit;
	}
	$p     = wp_unslash( $_POST );
	$parts = preg_split( '/\s+/', trim( sanitize_text_field( $p['name'] ) ) );
	$base  = ( count( $parts ) > 1 ? end( $parts ) . '_' . $parts[0] : $parts[0] );
	$data  = array(
		'name'       => sanitize_text_field( $p['name'] ),
		'title_line' => sanitize_text_field( $p['title_line'] ),
		'department' => sanitize_text_field( $p['department'] ),
		'experience' => mb_substr( sanitize_textarea_field( $p['experience'] ), 0, 5000 ),
		'vision'     => mb_substr( sanitize_textarea_field( $p['vision'] ), 0, 5000 ),
	);
	$data['statement'] = $data['experience'];
	// save the text first so nothing typed is lost if an upload fails
	$GLOBALS['wpdb']->update( Usucger_DB::t( 'candidates' ), $data, array( 'id' => $c->id ) );
	$data = array();
	foreach ( array( 'photo' => array( array( 'jpg|jpeg' => 'image/jpeg', 'png' => 'image/png' ), 5, $base . '_photo', 'photo' ), 'cv' => array( array( 'pdf' => 'application/pdf' ), 10, $base . '_CV', 'cv_url' ), 'packet' => array( array( 'pdf' => 'application/pdf' ), 15, $base, 'packet_url' ) ) as $field => $cfg ) {
		$u = usucger_packet_upload( $field, $cfg[0], $cfg[1], $cfg[2] );
		if ( is_wp_error( $u ) ) {
			wp_safe_redirect( add_query_arg( usucger_flash_arg( 'perr', $u->get_error_message() ), $back ) );
			exit;
		}
		if ( $u ) {
			$data[ $cfg[3] ] = $u;
		}
	}
	$first          = ! $c->packet_at;
	$data['packet_at'] = current_time( 'mysql' );
	$GLOBALS['wpdb']->update( Usucger_DB::t( 'candidates' ), $data, array( 'id' => $c->id ) );
	$c                = usucger_candidate( $c->id );
	list( $ok, $miss ) = usucger_packet_status( $c );
	usucger_notify( usucger_election_notify_to(), ( $first ? 'Candidate statement received: ' : 'Candidate statement updated: ' ) . $c->name,
		'<p><strong>' . esc_html( $c->name ) . '</strong> (' . esc_html( ucfirst( $c->position ) ) . ' seat) ' . ( $first ? 'submitted' : 'updated' ) . ' their candidate statement' . ( $ok ? ' — complete.' : ' — still missing ' . esc_html( implode( ', ', $miss ) ) . '.' ) . '</p><p><a href="' . esc_url( usucger_admin_url( 'usucger-elections', array( 'id' => $c->election_id, 'view' => 'candidates' ) ) ) . '">Review nominees</a></p>' );
	Usucger_DB::log( 'candidate_packet', 'election:' . $c->election_id, $c->name );
	wp_safe_redirect( add_query_arg( 'saved', 1, $back ) );
	exit;
}

/* Candidate card used on the election page and ballot. */
function usucger_candidate_card( $c, $with_radio = '' ) {
	$pdf  = $c->packet_url ? $c->packet_url : $c->cv_url;
	$sub  = trim( ( $c->title_line ? $c->title_line : $c->rank_title ) . ( $c->department ? ', ' . $c->department : ( $c->institution ? ', ' . $c->institution : '' ) ), ', ' );
	$o    = '<div class="usg-candcard" id="cand-' . (int) $c->id . '">' . ( $c->photo ? '<img class="usg-av usg-av-xl" src="' . esc_url( $c->photo ) . '" alt="">' : '<span class="usg-av usg-av-xl usg-av-i">' . esc_html( usucger_initials( $c->name ) ) . '</span>' ) . '<div>';
	$o   .= $with_radio . '<strong class="usg-cname">' . esc_html( $c->name ) . '</strong><span class="usg-sub">' . esc_html( $sub ) . '</span>';
	if ( $c->experience || $c->vision || $c->statement ) {
		$o .= '<details><summary>Candidate statement</summary>';
		if ( $c->experience || $c->statement ) {
			$o .= '<h4>Summary of experience</h4><p>' . nl2br( esc_html( $c->experience ? $c->experience : $c->statement ) ) . '</p>';
		}
		if ( $c->vision ) {
			$o .= '<h4>Vision and goals</h4><p>' . nl2br( esc_html( $c->vision ) ) . '</p>';
		}
		$o .= '</details>';
	}
	if ( $pdf ) {
		$o .= '<a class="usg-pdf" href="' . esc_url( $pdf ) . '" target="_blank" rel="noopener">' . ( $c->packet_url ? 'Statement &amp; CV (PDF)' : 'CV (PDF)' ) . '</a>';
	}
	return $o . '</div></div>';
}

/* =================================================================== templates */

add_action( 'init', function () {
	$have = usucger_email_templates();
	$add  = array(
		'election_packet_request' => array( 'Election: request candidate statements', 'official', 'USUCGER Board election — candidate statement due {packet_due}', "<p>Dear {first_name},</p>\n<p>Thank you for your willingness to serve on the USUCGER Board if elected; we appreciate your commitment to the USUCGER community!</p>\n<p>In preparation for the {election_title}, we are asking all candidates for a candidate statement and an abbreviated CV. By <strong>{packet_due}</strong>, please use the button below to enter your one-page candidate statement (title, department and institution, summary of experience, and vision and goals), upload a headshot photo, and upload a two-page CV as a PDF. You may also upload your combined three-page PDF named LastName_FirstName.pdf.</p>\n{packet_button}\n<p>This information will be provided to the membership as part of the election. If you have any questions, please reply to this email.</p>\n{signature}" ),
		'election_packet_reminder' => array( 'Election: candidate statement reminder', 'official', 'Reminder: your USUCGER candidate statement is due {packet_due}', "<p>Dear {first_name},</p>\n<p>A friendly reminder that your candidate statement, headshot and two-page CV for the {election_title} are due <strong>{packet_due}</strong>. It takes about 15 minutes:</p>\n{packet_button}\n{signature}" ),
		'election_candidates'     => array( 'Election: meet the candidates (all members)', 'official', 'Meet the candidates: {election_title}', "<p>Dear {first_name},</p>\n<p>Voting in the {election_title} is open until <strong>{vote_close}</strong>. Each member institution casts one ballot through its delegate — one vote for the junior seat and one for the senior seat. Here are the candidates:</p>\n{candidate_cards}\n<p>Full statements and CVs are on the <a href=\"{election_url}\">elections page</a>. If you are your institution's delegate, your personal ballot link arrives in a separate email.</p>\n{signature}" ),
	);
	$changed = false;
	foreach ( $add as $k => $v ) {
		if ( ! isset( $have[ $k ] ) ) {
			$have[ $k ] = array( 'name' => $v[0], 'kind' => $v[1], 'subject' => $v[2], 'body' => $v[3] );
			$changed    = true;
		}
	}
	if ( $changed ) {
		update_option( 'usucger_templates', $have, false );
	}
}, 22 );

/* ======================================================= nomination acceptance */

add_filter( 'usucger_email_groups', function ( $g ) {
	$g['candidates_unconfirmed'] = array( 'Election: nominees who have not yet accepted their nomination', 'official' );
	return $g;
} );

add_filter( 'usucger_recipients', function ( $rows, $group, $args ) {
	if ( 'candidates_unconfirmed' !== $group ) {
		return $rows;
	}
	$e = ! empty( $args['election'] ) ? usucger_election( (int) $args['election'] ) : usucger_current_election();
	$out = array();
	foreach ( $e ? usucger_candidates( $e->id, array( 'nominated' ) ) : array() as $c ) {
		if ( is_email( $c->email ) && 'question' !== $c->position ) {
			$out[] = Usucger_Members::ensure_contact( $c->email, $c->name, $c->institution );
		}
	}
	return $out;
}, 10, 3 );

/* Skip anyone who answered between approval and sending; remember who was asked. */
add_filter( 'usucger_outbox_skip', function ( $skip, $row, $b ) {
	if ( $skip || ! $b || 'candidates_unconfirmed' !== $b->group_key ) {
		return $skip;
	}
	$e = ! empty( $b->args['election'] ) ? usucger_election( (int) $b->args['election'] ) : usucger_current_election();
	foreach ( $e ? usucger_candidates( $e->id ) : array() as $c ) {
		if ( strtolower( $c->email ) === strtolower( $row->email ) ) {
			if ( 'nominated' !== $c->status ) {
				return true;
			}
			usucger_cand_meta_set( $c, 'accept_asked', usucger_today() );
			return false;
		}
	}
	return $skip;
}, 20, 3 );

/**
 * Create (or reuse) the "please confirm your nomination" email for nominees who have not answered.
 * $now = true: return the draft for the officer to review immediately; false: pending + notify officer.
 */
function usucger_queue_accept_requests( $e, $now ) {
	global $wpdb;
	$bt   = Usucger_DB::t( 'batches' );
	$open = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $bt WHERE group_key = 'candidates_unconfirmed' AND status IN ('draft','pending') AND group_args LIKE %s ORDER BY id DESC LIMIT 1", '%"election":' . (int) $e->id . '%' ) );
	if ( $open ) {
		usucger_batch_save( array( 'total' => count( Usucger_Members::recipients( 'candidates_unconfirmed', array( 'election' => $e->id ), 'official' ) ) ), $open );
		return $open;
	}
	$tpls = usucger_email_templates();
	$t    = $tpls['election_accept_request'];
	$args = array( 'election' => $e->id );
	if ( ! empty( $e->settings['officer_signature'] ) ) {
		$args['sign']      = 'custom';
		$args['sign_text'] = $e->settings['officer_signature'];
	}
	$id = usucger_batch_save( array( 'kind' => 'official', 'group_key' => 'candidates_unconfirmed', 'args' => $args, 'template_key' => 'election_accept_request', 'subject' => $t['subject'], 'body' => $t['body'], 'source' => 'election' ) );
	if ( ! $now ) {
		$n = count( Usucger_Members::recipients( 'candidates_unconfirmed', array( 'election' => $e->id ), 'official' ) );
		usucger_batch_save( array( 'status' => 'pending', 'submitted' => current_time( 'mysql' ), 'total' => $n ), $id );
		usucger_notify( usucger_election_notify_to(), 'Approve: ask ' . $n . ' nominee(s) to confirm', '<p>New nominations are waiting for the nominees to confirm they are willing to serve. The “please confirm” email is ready for your approval.</p><p><a href="' . esc_url( usucger_desk_url() ) . '">Approve on the desk</a> · <a href="' . esc_url( usucger_admin_url( 'usucger-outbox', array( 'batch' => $id ) ) ) . '">Preview</a></p>' );
	}
	return $id;
}

add_filter( 'usucger_merge_tag_help', function ( $t ) {
	return $t + array(
		'{accept_button}'  => 'Personal "Accept / decline my nomination" button (nominees)',
		'{nominated_seat}' => 'Seat the person was nominated for',
		'{accept_due}'     => 'Date nominees should answer by (election settings)',
		'{voting_months}'  => 'Month(s) of voting, e.g. November',
		'{site_url}'       => 'Website address',
	);
} );

add_filter( 'usucger_merge_map', function ( $map, $c, $kind, $text ) {
	$map['{site_url}'] = esc_url( home_url( '/' ) );
	if ( false === strpos( $text, '{accept_' ) && false === strpos( $text, '{nominated_seat}' ) && false === strpos( $text, '{voting_months}' ) ) {
		return $map;
	}
	$e     = ( ! empty( $GLOBALS['usucger_render_args']['election'] ) ? usucger_election( (int) $GLOBALS['usucger_render_args']['election'] ) : usucger_current_election() );
	if ( $e ) {
		$due                   = ! empty( $e->settings['accept_due'] ) ? $e->settings['accept_due'] : $e->nom_close;
		$map['{accept_due}']   = esc_html( usucger_fmt_date( $due, 'l, F j' ) );
		$m1                    = usucger_fmt_date( $e->vote_open, 'F' );
		$m2                    = usucger_fmt_date( $e->vote_close, 'F' );
		$map['{voting_months}'] = esc_html( $m1 === $m2 ? $m1 : $m1 . '/' . $m2 );
	}
	$email = isset( $c->email ) ? strtolower( $c->email ) : '';
	$map['{accept_button}']  = '';
	$map['{nominated_seat}'] = '';
	foreach ( $e ? usucger_candidates( $e->id ) : array() as $cd ) {
		if ( $email && strtolower( $cd->email ) === $email ) {
			$url = add_query_arg( array( 'usg_nominee' => $cd->id, 'k' => usucger_candidate_token( $cd ) ), usucger_election_page_url() );
			$col = sanitize_hex_color( usucger_core_opt( 'letter_color' ) );
			$map['{nominated_seat}'] = esc_html( ucfirst( $cd->position ) . ' Director (' . ( 'junior' === $cd->position ? 'Assistant Professor' : 'Associate or Full Professor' ) . ')' );
			$ph                      = usucger_personal_placeholder( 'accept_button' );
			$map['{accept_button}']  = null !== $ph ? $ph : '<table role="presentation" cellpadding="0" cellspacing="0" style="margin:0 0 18px"><tr><td style="background:' . ( $col ? $col : '#C2410C' ) . ';border-radius:4px"><a href="' . esc_url( $url ) . '" style="display:inline-block;padding:12px 22px;font-family:Arial,Helvetica,sans-serif;font-size:15px;font-weight:700;color:#FFFFFF;text-decoration:none">Yes, I accept the nomination &rarr;</a></td></tr></table><p style="font-size:13px;color:#686460;margin:-8px 0 14px">The button opens a short page where you confirm (or decline). If you have a USUCGER account you can also answer in the member area.</p>';
		}
	}
	return $map;
}, 10, 4 );

add_action( 'init', function () {
	$have = usucger_email_templates();
	if ( ! isset( $have['election_accept_request'] ) ) {
		$have['election_accept_request'] = array(
			'name'    => 'Election: please confirm your nomination',
			'kind'    => 'official',
			'subject' => 'USUCGER Board of Directors — would you be willing to be nominated?',
			'body'    => "<p>Dear {first_name},</p>\n<p>I hope the start of your semester is going well.</p>\n<p>I am writing to you in my capacity as a member of the USUCGER Board Nominating Committee. We are currently selecting individuals who would be willing to be nominated for the upcoming USUCGER Board elections. Each year, there are at least four nominees, and one junior-level and one senior-level candidate are elected to the Board.</p>\n<p>The Nominating Committee has put forward your name as a potential nominee for the <strong>{nominated_seat}</strong> position. Would you be willing to be nominated for a position on the USUCGER Board of Directors? You can read more about the Board and its activities on the <a href=\"{site_url}\">USUCGER website</a>. I would be happy to answer any questions that you may have. Could you please let us know if you are willing to be a nominee by <strong>{accept_due}</strong>?</p>\n{accept_button}\n<p>If you accept the nomination, we will send along instructions in a couple of weeks about candidate statements and other logistics. The elections are slated to occur in {voting_months}, and the new Board members will be installed in January; terms on the Board of Directors are four years in length. Thank you for the consideration!</p>\n{signature}",
		);
		update_option( 'usucger_templates', $have, false );
	}
}, 23 );

/* Daily: if nominees are waiting to be asked, prepare the email for the officer. */
add_action( 'usucger_daily', function () {
	$e = usucger_current_election();
	if ( $e && 'board' === $e->kind && in_array( usucger_election_phase( $e ), array( 'scheduled', 'nominations', 'review' ), true ) ) {
		$waiting = 0;
		foreach ( usucger_candidates( $e->id, array( 'nominated' ) ) as $c ) {
			$m = usucger_cand_meta( $c );
			if ( empty( $m['accept_asked'] ) && is_email( $c->email ) ) {
				$waiting++;
			}
		}
		if ( $waiting ) {
			usucger_queue_accept_requests( $e, false );
		}
	}
}, 28 );

/* ---------------------------------------------- member area: my nomination */

/** The signed-in user's nominations in the current election. */
function usucger_my_nominations() {
	$e = usucger_current_election();
	if ( ! $e || ! is_user_logged_in() ) {
		return array();
	}
	$email = strtolower( wp_get_current_user()->user_email );
	return array_values( array_filter( usucger_candidates( $e->id ), function ( $c ) use ( $email ) {
		return strtolower( $c->email ) === $email && 'question' !== $c->position;
	} ) );
}

function usucger_portal_nomination_box() {
	$mine = usucger_my_nominations();
	if ( ! $mine ) {
		return '';
	}
	$e = usucger_current_election();
	if ( in_array( usucger_election_phase( $e ), array( 'closed', 'certified' ), true ) ) {
		return ''; // nothing left to do; results are shown in the election box
	}
	$o = '';
	if ( isset( $_GET['nomination'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		$o .= '<div class="usg-notice usg-ok"><strong>' . ( 'accepted' === $_GET['nomination'] ? 'Thank you — your nomination is accepted.' : 'Your answer has been recorded.' ) . '</strong></div>'; // phpcs:ignore WordPress.Security.NonceVerification
	}
	foreach ( $mine as $c ) {
		$seat = ucfirst( $c->position ) . ' Director';
		if ( 'nominated' === $c->status ) {
			$o .= '<div class="usg-banner usg-nom"><div><strong>You have been nominated for the ' . esc_html( $seat ) . ' seat</strong> in the ' . esc_html( $e->title ) . '. Will you serve if elected? Please answer by ' . esc_html( usucger_fmt_date( ! empty( $e->settings['accept_due'] ) && $e->settings['accept_due'] >= usucger_today() ? $e->settings['accept_due'] : $e->nom_close, 'F j' ) ) . '.</div>'
				. '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="usg-nom-actions"><input type="hidden" name="action" value="usucger_nominee"><input type="hidden" name="from_portal" value="1"><input type="hidden" name="cand" value="' . (int) $c->id . '"><input type="hidden" name="k" value="' . esc_attr( usucger_candidate_token( $c ) ) . '">'
				. '<button class="btn btn-amber" name="accept" value="1">Accept nomination</button> <button class="btn btn-outline" name="decline" value="1" onclick="return confirm(\'Decline this nomination?\')">Decline</button></form></div>';
		} elseif ( in_array( $c->status, array( 'accepted', 'approved' ), true ) ) {
			list( $ok, $missing ) = usucger_packet_status( $c );
			if ( usucger_packet_due( $e ) < usucger_today() || 'voting' === usucger_election_phase( $e ) ) {
				$o .= '<div class="usg-card"><div class="usg-card-h"><h3>Your nomination: ' . esc_html( $seat ) . '</h3><span class="usg-st sent">' . ( 'approved' === $c->status ? 'On the ballot' : 'Accepted' ) . '</span></div><p>The deadline for candidate material has passed' . ( $ok ? '' : ' — contact the election officer if something is missing' ) . '. Results will appear here when voting closes.</p></div>';
				continue;
			}
			$m  = usucger_cand_meta( $c );
			$o .= '<div class="usg-card usg-cta"><div class="usg-card-h"><h3>Your nomination: ' . esc_html( $seat ) . '</h3><span class="usg-st ' . ( 'approved' === $c->status ? 'sent' : 'awaiting' ) . '">' . ( 'approved' === $c->status ? 'On the ballot' : 'Accepted' . ( ! empty( $m['accepted_at'] ) ? ' ' . esc_html( mysql2date( 'M j', $m['accepted_at'] ) ) : '' ) ) . '</span></div>'
				. ( $ok ? '<p>Your candidate statement, photo and CV are in. You can still edit them until ' . esc_html( usucger_fmt_date( usucger_packet_due( $e ), 'F j' ) ) . '.</p>' : '<p>Next step: your candidate statement, headshot and two-page CV — due <strong>' . esc_html( usucger_fmt_date( usucger_packet_due( $e ), 'F j' ) ) . '</strong>. Still needed: ' . esc_html( implode( ', ', $missing ) ) . '.</p>' )
				. '<a class="btn btn-cobalt btn-sm" href="' . esc_url( usucger_packet_url( $c ) ) . '">' . ( $ok ? 'Review my statement' : 'Complete my candidate statement' ) . '</a></div>';
		} elseif ( 'declined' === $c->status ) {
			$o .= '<div class="usg-card"><p>You declined the nomination for the ' . esc_html( $seat ) . ' seat. Changed your mind? Contact the election officer.</p></div>';
		}
	}
	return $o;
}
