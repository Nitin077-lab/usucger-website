<?php
/**
 * Email sign-in code (second step) for people who can change the site, approve email or
 * run elections: administrators, approvers (President), election officers, Board members
 * and the Membership Coordinator. Members sign in as usual.
 *
 * After a correct password the session is not started; a 6-digit code is emailed and must be
 * entered within 10 minutes (5 tries). "Trust this browser" skips the code for 30 days.
 * Turn off in Settings, or with define( 'USUCGER_DISABLE_2FA', true ) in wp-config.php
 * (e.g. if email is down and you are locked out).
 *
 * @package usucger-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function usucger_2fa_enabled() {
	return ! ( defined( 'USUCGER_DISABLE_2FA' ) && USUCGER_DISABLE_2FA ) && usucger_core_opt( 'two_factor' );
}

function usucger_2fa_required( $user ) {
	if ( ! $user instanceof WP_User || ! usucger_2fa_enabled() ) {
		return false;
	}
	$staff = array_intersect( (array) $user->roles, array( 'administrator', 'editor', 'usucger_board', 'usucger_coordinator' ) );
	return (bool) apply_filters( 'usucger_2fa_required', $staff || user_can( $user, 'usucger_approve' ) || user_can( $user, 'usucger_elections' ) || user_can( $user, 'usucger_manage' ), $user );
}

function usucger_2fa_trust_sig( $uid, $exp ) {
	$u = get_userdata( $uid );
	// tied to the password hash: changing the password revokes trusted browsers
	return hash_hmac( 'sha256', $uid . '|' . $exp . '|' . ( $u ? substr( $u->user_pass, -12 ) : '' ), wp_salt( 'secure_auth' ) );
}

function usucger_2fa_trusted( $uid ) {
	if ( empty( $_COOKIE['usg_2fa_trust'] ) ) {
		return false;
	}
	$parts = explode( '|', sanitize_text_field( wp_unslash( $_COOKIE['usg_2fa_trust'] ) ) );
	if ( 3 !== count( $parts ) || (int) $parts[0] !== (int) $uid || (int) $parts[1] < time() ) {
		return false;
	}
	return hash_equals( usucger_2fa_trust_sig( (int) $parts[0], (int) $parts[1] ), $parts[2] );
}

function usucger_2fa_send( $key, &$ch ) {
	$code       = (string) wp_rand( 100000, 999999 );
	$ch['hash'] = hash_hmac( 'sha256', $code, wp_salt( 'auth' ) . $key );
	$ch['sent'] = time();
	$u          = get_userdata( $ch['uid'] );
	$ip         = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	$ok = wp_mail(
		$u->user_email,
		'USUCGER sign-in code: ' . $code,
		"Your USUCGER sign-in code is:\n\n    " . $code . "\n\nIt expires in 10 minutes. If you did not just sign in to " . home_url( '/' ) . ', change your password — someone knows it. (Request from ' . $ip . ")\n"
	);
	return $ok;
}

function usucger_2fa_pending( $user ) {
	return usucger_2fa_required( $user ) && ! usucger_2fa_trusted( $user->ID ) && empty( $GLOBALS['usucger_2fa_passed'] );
}

/*
 * Password accepted for someone who needs a code: make sure no login cookie is ever sent for
 * this request (wp_signon sets cookies before wp_login fires), and refuse XML-RPC, which has
 * no way to ask for a code.
 */
add_filter( 'authenticate', function ( $user ) {
	if ( $user instanceof WP_User && usucger_2fa_pending( $user ) ) {
		if ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST ) {
			return new WP_Error( 'usucger_2fa', 'Staff accounts cannot sign in through XML-RPC.' );
		}
		add_filter( 'send_auth_cookies', '__return_false', 999 );
	}
	return $user;
}, PHP_INT_MAX );

/* Remember the session token wp_signon created, so it can be destroyed server-side too. */
add_action( 'set_logged_in_cookie', function ( $cookie, $expire, $expiration, $uid, $scheme, $token ) {
	$GLOBALS['usucger_2fa_token'] = array( $uid, $token );
}, 10, 6 );

/* Application passwords (REST/XML-RPC) would skip the code: not available to staff. */
add_filter( 'wp_is_application_passwords_available_for_user', function ( $ok, $user ) {
	return $ok && ! usucger_2fa_required( $user );
}, 10, 2 );
add_filter( 'xmlrpc_enabled', function ( $on ) {
	return usucger_2fa_enabled() ? false : $on; // the site does not use XML-RPC
} );

/* After a correct password: end the session, email a code, ask for it. */
add_action( 'wp_login', function ( $login, $user ) {
	if ( ! usucger_2fa_pending( $user ) ) {
		return;
	}
	if ( ! empty( $GLOBALS['usucger_2fa_token'] ) && (int) $GLOBALS['usucger_2fa_token'][0] === (int) $user->ID ) {
		WP_Session_Tokens::get_instance( $user->ID )->destroy( $GLOBALS['usucger_2fa_token'][1] );
	}
	// per-user cap on failed codes across logins (stops endless guessing with a known password)
	if ( (int) get_transient( 'usg2fa_fail_' . $user->ID ) >= 15 ) {
		wp_clear_auth_cookie();
		Usucger_DB::log( 'login_code_blocked', 'user:' . $user->ID );
		wp_safe_redirect( add_query_arg( 'usg2fa', 'locked', wp_login_url() ) );
		exit;
	}
	wp_clear_auth_cookie();
	wp_set_current_user( 0 );
	$key = wp_generate_password( 32, false, false );
	$ch  = array(
		'uid'      => $user->ID,
		'tries'    => 0,
		'remember' => ! empty( $_POST['rememberme'] ), // phpcs:ignore WordPress.Security.NonceVerification
		'redirect' => isset( $_REQUEST['redirect_to'] ) ? esc_url_raw( wp_unslash( $_REQUEST['redirect_to'] ) ) : '', // phpcs:ignore WordPress.Security.NonceVerification
	);
	$sent = usucger_2fa_send( $key, $ch );
	set_transient( 'usg2fa_' . $key, $ch, 10 * MINUTE_IN_SECONDS );
	Usucger_DB::log( 'login_code_sent', 'user:' . $user->ID, $sent ? 'sent' : 'mail failed' );
	wp_safe_redirect( add_query_arg( array( 'action' => 'usucger_2fa', 'c' => $key ), wp_login_url() ) );
	exit;
}, 1, 2 );

add_action( 'login_form_usucger_2fa', function () {
	$key = isset( $_REQUEST['c'] ) ? preg_replace( '/[^A-Za-z0-9]/', '', wp_unslash( $_REQUEST['c'] ) ) : ''; // phpcs:ignore
	$ch  = $key ? get_transient( 'usg2fa_' . $key ) : false;
	$err = '';
	if ( ! $ch ) {
		wp_safe_redirect( add_query_arg( 'usg2fa', 'expired', wp_login_url() ) );
		exit;
	}
	if ( 'POST' === $_SERVER['REQUEST_METHOD'] ) { // phpcs:ignore
		check_admin_referer( 'usucger_2fa_' . $key );
		if ( ! empty( $_POST['resend'] ) ) {
			if ( time() - (int) $ch['sent'] < 45 ) {
				$err = 'Please wait a minute before asking for another code.';
			} else {
				usucger_2fa_send( $key, $ch );
				set_transient( 'usg2fa_' . $key, $ch, 10 * MINUTE_IN_SECONDS );
				$err = 'A new code is on its way.';
			}
		} else {
			$code = preg_replace( '/\D/', '', wp_unslash( isset( $_POST['code'] ) ? $_POST['code'] : '' ) ); // phpcs:ignore
			$ch['tries']++;
			if ( $ch['tries'] > 5 ) {
				delete_transient( 'usg2fa_' . $key );
				Usucger_DB::log( 'login_code_locked', 'user:' . $ch['uid'] );
				wp_safe_redirect( add_query_arg( 'usg2fa', 'locked', wp_login_url() ) );
				exit;
			}
			if ( hash_equals( $ch['hash'], hash_hmac( 'sha256', $code, wp_salt( 'auth' ) . $key ) ) ) {
				delete_transient( 'usg2fa_' . $key );
				delete_transient( 'usg2fa_fail_' . $ch['uid'] );
				$user = get_userdata( $ch['uid'] );
				$GLOBALS['usucger_2fa_passed'] = true;
				remove_filter( 'send_auth_cookies', '__return_false', 999 );
				wp_set_auth_cookie( $user->ID, $ch['remember'], is_ssl() );
				wp_set_current_user( $user->ID );
				if ( ! empty( $_POST['trust'] ) ) {
					$exp = time() + 30 * DAY_IN_SECONDS;
					setcookie( 'usg_2fa_trust', $user->ID . '|' . $exp . '|' . usucger_2fa_trust_sig( $user->ID, $exp ), array( 'expires' => $exp, 'path' => COOKIEPATH ? COOKIEPATH : '/', 'domain' => COOKIE_DOMAIN, 'secure' => is_ssl(), 'httponly' => true, 'samesite' => 'Lax' ) );
				}
				Usucger_DB::log( 'login_code_ok', 'user:' . $user->ID, ! empty( $_POST['trust'] ) ? 'trusted browser' : '' );
				$GLOBALS['usucger_2fa_passed'] = true;
				$to = apply_filters( 'login_redirect', $ch['redirect'] ? $ch['redirect'] : admin_url(), $ch['redirect'], $user );
				wp_safe_redirect( $to ? $to : admin_url() );
				exit;
			}
			set_transient( 'usg2fa_' . $key, $ch, 10 * MINUTE_IN_SECONDS );
			set_transient( 'usg2fa_fail_' . $ch['uid'], (int) get_transient( 'usg2fa_fail_' . $ch['uid'] ) + 1, HOUR_IN_SECONDS );
			$err = 'That code is not right. ' . ( 5 - $ch['tries'] ) . ' tries left.';
		}
	}
	$u = get_userdata( $ch['uid'] );
	login_header( 'Sign-in code', '<p class="message">We emailed a 6-digit code to <strong>' . esc_html( preg_replace( '/(?<=.).(?=[^@]*?.@)/u', '•', $u->user_email ) ) . '</strong>. Enter it to finish signing in.</p>' . ( $err ? '<div id="login_error" class="notice notice-error">' . esc_html( $err ) . '</div>' : '' ) );
	?>
	<form name="usg2fa" id="loginform" method="post" action="<?php echo esc_url( add_query_arg( array( 'action' => 'usucger_2fa', 'c' => $key ), wp_login_url() ) ); ?>">
		<?php wp_nonce_field( 'usucger_2fa_' . $key ); ?>
		<p><label for="usgcode">Sign-in code</label>
		<input type="text" name="code" id="usgcode" class="input" inputmode="numeric" autocomplete="one-time-code" pattern="[0-9 ]{6,7}" maxlength="7" size="20" autofocus required style="font-size:24px;letter-spacing:.3em;text-align:center"></p>
		<p class="forgetmenot"><label><input name="trust" type="checkbox" value="1"> Trust this browser for 30 days</label></p>
		<p class="submit"><button type="submit" class="button button-primary button-large" id="wp-submit">Verify &amp; sign in</button></p>
	</form>
	<form method="post" action="<?php echo esc_url( add_query_arg( array( 'action' => 'usucger_2fa', 'c' => $key ), wp_login_url() ) ); ?>" style="margin-top:12px;padding:0;background:none;box-shadow:none;border:0">
		<?php wp_nonce_field( 'usucger_2fa_' . $key ); ?><input type="hidden" name="resend" value="1">
		<p style="text-align:center"><button type="submit" class="button-link">Email me a new code</button></p>
	</form>
	<?php
	login_footer( 'usgcode' );
	exit;
} );

add_filter( 'login_message', function ( $m ) {
	$s = isset( $_GET['usg2fa'] ) ? sanitize_key( $_GET['usg2fa'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	if ( 'expired' === $s ) {
		$m .= '<div id="login_error" class="notice notice-error">That sign-in code expired. Please sign in again.</div>';
	} elseif ( 'locked' === $s ) {
		$m .= '<div id="login_error" class="notice notice-error">Too many wrong codes. Please sign in again to get a new code (after 15 wrong codes, wait an hour or contact the webmaster).</div>';
	}
	return $m;
} );

/*
 * Membership, delegate and nominee identity follow the account email, so it must not be changed
 * without proof. WordPress's own profile screen already confirms a new address by email; the
 * WooCommerce "Account details" form does not, so changes there are refused.
 */
add_action( 'woocommerce_save_account_details_errors', function ( $errors, $user ) {
	$cur = get_userdata( $user->ID );
	if ( $cur && isset( $user->user_email ) && strtolower( $user->user_email ) !== strtolower( $cur->user_email ) ) {
		$errors->add( 'usucger_email', 'To change your email address, use <a href="' . esc_url( admin_url( 'profile.php' ) ) . '">your profile</a> — we send a confirmation link to the new address first.' );
	}
}, 10, 2 );
