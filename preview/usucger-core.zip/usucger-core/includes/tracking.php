<?php
/**
 * Privacy-friendly page-view counter: one row per page per day, no cookies, no IPs.
 * Skips logged-in editors, bots, previews, feeds and admin/AJAX requests.
 *
 * @package usucger-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'template_redirect', function () {
	if ( ! usucger_core_opt( 'track_views' ) || is_admin() || wp_doing_ajax() || is_feed() || is_preview() || is_404() || current_user_can( 'edit_posts' ) ) {
		return;
	}
	if ( 'GET' !== ( isset( $_SERVER['REQUEST_METHOD'] ) ? $_SERVER['REQUEST_METHOD'] : '' ) ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		return;
	}
	$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? strtolower( sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) ) : '';
	if ( '' === $ua || preg_match( '/bot|crawl|spider|slurp|preview|monitor|curl|wget|python|headless|facebookexternalhit|lighthouse/', $ua ) ) {
		return;
	}
	$path = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_parse_url( esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ), PHP_URL_PATH ) : '/';
	$home = (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH );
	if ( $home && 0 === strpos( $path, $home ) ) {
		$path = '/' . ltrim( substr( $path, strlen( $home ) ), '/' );
	}
	$path = substr( $path ? $path : '/', 0, 190 );
	usucger_count_view( $path );
}, 99 );

function usucger_count_view( $path, $day = null ) {
	global $wpdb;
	$t   = Usucger_DB::t( 'views' );
	$day = $day ? $day : usucger_today();
	$n   = $wpdb->query( $wpdb->prepare( "UPDATE $t SET views = views + 1 WHERE day = %s AND path = %s", $day, $path ) );
	if ( ! $n ) {
		$wpdb->insert( $t, array( 'day' => $day, 'path' => $path, 'views' => 1 ) );
	}
}

/** Top pages over the last N days. */
function usucger_top_pages( $days = 30, $limit = 15 ) {
	global $wpdb;
	$t = Usucger_DB::t( 'views' );
	return $wpdb->get_results( $wpdb->prepare( "SELECT path, SUM(views) v FROM $t WHERE day >= %s GROUP BY path ORDER BY v DESC LIMIT %d", gmdate( 'Y-m-d', strtotime( "-$days days" ) ), $limit ) );
}

/** Daily totals for the last N days (for the dashboard sparkline). */
function usucger_daily_views( $days = 30 ) {
	global $wpdb;
	$t    = Usucger_DB::t( 'views' );
	$rows = $wpdb->get_results( $wpdb->prepare( "SELECT day, SUM(views) v FROM $t WHERE day >= %s GROUP BY day ORDER BY day", gmdate( 'Y-m-d', strtotime( '-' . ( $days - 1 ) . ' days' ) ) ), OBJECT_K );
	$out  = array();
	for ( $i = $days - 1; $i >= 0; $i-- ) {
		$d         = gmdate( 'Y-m-d', strtotime( "-$i days" ) );
		$out[ $d ] = isset( $rows[ $d ] ) ? (int) $rows[ $d ]->v : 0;
	}
	return $out;
}

/* Keep 400 days of history. */
add_action( 'usucger_daily', function () {
	global $wpdb;
	$t = Usucger_DB::t( 'views' );
	$wpdb->query( $wpdb->prepare( "DELETE FROM $t WHERE day < %s", gmdate( 'Y-m-d', strtotime( '-400 days' ) ) ) );
} );
