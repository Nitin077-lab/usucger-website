<?php
/**
 * Key-email calendar: the emails USUCGER must send every year (travel-grant calls,
 * award nominations, annual meeting notice, …). Each item has a send date, an owner and a
 * template. A draft is created automatically a few days before the date and goes to the
 * approval queue; if it has not gone out by its date, the owner and the approvers are
 * reminded every two days until it is sent. Repeating items roll forward after sending.
 *
 * The calendar view also shows the election steps and the renewal-reminder plan, so the
 * webmaster sees every planned email in one list.
 *
 * @package usucger-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function usucger_cal_items() {
	$c = get_option( 'usucger_calendar', null );
	if ( null === $c ) {
		$c = usucger_cal_seed();
		update_option( 'usucger_calendar', $c, false );
	}
	return is_array( $c ) ? $c : array();
}

function usucger_cal_save( $items ) {
	update_option( 'usucger_calendar', $items, false );
}

/** Next date (today or later) for a month-day. */
function usucger_next_md( $md ) {
	$y = (int) wp_date( 'Y' );
	$d = $y . '-' . $md;
	return $d >= usucger_today() ? $d : ( $y + 1 ) . '-' . $md;
}

function usucger_cal_seed() {
	$items = array();
	$add   = function ( $key, $title, $md, $tpl, $group, $lead = 7, $repeat = 'yearly' ) use ( &$items ) {
		$items[ $key ] = array( 'title' => $title, 'due' => usucger_next_md( $md ), 'template' => $tpl, 'group' => $group, 'args' => array(), 'lead' => $lead, 'repeat' => $repeat, 'owner' => 0, 'batch' => 0, 'last_reminder' => '', 'history' => array(), 'active' => 1 );
	};
	$add( 'tg_call_fall', 'Student travel grants — call (Jan–Apr conferences)', '10-01', 'travel_grants', 'current' );
	$add( 'tg_remind_fall', 'Student travel grants — deadline in one week (Nov 15)', '11-08', 'travel_grant_reminder', 'current', 5 );
	$add( 'award_call', 'Award nominations — call', '11-01', 'award_call', 'current' );
	$add( 'award_remind', 'Award nominations — last call', '01-08', 'award_reminder', 'current', 5 );
	$add( 'annual_meeting', 'Annual business meeting notice (Geo-Congress)', '02-01', 'annual_meeting', 'current', 10 );
	$add( 'tg_call_spring', 'Student travel grants — call (May–Aug conferences)', '02-15', 'travel_grants', 'current' );
	$add( 'tg_remind_spring', 'Student travel grants — deadline in one week (Mar 15)', '03-08', 'travel_grant_reminder', 'current', 5 );
	$add( 'minutes_posted', 'Annual meeting minutes posted', '04-15', 'minutes_posted', 'current', 5 );
	return $items;
}

/** Status of a calendar item: upcoming | draft | awaiting | sending | sent | overdue | paused */
function usucger_cal_status( $it ) {
	if ( empty( $it['active'] ) ) {
		return 'paused';
	}
	$today = usucger_today();
	$b     = ! empty( $it['batch'] ) ? usucger_batch( $it['batch'] ) : null;
	if ( $b && in_array( $b->status, array( 'cancelled', 'rejected' ), true ) ) {
		$b = null; // treated as not drafted yet; the daily job prepares a fresh draft
	}
	if ( $b ) {
		if ( 'done' === $b->status ) {
			return 'sent';
		}
		if ( 'sending' === $b->status ) {
			return 'sending';
		}
		if ( $today > $it['due'] ) {
			return 'overdue';
		}
		return 'pending' === $b->status ? 'awaiting' : 'draft';
	}
	return $today > $it['due'] ? 'overdue' : 'upcoming';
}

function usucger_cal_create_draft( $key ) {
	$items = usucger_cal_items();
	if ( empty( $items[ $key ] ) ) {
		return 0;
	}
	$it   = $items[ $key ];
	$tpls = usucger_email_templates();
	$tpl  = isset( $tpls[ $it['template'] ] ) ? $tpls[ $it['template'] ] : array( 'kind' => 'news', 'subject' => $it['title'], 'body' => '<p>Dear {first_name},</p><p>[Write the message]</p>{signature}' );
	$id   = usucger_batch_save( array(
		'kind'         => $tpl['kind'],
		'group_key'    => $it['group'],
		'args'         => (array) $it['args'],
		'template_key' => $it['template'],
		'subject'      => $tpl['subject'],
		'body'         => $tpl['body'],
		'source'       => 'calendar:' . $key,
		'created_by'   => (int) $it['owner'],
		'status'       => 'draft',
	) );
	$items[ $key ]['batch'] = $id;
	usucger_cal_save( $items );
	$to = usucger_approver_emails();
	if ( $it['owner'] && get_userdata( $it['owner'] ) ) {
		$to[] = get_userdata( $it['owner'] )->user_email;
	}
	usucger_notify( array_unique( $to ), 'Due ' . usucger_fmt_date( $it['due'] ) . ': ' . $it['title'], '<p>The draft for <strong>' . esc_html( $it['title'] ) . '</strong> is ready. It should go out on <strong>' . esc_html( usucger_fmt_date( $it['due'], 'F j, Y' ) ) . '</strong>.</p><p>Check the dates and links in the text, then submit or approve it.</p><p><a href="' . esc_url( usucger_admin_url( 'usucger-compose', array( 'batch' => $id ) ) ) . '">Open the draft</a> · <a href="' . esc_url( usucger_desk_url() ) . '">Webmaster desk</a></p>' );
	Usucger_DB::log( 'calendar_draft', 'calendar:' . $key, 'batch ' . $id );
	return $id;
}

add_action( 'usucger_daily', function () {
	$items   = usucger_cal_items();
	$today   = usucger_today();
	$changed = false;
	foreach ( $items as $key => $it ) {
		if ( empty( $it['active'] ) ) {
			continue;
		}
		$status = usucger_cal_status( $it );
		// roll repeating items forward once sent
		if ( 'sent' === $status && 'none' !== $it['repeat'] && $today >= $it['due'] ) {
			$items[ $key ]['history'][] = array( $it['due'], $it['batch'] );
			$items[ $key ]['history']   = array_slice( $items[ $key ]['history'], -10 );
			$items[ $key ]['due']       = gmdate( 'Y-m-d', strtotime( $it['due'] . ( 'yearly' === $it['repeat'] ? ' +1 year' : ' +6 months' ) ) );
			$items[ $key ]['batch']     = 0;
			$items[ $key ]['last_reminder'] = '';
			$changed                    = true;
			continue;
		}
		if ( 'upcoming' === $status && $today >= gmdate( 'Y-m-d', strtotime( $it['due'] . ' -' . (int) $it['lead'] . ' days' ) ) ) {
			usucger_cal_save( $items );
			usucger_cal_create_draft( $key );
			$items = usucger_cal_items();
			continue;
		}
		if ( 'overdue' === $status && ( ! $it['last_reminder'] || usucger_days_between( $it['last_reminder'], $today ) >= 2 ) ) {
			$cb = ! empty( $it['batch'] ) ? usucger_batch( $it['batch'] ) : null;
			if ( ! $it['batch'] || ( $cb && in_array( $cb->status, array( 'cancelled', 'rejected' ), true ) ) ) {
				usucger_cal_save( $items );
				usucger_cal_create_draft( $key );
				$items = usucger_cal_items();
			}
			$to = usucger_approver_emails();
			if ( $it['owner'] && get_userdata( $it['owner'] ) ) {
				$to[] = get_userdata( $it['owner'] )->user_email;
			}
			$late = usucger_days_between( $it['due'], $today );
			usucger_notify( array_unique( $to ), 'Overdue (' . $late . ' day' . ( 1 === $late ? '' : 's' ) . '): ' . $it['title'], '<p><strong>' . esc_html( $it['title'] ) . '</strong> was due on ' . esc_html( usucger_fmt_date( $it['due'], 'F j, Y' ) ) . ' and has not been sent.</p><p><a href="' . esc_url( usucger_desk_url() ) . '">Open the webmaster desk</a> to approve it, or pause it in USUCGER → Email calendar if it is not needed this year.</p>' );
			$items[ $key ]['last_reminder'] = $today;
			$changed                        = true;
		}
	}
	if ( $changed ) {
		usucger_cal_save( $items );
	}
}, 25 );

/**
 * Every planned email in one list: calendar items + election steps + renewal plan.
 * Each row: source, key, title, date, status, batch, owner, edit link.
 */
function usucger_comm_rows() {
	$rows = array();
	foreach ( usucger_cal_items() as $k => $it ) {
		$rows[] = array( 'source' => 'Key email', 'key' => $k, 'title' => $it['title'], 'date' => $it['due'], 'status' => usucger_cal_status( $it ), 'batch' => (int) $it['batch'], 'owner' => (int) $it['owner'], 'repeat' => $it['repeat'] );
	}
	foreach ( usucger_elections( 5 ) as $row ) {
		$e = usucger_election( $row->id );
		if ( ! $e || 'active' !== $e->status ) {
			continue;
		}
		foreach ( usucger_election_steps( $e ) as $k => $s ) {
			$bid = isset( $e->settings['steps_done'][ $k ] ) ? (int) $e->settings['steps_done'][ $k ] : 0;
			$b   = $bid ? usucger_batch( $bid ) : null;
			$st  = $b ? ( 'done' === $b->status ? 'sent' : ( 'sending' === $b->status ? 'sending' : ( 'pending' === $b->status ? 'awaiting' : 'draft' ) ) ) : ( $s[0] < usucger_today() ? 'skipped' : 'upcoming' );
			$rows[] = array( 'source' => 'Election', 'key' => 'election:' . $e->id . ':' . $k, 'title' => $s[3], 'date' => $s[0], 'status' => $st, 'batch' => $bid, 'owner' => 0, 'repeat' => 'none' );
		}
	}
	foreach ( usucger_renewal_plan() as $i => $s ) {
		$b      = ! empty( $s['batch'] ) ? usucger_batch( $s['batch'] ) : null;
		$tpl    = usucger_email_templates();
		$st     = $b ? ( 'done' === $b->status ? 'sent' : ( 'sending' === $b->status ? 'sending' : ( 'pending' === $b->status ? 'awaiting' : 'draft' ) ) ) : 'upcoming';
		$rows[] = array( 'source' => 'Renewals', 'key' => 'renewal:' . $i, 'title' => isset( $tpl[ $s['template'] ] ) ? $tpl[ $s['template'] ]['name'] : $s['template'], 'date' => $s['date'], 'status' => $st, 'batch' => $b ? (int) $b->id : 0, 'owner' => 0, 'repeat' => 'none' );
	}
	usort( $rows, function ( $a, $b ) {
		return strcmp( $a['date'], $b['date'] );
	} );
	return $rows;
}

function usucger_cal_status_label( $s ) {
	$l = array( 'upcoming' => 'Upcoming', 'draft' => 'Draft ready', 'awaiting' => 'Waiting for approval', 'sending' => 'Sending', 'sent' => 'Sent', 'overdue' => 'Overdue', 'paused' => 'Paused', 'skipped' => 'Not created' );
	return isset( $l[ $s ] ) ? $l[ $s ] : $s;
}

/* Templates used by the calendar. */
add_action( 'init', function () {
	$have = usucger_email_templates();
	$add  = array(
		'travel_grant_reminder' => array( 'Travel grants — deadline in one week', 'news', 'One week left: USUCGER student travel grants', "<p>Dear {first_name},</p>\n<p>A reminder that applications for USUCGER student travel grants (up to \$1,000 per student) are due in one week. The advisor must be a current USUCGER member.</p>\n<p>Details and the online form: <a href=\"" . home_url( '/travel-grants/' ) . "\">travel grants page</a>. Please pass this on to your students.</p>\n{signature}" ),
		'award_call'            => array( 'Award nominations — call', 'news', 'Call for nominations: USUCGER Early Career Researcher Award and Distinguished Service Award', "<p>Dear Colleagues,</p>\n<p>The USUCGER Board is pleased to announce the call for nominations for two awards: the <strong>USUCGER Early Career Researcher Award</strong> and the <strong>USUCGER Distinguished Service Award</strong>. These will be awarded at {annual_meeting}. Please see the attachment for details. The deadline is <strong>{award_deadline}</strong>.</p>\n<p>We look forward to your nominations. Please contact us with any questions.</p>\n<p>Award descriptions and past recipients: <a href=\"" . home_url( '/awards/' ) . "\">awards page</a>.</p>\n{signature}" ),
		'award_reminder'        => array( 'Award nominations — last call', 'news', 'Last call: USUCGER award nominations due {award_deadline}', "<p>Dear Colleagues,</p>\n<p>A reminder that nominations for the USUCGER Early Career Researcher Award and Distinguished Service Award are due <strong>{award_deadline}</strong>. Details are in the original call and on the <a href=\"" . home_url( '/awards/' ) . "\">awards page</a>.</p>\n{signature}" ),
		'annual_meeting'        => array( 'Annual business meeting notice', 'official', 'USUCGER annual business meeting', "<p>Dear {first_name},</p>\n<p>The USUCGER annual business meeting will be held at Geo-Congress on <strong>[date, time, room]</strong>. The agenda is attached / linked here: [link].</p>\n<p>All members are welcome; delegates are especially encouraged to attend.</p>\n{signature}" ),
		'minutes_posted'        => array( 'Annual meeting minutes posted', 'news', 'Minutes of the USUCGER annual meeting are posted', "<p>Dear {first_name},</p>\n<p>The minutes of this year’s annual business meeting are now on the <a href=\"" . home_url( '/minutes/' ) . "\">minutes page</a>.</p>\n{signature}" ),
	);
	$changed = false;
	foreach ( $add as $k => $v ) {
		if ( ! isset( $have[ $k ] ) ) {
			$have[ $k ] = array( 'name' => $v[0], 'kind' => $v[1], 'subject' => $v[2], 'body' => $v[3] );
			$changed    = true;
		}
	}
	if ( $changed ) {
		update_option( 'usucger_templates', $have, false );
	}
}, 21 );


/* Award tags: {award_deadline} from the next "award" deadline; {annual_meeting} from Settings. */
add_filter( 'usucger_merge_tag_help', function ( $t ) {
	return $t + array(
		'{award_deadline}' => 'Next award-nomination deadline (from Deadlines)',
		'{annual_meeting}' => 'Where the annual meeting is (Settings)',
	);
} );
add_filter( 'usucger_merge_map', function ( $map, $c, $kind, $text ) {
	if ( false !== strpos( $text, '{award_deadline}' ) ) {
		$best = '';
		foreach ( usucger_items( 'usucger_deadline' ) as $d ) {
			if ( false !== stripos( $d['title'], 'award' ) && $d['date'] >= usucger_today() && ( ! $best || $d['date'] < $best ) ) {
				$best = $d['date'];
			}
		}
		$map['{award_deadline}'] = $best ? esc_html( usucger_fmt_date( $best, 'F j, Y' ) ) : '[add the award deadline under USUCGER → Deadlines]';
	}
	$map['{annual_meeting}'] = esc_html( usucger_core_opt( 'annual_meeting' ) );
	return $map;
}, 10, 4 );
