<?php
/**
 * One-time importer for the redesigned site (USUCGER → Setup & import).
 * Seed data ships in data/seed (generated from the static site repository).
 *
 *  • Pages: 22 pages with their header settings; data sections become shortcodes so
 *    they stay live. Existing pages with the same slug are skipped unless "replace" is
 *    chosen (WordPress keeps the old content under Revisions).
 *  • Content types: positions, conferences, Board, minutes, deadlines.
 *  • Members directory (331) and member universities (with states) → contacts/institutions.
 *  • Minutes and travel-grant PDFs → Media Library.
 *
 * @package usucger-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function usucger_seed_path( $f ) {
	return USUCGER_CORE_DIR . 'data/seed/' . $f;
}

function usucger_seed_json( $f ) {
	$p = usucger_seed_path( $f );
	return file_exists( $p ) ? json_decode( (string) file_get_contents( $p ), true ) : array();
}

function usucger_seed_lines( $f, $cols ) {
	$out = array();
	$p   = usucger_seed_path( $f );
	if ( ! file_exists( $p ) ) {
		return $out;
	}
	foreach ( file( $p, FILE_IGNORE_NEW_LINES ) as $line ) {
		if ( '' === trim( $line ) ) {
			continue;
		}
		$parts = array_map( 'trim', explode( '|', $line ) );
		$out[] = array_pad( array_slice( $parts, 0, $cols ), $cols, '' );
	}
	return $out;
}

/** Copy a seed file into the Media Library once; returns its URL. */
function usucger_seed_media( $name ) {
	$existing = get_posts( array( 'post_type' => 'attachment', 'post_status' => 'inherit', 'meta_key' => '_usucger_seed', 'meta_value' => $name, 'numberposts' => 1 ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
	if ( $existing ) {
		return wp_get_attachment_url( $existing[0]->ID );
	}
	$src = usucger_seed_path( 'files/' . $name );
	if ( ! file_exists( $src ) ) {
		return '';
	}
	$up = wp_upload_bits( $name, null, (string) file_get_contents( $src ) );
	if ( ! empty( $up['error'] ) ) {
		return '';
	}
	$ft  = wp_check_filetype( $up['file'] );
	$aid = wp_insert_attachment( array(
		'post_mime_type' => $ft['type'] ? $ft['type'] : 'application/pdf',
		'post_title'     => preg_replace( '/\.[^.]+$/', '', str_replace( array( '_', '-' ), ' ', $name ) ),
		'post_status'    => 'inherit',
	), $up['file'] );
	update_post_meta( $aid, '_usucger_seed', $name );
	return $up['url'];
}

/** Rewrite static links ("about.html#x", "assets/…") for WordPress. */
function usucger_rewrite_links( $html ) {
	$html = preg_replace_callback( '#(href|src)="assets/(?:minutes|travel-grants)/([^"]+)"#', function ( $m ) {
		$u = usucger_seed_media( rawurldecode( $m[2] ) );
		return $m[1] . '="' . esc_url( $u ? $u : '#' ) . '"';
	}, $html );
	$html = preg_replace_callback( '#href="([a-z0-9\-]+)\.html(\#[^"]*)?"#i', function ( $m ) {
		$slug = 'index' === $m[1] ? '' : $m[1];
		$url  = '' === $slug ? home_url( '/' ) : home_url( '/' . $slug . '/' );
		return 'href="' . esc_url( $url . ( isset( $m[2] ) ? $m[2] : '' ) ) . '"';
	}, $html );
	return str_replace( 'https://usucger.org/my-account/', esc_url( usucger_core_url( 'login' ) ), $html );
}

/** Static page body → blocks (Custom HTML + Shortcode blocks). */
function usucger_body_to_blocks( $body ) {
	$parts = preg_split( '#\s*<!--usg-sc:(.*?)-->\s*#s', $body, -1, PREG_SPLIT_DELIM_CAPTURE );
	$out   = '';
	foreach ( $parts as $i => $part ) {
		if ( 1 === $i % 2 ) {
			$out .= "<!-- wp:shortcode -->\n" . trim( $part ) . "\n<!-- /wp:shortcode -->\n\n";
		} elseif ( '' !== trim( $part ) ) {
			$out .= "<!-- wp:html -->\n" . trim( usucger_rewrite_links( $part ) ) . "\n<!-- /wp:html -->\n\n";
		}
	}
	return trim( $out );
}

function usucger_import_pages( $mode = 'skip' ) {
	$manifest = usucger_seed_json( 'pages.json' );
	$log      = array( 'created' => 0, 'replaced' => 0, 'skipped' => array() );
	$order    = 0;
	foreach ( $manifest as $file => $meta ) {
		$order++;
		$slug  = preg_replace( '/\.html$/', '', $file );
		$slug  = 'index' === $slug ? 'home' : $slug;
		$title = 'home' === $slug ? 'Home' : wp_strip_all_tags( html_entity_decode( isset( $meta['h1'] ) ? $meta['h1'] : preg_replace( '/\s+—\s+USUCGER$/u', '', $meta['title'] ), ENT_QUOTES, 'UTF-8' ) );
		$body  = usucger_body_to_blocks( (string) file_get_contents( usucger_seed_path( 'pages/' . $file ) ) );
		$hero  = array(
			'eyebrow'     => isset( $meta['eyebrow'] ) ? $meta['eyebrow'] : '',
			'h1'          => isset( $meta['h1'] ) ? $meta['h1'] : '',
			'lead'        => isset( $meta['lead'] ) ? usucger_rewrite_links( $meta['lead'] ) : '',
			'crumbs'      => isset( $meta['crumbs'] ) ? array_map( function ( $c ) {
				return array( $c[0], $c[1] ? preg_replace( '/\.html$/', '', $c[1] ) : null );
			}, $meta['crumbs'] ) : array(),
			'actions'     => isset( $meta['actions'] ) ? array_map( function ( $a ) {
				return array( $a[0], preg_replace( '/\.html(#|$)/', '$1', $a[1] ), $a[2] );
			}, $meta['actions'] ) : array(),
			'description' => html_entity_decode( $meta['description'], ENT_QUOTES, 'UTF-8' ),
			'no_hero'     => 'home' === $slug,
		);
		if ( isset( $meta['cta'] ) ) {
			$hero['cta'] = (bool) $meta['cta'];
		}
		foreach ( array( 'cta_heading', 'cta_sub' ) as $k ) {
			if ( isset( $meta[ $k ] ) ) {
				$hero[ $k ] = $meta[ $k ];
			}
		}
		$existing = get_page_by_path( $slug, OBJECT, 'page' );
		if ( $existing && 'replace' !== $mode ) {
			$log['skipped'][] = $slug;
			continue;
		}
		$arr = array(
			'post_type'    => 'page',
			'post_status'  => 'publish',
			'post_title'   => $title,
			'post_name'    => $slug,
			'post_content' => $body,
			'menu_order'   => $order,
		);
		if ( $existing ) {
			delete_post_meta( $existing->ID, '_et_pb_use_builder' ); // the old Divi layout is kept in Revisions
			delete_post_meta( $existing->ID, '_usucger_retired' );
			$arr['ID'] = $existing->ID;
			$id        = wp_update_post( wp_slash( $arr ) );
			$log['replaced']++;
		} else {
			$id = wp_insert_post( wp_slash( $arr ) );
			$log['created']++;
		}
		if ( $id && ! is_wp_error( $id ) ) {
			update_post_meta( $id, '_usucger_hero', $hero );
			update_post_meta( $id, '_usucger_raw', 1 );
			if ( 'home' === $slug ) {
				update_option( 'show_on_front', 'page' );
				update_option( 'page_on_front', $id );
			}
		}
	}
	return $log;
}

function usucger_import_cpts( $replace = false ) {
	$log  = array();
	$make = function ( $pt, $title, $meta, $order = 0, $date = '' ) {
		$id = wp_insert_post( wp_slash( array( 'post_type' => $pt, 'post_status' => 'publish', 'post_title' => $title, 'menu_order' => $order ) ) );
		foreach ( $meta as $k => $v ) {
			update_post_meta( $id, $k, $v );
		}
		update_post_meta( $id, '_usucger_seed', 1 );
		return $id;
	};
	foreach ( array_keys( usucger_cpt_defs() ) as $pt ) {
		$have = get_posts( array( 'post_type' => $pt, 'post_status' => 'any', 'numberposts' => -1, 'fields' => 'ids' ) );
		if ( $have && ! $replace ) {
			$log[ $pt ] = 'kept ' . count( $have ) . ' existing';
			continue;
		}
		foreach ( $have as $hid ) {
			wp_delete_post( $hid, true );
		}
		$n = 0;
		switch ( $pt ) {
			case 'usucger_position':
				$pos = usucger_seed_json( 'positions.json' );
				foreach ( array( 'academic', 'industry' ) as $kind ) {
					foreach ( isset( $pos[ $kind ] ) ? $pos[ $kind ] : array() as $p ) {
						$make( $pt, $p['title'], array( 'institution' => $p['institution'], 'location' => isset( $p['location'] ) ? $p['location'] : '', 'url' => $p['url'], 'kind' => $kind, 'posted' => $p['posted'], 'closes' => '' ) );
						$n++;
					}
				}
				break;
			case 'usucger_conference':
				foreach ( usucger_seed_json( 'conferences.json' ) as $c ) {
					$make( $pt, html_entity_decode( $c['name'], ENT_QUOTES, 'UTF-8' ), array( 'start' => $c['start'], 'end' => isset( $c['end'] ) ? $c['end'] : '', 'year_only' => empty( $c['year_only'] ) ? '' : '1', 'location' => html_entity_decode( $c['location'], ENT_QUOTES, 'UTF-8' ), 'url' => $c['url'], 'note' => isset( $c['note'] ) ? html_entity_decode( $c['note'], ENT_QUOTES, 'UTF-8' ) : '' ) );
					$n++;
				}
				break;
			case 'usucger_board':
				$i = 0;
				foreach ( usucger_seed_json( 'board.json' ) as $b ) {
					$make( $pt, $b['name'], array( 'role' => $b['role'], 'seat' => $b['seat'], 'inst' => $b['inst'], 'term' => $b['term'], 'photo' => $b['photo'], 'officer' => in_array( $b['role'], array( 'President', 'Secretary', 'Membership Coordinator', 'Webmaster' ), true ) ? '1' : '' ), ++$i );
					$n++;
				}
				break;
			case 'usucger_minutes':
				foreach ( usucger_seed_json( 'minutes.json' ) as $m ) {
					$url = $m['url'];
					if ( 0 === strpos( $url, 'assets/minutes/' ) ) {
						$url = usucger_seed_media( substr( $url, strlen( 'assets/minutes/' ) ) );
					}
					$make( $pt, usucger_fmt_date( $m['date'], 'F j, Y' ) . ' — ' . $m['kind'], array( 'date' => $m['date'], 'date_text' => $m['date_text'], 'kind' => $m['kind'], 'file' => $url, 'label' => $m['label'], 'general' => $m['general'] ? '1' : '' ) );
					$n++;
				}
				break;
			case 'usucger_deadline':
				foreach ( usucger_seed_json( 'deadlines.json' ) as $d ) {
					$make( $pt, $d['label'], array( 'date' => $d['date'], 'href' => preg_replace( '/\.html(#|$)/', '$1', $d['href'] ), 'detail' => $d['detail'], 'closed' => $d['closed'] ) );
					$n++;
				}
				break;
		}
		$log[ $pt ] = $n;
	}
	return $log;
}

function usucger_import_people( $replace = false ) {
	global $wpdb;
	$ct  = Usucger_DB::t( 'contacts' );
	$it  = Usucger_DB::t( 'institutions' );
	$log = array();
	if ( $replace ) {
		$wpdb->query( "DELETE FROM $ct WHERE source = 'import'" ); // phpcs:ignore WordPress.DB
		$wpdb->query( "DELETE FROM $it" ); // phpcs:ignore WordPress.DB
	}
	if ( ! (int) $wpdb->get_var( "SELECT COUNT(*) FROM $ct WHERE source = 'import'" ) ) { // phpcs:ignore WordPress.DB
		$now = current_time( 'mysql' );
		$n   = 0;
		foreach ( usucger_seed_lines( 'members.txt', 3 ) as $m ) {
			$wpdb->insert( $ct, array(
				'first_name'   => $m[0],
				'last_name'    => $m[1],
				'institution'  => $m[2],
				'source'       => 'import',
				'status'       => 'current',
				'category'     => '',
				'end_date'     => usucger_core_opt( 'cycle_end' ) ? usucger_core_opt( 'cycle_end' ) : null,
				'in_directory' => 1,
				'token'        => usucger_token(),
				'created'      => $now,
				'updated'      => $now,
			) );
			$n++;
		}
		$log['contacts'] = $n;
	} else {
		$log['contacts'] = 'kept existing';
	}
	if ( ! (int) $wpdb->get_var( "SELECT COUNT(*) FROM $it" ) ) { // phpcs:ignore WordPress.DB
		$states = array();
		foreach ( usucger_seed_lines( 'university_states.txt', 2 ) as $s ) {
			$states[ $s[0] ] = $s[1];
		}
		$n = 0;
		foreach ( usucger_seed_lines( 'universities.txt', 2 ) as $u ) {
			$wpdb->insert( $it, array( 'name' => $u[0], 'contact_name' => $u[1], 'state' => isset( $states[ $u[0] ] ) ? $states[ $u[0] ] : '', 'status' => 'member', 'updated' => current_time( 'mysql' ) ) );
			$n++;
		}
		$log['institutions'] = $n;
	} else {
		$log['institutions'] = 'kept existing';
	}
	return $log;
}

/** Run everything. $opts: pages => skip|replace, data_replace => bool */
function usucger_import_all( $opts = array() ) {
	$opts = wp_parse_args( $opts, array( 'pages' => 'skip', 'data_replace' => false, 'retire' => false ) );
	if ( function_exists( 'set_time_limit' ) ) {
		@set_time_limit( 300 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
	}
	kses_remove_filters();
	$res = array(
		'people'     => usucger_import_people( $opts['data_replace'] ),
		'cpts'       => usucger_import_cpts( $opts['data_replace'] ),
		'recipients' => usucger_import_recipients( $opts['data_replace'] ),
		'pages'  => usucger_import_pages( $opts['pages'] ),
	);
	usucger_ensure_system_pages();
	if ( $opts['retire'] ) {
		$res['retired'] = usucger_retire_divi_pages();
	}
	kses_init();
	update_option( 'usucger_imported', array( 'time' => current_time( 'mysql' ), 'result' => $res ), false );
	usucger_bump_content_version();
	delete_transient( 'usucger_map_data' );
	Usucger_DB::log( 'import', '', $res );
	return $res;
}

/** Member area, elections and webmaster desk pages (created once, never overwritten). */
function usucger_ensure_system_pages() {
	$pages = array(
		'members'   => array( 'Member Area', '[usucger_portal]', array( 'eyebrow' => 'Members', 'h1' => 'Member area', 'lead' => 'Your membership, your profile, colleagues by expertise, who is going where — and your institution’s ballot at election time.', 'crumbs' => array( array( 'Members', 'membership' ), array( 'Member area', null ) ), 'cta' => false ) ),
		'elections' => array( 'Elections', '[usucger_election]', array( 'eyebrow' => 'Governance', 'h1' => 'Board elections', 'lead' => 'Each year members elect one junior and one senior director. Member institutions vote through their delegates — one ballot per institution (By-Laws Art. III and VI).', 'crumbs' => array( array( 'About', 'about' ), array( 'Elections', null ) ), 'actions' => array( array( 'Read the By-Laws &rarr;', 'bylaws#article-vi', 'btn-ghost' ) ), 'cta' => false ) ),
		'webmaster' => array( 'Webmaster Desk', '[usucger_webmaster]', array( 'no_hero' => true, 'cta' => false ) ),
		'post-a-position'          => array( 'Post a Position', '[usucger_submit_position]', array( 'eyebrow' => 'Positions', 'h1' => 'Post a position', 'lead' => 'Faculty, postdoctoral, industry and agency openings in geotechnical engineering. Listings are free for member institutions and reviewed before they go live.', 'crumbs' => array( array( 'Positions', 'positions' ), array( 'Post a position', null ) ), 'cta' => false ) ),
		'nominate'                 => array( 'Award Nomination', '[usucger_award_nomination]', array( 'eyebrow' => 'Awards', 'h1' => 'Nominate a colleague', 'lead' => 'Nominations go to the USUCGER Board. Upload the nomination letter as a PDF, with the nominee’s CV if you have it; up to three support letters are welcome. Fields are required unless marked optional.', 'crumbs' => array( array( 'Awards', 'awards' ), array( 'Nominate', null ) ), 'cta' => false ) ),
		'travel-grant-application' => array( 'Travel Grant Application', '[usucger_travel_grant_apply]', array( 'eyebrow' => 'Students', 'h1' => 'Student travel grant application', 'lead' => 'For students whose advisor is a current USUCGER member. Applications are reviewed by the Board after the deadline.', 'crumbs' => array( array( 'Travel grants', 'travel-grants' ), array( 'Apply', null ) ), 'cta' => false ) ),
		'privacy'                  => array( 'Privacy', '[usucger_privacy]', array( 'eyebrow' => 'About', 'h1' => 'Privacy', 'lead' => 'What this website keeps about you, why, and how to get a copy or have it removed.', 'crumbs' => array( array( 'About', 'about' ), array( 'Privacy', null ) ), 'cta' => false ) ),
	);
	foreach ( $pages as $slug => $p ) {
		if ( get_page_by_path( $slug ) ) {
			continue;
		}
		$id = wp_insert_post( array(
			'post_type'    => 'page',
			'post_status'  => 'publish',
			'post_title'   => $p[0],
			'post_name'    => $slug,
			'post_content' => "<!-- wp:shortcode -->\n" . $p[1] . "\n<!-- /wp:shortcode -->",
		) );
		if ( $id && ! is_wp_error( $id ) ) {
			update_post_meta( $id, '_usucger_hero', $p[2] );
			update_post_meta( $id, '_usucger_raw', 1 );
		}
	}
	$priv = get_page_by_path( 'privacy' );
	if ( $priv && 'publish' !== get_post_status( (int) get_option( 'wp_page_for_privacy_policy' ) ) ) { // WordPress's sample page is a draft
		update_option( 'wp_page_for_privacy_policy', $priv->ID );
	}
	update_option( 'usucger_system_pages', USUCGER_CORE_VER, false );
}

add_action( 'init', function () {
	if ( get_option( 'usucger_system_pages' ) !== USUCGER_CORE_VER && get_option( 'usucger_imported' ) ) {
		usucger_ensure_system_pages();
	}
}, 30 );

/**
 * After the new pages exist, the old Divi-built pages would show raw [et_pb_…] code under the
 * new theme. WooCommerce/Memberships system pages (cart, checkout, my account, shop, content
 * restricted) keep their address and just lose the Divi wrapper; every other Divi page that the
 * import did not replace is moved to Draft (kept, restorable), so its old address 404s and the
 * redirect list sends visitors to the new page.
 */
function usucger_retire_divi_pages() {
	$system = array();
	if ( function_exists( 'wc_get_page_id' ) ) {
		foreach ( array( 'cart', 'checkout', 'myaccount', 'shop', 'terms' ) as $k ) {
			if ( wc_get_page_id( $k ) > 0 ) {
				$system[] = (int) wc_get_page_id( $k );
			}
		}
	}
	$log = array( 'cleaned' => array(), 'drafted' => array() );
	foreach ( get_posts( array( 'post_type' => 'page', 'post_status' => array( 'publish', 'private' ), 'posts_per_page' => -1 ) ) as $p ) {
		if ( false === strpos( $p->post_content, '[et_pb_' ) || get_post_meta( $p->ID, '_usucger_hero', true ) ) {
			continue; // not Divi, or one of ours
		}
		$is_system = in_array( (int) $p->ID, $system, true ) || preg_match( '/\[(woocommerce_|wcm_)/', $p->post_content );
		if ( $is_system ) {
			$clean = trim( preg_replace( '/\[\/?et_pb_[^\]]*\]/', '', $p->post_content ) );
			wp_update_post( wp_slash( array( 'ID' => $p->ID, 'post_content' => $clean ) ) );
			delete_post_meta( $p->ID, '_et_pb_use_builder' );
			$log['cleaned'][] = $p->post_name;
		} elseif ( (int) get_option( 'page_on_front' ) !== (int) $p->ID ) {
			wp_update_post( array( 'ID' => $p->ID, 'post_status' => 'draft' ) );
			update_post_meta( $p->ID, '_usucger_retired', 1 );
			$log['drafted'][] = $p->post_name;
		}
	}
	Usucger_DB::log( 'divi_pages_retired', '', $log );
	return $log;
}

/** Undo: publish the old Divi pages again (e.g. when rolling back to Divi). */
function usucger_restore_divi_pages() {
	$n = 0;
	foreach ( get_posts( array( 'post_type' => 'page', 'post_status' => 'draft', 'posts_per_page' => -1, 'meta_key' => '_usucger_retired', 'meta_value' => 1 ) ) as $p ) { // phpcs:ignore WordPress.DB.SlowDBQuery
		wp_update_post( array( 'ID' => $p->ID, 'post_status' => 'publish' ) );
		delete_post_meta( $p->ID, '_usucger_retired' );
		$n++;
	}
	return $n;
}
