<?php
/**
 * Shared helpers.
 *
 * @package usucger-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function usucger_today() {
	return wp_date( 'Y-m-d' );
}

/** "Jan 5, 2026" */
function usucger_fmt_date( $iso, $format = 'M j, Y' ) {
	if ( ! $iso ) {
		return '';
	}
	$ts = strtotime( $iso . ' 12:00:00' );
	return $ts ? wp_date( $format, $ts, new DateTimeZone( 'UTC' ) ) : esc_html( $iso );
}

function usucger_days_between( $from, $to ) {
	return (int) floor( ( strtotime( $to . ' 12:00:00' ) - strtotime( $from . ' 12:00:00' ) ) / DAY_IN_SECONDS );
}

function usucger_initials( $name ) {
	$parts = preg_split( '/[\s\-]+/u', trim( $name ), -1, PREG_SPLIT_NO_EMPTY );
	if ( count( $parts ) > 1 ) {
		return mb_strtoupper( mb_substr( $parts[0], 0, 1 ) . mb_substr( end( $parts ), 0, 1 ) );
	}
	return mb_strtoupper( mb_substr( isset( $parts[0] ) ? $parts[0] : '?', 0, 2 ) );
}

function usucger_token() {
	return wp_generate_password( 32, false, false );
}

/** Lower-case, punctuation-free key for matching institution names. */
function usucger_norm( $s ) {
	$s = mb_strtolower( str_replace( '&', 'and', (string) $s ) );
	$s = preg_replace( '/[–—\-,\/()]/u', ' ', $s );
	$s = preg_replace( '/\b(the|at)\b/u', ' ', $s );
	return trim( preg_replace( '/\s+/u', ' ', $s ) );
}

/** Users who approve content and email (administrators + anyone with usucger_approve). */
function usucger_approver_emails() {
	$list = array_filter( array_map( 'trim', explode( ',', (string) usucger_core_opt( 'notify_emails' ) ) ), 'is_email' );
	if ( $list ) {
		return $list;
	}
	$emails = array();
	foreach ( get_users( array( 'capability' => 'usucger_approve', 'fields' => array( 'user_email' ) ) ) as $u ) {
		$emails[] = $u->user_email;
	}
	foreach ( (array) usucger_core_opt( 'approvers' ) as $uid ) { // President / co-approvers (granted at runtime)
		$u = get_userdata( (int) $uid );
		if ( $u ) {
			$emails[] = $u->user_email;
		}
	}
	$emails = array_values( array_unique( $emails ) );
	return $emails ? $emails : array( get_option( 'admin_email' ) );
}

function usucger_can_approve() {
	return is_user_logged_in() && ( current_user_can( 'usucger_approve' ) || current_user_can( 'manage_options' ) );
}

/** Label for the approver ("Webmaster", "President", …) used on the desk and in the log. */
function usucger_approver_label( $uid = 0 ) {
	$uid = $uid ? (int) $uid : get_current_user_id();
	if ( user_can( $uid, 'manage_options' ) ) {
		return 'Webmaster';
	}
	if ( in_array( $uid, array_map( 'intval', (array) usucger_core_opt( 'approvers' ) ), true ) ) {
		$titles = (array) usucger_core_opt( 'approver_titles' );
		return ! empty( $titles[ $uid ] ) ? $titles[ $uid ] : 'President';
	}
	return '';
}

function usucger_admin_url( $page, $args = array() ) {
	return add_query_arg( array_merge( array( 'page' => $page ), $args ), admin_url( 'admin.php' ) );
}

/** Redirect back with a notice code (shown by usucger_admin_notice()). */
function usucger_back( $url, $msg = '', $type = 'success' ) {
	if ( $msg ) {
		set_transient( 'usucger_notice_' . get_current_user_id(), array( $msg, $type ), 60 );
	}
	wp_safe_redirect( $url );
	exit;
}

function usucger_check( $action, $cap ) {
	if ( ! current_user_can( $cap ) ) {
		wp_die( esc_html__( 'You do not have permission to do that.', 'usucger' ), 403 );
	}
	check_admin_referer( $action );
}

/* ------------------------------------------------------------ meta fields */

/**
 * Tiny meta-field framework used by the content types.
 * $fields: key => [ label, type (text|date|url|select|checkbox|textarea|media|number), options/help ]
 */
function usucger_fields_box( $post, $fields, $nonce ) {
	wp_nonce_field( $nonce, $nonce . '_nonce' );
	echo '<table class="form-table usg-fields" role="presentation"><tbody>';
	foreach ( $fields as $key => $f ) {
		$type  = $f[1];
		$val   = get_post_meta( $post->ID, $key, true );
		$id    = 'usg_' . sanitize_key( $key );
		$help  = isset( $f['help'] ) ? '<p class="description">' . wp_kses_post( $f['help'] ) . '</p>' : '';
		echo '<tr><th scope="row"><label for="' . esc_attr( $id ) . '">' . esc_html( $f[0] ) . '</label></th><td>';
		switch ( $type ) {
			case 'select':
				echo '<select id="' . esc_attr( $id ) . '" name="usg_meta[' . esc_attr( $key ) . ']">';
				foreach ( $f[2] as $ov => $ol ) {
					echo '<option value="' . esc_attr( $ov ) . '"' . selected( $val, $ov, false ) . '>' . esc_html( $ol ) . '</option>';
				}
				echo '</select>';
				break;
			case 'checkbox':
				echo '<label><input type="checkbox" id="' . esc_attr( $id ) . '" name="usg_meta[' . esc_attr( $key ) . ']" value="1"' . checked( $val, '1', false ) . '> ' . esc_html( isset( $f[2] ) ? $f[2] : '' ) . '</label>';
				break;
			case 'checks':
				$sel = array_filter( array_map( 'trim', explode( ',', (string) $val ) ) );
				foreach ( $f[2] as $ov => $ol ) {
					echo '<label style="display:block"><input type="checkbox" name="usg_meta[' . esc_attr( $key ) . '][]" value="' . esc_attr( $ov ) . '"' . checked( in_array( (string) $ov, $sel, true ), true, false ) . '> ' . esc_html( $ol ) . '</label>';
				}
				break;
			case 'textarea':
				echo '<textarea class="large-text" rows="3" id="' . esc_attr( $id ) . '" name="usg_meta[' . esc_attr( $key ) . ']">' . esc_textarea( $val ) . '</textarea>';
				break;
			case 'media':
				echo '<input type="url" class="regular-text usg-media-url" id="' . esc_attr( $id ) . '" name="usg_meta[' . esc_attr( $key ) . ']" value="' . esc_attr( $val ) . '"> <button type="button" class="button usg-media-pick" data-target="' . esc_attr( $id ) . '">' . esc_html__( 'Choose / upload file', 'usucger' ) . '</button>';
				break;
			default:
				$html_type = in_array( $type, array( 'date', 'url', 'number', 'email' ), true ) ? $type : 'text';
				echo '<input type="' . esc_attr( $html_type ) . '" class="regular-text" id="' . esc_attr( $id ) . '" name="usg_meta[' . esc_attr( $key ) . ']" value="' . esc_attr( $val ) . '"' . ( ! empty( $f['required'] ) ? ' required' : '' ) . '>';
		}
		echo $help . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}
	echo '</tbody></table>';
}

function usucger_fields_save( $post_id, $fields, $nonce ) {
	if ( ! isset( $_POST[ $nonce . '_nonce' ] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST[ $nonce . '_nonce' ] ) ), $nonce ) ) {
		return;
	}
	if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	$in = isset( $_POST['usg_meta'] ) ? (array) wp_unslash( $_POST['usg_meta'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	foreach ( $fields as $key => $f ) {
		$v = isset( $in[ $key ] ) ? $in[ $key ] : '';
		switch ( $f[1] ) {
			case 'url':
			case 'media':
				$v = esc_url_raw( trim( $v ) );
				break;
			case 'date':
				$v = preg_match( '/^\d{4}-\d{2}-\d{2}$/', $v ) ? $v : '';
				break;
			case 'checkbox':
				$v = $v ? '1' : '';
				break;
			case 'checks':
				$v = implode( ',', array_values( array_intersect( array_map( 'strval', (array) $v ), array_map( 'strval', array_keys( $f[2] ) ) ) ) );
				break;
			case 'number':
				$v = '' === $v ? '' : (string) intval( $v );
				break;
			case 'select':
				$v = isset( $f[2][ $v ] ) ? $v : key( $f[2] );
				break;
			case 'textarea':
				$v = wp_kses_post( $v );
				break;
			default:
				$v = wp_kses( $v, array( 'em' => array(), 'strong' => array(), 'br' => array() ) );
		}
		update_post_meta( $post_id, $key, $v );
	}
}

add_action( 'admin_enqueue_scripts', function () {
	$screen = get_current_screen();
	if ( ! $screen || 0 !== strpos( (string) $screen->post_type, 'usucger_' ) ) {
		return;
	}
	wp_enqueue_media();
	wp_add_inline_script( 'jquery-core', "jQuery(function($){\$(document).on('click','.usg-media-pick',function(e){e.preventDefault();var t=\$('#'+\$(this).data('target'));var f=wp.media({title:'Choose a file',multiple:false});f.on('select',function(){t.val(f.state().get('selection').first().toJSON().url)});f.open();});});" );
} );

/** Stop spreadsheet formula injection from form input (=, +, -, @ at the start). */
function usucger_csv_safe( $v ) {
	$v = (string) $v;
	return '' !== $v && in_array( $v[0], array( '=', '+', '-', '@', "\t", "\r" ), true ) ? "'" . $v : $v;
}

/**
 * Status messages passed through a redirect are signed, so a crafted link cannot make the
 * site display text of someone else's choosing.
 */
function usucger_flash_arg( $key, $msg ) {
	$msg = sanitize_text_field( (string) $msg );
	return array( $key => rawurlencode( $msg ), $key . '_s' => substr( hash_hmac( 'sha256', $key . '|' . $msg, wp_salt( 'nonce' ) ), 0, 12 ) );
}

function usucger_flash_read( $key ) {
	if ( ! isset( $_GET[ $key ], $_GET[ $key . '_s' ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		return '';
	}
	$msg = sanitize_text_field( wp_unslash( $_GET[ $key ] ) ); // phpcs:ignore WordPress.Security.NonceVerification
	$sig = substr( hash_hmac( 'sha256', $key . '|' . $msg, wp_salt( 'nonce' ) ), 0, 12 );
	return hash_equals( $sig, sanitize_text_field( wp_unslash( $_GET[ $key . '_s' ] ) ) ) ? $msg : ''; // phpcs:ignore WordPress.Security.NonceVerification
}

/** "3 hours ago" for a post, robust to drafts whose GMT dates are empty. */
function usucger_post_ago( $p ) {
	$t = ( $p->post_modified_gmt && '0000-00-00 00:00:00' !== $p->post_modified_gmt ) ? strtotime( $p->post_modified_gmt . ' UTC' ) : get_post_modified_time( 'U', true, $p );
	return $t ? human_time_diff( $t ) . ' ago' : '';
}

/** Who made a post: the author, or the public-form submitter. */
function usucger_post_by( $p ) {
	$au = $p->post_author ? get_userdata( $p->post_author ) : null;
	if ( $au ) {
		return $au->display_name;
	}
	$sub = (string) get_post_meta( $p->ID, '_submitter', true );
	return $sub ? trim( preg_replace( '/<[^>]*>/', '', $sub ) ) . ' (public form)' : 'public form';
}

function usucger_n( $n, $one, $many ) {
	return (int) $n . ' ' . ( 1 === (int) $n ? $one : $many );
}
