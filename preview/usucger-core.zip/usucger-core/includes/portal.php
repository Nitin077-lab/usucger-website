<?php
/**
 * Member area: [usucger_portal] on the "members" page.
 * Tabs: Home · My profile · Find an expert · Where I'll be · Elections · Membership
 *
 * @package usucger-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function usucger_portal_url( $tab = '' ) {
	$p   = get_page_by_path( 'members' );
	$url = $p ? get_permalink( $p ) : home_url( '/members/' );
	return $tab ? add_query_arg( 'tab', $tab, $url ) : $url;
}

add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style( 'usucger-portal', USUCGER_CORE_URL . 'assets/portal.css', array(), USUCGER_CORE_VER . '-' . substr( md5_file( USUCGER_CORE_DIR . 'assets/portal.css' ), 0, 6 ) );
}, 20 );

/* Members-only pages: keep them out of search engines. */
add_action( 'wp_head', function () {
	if ( is_page( array( 'members', 'webmaster' ) ) || isset( $_GET['usg_ballot'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		echo '<meta name="robots" content="noindex,nofollow">' . "\n";
	}
}, 2 );

function usucger_portal_tabs() {
	$tabs = array(
		'home'       => 'Home',
		'profile'    => 'My profile',
		'experts'    => 'Find an expert',
		'events'     => 'Where I’ll be',
		'vote'       => 'Elections',
		'membership' => 'Membership',
	);
	if ( function_exists( 'usucger_desk_kind' ) && usucger_desk_kind() ) {
		$tabs = array( 'desk' => usucger_desk_label() ) + $tabs; // Board / President / Webmaster dashboard first
	}
	return apply_filters( 'usucger_portal_tabs', $tabs );
}

function usucger_initial_badge( $p, $cls = 'usg-av' ) {
	if ( $p->photo ) {
		return '<img class="' . esc_attr( $cls ) . '" src="' . esc_url( $p->photo ) . '" alt="">';
	}
	return '<span class="' . esc_attr( $cls ) . ' usg-av-i" aria-hidden="true">' . esc_html( usucger_initials( $p->name ) ) . '</span>';
}

function usucger_chip_list( $tags, $link = true ) {
	$o = '';
	foreach ( $tags as $t ) {
		$o .= $link ? '<a class="usg-chip" href="' . esc_url( add_query_arg( array( 'tab' => 'experts', 'tag' => $t ), usucger_portal_url() ) ) . '">' . esc_html( $t ) . '</a>' : '<span class="usg-chip">' . esc_html( $t ) . '</span>';
	}
	return $o;
}

add_shortcode( 'usucger_portal', function () {
	if ( ! is_user_logged_in() ) {
		return usucger_portal_login();
	}
	$tabs = usucger_portal_tabs();
	$tab  = isset( $_GET['tab'] ) && isset( $tabs[ $_GET['tab'] ] ) ? sanitize_key( $_GET['tab'] ) : ( isset( $tabs['desk'] ) ? 'desk' : 'home' ); // phpcs:ignore WordPress.Security.NonceVerification
	$me   = usucger_profile( get_current_user_id() );
	$nav  = '<nav class="usg-tabs" aria-label="Member area">';
	foreach ( $tabs as $k => $label ) {
		$badge = '';
		if ( 'vote' === $k && function_exists( 'usucger_my_ballot' ) ) {
			$b = usucger_my_ballot();
			if ( $b && ! $b->voter->voted_at && 'voting' === $b->phase ) {
				$badge = ' <span class="usg-dot" title="Your ballot is open"></span>';
			}
		}
		$nav .= '<a class="usg-tab' . ( $k === $tab ? ' on' : '' ) . '" href="' . esc_url( add_query_arg( 'tab', $k, usucger_portal_url() ) ) . '">' . esc_html( $label ) . $badge . '</a>';
	}
	$nav .= '<a class="usg-tab usg-tab-out" href="' . esc_url( wp_logout_url( home_url( '/' ) ) ) . '">Sign out</a></nav>';
	switch ( $tab ) {
		case 'profile':
			$body = usucger_portal_profile( $me );
			break;
		case 'experts':
			$body = usucger_portal_experts();
			break;
		case 'events':
			$body = usucger_portal_events( $me );
			break;
		case 'vote':
			$body = function_exists( 'usucger_portal_vote' ) ? usucger_portal_vote() : '';
			break;
		case 'desk':
			$body = usucger_desk_inner();
			break;
		case 'membership':
			$body = '<div class="usg-panel">' . usucger_my_membership_html() . '<p style="margin-top:1rem">' . ( function_exists( 'wc_get_page_id' ) && wc_get_page_id( 'myaccount' ) > 0 ? '<a href="' . esc_url( wc_get_page_permalink( 'myaccount' ) ) . '">Orders, payment receipts and billing details &rarr;</a> · ' : '' ) . '<a href="' . esc_url( admin_url( 'profile.php' ) ) . '">Change my password or email &rarr;</a></p></div>';
			break;
		default:
			$body = usucger_portal_home( $me );
	}
	return '<section class="section bg-white usg-portal"><div class="wrap">' . $nav . $body . '</div></section>';
} );

/* ------------------------------------------------------------------ login */

function usucger_portal_login() {
	$o = '<section class="section bg-white usg-portal"><div class="wrap"><div class="usg-login">';
	if ( isset( $_GET['linksent'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		$o .= '<div class="usg-notice usg-wide"><strong>Check your email.</strong> If that address belongs to a USUCGER account, a sign-in link is on its way. It works once and expires in 20 minutes.</div>';
	}
	if ( isset( $_GET['linkbad'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		$o .= '<div class="usg-notice usg-wide"><strong>That sign-in link has expired or was already used.</strong> Ask for a new one below.</div>';
	}
	$o .= '<div class="usg-card usg-login-main"><div class="eyebrow"><span class="eyebrow-line"></span>No password needed</div><h2>Sign in with an email link</h2><p>Enter the email address you use for USUCGER and we will send you a one-time sign-in link.</p>'
		. '<form method="post" class="usg-form"><input type="hidden" name="usg_ll_nonce" value="' . esc_attr( wp_create_nonce( 'usg_login_link' ) ) . '"><label for="usgll">Email address</label><input id="usgll" type="email" name="usg_login_link" required autocomplete="email" placeholder="you@university.edu"><button class="btn btn-cobalt" type="submit">Email me a sign-in link &rarr;</button></form></div>';
	$o .= '<div class="usg-card"><h3>Or use your password</h3>' . wp_login_form( array( 'echo' => false, 'redirect' => usucger_portal_url(), 'label_username' => 'Email or username', 'remember' => true ) )
		. '<p class="usg-small"><a href="' . esc_url( wp_lostpassword_url( usucger_portal_url() ) ) . '">Forgot your password?</a></p></div>';
	$o .= '<div class="usg-card usg-login-why"><h3>What members get</h3><ul class="usg-ticks"><li>Your listing in the directory and member map</li><li>A profile with your expertise, searchable by other members</li><li>See which colleagues are going to the same conferences</li><li>Vote for the Board on behalf of your institution (delegates)</li><li>Student travel grant eligibility for your students</li></ul>'
		. '<a class="btn btn-amber" href="' . esc_url( usucger_core_url( 'membership' ) ) . '">Not a member? Join for ' . esc_html( usucger_core_opt( 'dues' ) ) . ' &rarr;</a></div>';
	return $o . '</div></div></section>';
}

/* ------------------------------------------------------------------- home */

function usucger_portal_home( $me ) {
	global $wpdb;
	$c      = $me->contact;
	$status = $c ? $c->status : '';
	$first  = $me->first ? $me->first : $me->name;
	list( $pct, $missing ) = usucger_profile_completeness( $me );
	$prev   = (int) get_user_meta( $me->id, 'usg_prev_seen', true );
	$o      = '<div class="usg-welcome"><div>' . usucger_initial_badge( $me, 'usg-av usg-av-lg' ) . '</div><div><h2>Welcome back, ' . esc_html( $first ) . '</h2><p class="usg-sub">' . esc_html( trim( $me->title . ( $me->institution ? ' · ' . $me->institution : '' ), ' ·' ) ) . '</p></div>';
	if ( 'current' === $status ) {
		$o .= '<div class="usg-status ok"><strong>Active member</strong><span>' . ( $c->end_date ? 'through ' . esc_html( usucger_fmt_date( $c->end_date, 'F j, Y' ) ) : esc_html( usucger_core_opt( 'cycle' ) ) ) . '</span></div>';
	} else {
		$o .= '<div class="usg-status warn"><strong>' . ( 'lapsed' === $status ? 'Not renewed for ' . esc_html( usucger_core_opt( 'cycle' ) ) : 'No current membership' ) . '</strong><a class="btn btn-amber btn-sm" href="' . esc_url( usucger_renew_url() ) . '">Renew for ' . esc_html( usucger_core_opt( 'dues' ) ) . ' &rarr;</a></div>';
	}
	$o .= '</div>';

	// nomination (accept / statement) and election banner
	if ( function_exists( 'usucger_portal_nomination_box' ) ) {
		$o .= usucger_portal_nomination_box();
	}
	if ( function_exists( 'usucger_portal_election_banner' ) ) {
		$o .= usucger_portal_election_banner();
	}
	if ( function_exists( 'usucger_visibility_prompt' ) ) {
		$o .= usucger_visibility_prompt();
	}

	// since last visit
	$since = array();
	if ( $prev ) {
		$newpos = 0;
		foreach ( usucger_items( 'usucger_position' ) as $p ) {
			if ( $p['posted'] && strtotime( $p['posted'] ) >= $prev - DAY_IN_SECONDS ) {
				$newpos++;
			}
		}
		if ( $newpos ) {
			$since[] = '<a href="' . esc_url( usucger_core_url( 'positions' ) ) . '">' . $newpos . ' new position' . ( 1 === $newpos ? '' : 's' ) . '</a>';
		}
		$ct     = Usucger_DB::t( 'contacts' );
		$newmem = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $ct WHERE status = 'current' AND source <> 'import' AND created >= %s", gmdate( 'Y-m-d H:i:s', $prev ) ) );
		if ( $newmem ) {
			$since[] = $newmem . ' new member' . ( 1 === $newmem ? '' : 's' );
		}
		if ( $since ) {
			$o .= '<p class="usg-since">Since your last visit: ' . implode( ' · ', $since ) . '</p>';
		}
	}

	$o .= '<div class="usg-grid2"><div>';
	// my events
	$mine = array_filter( usucger_my_events( $me->id ), function ( $r ) {
		return ! $r->past;
	} );
	$o .= '<div class="usg-card"><div class="usg-card-h"><h3>Where I’ll be</h3><a href="' . esc_url( usucger_portal_url( 'events' ) ) . '">Add an event &rarr;</a></div>';
	if ( $mine ) {
		$o .= '<ul class="usg-list">';
		foreach ( $mine as $r ) {
			$n   = $r->conference_id ? max( 0, usucger_attendance_count( $r->conference_id ) - 1 ) : 0;
			$o  .= '<li><strong>' . esc_html( $r->event_name ) . '</strong><span>' . esc_html( usucger_fmt_date( $r->event_start ) . ( $r->location ? ' · ' . $r->location : '' ) ) . ' · ' . esc_html( usucger_attendance_roles()[ $r->role ] ) . '</span>' . ( $n ? '<a class="usg-pill" href="' . esc_url( add_query_arg( array( 'tab' => 'events', 'conf' => $r->conference_id ), usucger_portal_url() ) . '#going' ) . '">' . $n . ' colleague' . ( 1 === $n ? '' : 's' ) . ' also going</a>' : '' ) . '</li>';
		}
		$o .= '</ul>';
	} else {
		$o .= '<p class="usg-muted">Tell colleagues which conferences you are going to — it is the easiest way to meet up.</p>';
	}
	$o .= '</div>';

	// colleagues on the road
	$ev = usucger_events_with_members( 6 );
	if ( $ev && usucger_is_member_viewer() ) {
		$o .= '<div class="usg-card"><div class="usg-card-h"><h3>Colleagues on the road</h3><a href="' . esc_url( usucger_portal_url( 'events' ) ) . '#going">Who’s going &rarr;</a></div><ul class="usg-list">';
		foreach ( $ev as $e ) {
			$o .= '<li><strong>' . esc_html( $e->title ) . '</strong><span>' . esc_html( usucger_fmt_date( $e->start ) . ' · ' . $e->location ) . '</span><a class="usg-pill" href="' . esc_url( add_query_arg( array( 'tab' => 'events', 'conf' => $e->id ), usucger_portal_url() ) . '#going' ) . '">' . (int) $e->n . ' member' . ( 1 === $e->n ? '' : 's' ) . '</a></li>';
		}
		$o .= '</ul></div>';
	}

	// recent positions
	$pos = array_slice( usucger_positions_list( 'academic' ), 0, 4 );
	if ( $pos ) {
		$o .= '<div class="usg-card"><div class="usg-card-h"><h3>Recent academic positions</h3><a href="' . esc_url( usucger_core_url( 'positions' ) ) . '">All positions &rarr;</a></div><ul class="usg-list">';
		foreach ( $pos as $p ) {
			$o .= '<li><a href="' . esc_url( $p['url'] ) . '" target="_blank" rel="noopener"><strong>' . esc_html( $p['institution'] ) . '</strong></a><span>' . esc_html( $p['title'] ) . ' · posted ' . esc_html( usucger_fmt_date( $p['posted'] ) ) . '</span></li>';
		}
		$o .= '</ul></div>';
	}
	$o .= '</div><div>';

	// profile completeness
	$o .= '<div class="usg-card"><h3>Your profile is ' . (int) $pct . '% complete</h3><div class="usg-meter"><i style="width:' . (int) $pct . '%"></i></div>';
	if ( $missing ) {
		$o .= '<p class="usg-muted">Add ' . esc_html( implode( ', ', array_slice( $missing, 0, 3 ) ) ) . ' so colleagues can find you by expertise.</p><a class="btn btn-cobalt btn-sm" href="' . esc_url( usucger_portal_url( 'profile' ) ) . '">Complete my profile</a>';
	} else {
		$o .= '<p class="usg-muted">Nicely done — members can find you in the expert finder.</p>';
	}
	if ( $me->expertise ) {
		$o .= '<div class="usg-chips" style="margin-top:.8rem">' . usucger_chip_list( $me->expertise ) . '</div>';
	}
	$o .= '</div>';

	$o .= do_shortcode( '[usucger_deadlines]' );

	// new members
	$ct  = Usucger_DB::t( 'contacts' );
	$new = $wpdb->get_results( $wpdb->prepare( "SELECT first_name, last_name, institution, user_id FROM $ct WHERE status = 'current' AND in_directory = 1 AND source <> 'import' AND created >= %s ORDER BY created DESC LIMIT 8", gmdate( 'Y-m-d', strtotime( '-45 days' ) ) ) );
	if ( $new ) {
		$o .= '<div class="usg-card"><h3>Welcome to our newest members</h3><ul class="usg-list usg-list-tight">';
		foreach ( $new as $n ) {
			$o .= '<li><strong>' . esc_html( trim( $n->first_name . ' ' . $n->last_name ) ) . '</strong><span>' . esc_html( $n->institution ) . '</span></li>';
		}
		$o .= '</ul></div>';
	}
	$o .= '<div class="usg-card"><h3>Shortcuts</h3><div class="usg-shortcuts">'
		. '<a href="' . esc_url( usucger_portal_url( 'experts' ) ) . '">Find an expert</a>'
		. '<a href="' . esc_url( usucger_core_url( 'directory' ) ) . '">Membership directory</a>'
		. '<a href="' . esc_url( usucger_core_url( 'travel-grants' ) ) . '">Student travel grants</a>'
		. '<a href="' . esc_url( usucger_core_url( 'minutes' ) ) . '">Meeting minutes</a>'
		. '<a href="' . esc_url( usucger_core_opt( 'form_awards' ) ? usucger_core_url( 'nominate' ) : usucger_core_url( 'awards' ) ) . '">Nominate for an award</a>'
		. '<a href="' . usucger_mailto( 'Academic Position Posting' ) . '">Post a position</a>' . '<a href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=usucger_my_data' ), 'usucger_my_data' ) ) . '">Download my data</a></div></div>';
	return $o . '</div></div>';
}

/* ---------------------------------------------------------------- profile */

function usucger_portal_profile( $me ) {
	$vocab = usucger_expertise_vocab();
	$other = array_diff( $me->expertise, $vocab );
	$o     = '';
	if ( isset( $_GET['saved'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		$o .= '<div class="usg-notice"><strong>Saved.</strong> ' . ( 'inst' === $_GET['saved'] ? 'Your institution change is waiting for the Membership Coordinator to confirm it (it decides which institution you vote with). ' : '' ) . '<a href="' . esc_url( add_query_arg( array( 'tab' => 'experts', 'person' => $me->id ), usucger_portal_url() ) ) . '">See how other members see your profile &rarr;</a></div>';
	}
	$o .= '<form class="usg-form usg-card" method="post" enctype="multipart/form-data" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">' . wp_nonce_field( 'usucger_profile', '_wpnonce', true, false ) . '<input type="hidden" name="action" value="usucger_profile">';
	$o .= '<div class="usg-form-photo">' . usucger_initial_badge( $me, 'usg-av usg-av-xl' ) . '<div><label for="usgph">Photo</label><input id="usgph" type="file" name="photo" accept="image/jpeg,image/png,image/webp"><p class="usg-small">JPG or PNG, square works best, up to 3 MB.</p>' . ( $me->photo ? '<label class="usg-check"><input type="checkbox" name="remove_photo" value="1"> Remove photo</label>' : '' ) . '</div></div>';
	$o .= '<div class="usg-row2"><div><label for="usgfn">First name</label><input id="usgfn" name="first_name" value="' . esc_attr( $me->first ) . '"></div><div><label for="usgln">Last name</label><input id="usgln" name="last_name" value="' . esc_attr( $me->last ) . '"></div></div>';
	$o .= '<div class="usg-row2"><div><label for="usgrk">Rank</label><select id="usgrk" name="rank"><option value="">Choose…</option>';
	foreach ( usucger_ranks() as $r => $x ) {
		$o .= '<option' . selected( $me->rank, $r, false ) . '>' . esc_html( $r ) . '</option>';
	}
	$o .= '</select><p class="usg-small">Used for Board elections: junior seats are for Assistant Professors, senior seats for Associate and Full Professors.</p></div><div><label for="usgtt">Title / department</label><input id="usgtt" name="title" value="' . esc_attr( $me->title ) . '" placeholder="e.g. Associate Professor of Civil Engineering"></div></div>';
	$o .= '<label for="usgin">Institution</label><input id="usgin" name="institution" value="' . esc_attr( $me->institution ) . '">';
	$o .= '<fieldset class="usg-tagpick"><legend>Expertise <span class="usg-small">(pick up to 12)</span></legend>';
	foreach ( $vocab as $t ) {
		$o .= '<label class="usg-tagopt"><input type="checkbox" name="expertise[]" value="' . esc_attr( $t ) . '"' . checked( in_array( $t, $me->expertise, true ), true, false ) . '><span>' . esc_html( $t ) . '</span></label>';
	}
	$o .= '</fieldset><label for="usgeo">Other expertise (comma separated)</label><input id="usgeo" name="expertise_other" value="' . esc_attr( implode( ', ', $other ) ) . '" placeholder="e.g. Microbially induced calcite precipitation, Mine tailings">';
	$o .= '<label for="usgsm">Research summary <span class="usg-small">(2–4 sentences)</span></label><textarea id="usgsm" name="summary" rows="4" maxlength="900">' . esc_textarea( $me->summary ) . '</textarea>';
	$o .= '<div class="usg-row2"><div><label for="usgsc">Google Scholar</label><input id="usgsc" type="url" name="scholar" value="' . esc_attr( isset( $me->links['scholar'] ) ? $me->links['scholar'] : '' ) . '"></div><div><label for="usgor">ORCID</label><input id="usgor" type="url" name="orcid" value="' . esc_attr( isset( $me->links['orcid'] ) ? $me->links['orcid'] : '' ) . '" placeholder="https://orcid.org/0000-…"></div></div>';
	$o .= '<div class="usg-row2"><div><label for="usgwb">Lab / personal website</label><input id="usgwb" type="url" name="web" value="' . esc_attr( isset( $me->links['web'] ) ? $me->links['web'] : '' ) . '"></div><div><label for="usgli">LinkedIn</label><input id="usgli" type="url" name="linkedin" value="' . esc_attr( isset( $me->links['linkedin'] ) ? $me->links['linkedin'] : '' ) . '"></div></div>';
	$o .= '<label class="usg-check"><input type="checkbox" name="visible" value="1"' . checked( $me->visible, true, false ) . '> Show my profile to other signed-in members (expert finder and “who’s going”). Never shown to the public; your email address is never displayed.</label>';
	$o .= '<p><button class="btn btn-cobalt" type="submit">Save profile</button></p></form>';
	return $o;
}

/* ---------------------------------------------------------------- experts */

function usucger_portal_experts() {
	if ( ! usucger_is_member_viewer() ) {
		return '<div class="usg-notice">The expert finder is for current members. <a href="' . esc_url( usucger_renew_url() ) . '">Renew your membership</a> to search colleagues by expertise.</div>';
	}
	$person = isset( $_GET['person'] ) ? (int) $_GET['person'] : 0; // phpcs:ignore WordPress.Security.NonceVerification
	if ( $person ) {
		return usucger_portal_person( $person );
	}
	$q     = isset( $_GET['q'] ) ? sanitize_text_field( wp_unslash( $_GET['q'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	$tag   = isset( $_GET['tag'] ) ? sanitize_text_field( wp_unslash( $_GET['tag'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	$state = isset( $_GET['st'] ) ? sanitize_key( $_GET['st'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	$state = strtoupper( $state );
	$cnt   = usucger_expertise_counts();
	$o     = '<form class="usg-search" method="get" action="' . esc_url( usucger_portal_url() ) . '"><input type="hidden" name="tab" value="experts">'
		. '<input type="search" name="q" value="' . esc_attr( $q ) . '" placeholder="Search expertise, name, institution… e.g. liquefaction, CPT, landslides" aria-label="Search">'
		. '<select name="tag" aria-label="Expertise"><option value="">All expertise</option>';
	foreach ( array_unique( array_merge( array_keys( $cnt ), usucger_expertise_vocab() ) ) as $t ) {
		$o .= '<option' . selected( $tag, $t, false ) . '>' . esc_html( $t ) . '</option>';
	}
	$o .= '</select><select name="st" aria-label="State"><option value="">All states</option>';
	foreach ( usucger_state_names() as $k => $n ) {
		$o .= '<option value="' . esc_attr( $k ) . '"' . selected( $state, $k, false ) . '>' . esc_html( $n ) . '</option>';
	}
	$o .= '</select><button class="btn btn-cobalt" type="submit">Search</button></form>';
	if ( $cnt && ! $q && ! $tag && ! $state ) {
		$o .= '<div class="usg-chips usg-cloud">';
		foreach ( array_slice( $cnt, 0, 30, true ) as $t => $n ) {
			$o .= '<a class="usg-chip" href="' . esc_url( add_query_arg( array( 'tab' => 'experts', 'tag' => $t ), usucger_portal_url() ) ) . '">' . esc_html( $t ) . ' <b>' . (int) $n . '</b></a>';
		}
		$o .= '</div>';
	}
	$res = usucger_expert_search( $q, $tag, $state );
	$o  .= '<p class="usg-muted">' . count( $res ) . ' member' . ( 1 === count( $res ) ? '' : 's' ) . ( $q || $tag || $state ? ' match' : ' have filled in their expertise' ) . '. Only members who chose to show their profile appear here.</p><div class="usg-people">';
	foreach ( $res as $p ) {
		$o .= '<a class="usg-person" href="' . esc_url( add_query_arg( array( 'tab' => 'experts', 'person' => $p->id ), usucger_portal_url() ) ) . '">' . usucger_initial_badge( $p ) . '<div><strong>' . esc_html( $p->name ) . '</strong><span class="usg-sub">' . esc_html( trim( $p->rank . ( $p->institution ? ' · ' . $p->institution : '' ), ' ·' ) ) . '</span><div class="usg-chips">' . usucger_chip_list( array_slice( $p->expertise, 0, 5 ), false ) . '</div></div></a>';
	}
	if ( ! $res ) {
		$o .= '<p>No one found. Try a broader word, or <a href="' . esc_url( usucger_core_url( 'directory' ) ) . '">browse the full directory</a>.</p>';
	}
	return $o . '</div>';
}

function usucger_portal_person( $uid ) {
	$p = usucger_profile( $uid );
	if ( ! $p || ( ! $p->visible && get_current_user_id() !== $uid ) ) {
		return '<p>This profile is not available.</p>';
	}
	$msg = isset( $_GET['msg'] ) ? sanitize_key( $_GET['msg'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	$o   = '<p><a href="' . esc_url( usucger_portal_url( 'experts' ) ) . '">&larr; Back to the expert finder</a></p><div class="usg-grid2"><div class="usg-card usg-profile">';
	$o  .= '<div class="usg-welcome">' . usucger_initial_badge( $p, 'usg-av usg-av-xl' ) . '<div><h2>' . esc_html( $p->name ) . '</h2><p class="usg-sub">' . esc_html( $p->title ? $p->title : $p->rank ) . '</p><p class="usg-sub">' . esc_html( $p->institution ) . '</p></div></div>';
	if ( $p->expertise ) {
		$o .= '<h3>Expertise</h3><div class="usg-chips">' . usucger_chip_list( $p->expertise ) . '</div>';
	}
	if ( $p->summary ) {
		$o .= '<h3>Research</h3><p>' . nl2br( esc_html( $p->summary ) ) . '</p>';
	}
	$labels = array( 'scholar' => 'Google Scholar', 'orcid' => 'ORCID', 'web' => 'Website', 'linkedin' => 'LinkedIn' );
	$links  = array();
	foreach ( $labels as $k => $l ) {
		if ( ! empty( $p->links[ $k ] ) ) {
			$links[] = '<a href="' . esc_url( $p->links[ $k ] ) . '" target="_blank" rel="noopener">' . esc_html( $l ) . '</a>';
		}
	}
	if ( $links ) {
		$o .= '<p class="usg-links">' . implode( ' · ', $links ) . '</p>';
	}
	$ev = array_filter( usucger_my_events( $uid ), function ( $r ) {
		return ! $r->past;
	} );
	if ( $ev ) {
		$o .= '<h3>Upcoming events</h3><ul class="usg-list">';
		foreach ( $ev as $r ) {
			$o .= '<li><strong>' . esc_html( $r->event_name ) . '</strong><span>' . esc_html( usucger_fmt_date( $r->event_start ) . ( $r->location ? ' · ' . $r->location : '' ) . ' · ' . usucger_attendance_roles()[ $r->role ] ) . '</span></li>';
		}
		$o .= '</ul>';
	}
	$o .= '</div><div class="usg-card">';
	if ( get_current_user_id() === $uid ) {
		$o .= '<h3>This is your profile</h3><p class="usg-muted">This is how other members see you.</p><a class="btn btn-cobalt btn-sm" href="' . esc_url( usucger_portal_url( 'profile' ) ) . '">Edit my profile</a>';
	} else {
		if ( 'sent' === $msg ) {
			$o .= '<div class="usg-notice"><strong>Message sent.</strong> ' . esc_html( $p->first ? $p->first : $p->name ) . ' can reply to you directly by email.</div>';
		} elseif ( 'limit' === $msg ) {
			$o .= '<div class="usg-notice">You have reached today’s limit of 10 messages.</div>';
		}
		$o .= '<h3>Contact ' . esc_html( $p->first ? $p->first : $p->name ) . '</h3><p class="usg-muted">Your message is emailed with your address as the reply-to. Their address stays private.</p>'
			. '<form class="usg-form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">' . wp_nonce_field( 'usucger_contact_member', '_wpnonce', true, false ) . '<input type="hidden" name="action" value="usucger_contact_member"><input type="hidden" name="to" value="' . (int) $uid . '"><textarea name="message" rows="6" required minlength="10" placeholder="Hello, I saw your profile on USUCGER…"></textarea><button class="btn btn-cobalt" type="submit">Send message</button></form>';
	}
	return $o . '</div></div>';
}

/* ----------------------------------------------------------------- events */

function usucger_portal_events( $me ) {
	$confs = usucger_items( 'usucger_conference' );
	usort( $confs, function ( $a, $b ) {
		return strcmp( $a['start'], $b['start'] );
	} );
	$mine = usucger_my_events( $me->id );
	$o    = '';
	if ( isset( $_GET['saved'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		$o .= '<div class="usg-notice"><strong>Saved.</strong> Colleagues will see it in “Who’s going”.</div>';
	}
	$o .= '<div class="usg-grid2"><div><div class="usg-card"><h3>My events</h3>';
	if ( $mine ) {
		$o .= '<ul class="usg-list">';
		foreach ( $mine as $r ) {
			$o .= '<li class="' . ( $r->past ? 'usg-past' : '' ) . '"><strong>' . esc_html( $r->event_name ) . '</strong><span>' . esc_html( usucger_fmt_date( $r->event_start ) . ( $r->location ? ' · ' . $r->location : '' ) . ' · ' . usucger_attendance_roles()[ $r->role ] . ( $r->note ? ' — ' . $r->note : '' ) ) . '</span>'
				. '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="usg-inline">' . wp_nonce_field( 'usucger_attend', '_wpnonce', true, false ) . '<input type="hidden" name="action" value="usucger_attend"><input type="hidden" name="remove" value="' . (int) $r->id . '"><button class="usg-linkbtn" type="submit">Remove</button></form></li>';
		}
		$o .= '</ul>';
	} else {
		$o .= '<p class="usg-muted">Nothing yet.</p>';
	}
	$o .= '</div><form class="usg-card usg-form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">' . wp_nonce_field( 'usucger_attend', '_wpnonce', true, false ) . '<input type="hidden" name="action" value="usucger_attend"><h3>I’m going to…</h3>'
		. '<label for="usgcf">Conference</label><select id="usgcf" name="conference_id" onchange="document.getElementById(\'usgOther\').style.display=this.value===\'0\'?\'\':\'none\'">';
	foreach ( $confs as $cf ) {
		$o .= '<option value="' . (int) $cf['id'] . '">' . esc_html( $cf['title'] . ' — ' . usucger_fmt_date( $cf['start'] ) ) . '</option>';
	}
	$o .= '<option value="0">Another event or workshop (not listed)…</option></select>'
		. '<div id="usgOther" style="display:' . ( $confs ? 'none' : '' ) . '"><label for="usgen">Event name</label><input id="usgen" name="event_name"><div class="usg-row2"><div><label for="usges">Starts</label><input id="usges" type="date" name="event_start"></div><div><label for="usgee">Ends</label><input id="usgee" type="date" name="event_end"></div></div><label for="usgel">Location</label><input id="usgel" name="location"></div>'
		. '<div class="usg-row2"><div><label for="usgrl">I’m</label><select id="usgrl" name="role">';
	foreach ( usucger_attendance_roles() as $k => $l ) {
		$o .= '<option value="' . esc_attr( $k ) . '">' . esc_html( $l ) . '</option>';
	}
	$o .= '</select></div><div><label for="usgnt">Note (optional)</label><input id="usgnt" name="note" maxlength="200" placeholder="e.g. session TC-3, Tue afternoon"></div></div><button class="btn btn-cobalt" type="submit">Add to my events</button></form></div>';

	// who's going
	$o .= '<div><div class="usg-card" id="going"><h3>Who’s going</h3>';
	if ( ! usucger_is_member_viewer() ) {
		$o .= '<p class="usg-muted">Names are visible to current members.</p>';
	} else {
		$sel = isset( $_GET['conf'] ) ? (int) $_GET['conf'] : 0; // phpcs:ignore WordPress.Security.NonceVerification
		$any = false;
		foreach ( $confs as $cf ) {
			$people = usucger_attendees( $cf['id'] );
			if ( ! $people ) {
				continue;
			}
			$any = true;
			$o  .= '<details class="usg-going"' . ( $sel === $cf['id'] || ! $sel ? ' open' : '' ) . '><summary><strong>' . esc_html( $cf['title'] ) . '</strong> <span class="usg-pill">' . count( $people ) . '</span><span class="usg-sub">' . esc_html( usucger_fmt_date( $cf['start'] ) . ' · ' . $cf['location'] ) . '</span></summary><ul class="usg-list usg-list-tight">';
			foreach ( $people as $p ) {
				$o .= '<li><a href="' . esc_url( add_query_arg( array( 'tab' => 'experts', 'person' => $p->id ), usucger_portal_url() ) ) . '"><strong>' . esc_html( $p->name ) . '</strong></a><span>' . esc_html( $p->institution . ' · ' . usucger_attendance_roles()[ $p->role ] . ( $p->note ? ' — ' . $p->note : '' ) ) . '</span></li>';
			}
			$o .= '</ul></details>';
		}
		if ( ! $any ) {
			$o .= '<p class="usg-muted">No one has added an event yet — be the first.</p>';
		}
	}
	return $o . '</div></div></div>';
}
