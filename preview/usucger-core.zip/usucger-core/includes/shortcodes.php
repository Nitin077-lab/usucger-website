<?php
/**
 * Shortcodes that render the data-driven parts of the site with the same markup as
 * the static redesign.
 *
 *   [usucger_positions kind="academic|industry"]  full positions board
 *   [usucger_positions_module count="4"]          home-page "Recent academic positions"
 *   [usucger_conferences]                          upcoming conferences by year
 *   [usucger_board]                                officers, directors, ex-officio
 *   [usucger_minutes]                              minutes timeline
 *   [usucger_deadlines]                            countdown card
 *   [usucger_directory]                            membership directory page body
 *   [usucger_universities]                         member universities page body (with map)
 *   [usucger_member_map]                           the US map on its own
 *   [usucger_count of="members|institutions|positions|states"]
 *
 * @package usucger-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function usucger_e( $s ) {
	return esc_html( html_entity_decode( (string) $s, ENT_QUOTES, 'UTF-8' ) );
}

function usucger_u( $ref ) {
	return esc_url( usucger_core_url( $ref ) );
}

function usucger_mailto( $subject ) {
	if ( false !== stripos( $subject, 'Position Posting' ) ) {
		$form = apply_filters( 'usucger_position_post_link', '' );
		if ( $form ) {
			return esc_attr( add_query_arg( 'kind', false !== stripos( $subject, 'Industry' ) ? 'industry' : 'academic', $form ) );
		}
	}
	return esc_attr( 'mailto:' . usucger_core_opt( 'contact_email' ) . '?subject=' . rawurlencode( $subject ) );
}

/* ---------------------------------------------------------------- positions */

function usucger_positions_list( $kind ) {
	$items = array_values( array_filter( usucger_items( 'usucger_position' ), function ( $p ) use ( $kind ) {
		return ( $p['kind'] ? $p['kind'] : 'academic' ) === $kind;
	} ) );
	usort( $items, function ( $a, $b ) {
		$c = strcmp( $b['posted'], $a['posted'] );
		return $c ? $c : $a['id'] - $b['id'];
	} );
	return $items;
}

function usucger_posting_row( $p ) {
	$fresh = $p['posted'] && usucger_days_between( $p['posted'], usucger_today() ) <= 45;
	$badge = $fresh ? '<span class="badge badge-amber"><span class="bdot"></span>New</span> ' : '';
	return sprintf(
		'<a class="linkrow pos-row" href="%s" target="_blank" rel="noopener" data-inst="%s" data-title="%s" data-loc="%s"><div class="linkrow-ic">&#127979;</div><div class="linkrow-body"><div class="linkrow-title">%s%s</div><div class="linkrow-desc">%s%s</div><div class="linkrow-meta">Posted %s</div></div><div class="pos-go" aria-hidden="true">&rarr;</div></a>',
		esc_url( $p['url'] ),
		esc_attr( mb_strtolower( $p['institution'] ) ),
		esc_attr( mb_strtolower( $p['title'] ) ),
		esc_attr( mb_strtolower( $p['location'] ) ),
		$badge,
		usucger_e( $p['institution'] ),
		usucger_e( $p['title'] ),
		$p['location'] ? ' &middot; ' . usucger_e( $p['location'] ) : '',
		esc_html( usucger_fmt_date( $p['posted'] ) )
	);
}

add_shortcode( 'usucger_positions', function ( $atts ) {
	$a    = shortcode_atts( array( 'kind' => 'academic' ), $atts );
	$kind = 'industry' === $a['kind'] ? 'industry' : 'academic';
	$rows = usucger_positions_list( $kind );
	$n    = count( $rows );
	ob_start();
	if ( 'academic' === $kind ) :
		?>
<section class="section bg-white">
  <div class="wrap">
    <div class="split">
      <div class="rv">
        <div class="pos-toolbar">
          <div class="tbl-search"><span class="si" aria-hidden="true">&#128269;</span><input id="posSearch" type="search" placeholder="Filter by institution, title or location&hellip;" aria-label="Filter positions"></div>
          <div class="tbl-count" id="posCount"><?php echo (int) $n; ?> open position<?php echo 1 === $n ? '' : 's'; ?></div>
        </div>
        <div class="linklist" id="posList">
          <?php echo implode( "\n", array_map( 'usucger_posting_row', $rows ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
        </div>
        <div class="tbl-empty" id="posEmpty" <?php echo $n ? 'hidden' : ''; ?>><?php echo $n ? 'No positions match that filter.' : 'No open positions are listed right now.'; ?></div>
        <p style="font-size:.79rem;color:var(--muted-lt);margin-top:1rem">Always confirm the closing date on the official posting &mdash; searches sometimes close before a listing is removed here. Listings are removed one year after posting.</p>
      </div>
      <aside class="sticky-aside rv d2">
        <div class="award-box" style="padding:1.6rem 1.7rem">
          <div class="ab-amount" style="font-size:2.4rem">Free</div>
          <div class="ab-label">to post for member institutions</div>
          <div class="ab-body">Email the position title, institution and a link to the official posting to the webmaster. Listings go up within a few days and stay for one year.</div>
          <a href="<?php echo usucger_mailto( 'Academic Position Posting' ); // phpcs:ignore ?>" class="btn btn-amber" style="margin-top:1.1rem">Post a position &rarr;</a>
        </div>
        <div class="sidebar-card">
          <div class="sc-head">&#128188; Industry &amp; practice</div>
          <div class="sc-body">
            <p style="font-size:.83rem;line-height:1.7;color:var(--ink-2)">Looking for, or offering, a role in consulting, contracting or government? Those go on a separate board.</p>
            <a href="<?php echo usucger_u( 'industry-positions' ); // phpcs:ignore ?>" class="btn btn-outline btn-sm" style="margin-top:.9rem">Industry positions &rarr;</a>
          </div>
        </div>
        <div class="sidebar-card">
          <div class="sc-head">&#128279; For candidates</div>
          <div class="sc-body">
            <a class="sc-link" href="<?php echo usucger_u( 'universities' ); // phpcs:ignore ?>"><span class="sc-link-ic">&#127979;</span> Member universities</a>
            <a class="sc-link" href="<?php echo usucger_u( 'directory' ); // phpcs:ignore ?>"><span class="sc-link-ic">&#128101;</span> Membership directory</a>
            <a class="sc-link" href="<?php echo usucger_u( 'funding-tips' ); // phpcs:ignore ?>"><span class="sc-link-ic">&#128161;</span> Funding tips for new faculty</a>
            <a class="sc-link" href="<?php echo usucger_u( 'membership' ); // phpcs:ignore ?>"><span class="sc-link-ic">&#128179;</span> Join USUCGER</a>
          </div>
        </div>
      </aside>
    </div>
  </div>
</section>
<script>
(function(){
  var q=document.getElementById('posSearch'),rows=[].slice.call(document.querySelectorAll('#posList .pos-row')),
      count=document.getElementById('posCount'),empty=document.getElementById('posEmpty');
  if(!q)return;
  q.addEventListener('input',function(){
    var v=q.value.trim().toLowerCase(),n=0;
    rows.forEach(function(r){var hit=!v||(r.dataset.inst+' '+r.dataset.title+' '+r.dataset.loc).indexOf(v)!==-1;r.hidden=!hit;if(hit)n++;});
    count.textContent=n+' of '+rows.length+' position'+(rows.length===1?'':'s');empty.hidden=n>0;
  });
})();
</script>
		<?php
	else :
		?>
<section class="section bg-white">
  <div class="wrap">
    <div class="split">
      <div class="rv">
		<?php if ( $rows ) : ?>
        <div class="linklist"><?php echo implode( "\n", array_map( 'usucger_posting_row', $rows ) ); // phpcs:ignore ?></div>
		<?php else : ?>
        <div class="empty-state">
          <div class="es-art" aria-hidden="true">
            <svg viewBox="0 0 120 120" width="96" height="96"><defs><clipPath id="esClip"><path d="M34 12 V67 A26 26 0 0 0 86 67 V12 Z"/></clipPath></defs>
              <path d="M34 12 V67 A26 26 0 0 0 86 67 V12 Z" fill="#fff"/>
              <g clip-path="url(#esClip)"><path d="M24 44 Q60 62 96 44 V110 H24Z" fill="var(--primary-md)" opacity=".25"/><path d="M24 60 Q60 78 96 60 V110 H24Z" fill="var(--primary)" opacity=".35"/><path d="M24 76 Q60 94 96 76 V110 H24Z" fill="var(--primary-dk)" opacity=".45"/></g>
              <path d="M20 10 V67 A40 40 0 0 0 100 67 V10 H86 V67 A26 26 0 0 1 34 67 V10 Z" fill="var(--border-dk)"/>
              <path d="M56 4 H64 V72 L60 82 L56 72 Z" fill="var(--accent)" opacity=".55"/>
            </svg>
          </div>
          <h2 style="color:var(--cobalt-dk)">No industry positions posted yet</h2>
          <p class="lead" style="margin:.6rem auto 0;max-width:52ch">This board is reserved for roles in consulting, contracting, instrumentation, software and government agencies. It opens as soon as the first listing arrives &mdash; be the first to post.</p>
          <div style="display:flex;gap:.7rem;justify-content:center;flex-wrap:wrap;margin-top:1.6rem">
            <a href="<?php echo usucger_mailto( 'Industry Position Posting' ); // phpcs:ignore ?>" class="btn btn-cobalt">Post the first listing &rarr;</a>
            <a href="<?php echo usucger_u( 'positions' ); // phpcs:ignore ?>" class="btn btn-outline">See academic positions</a>
          </div>
        </div>
        <div class="grid-3" style="margin-top:2.4rem">
          <div class="card"><div class="card-icon">&#128203;</div><div class="card-title">What to send</div><div class="card-desc">Role title, employer, location, a link to the official posting, and the closing date if there is one.</div></div>
          <div class="card"><div class="card-icon">&#128101;</div><div class="card-title">Who sees it</div><div class="card-desc">Faculty at 170+ member institutions and, through them, the graduate students they advise.</div></div>
          <div class="card"><div class="card-icon">&#9203;</div><div class="card-title">How long it stays</div><div class="card-desc">Up to one year, or until you tell the webmaster the search has closed.</div></div>
        </div>
		<?php endif; ?>
      </div>
      <aside class="sticky-aside rv d2">
        <div class="award-box" style="padding:1.6rem 1.7rem">
          <div class="ab-amount" style="font-size:2.4rem">Post</div>
          <div class="ab-label">an industry or agency position</div>
          <div class="ab-body">Send the role title, employer, location and a link to the official posting. Include a closing date if there is one. Listings stay for up to one year.</div>
          <a href="<?php echo usucger_mailto( 'Industry Position Posting' ); // phpcs:ignore ?>" class="btn btn-amber" style="margin-top:1.1rem">Submit a listing &rarr;</a>
        </div>
        <div class="sidebar-card">
          <div class="sc-head">&#127979; Academic openings</div>
          <div class="sc-body">
            <p style="font-size:.83rem;line-height:1.7;color:var(--ink-2)">Faculty, lecturer and postdoctoral positions at universities are listed on the academic positions board.</p>
            <a href="<?php echo usucger_u( 'positions' ); // phpcs:ignore ?>" class="btn btn-outline btn-sm" style="margin-top:.9rem">Academic positions &rarr;</a>
          </div>
        </div>
        <div class="info-callout callout-grey">
          <div class="ic-head">Who reads this</div>
          <div class="ic-body">USUCGER's network reaches roughly 300 faculty and their graduate students at 170+ institutions &mdash; the people who will be your next hires.</div>
        </div>
      </aside>
    </div>
  </div>
</section>
		<?php
	endif;
	return ob_get_clean();
} );

add_shortcode( 'usucger_positions_module', function ( $atts ) {
	$a    = shortcode_atts( array( 'count' => 4 ), $atts );
	$rows = array_slice( usucger_positions_list( 'academic' ), 0, max( 1, (int) $a['count'] ) );
	ob_start();
	?>
<section class="section bg-white" id="positions">
  <div class="wrap">
    <div class="pos-head rv">
      <div>
        <div class="eyebrow"><span class="eyebrow-line"></span>Careers</div>
        <h2 style="color:var(--cobalt-dk)">Recent academic positions</h2>
        <p class="lead" style="margin-top:.4rem">Faculty and lecturer openings shared by member institutions. Free to post; updated as listings arrive.</p>
      </div>
      <a href="<?php echo usucger_u( 'positions' ); // phpcs:ignore ?>" class="btn btn-cobalt">All recent positions &rarr;</a>
    </div>
    <div class="linklist rv">
      <?php echo $rows ? implode( "\n", array_map( 'usucger_posting_row', $rows ) ) : '<p class="lead">New openings will appear here as they are posted.</p>'; // phpcs:ignore ?>
    </div>
    <div class="pos-foot rv">
      <span>Member institutions post for free &middot; <a href="<?php echo usucger_mailto( 'Academic Position Posting' ); // phpcs:ignore ?>">submit a listing</a></span>
      <a href="<?php echo usucger_u( 'industry-positions' ); // phpcs:ignore ?>">Industry &amp; agency positions &rarr;</a>
    </div>
  </div>
</section>
	<?php
	return ob_get_clean();
} );

/* -------------------------------------------------------------- conferences */

function usucger_conf_when( $e ) {
	$m = array( 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December' );
	$s = explode( '-', $e['start'] );
	if ( $e['year_only'] ) {
		return $s[0];
	}
	if ( ! $e['end'] ) {
		return (int) $s[2] . ' ' . $m[ $s[1] - 1 ] . ' ' . $s[0];
	}
	$t = explode( '-', $e['end'] );
	if ( $s[0] === $t[0] && $s[1] === $t[1] ) {
		return (int) $s[2] . '&ndash;' . (int) $t[2] . ' ' . $m[ $s[1] - 1 ] . ' ' . $s[0];
	}
	return (int) $s[2] . ' ' . $m[ $s[1] - 1 ] . ' &ndash; ' . (int) $t[2] . ' ' . $m[ $t[1] - 1 ] . ' ' . $t[0];
}

add_shortcode( 'usucger_conferences', function () {
	$up = usucger_items( 'usucger_conference' );
	usort( $up, function ( $a, $b ) {
		return strcmp( $a['start'], $b['start'] );
	} );
	if ( ! $up ) {
		return '<p class="lead">Upcoming conferences will be listed here.</p>';
	}
	$years = array();
	foreach ( $up as $e ) {
		$years[ substr( $e['start'], 0, 4 ) ][] = $e;
	}
	$last = substr( end( $up )['start'], 0, 4 );
	$o    = '<p class="lead" style="margin-bottom:1.6rem">' . count( $up ) . ' upcoming events through ' . esc_html( $last ) . ', listed by start date. Past events drop off automatically.</p>';
	foreach ( $years as $y => $list ) {
		$o .= '<h2 style="color:var(--cobalt-dk);margin-bottom:1.2rem">' . esc_html( $y ) . '</h2><div class="linklist" style="margin-bottom:2.4rem">';
		foreach ( $list as $e ) {
			$end  = $e['year_only'] ? substr( $e['start'], 0, 4 ) . '-12-31' : ( $e['end'] ? $e['end'] : $e['start'] );
			$meta = usucger_conf_when( $e ) . ( $e['location'] ? ' &middot; ' . usucger_e( $e['location'] ) : '' );
			if ( $e['note'] ) {
				$meta .= ' &middot; <strong style="color:var(--amber)">' . usucger_e( $e['note'] ) . '</strong>';
			}
			$going = function_exists( 'usucger_attendance_count' ) ? usucger_attendance_count( $e['id'] ) : 0;
			if ( $going ) {
				$meta .= ' &middot; <span class="usg-going">' . (int) $going . ' USUCGER member' . ( 1 === $going ? '' : 's' ) . ' attending</span>';
			}
			$o .= '<a class="linkrow conf-row" data-end="' . esc_attr( $end ) . '" href="' . esc_url( $e['url'] ? $e['url'] : '#' ) . '" target="_blank" rel="noopener"><div class="linkrow-body"><div class="linkrow-title">' . usucger_e( $e['title'] ) . '</div><div class="linkrow-meta">' . $meta . '</div></div></a>';
		}
		$o .= '</div>';
	}
	$o .= '<p class="usg-going-cta">Going to one of these? <a href="' . esc_url( add_query_arg( 'tab', 'events', usucger_portal_url() ) ) . '">Tell other members in the member area &rarr;</a></p>';
	$o .= '<script>document.addEventListener("DOMContentLoaded",function(){var t=new Date().toISOString().slice(0,10);document.querySelectorAll(".conf-row[data-end]").forEach(function(r){if(r.dataset.end<t)r.remove()});document.querySelectorAll(".linklist").forEach(function(l){if(!l.children.length){var h=l.previousElementSibling;l.remove();if(h&&h.tagName==="H2")h.remove()}})});</script>';
	return $o;
} );

/* -------------------------------------------------------------------- board */

function usucger_board_photo( $m ) {
	$thumb = get_the_post_thumbnail_url( $m['id'], 'medium' );
	return $thumb ? $thumb : $m['photo'];
}

function usucger_person_card( $m ) {
	$seats = array( 'junior' => array( 'seat-junior', 'Junior seat' ), 'senior' => array( 'seat-senior', 'Senior seat' ), 'ex' => array( 'seat-ex', 'Non-voting' ) );
	$s     = isset( $seats[ $m['seat'] ] ) ? $seats[ $m['seat'] ] : $seats['ex'];
	$photo = usucger_board_photo( $m );
	$img   = $photo
		? '<div class="person-photo"><img src="' . esc_url( $photo ) . '" alt="' . esc_attr( $m['title'] ) . '" loading="lazy" onerror="this.style.display=\'none\';this.parentNode.insertAdjacentHTML(\'beforeend\',\'<span class=init>' . esc_attr( usucger_initials( $m['title'] ) ) . '</span>\')"></div>'
		: '<div class="person-photo"><span class="init">' . esc_html( usucger_initials( $m['title'] ) ) . '</span></div>';
	return '<div class="person has-photo">' . $img . '<span class="seat ' . $s[0] . '">' . $s[1] . '</span><div class="person-name">' . usucger_e( $m['title'] ) . '</div><div class="person-role">' . usucger_e( $m['role'] ) . '</div><div class="person-inst">' . usucger_e( $m['inst'] ) . '</div>' . ( $m['term'] ? '<div class="person-term">Term ' . usucger_e( $m['term'] ) . '</div>' : '' ) . '</div>';
}

function usucger_officer_cell( $m ) {
	$photo = usucger_board_photo( $m );
	$img   = $photo ? '<img src="' . esc_url( $photo ) . '" alt="" loading="lazy" onerror="this.style.display=\'none\';this.parentNode.insertAdjacentHTML(\'beforeend\',\'<span class=init>' . esc_attr( usucger_initials( $m['title'] ) ) . '</span>\')">' : '<span class="init">' . esc_html( usucger_initials( $m['title'] ) ) . '</span>';
	return '<div class="of-cell"><span class="of-photo-wrap">' . $img . '</span><div><div class="of-role">' . usucger_e( $m['role'] ) . '</div><div class="of-name">' . usucger_e( $m['title'] ) . '</div><div class="of-inst">' . usucger_e( $m['inst'] ) . '</div></div></div>';
}

add_shortcode( 'usucger_board', function () {
	$all      = usucger_items( 'usucger_board' );
	$officers = array_filter( $all, function ( $m ) {
		return $m['officer'];
	} );
	$elected  = array_filter( $all, function ( $m ) {
		return in_array( $m['seat'], array( 'junior', 'senior' ), true );
	} );
	$exoff    = array_filter( $all, function ( $m ) {
		return 'ex' === $m['seat'];
	} );
	$board    = esc_html( usucger_core_opt( 'board_email' ) );
	$web      = esc_html( usucger_core_opt( 'contact_email' ) );
	ob_start();
	?>
<section class="section bg-white">
  <div class="wrap">
    <div class="rv" style="margin-bottom:1.4rem">
      <div class="eyebrow"><span class="eyebrow-line"></span>Officers</div>
      <h2 style="color:var(--cobalt-dk)">Council officers</h2>
      <p class="lead" style="margin-top:.4rem">The President is elected from among Board members for a two-year term; the Secretary/Treasurer, Comptroller and Webmaster are appointed by the Board.</p>
    </div>
    <div class="officer-strip rv">
      <?php echo implode( "\n", array_map( 'usucger_officer_cell', $officers ) ); // phpcs:ignore ?>
    </div>
    <div class="split">
      <div>
        <div class="rv" style="margin-bottom:1.4rem">
          <div class="eyebrow"><span class="eyebrow-line"></span>Elected Directors</div>
          <h2 style="color:var(--cobalt-dk)">The full Board</h2>
          <p class="lead" style="margin-top:.4rem">Eight directors serve four-year terms &mdash; four senior and four junior &mdash; with two elected each year, one of each. Only one delegate from any member institution may serve at a time.</p>
        </div>
        <div class="people-grid rv" style="margin-bottom:2.4rem">
          <?php echo implode( "\n", array_map( 'usucger_person_card', $elected ) ); // phpcs:ignore ?>
        </div>
        <div class="rv" style="margin-bottom:1.4rem">
          <div class="eyebrow"><span class="eyebrow-line"></span>Ex-Officio</div>
          <h2 style="color:var(--cobalt-dk)">Ex-officio members</h2>
        </div>
        <div class="people-grid rv">
          <?php echo implode( "\n", array_map( 'usucger_person_card', $exoff ) ); // phpcs:ignore ?>
        </div>
      </div>
      <aside class="sticky-aside rv d2">
        <div class="info-callout">
          <div class="ic-head">&#9993; Reach the Board</div>
          <div class="ic-body">The whole Board can be reached at <a href="mailto:<?php echo $board; // phpcs:ignore ?>"><?php echo $board; // phpcs:ignore ?></a> &mdash; use this address for award nominations, travel grant questions and Council business. Website corrections go to <a href="mailto:<?php echo $web; // phpcs:ignore ?>"><?php echo $web; // phpcs:ignore ?></a>.</div>
        </div>
        <div class="sidebar-card">
          <div class="sc-head">&#128499; How the Board is elected</div>
          <div class="sc-body">
            <p style="font-size:.8rem;color:var(--muted);line-height:1.65">Two directors are elected each year &mdash; one junior and one senior &mdash; by the delegates of the member institutions, and new directors take office at the annual meeting.</p>
            <p style="font-size:.8rem;color:var(--muted);line-height:1.65;margin-top:.6rem">Each member institution holds two votes &mdash; one for a junior faculty candidate and one for a senior faculty candidate. No proxy votes are allowed.</p>
            <a href="<?php echo usucger_u( 'bylaws#article-vi' ); // phpcs:ignore ?>" class="btn btn-outline btn-sm" style="margin-top:.9rem">By-Laws, Article VI &rarr;</a>
          </div>
        </div>
        <div class="sidebar-card">
          <div class="sc-head">&#128203; Board record</div>
          <div class="sc-body">
            <a class="sc-link" href="<?php echo usucger_u( 'minutes' ); // phpcs:ignore ?>"><span class="sc-link-ic">&#128203;</span> Meeting minutes archive</a>
            <a class="sc-link" href="<?php echo usucger_u( 'awards' ); // phpcs:ignore ?>"><span class="sc-link-ic">&#127942;</span> Awards administered by the Board</a>
            <a class="sc-link" href="<?php echo usucger_u( 'travel-grants' ); // phpcs:ignore ?>"><span class="sc-link-ic">&#9992;</span> Student travel grants</a>
            <a class="sc-link" href="<?php echo usucger_u( 'research-grants' ); // phpcs:ignore ?>"><span class="sc-link-ic">&#128176;</span> Small research grants</a>
          </div>
        </div>
      </aside>
    </div>
  </div>
</section>
	<?php
	return ob_get_clean();
} );

/* ------------------------------------------------------------------ minutes */

add_shortcode( 'usucger_minutes', function () {
	$items = usucger_items( 'usucger_minutes' );
	usort( $items, function ( $a, $b ) {
		$c = strcmp( $b['date'], $a['date'] );
		return $c ? $c : $a['id'] - $b['id'];
	} );
	$o    = '<div class="tl">';
	$year = '';
	foreach ( $items as $m ) {
		$y = substr( $m['date'], 0, 4 );
		if ( $y !== $year ) {
			$o   .= '<div class="tl-year">' . esc_html( $y ) . '</div>';
			$year = $y;
		}
		$when  = $m['date_text'] ? $m['date_text'] : usucger_fmt_date( $m['date'], 'F j, Y' );
		$label = $m['label'] ? $m['label'] : 'Open PDF';
		$o    .= '<div class="tl-item' . ( $m['general'] ? ' gen' : '' ) . '"><span class="tl-date">' . usucger_e( $when ) . '</span><span class="tl-kind">' . usucger_e( $m['kind'] ) . '</span><a class="tl-link" href="' . esc_url( $m['file'] ) . '" target="_blank" rel="noopener">' . usucger_e( $label ) . ' &rarr;</a></div>';
	}
	return $o . '</div>';
} );

/* ---------------------------------------------------------------- deadlines */

add_shortcode( 'usucger_deadlines', function () {
	$items = usucger_items( 'usucger_deadline' );
	usort( $items, function ( $a, $b ) {
		return strcmp( $a['date'], $b['date'] );
	} );
	$rows = '';
	foreach ( $items as $d ) {
		$rows .= '<a class="dl-row" href="' . esc_url( usucger_core_url( $d['href'] ? $d['href'] : '' ) ) . '" data-deadline="' . esc_attr( $d['date'] ) . '" data-closed="' . esc_attr( $d['closed'] ) . '"><div class="dl-when"><span class="dl-days">&mdash;</span><span class="dl-unit">days</span></div><div class="dl-body"><div class="dl-label">' . usucger_e( $d['title'] ) . '</div><div class="dl-detail">' . usucger_e( $d['detail'] ) . '</div><div class="dl-date">' . esc_html( usucger_fmt_date( $d['date'] ) ) . '</div></div></a>';
	}
	return '<div class="sidebar-card" id="deadlines"><div class="sc-head">&#128197; Deadlines &amp; dates</div><div class="dl-list">' . $rows . '</div><div class="dl-foot">Countdowns update automatically. Passed dates drop to the bottom.</div></div>';
} );

/* ----------------------------------------------------- directory + universities */

add_shortcode( 'usucger_directory', function () {
	$members = Usucger_Members::directory_rows();
	$inst    = count( array_unique( array_filter( wp_list_pluck( array_map( function ( $r ) {
		return array( 'i' => $r[2] );
	}, $members ), 'i' ) ) ) );
	$cycle   = esc_html( usucger_core_opt( 'cycle' ) );
	$dues    = esc_html( usucger_core_opt( 'dues' ) );
	$end     = esc_html( substr( (string) usucger_core_opt( 'cycle_end' ), 0, 4 ) );
	$web     = esc_html( usucger_core_opt( 'contact_email' ) );
	ob_start();
	?>
<section class="section bg-white">
  <div class="wrap">
    <div class="split">
      <div class="rv">
        <div class="grid-4" style="margin-bottom:1.8rem">
          <div class="card" style="padding:1.2rem 1.3rem"><div class="stat-n" style="font-size:2rem"><?php echo (int) count( $members ); ?></div><div class="stat-l">Listed members</div></div>
          <div class="card" style="padding:1.2rem 1.3rem"><div class="stat-n" style="font-size:2rem"><?php echo (int) $inst; ?></div><div class="stat-l">Affiliations</div></div>
          <div class="card" style="padding:1.2rem 1.3rem"><div class="stat-n" style="font-size:2rem"><?php echo $dues; // phpcs:ignore ?></div><div class="stat-l">Dues per person</div></div>
          <div class="card" style="padding:1.2rem 1.3rem"><div class="stat-n" style="font-size:2rem"><?php echo $end; // phpcs:ignore ?></div><div class="stat-l">Cycle ends</div></div>
        </div>
        <div id="memberTable"></div>
        <p style="font-size:.79rem;color:var(--muted-lt);margin-top:.9rem">Directory reflects dues collected for the <?php echo $cycle; // phpcs:ignore ?> cycle. Missing or incorrect? Email <a href="mailto:<?php echo $web; // phpcs:ignore ?>" style="color:var(--teal);font-weight:600"><?php echo $web; // phpcs:ignore ?></a>.</p>
      </div>
      <aside class="sticky-aside rv d2">
        <div class="info-callout">
          <div class="ic-head">&#128269; Searching the directory</div>
          <div class="ic-body">Type any part of a faculty member's name or an academic institution to filter instantly. Click a column heading to sort, and click again to reverse.</div>
        </div>
        <div class="sidebar-card">
          <div class="sc-head">&#128279; Related</div>
          <div class="sc-body">
            <a class="sc-link" href="<?php echo usucger_u( 'universities' ); // phpcs:ignore ?>"><span class="sc-link-ic">&#127979;</span> Member universities &amp; contacts</a>
            <a class="sc-link" href="<?php echo usucger_u( 'membership' ); // phpcs:ignore ?>"><span class="sc-link-ic">&#128179;</span> Join or renew</a>
            <a class="sc-link" href="<?php echo usucger_u( 'login' ); // phpcs:ignore ?>"><span class="sc-link-ic">&#128274;</span> Member login</a>
            <a class="sc-link" href="<?php echo usucger_u( 'board' ); // phpcs:ignore ?>"><span class="sc-link-ic">&#127963;</span> Board of Directors</a>
          </div>
        </div>
        <div class="info-callout callout-grey">
          <div class="ic-head">Add yourself</div>
          <div class="ic-body">Membership is <?php echo $dues; // phpcs:ignore ?> per person for the full <?php echo $cycle; // phpcs:ignore ?> cycle, in either the University or Associate category. <a href="<?php echo usucger_u( 'membership' ); // phpcs:ignore ?>">See the options &rarr;</a></div>
        </div>
      </aside>
    </div>
  </div>
</section>
<script>
document.addEventListener('DOMContentLoaded', function () {
if (!window.buildDataTable) return;
buildDataTable({
  mount: 'memberTable',
  noun: 'members',
  placeholder: 'Search members by name or institution…',
  defaultSort: 1,
  columns: [{label:'First name'},{label:'Last name'},{label:'Affiliation'}],
  rows: <?php echo wp_json_encode( $members ); ?>
});
});
</script>
	<?php
	return ob_get_clean();
} );

add_shortcode( 'usucger_universities', function () {
	$unis = array();
	foreach ( Usucger_Members::institutions() as $i ) {
		$unis[] = array( $i->name, $i->contact_name );
	}
	ob_start();
	?>
<section class="section bg-white">
  <div class="wrap">
    <div class="rv" style="margin-bottom:2.6rem"><?php echo do_shortcode( '[usucger_member_map]' ); // phpcs:ignore ?></div>
    <div class="split">
      <div class="rv">
        <div id="uniTable"></div>
        <p style="font-size:.79rem;color:var(--muted-lt);margin-top:.9rem">Each member institution designates a contact person who serves as its delegate for Council voting. To update your institution's contact, email <a href="mailto:<?php echo esc_attr( usucger_core_opt( 'contact_email' ) ); ?>" style="color:var(--teal);font-weight:600"><?php echo esc_html( usucger_core_opt( 'contact_email' ) ); ?></a>.</p>
      </div>
      <aside class="sticky-aside rv d2">
        <div class="stat-block">
          <div class="stat-cell"><div class="stat-n"><?php echo (int) count( $unis ); ?></div><div class="stat-l">Institutions</div><div class="stat-d">Geotechnical programs represented in the Council</div></div>
          <div class="stat-cell"><div class="stat-n">2</div><div class="stat-l">Votes each</div><div class="stat-d">One for a junior and one for a senior Board candidate</div></div>
        </div>
        <div class="info-callout">
          <div class="ic-head">&#128220; What membership requires</div>
          <div class="ic-body">Academic institutions in the U.S. with a program of research and/or education in geotechnical engineering are eligible, subject to Board approval. Each institution must have a paid member serving as contact person. <a href="<?php echo usucger_u( 'bylaws#article-iii' ); // phpcs:ignore ?>">By-Laws, Article III &rarr;</a></div>
        </div>
        <div class="sidebar-card">
          <div class="sc-head">&#128279; Related</div>
          <div class="sc-body">
            <a class="sc-link" href="<?php echo usucger_u( 'directory' ); // phpcs:ignore ?>"><span class="sc-link-ic">&#128101;</span> Full membership directory</a>
            <a class="sc-link" href="<?php echo usucger_u( 'membership' ); // phpcs:ignore ?>"><span class="sc-link-ic">&#128179;</span> Membership &amp; dues</a>
            <a class="sc-link" href="<?php echo usucger_u( 'positions' ); // phpcs:ignore ?>"><span class="sc-link-ic">&#128188;</span> Post a faculty position</a>
          </div>
        </div>
      </aside>
    </div>
  </div>
</section>
<script>
document.addEventListener('DOMContentLoaded', function () {
if (!window.buildDataTable) return;
buildDataTable({
  mount: 'uniTable',
  noun: 'institutions',
  placeholder: 'Search institutions or contacts…',
  defaultSort: 0,
  columns: [{label:'Member institution'},{label:'Contact person'}],
  rows: <?php echo wp_json_encode( $unis ); ?>
});
});
</script>
	<?php
	return ob_get_clean();
} );

add_shortcode( 'usucger_count', function ( $atts ) {
	$a = shortcode_atts( array( 'of' => 'members' ), $atts );
	$f = apply_filters( 'usucger_count_value', null, $a['of'] );
	if ( null !== $f ) {
		return $f;
	}
	switch ( $a['of'] ) {
		case 'institutions':
			return (string) count( Usucger_Members::institutions() );
		case 'positions':
			return (string) count( usucger_positions_list( 'academic' ) );
		case 'states':
			$m = usucger_map_data();
			return (string) $m['n_states'];
		default:
			return (string) count( Usucger_Members::directory_rows() );
	}
} );
