<?php
/**
 * Staging mode, for Board review on a SiteGround staging copy before go-live.
 *
 * Switches on automatically on hosts like staging1.usucger.org, when WP_ENVIRONMENT_TYPE is
 * "staging" or "development", or with Settings → Staging. While on:
 *   - email goes ONLY to the allowed addresses (Board, officers, approvers, administrators, and
 *     anyone listed in Settings); every other message is held and recorded in the Activity log
 *   - Cc/Bcc are removed
 *   - checkout is blocked (no real payments on the copy)
 *   - search engines are told not to index the copy
 *   - a banner says it is the staging copy
 *
 * @package usucger-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function usucger_is_staging() {
	if ( defined( 'USUCGER_STAGING' ) ) {
		return (bool) USUCGER_STAGING;
	}
	$mode = (string) usucger_core_opt( 'staging_mode' ); // auto | on | off
	if ( 'on' === $mode ) {
		return true;
	}
	if ( 'off' === $mode ) {
		return false;
	}
	$host = (string) wp_parse_url( home_url(), PHP_URL_HOST );
	return (bool) preg_match( '/^(staging\d*|stage|dev|test)[.-]/i', $host ) || in_array( wp_get_environment_type(), array( 'staging', 'development' ), true );
}

/** Addresses that may receive email on staging. */
function usucger_staging_allowed() {
	static $list = null;
	if ( null !== $list ) {
		return $list;
	}
	$list = array();
	preg_match_all( '/[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}/i', (string) usucger_core_opt( 'staging_allow' ), $m );
	foreach ( $m[0] as $e ) {
		$list[] = strtolower( $e );
	}
	$ids = array_merge( (array) usucger_core_opt( 'approvers' ), (array) usucger_core_opt( 'election_officers' ) );
	foreach ( get_users( array( 'role__in' => array( 'administrator', 'usucger_board', 'usucger_coordinator' ), 'fields' => array( 'ID' ) ) ) as $u ) {
		$ids[] = $u->ID;
	}
	foreach ( array_unique( array_map( 'intval', $ids ) ) as $id ) {
		$u = get_userdata( $id );
		if ( $u ) {
			$list[] = strtolower( $u->user_email );
		}
	}
	foreach ( array( 'contact_email', 'board_email' ) as $k ) {
		if ( is_email( usucger_core_opt( $k ) ) ) {
			$list[] = strtolower( usucger_core_opt( $k ) );
		}
	}
	$list = array_values( array_unique( $list ) );
	return $list;
}

/* Keep only allowed recipients; remember what was held. */
add_filter( 'wp_mail', function ( $atts ) {
	if ( ! usucger_is_staging() ) {
		return $atts;
	}
	$allowed = usucger_staging_allowed();
	$to      = is_array( $atts['to'] ) ? $atts['to'] : explode( ',', (string) $atts['to'] );
	$keep    = array();
	$held    = array();
	foreach ( $to as $addr ) {
		$addr = trim( $addr );
		if ( '' === $addr ) {
			continue;
		}
		$email = strtolower( preg_match( '/<([^>]+)>/', $addr, $mm ) ? $mm[1] : $addr );
		if ( in_array( $email, $allowed, true ) ) {
			$keep[] = $addr;
		} else {
			$held[] = $email;
		}
	}
	// no copies to anyone on staging
	$headers = is_array( $atts['headers'] ) ? $atts['headers'] : preg_split( '/\r?\n/', (string) $atts['headers'] );
	$atts['headers'] = array_values( array_filter( (array) $headers, function ( $h ) {
		return ! preg_match( '/^\s*(cc|bcc)\s*:/i', (string) $h );
	} ) );
	if ( $held ) {
		Usucger_DB::log( 'staging_mail_held', 'email', array( 'subject' => mb_substr( (string) $atts['subject'], 0, 120 ), 'held' => implode( ', ', array_slice( $held, 0, 20 ) ) . ( count( $held ) > 20 ? ' …' : '' ) ) );
	}
	$atts['to']                     = $keep;
	$GLOBALS['usucger_staging_none'] = ! $keep;
	if ( $keep ) {
		$atts['subject'] = '[STAGING] ' . $atts['subject'];
	}
	return $atts;
}, 9999 );

/* Nobody allowed → report "sent" without sending, so queues move on. */
add_filter( 'pre_wp_mail', function ( $pre ) {
	if ( usucger_is_staging() && ! empty( $GLOBALS['usucger_staging_none'] ) ) {
		$GLOBALS['usucger_staging_none'] = false;
		return true;
	}
	return $pre;
}, 1 ); // before SMTP plugins, which also use this filter to send

/* No payments on the copy. */
add_action( 'woocommerce_checkout_process', function () {
	if ( usucger_is_staging() && function_exists( 'wc_add_notice' ) ) {
		wc_add_notice( 'This is the USUCGER staging copy for Board review — payments are switched off. Please use usucger.org to pay dues.', 'error' );
	}
} );
add_action( 'woocommerce_before_checkout_form', function () {
	if ( usucger_is_staging() && function_exists( 'wc_print_notice' ) ) {
		wc_print_notice( 'Staging copy: checkout is switched off. Nothing you enter here is charged.', 'notice' );
	}
} );

/* Not for search engines. */
add_filter( 'wp_robots', function ( $r ) {
	if ( usucger_is_staging() ) {
		$r['noindex']  = true;
		$r['nofollow'] = true;
	}
	return $r;
} );
add_filter( 'robots_txt', function ( $txt ) {
	return usucger_is_staging() ? "User-agent: *\nDisallow: /\n" : $txt;
}, 99 );

/* Banner. */
function usucger_staging_banner_text() {
	if ( defined( 'USUCGER_PREVIEW' ) && USUCGER_PREVIEW ) {
		return 'Preview of the new USUCGER website for Board review — a private copy in your browser with demo accounts. Nothing is sent or saved; usucger.org is not affected.';
	}
	return 'Staging copy for Board review — emails go only to ' . count( usucger_staging_allowed() ) . ' Board/staff addresses; payments are off. Changes here do not affect usucger.org.';
}
add_action( 'wp_body_open', function () {
	if ( usucger_is_staging() ) {
		echo '<div role="note" style="background:#7a2e0a;color:#fff;text-align:center;font:600 13px/1.4 system-ui,sans-serif;padding:7px 12px;position:relative;z-index:9999">' . esc_html( usucger_staging_banner_text() ) . '</div>';
	}
} );
add_action( 'admin_notices', function () {
	if ( usucger_is_staging() && current_user_can( 'edit_posts' ) ) {
		echo '<div class="notice notice-warning"><p><strong>' . esc_html( usucger_staging_banner_text() ) . '</strong> Held emails are listed in <a href="' . esc_url( usucger_admin_url( 'usucger-log', array( 'act' => 'staging_mail_held' ) ) ) . '">Activity log</a>.</p></div>';
	}
} );
add_filter( 'login_message', function ( $m ) {
	return usucger_is_staging() ? '<p class="message">' . esc_html( usucger_staging_banner_text() ) . '</p>' . $m : $m;
} );

/* Preview only: the "public visitor" link signs out of the demo admin that Playground signs in. */
add_action( 'init', function () {
	if ( defined( 'USUCGER_PREVIEW' ) && USUCGER_PREVIEW && isset( $_GET['usucger_preview_public'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		wp_logout();
		wp_safe_redirect( home_url( '/' ) );
		exit;
	}
}, 1 );

/*
 * Preview only: WordPress Playground keeps the site inside the browser tab, so a file opened in a
 * NEW tab cannot be reached ("blocked"). Open uploaded files (PDFs) in the same tab instead.
 */
add_action( 'wp_footer', function () {
	if ( defined( 'USUCGER_PREVIEW' ) && USUCGER_PREVIEW ) {
		echo "<script>document.addEventListener('click',function(e){var a=e.target.closest&&e.target.closest('a[target=_blank]');if(a&&a.href.indexOf('/wp-content/uploads/')>-1){a.removeAttribute('target');}},true);</script>\n";
	}
}, 99 );

/*
 * Preview only: files stored inside the in-browser site cannot be opened on their own, so links
 * to the bundled files (award call, minutes) point to public copies of the same files instead.
 */
add_action( 'template_redirect', function () {
	if ( ! ( defined( 'USUCGER_PREVIEW' ) && USUCGER_PREVIEW ) ) {
		return;
	}
	$names = array_flip( array_diff( (array) scandir( USUCGER_CORE_DIR . 'data/seed/files' ), array( '.', '..' ) ) );
	$base  = defined( 'USUCGER_PREVIEW_FILES' ) ? USUCGER_PREVIEW_FILES : 'https://cdn.jsdelivr.net/gh/Nitin077-lab/usucger-website@main/preview/files/';
	ob_start( function ( $html ) use ( $names, $base ) {
		return preg_replace_callback( '#https?://[^"\'\s>]*/wp-content/uploads/\d{4}/\d{2}/([^"\'\s>?]+)#', function ( $m ) use ( $names, $base ) {
			$file = rawurldecode( $m[1] );
			$orig = preg_replace( '/-\d+(\.[a-z0-9]+)$/i', '$1', $file ); // WordPress adds -1, -2 to repeated names
			if ( isset( $names[ $file ] ) ) {
				return $base . rawurlencode( $file );
			}
			return isset( $names[ $orig ] ) ? $base . rawurlencode( $orig ) : $m[0];
		}, $html );
	} );
}, 0 );
