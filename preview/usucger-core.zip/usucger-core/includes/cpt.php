<?php
/**
 * Content types that drive the data pages: positions, conferences, Board members,
 * meeting minutes and deadlines. All are edited under USUCGER in wp-admin and
 * rendered on pages by shortcodes.
 *
 * @package usucger-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function usucger_cpt_defs() {
	return array(
		'usucger_position'   => array( 'Position', 'Positions', 'dashicons-businessman', 'Position title (e.g. Assistant Professor, Geotechnical Engineering)' ),
		'usucger_conference' => array( 'Conference', 'Conferences', 'dashicons-calendar-alt', 'Conference name' ),
		'usucger_board'      => array( 'Board member', 'Board members', 'dashicons-groups', 'Full name' ),
		'usucger_minutes'    => array( 'Minutes', 'Meeting minutes', 'dashicons-media-document', 'Short title (optional, e.g. 2026 Annual Meeting)' ),
		'usucger_deadline'   => array( 'Deadline', 'Deadlines', 'dashicons-clock', 'Label (e.g. Student travel grants — this cycle)' ),
	);
}

function usucger_cpt_fields( $pt ) {
	switch ( $pt ) {
		case 'usucger_position':
			return array(
				'institution' => array( 'Institution / employer', 'text', 'required' => true ),
				'location'    => array( 'Location', 'text', 'help' => 'City, State' ),
				'url'         => array( 'Link to the official posting', 'url', 'required' => true ),
				'kind'        => array( 'Board', 'select', array( 'academic' => 'Academic positions', 'industry' => 'Industry & agency positions' ) ),
				'posted'      => array( 'Date posted', 'date', 'help' => 'Listings are shown for one year after this date (change in Settings).' ),
				'closes'      => array( 'Closing date (optional)', 'date', 'help' => 'If set, the listing is removed the day after.' ),
			);
		case 'usucger_conference':
			return array(
				'start'     => array( 'Start date', 'date', 'required' => true ),
				'end'       => array( 'End date', 'date' ),
				'year_only' => array( 'Dates', 'checkbox', 'Only the year is known (show "2028")' ),
				'location'  => array( 'Location', 'text', 'help' => 'City, State / Country' ),
				'url'       => array( 'Website', 'url' ),
				'note'      => array( 'Short note (optional)', 'text', 'help' => 'Shown highlighted, e.g. "Geo-Congress is now part of ASCE2027"' ),
			);
		case 'usucger_board':
			return array(
				'role'  => array( 'Role', 'text', 'help' => 'President, Secretary, Membership Coordinator, Webmaster, Senior Director, Junior Director, Ex-officio …' ),
				'seat'  => array( 'Seat', 'select', array( 'senior' => 'Senior seat', 'junior' => 'Junior seat', 'ex' => 'Ex-officio (non-voting)' ) ),
				'inst'  => array( 'Institution', 'text' ),
				'term'  => array( 'Term', 'text', 'help' => 'e.g. 2023–2027' ),
				'photo' => array( 'Photo', 'media', 'help' => 'Or set a featured image.' ),
				'officer' => array( 'Officer strip', 'checkbox', 'Show in the "Council officers" strip' ),
			);
		case 'usucger_minutes':
			return array(
				'date'      => array( 'Meeting date', 'date', 'required' => true ),
				'date_text' => array( 'Date as shown (optional)', 'text', 'help' => 'e.g. "January 23 & February 4, 2005" when it differs from the date.' ),
				'kind'      => array( 'Meeting', 'select', array( 'Annual Meeting' => 'Annual Meeting', 'General Meeting' => 'General Meeting', 'Board Meeting' => 'Board Meeting', 'Special Meeting' => 'Special Meeting' ) ),
				'file'      => array( 'PDF file', 'media', 'required' => true ),
				'label'     => array( 'Link text', 'text', 'help' => 'Default "Open PDF". Use "Open agenda (PDF)" for agendas.' ),
				'general'   => array( 'Highlight', 'checkbox', 'Highlight as a general/annual meeting' ),
			);
		case 'usucger_deadline':
			return array(
				'date'   => array( 'Deadline date', 'date', 'required' => true ),
				'href'   => array( 'Links to (page slug or URL)', 'text', 'help' => 'e.g. travel-grants or awards' ),
				'detail' => array( 'Detail line', 'text' ),
				'closed' => array( 'Text after it closes', 'text' ),
				'awards' => array( 'Awards in this call', 'checks', function_exists( 'usucger_award_types' ) ? array_map( function ( $t ) {
					return $t['name'];
				}, array_filter( usucger_award_types(), function ( $t ) {
					return ! empty( $t['active'] );
				} ) ) : array(), 'help' => 'For an award deadline: which awards are open. None ticked = all current awards.' ),
				'pdf'    => array( 'Call / rules (PDF)', 'media', 'help' => 'Optional. Shown as “Read the call & rules” in the banner at the top of the awards page while this deadline is open.' ),
			);
	}
	return array();
}

function usucger_register_cpts() {
	foreach ( usucger_cpt_defs() as $pt => $d ) {
		register_post_type( $pt, array(
			'labels'          => array(
				'name'          => $d[1],
				'singular_name' => $d[0],
				'add_new_item'  => 'Add ' . strtolower( $d[0] ),
				'edit_item'     => 'Edit ' . strtolower( $d[0] ),
				'all_items'     => $d[1],
				'menu_name'     => $d[1],
			),
			'public'          => false,
			'show_ui'         => true,
			'show_in_menu'    => 'usucger',
			'show_in_rest'    => false,
			'supports'        => 'usucger_board' === $pt ? array( 'title', 'thumbnail', 'page-attributes' ) : array( 'title' ),
			'capability_type' => 'post',
			'map_meta_cap'    => true,
			'menu_icon'       => $d[2],
		) );
	}
}
add_action( 'init', 'usucger_register_cpts' );

add_filter( 'enter_title_here', function ( $t, $post ) {
	$d = usucger_cpt_defs();
	return isset( $d[ $post->post_type ] ) ? $d[ $post->post_type ][3] : $t;
}, 10, 2 );

add_action( 'add_meta_boxes', function () {
	foreach ( usucger_cpt_defs() as $pt => $d ) {
		add_meta_box( 'usg_fields', $d[0] . ' details', function ( $post ) use ( $pt ) {
			usucger_fields_box( $post, usucger_cpt_fields( $pt ), 'usg_' . $pt );
		}, $pt, 'normal', 'high' );
	}
} );

add_action( 'save_post', function ( $post_id, $post ) {
	if ( isset( usucger_cpt_defs()[ $post->post_type ] ) && empty( $GLOBALS['usg_in_title_update'] ) ) {
		usucger_fields_save( $post_id, usucger_cpt_fields( $post->post_type ), 'usg_' . $post->post_type );
		if ( 'usucger_position' === $post->post_type && ! get_post_meta( $post_id, 'posted', true ) ) {
			update_post_meta( $post_id, 'posted', usucger_today() );
		}
		if ( 'usucger_minutes' === $post->post_type && '' === trim( $post->post_title ) ) {
			$date = get_post_meta( $post_id, 'date', true );
			$kind = get_post_meta( $post_id, 'kind', true );
			if ( $date ) {
				$GLOBALS['usg_in_title_update'] = true;
				wp_update_post( array( 'ID' => $post_id, 'post_title' => usucger_fmt_date( $date, 'F j, Y' ) . ' — ' . $kind ) );
				$GLOBALS['usg_in_title_update'] = false;
			}
		}
		usucger_bump_content_version();
	}
}, 10, 2 );

/* Admin list columns. */
add_action( 'admin_init', function () {
	$cols = array(
		'usucger_position'   => array( 'institution' => 'Institution', 'kind' => 'Board', 'posted' => 'Posted', 'state' => 'Shown?' ),
		'usucger_conference' => array( 'start' => 'Start', 'location' => 'Location', 'state' => 'Shown?' ),
		'usucger_board'      => array( 'role' => 'Role', 'seat' => 'Seat', 'inst' => 'Institution', 'term' => 'Term' ),
		'usucger_minutes'    => array( 'date' => 'Date', 'kind' => 'Meeting', 'file' => 'File' ),
		'usucger_deadline'   => array( 'date' => 'Date', 'href' => 'Links to', 'state' => 'Shown?' ),
	);
	foreach ( $cols as $pt => $c ) {
		add_filter( "manage_{$pt}_posts_columns", function ( $columns ) use ( $c ) {
			$date = isset( $columns['date'] ) ? $columns['date'] : null;
			unset( $columns['date'] );
			$columns = array_merge( $columns, $c );
			if ( $date ) {
				$columns['date'] = 'Status';
			}
			return $columns;
		} );
		add_action( "manage_{$pt}_posts_custom_column", function ( $col, $id ) use ( $pt ) {
			if ( 'state' === $col ) {
				echo usucger_is_listed( get_post( $id ) ) ? '<span style="color:#008a20">Yes</span>' : '<span style="color:#996800">No — expired or past</span>';
				return;
			}
			$v = get_post_meta( $id, $col, true );
			if ( 'file' === $col && $v ) {
				echo '<a href="' . esc_url( $v ) . '" target="_blank" rel="noopener">' . esc_html( wp_basename( $v ) ) . '</a>';
				return;
			}
			echo esc_html( $v );
		}, 10, 2 );
	}
} );

/** Is this item currently shown on the public site (published and not expired)? */
function usucger_is_listed( $p ) {
	if ( ! $p || 'publish' !== $p->post_status ) {
		return false;
	}
	$today = usucger_today();
	switch ( $p->post_type ) {
		case 'usucger_position':
			$posted = get_post_meta( $p->ID, 'posted', true );
			$closes = get_post_meta( $p->ID, 'closes', true );
			if ( $closes && $closes < $today ) {
				return false;
			}
			return ! $posted || usucger_days_between( $posted, $today ) <= (int) usucger_core_opt( 'position_days' );
		case 'usucger_conference':
			$start = get_post_meta( $p->ID, 'start', true );
			$end   = get_post_meta( $p->ID, 'end', true );
			if ( get_post_meta( $p->ID, 'year_only', true ) ) {
				$end = substr( $start, 0, 4 ) . '-12-31';
			}
			return ( $end ? $end : $start ) >= $today;
		case 'usucger_deadline':
			return true; // passed deadlines stay (they sort to the bottom and show their "closed" text)
	}
	return true;
}

/** Fetch published items of a type with their meta, filtered to what is listed. */
function usucger_items( $pt, $args = array() ) {
	$q   = get_posts( array_merge( array(
		'post_type'      => $pt,
		'post_status'    => 'publish',
		'posts_per_page' => -1,
		'orderby'        => 'menu_order title',
		'order'          => 'ASC',
		'no_found_rows'  => true,
	), $args ) );
	$out = array();
	foreach ( $q as $p ) {
		if ( ! usucger_is_listed( $p ) ) {
			continue;
		}
		$row = array( 'id' => $p->ID, 'title' => $p->post_title, 'order' => $p->menu_order );
		foreach ( array_keys( usucger_cpt_fields( $pt ) ) as $k ) {
			$row[ $k ] = get_post_meta( $p->ID, $k, true );
		}
		$out[] = $row;
	}
	return $out;
}

/** Content version: bumps whenever pages or data change (search index cache key). */
function usucger_bump_content_version() {
	update_option( 'usucger_content_ver', time(), false );
}
add_action( 'save_post_page', 'usucger_bump_content_version' );
add_action( 'deleted_post', 'usucger_bump_content_version' );

/* Daily: unpublish positions that have expired (kept as drafts, so nothing is lost). */
add_action( 'usucger_daily', function () {
	foreach ( get_posts( array( 'post_type' => 'usucger_position', 'post_status' => 'publish', 'posts_per_page' => -1 ) ) as $p ) {
		if ( ! usucger_is_listed( $p ) ) {
			wp_update_post( array( 'ID' => $p->ID, 'post_status' => 'draft' ) );
			update_post_meta( $p->ID, '_usucger_expired', usucger_today() );
			Usucger_DB::log( 'position_expired', 'post:' . $p->ID, $p->post_title );
		}
	}
} );
