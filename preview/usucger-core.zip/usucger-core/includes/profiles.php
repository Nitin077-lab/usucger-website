<?php
/**
 * Member profiles (user meta), expertise finder, member-to-member contact form,
 * and passwordless "email me a login link".
 *
 * Profile meta on the WordPress user:
 *   usg_rank       Assistant Professor | Associate Professor | Professor | Lecturer / Teaching | Research Scientist | Postdoc | Student | Practitioner | Emeritus | Other
 *   usg_title      free text (e.g. "Associate Professor of Civil Engineering")
 *   usg_expertise  comma-separated tags
 *   usg_summary    short research summary
 *   usg_links      array( scholar, orcid, web, linkedin )
 *   usg_photo      attachment id
 *   usg_visible    1 = listed in the expertise finder (members only), 0 = hidden
 *
 * @package usucger-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function usucger_ranks() {
	return array(
		'Assistant Professor'  => 'junior',
		'Associate Professor'  => 'senior',
		'Professor'            => 'senior',
		'Professor Emeritus'   => 'other',
		'Lecturer / Teaching Professor' => 'other',
		'Research Scientist / Engineer' => 'other',
		'Postdoctoral Researcher'       => 'other',
		'Graduate Student'     => 'other',
		'Practitioner / Industry'       => 'other',
		'Government / Agency'  => 'other',
		'Other'                => 'other',
	);
}

/** Suggested expertise vocabulary (members can add their own tags too). */
function usucger_expertise_vocab() {
	return apply_filters( 'usucger_expertise_vocab', array(
		'Bio-geotechnics', 'Centrifuge modeling', 'Coastal & marine geotechnics', 'Constitutive modeling', 'CPT & in-situ testing',
		'Dams & levees', 'Data science & machine learning', 'Deep foundations', 'Earth retaining structures', 'Earthquake engineering',
		'Energy geotechnics', 'Engineering geology', 'Environmental geotechnics', 'Excavations & tunneling', 'Expansive & problematic soils',
		'Frozen ground & permafrost', 'Geophysics', 'Geosynthetics', 'Geotechnical asset management', 'Ground improvement',
		'Landslides & slope stability', 'Liquefaction', 'Numerical methods', 'Offshore geotechnics', 'Pavement geotechnics',
		'Reliability & risk', 'Rock mechanics', 'Sensing & monitoring', 'Shallow foundations', 'Site characterization',
		'Soil dynamics', 'Transportation geotechnics', 'Unsaturated soils', 'Waste containment & landfills', 'Wind & renewable energy foundations',
		'Geotechnical education',
	) );
}

function usucger_profile( $user_id ) {
	$u = get_userdata( $user_id );
	if ( ! $u ) {
		return null;
	}
	$links = get_user_meta( $user_id, 'usg_links', true );
	$c     = Usucger_Members::find_for_user( $user_id, strtolower( $u->user_email ), $u->first_name, $u->last_name );
	$photo = (int) get_user_meta( $user_id, 'usg_photo', true );
	return (object) array(
		'id'          => $user_id,
		'name'        => trim( $u->first_name . ' ' . $u->last_name ) ? trim( $u->first_name . ' ' . $u->last_name ) : $u->display_name,
		'first'       => $u->first_name,
		'last'        => $u->last_name,
		'email'       => $u->user_email,
		'rank'        => (string) get_user_meta( $user_id, 'usg_rank', true ),
		'title'       => (string) get_user_meta( $user_id, 'usg_title', true ),
		'expertise'   => array_values( array_filter( array_map( 'trim', explode( ',', (string) get_user_meta( $user_id, 'usg_expertise', true ) ) ) ) ),
		'summary'     => (string) get_user_meta( $user_id, 'usg_summary', true ),
		'links'       => is_array( $links ) ? $links : array(),
		'photo'       => $photo ? wp_get_attachment_image_url( $photo, 'thumbnail' ) : '',
		'visible'     => '1' === get_user_meta( $user_id, 'usg_visible', true ), // opt-in
		'institution' => $c ? $c->institution : (string) get_user_meta( $user_id, usucger_core_opt( 'institution_meta' ), true ),
		'status'      => $c ? $c->status : '',
		'contact'     => $c,
	);
}

/** Profile completeness 0–100 and the missing pieces. */
function usucger_profile_completeness( $p ) {
	$parts = array(
		'photo'     => array( (bool) $p->photo, 'a photo' ),
		'rank'      => array( (bool) $p->rank, 'your rank' ),
		'title'     => array( (bool) $p->title, 'your title' ),
		'inst'      => array( (bool) $p->institution, 'your institution' ),
		'expertise' => array( count( $p->expertise ) >= 2, 'at least two expertise areas' ),
		'summary'   => array( strlen( $p->summary ) >= 60, 'a short research summary' ),
		'links'     => array( (bool) array_filter( $p->links ), 'a profile link (Scholar / ORCID / website)' ),
	);
	$done    = count( array_filter( wp_list_pluck( $parts, 0 ) ) );
	$missing = array();
	foreach ( $parts as $x ) {
		if ( ! $x[0] ) {
			$missing[] = $x[1];
		}
	}
	return array( (int) round( 100 * $done / count( $parts ) ), $missing );
}

/** Is the current visitor allowed into the members-only areas? */
function usucger_is_member_viewer() {
	if ( ! is_user_logged_in() ) {
		return false;
	}
	if ( current_user_can( 'usucger_view_members' ) || current_user_can( 'manage_options' ) ) {
		return true;
	}
	$c = usucger_my_contact();
	return $c && 'current' === $c->status;
}

/**
 * Expertise search. Returns profiles of users who are current members (or Board),
 * visible, matching all words in $q (name, institution, tags, summary) and the tag/state filters.
 */
function usucger_expert_search( $q = '', $tag = '', $state = '', $limit = 200 ) {
	global $wpdb;
	$ids = $wpdb->get_col( "SELECT DISTINCT user_id FROM {$wpdb->usermeta} WHERE meta_key IN ('usg_expertise','usg_summary','usg_title') AND meta_value <> ''" ); // phpcs:ignore WordPress.DB
	$ct  = Usucger_DB::t( 'contacts' );
	$cur = array_flip( array_map( 'intval', $wpdb->get_col( "SELECT user_id FROM $ct WHERE status = 'current' AND user_id > 0" ) ) ); // phpcs:ignore WordPress.DB
	$st  = array();
	if ( $state ) {
		foreach ( Usucger_Members::institutions() as $i ) {
			if ( $i->state === $state ) {
				$st[ usucger_norm( $i->name ) ] = true;
			}
		}
	}
	$words = array_filter( preg_split( '/\s+/', mb_strtolower( trim( $q ) ) ) );
	$out   = array();
	foreach ( $ids as $uid ) {
		$uid = (int) $uid;
		if ( ! isset( $cur[ $uid ] ) && ! user_can( $uid, 'usucger_compose' ) ) {
			continue;
		}
		$p = usucger_profile( $uid );
		if ( ! $p || ! $p->visible ) {
			continue;
		}
		if ( $tag && ! in_array( mb_strtolower( $tag ), array_map( 'mb_strtolower', $p->expertise ), true ) ) {
			continue;
		}
		if ( $state && ! isset( $st[ usucger_norm( $p->institution ) ] ) ) {
			continue;
		}
		$hay   = mb_strtolower( $p->name . ' ' . $p->institution . ' ' . $p->title . ' ' . implode( ' ', $p->expertise ) . ' ' . $p->summary );
		$score = 0;
		foreach ( $words as $w ) {
			if ( false === mb_strpos( $hay, $w ) ) {
				continue 2;
			}
			$score += false !== mb_strpos( mb_strtolower( implode( ' ', $p->expertise ) ), $w ) ? 3 : 1;
		}
		$p->score = $score;
		$out[]    = $p;
	}
	usort( $out, function ( $a, $b ) {
		return $b->score - $a->score ? $b->score - $a->score : strcmp( $a->last, $b->last );
	} );
	return array_slice( $out, 0, $limit );
}

/** Tag cloud: tag => count among visible profiles. */
function usucger_expertise_counts() {
	global $wpdb;
	$counts = array();
	foreach ( $wpdb->get_col( "SELECT meta_value FROM {$wpdb->usermeta} WHERE meta_key = 'usg_expertise' AND meta_value <> ''" ) as $v ) { // phpcs:ignore WordPress.DB
		foreach ( array_filter( array_map( 'trim', explode( ',', $v ) ) ) as $t ) {
			$counts[ $t ] = isset( $counts[ $t ] ) ? $counts[ $t ] + 1 : 1;
		}
	}
	arsort( $counts );
	return $counts;
}

/* ----------------------------------------------------------- save profile */

add_action( 'admin_post_usucger_profile', function () {
	check_admin_referer( 'usucger_profile' );
	$uid = get_current_user_id();
	$p   = wp_unslash( $_POST );
	$ranks = usucger_ranks();
	wp_update_user( array(
		'ID'         => $uid,
		'first_name' => sanitize_text_field( $p['first_name'] ),
		'last_name'  => sanitize_text_field( $p['last_name'] ),
	) );
	update_user_meta( $uid, 'usg_rank', isset( $ranks[ $p['rank'] ] ) ? $p['rank'] : '' );
	update_user_meta( $uid, 'usg_title', sanitize_text_field( $p['title'] ) );
	$tags = array();
	foreach ( (array) ( isset( $p['expertise'] ) ? $p['expertise'] : array() ) as $t ) {
		$tags[] = sanitize_text_field( $t );
	}
	foreach ( explode( ',', (string) $p['expertise_other'] ) as $t ) {
		$t = trim( sanitize_text_field( $t ) );
		if ( $t && mb_strlen( $t ) <= 50 ) {
			$tags[] = mb_convert_case( $t, MB_CASE_TITLE ) === $t ? $t : ucfirst( $t );
		}
	}
	update_user_meta( $uid, 'usg_expertise', implode( ', ', array_slice( array_unique( array_filter( $tags ) ), 0, 12 ) ) );
	update_user_meta( $uid, 'usg_summary', mb_substr( sanitize_textarea_field( $p['summary'] ), 0, 900 ) );
	update_user_meta( $uid, 'usg_links', array(
		'scholar'  => esc_url_raw( $p['scholar'] ),
		'orcid'    => esc_url_raw( $p['orcid'] ),
		'web'      => esc_url_raw( $p['web'] ),
		'linkedin' => esc_url_raw( $p['linkedin'] ),
	) );
	update_user_meta( $uid, 'usg_visible', empty( $p['visible'] ) ? '0' : '1' );
	$inst_q = '';
	if ( ! empty( $p['institution'] ) ) {
		$inst_q = usucger_change_institution( usucger_my_contact(), $p['institution'] );
	}
	// photo upload (jpg/png/webp, max 3 MB)
	if ( ! empty( $_FILES['photo']['name'] ) && empty( $_FILES['photo']['error'] ) ) {
		$type = wp_check_filetype( sanitize_file_name( $_FILES['photo']['name'] ) );
		if ( in_array( $type['ext'], array( 'jpg', 'jpeg', 'png', 'webp' ), true ) && (int) $_FILES['photo']['size'] <= 3 * MB_IN_BYTES ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			require_once ABSPATH . 'wp-admin/includes/media.php';
			require_once ABSPATH . 'wp-admin/includes/image.php';
			$aid = media_handle_upload( 'photo', 0, array( 'post_author' => $uid ) );
			if ( ! is_wp_error( $aid ) ) {
				$old = (int) get_user_meta( $uid, 'usg_photo', true );
				if ( $old && (int) get_post_field( 'post_author', $old ) === $uid ) {
					wp_delete_attachment( $old, true );
				}
				update_user_meta( $uid, 'usg_photo', $aid );
			}
		}
	}
	if ( ! empty( $p['remove_photo'] ) ) {
		delete_user_meta( $uid, 'usg_photo' );
	}
	usucger_bump_content_version();
	wp_safe_redirect( add_query_arg( array( 'tab' => 'profile', 'saved' => 'queued' === $inst_q ? 'inst' : 1 ), usucger_portal_url() ) );
	exit;
} );

/* ------------------------------------------------- member-to-member contact */

add_action( 'admin_post_usucger_contact_member', function () {
	check_admin_referer( 'usucger_contact_member' );
	if ( ! usucger_is_member_viewer() ) {
		wp_die( 'Members only.' );
	}
	$to   = (int) $_POST['to'];
	$msg  = trim( sanitize_textarea_field( wp_unslash( $_POST['message'] ) ) );
	$back = add_query_arg( array( 'tab' => 'experts', 'person' => $to ), usucger_portal_url() );
	$sent = (int) get_transient( 'usg_msgs_' . get_current_user_id() );
	if ( $sent >= 10 ) {
		wp_safe_redirect( add_query_arg( 'msg', 'limit', $back ) );
		exit;
	}
	$p  = usucger_profile( $to );
	$me = usucger_profile( get_current_user_id() );
	if ( ! $p || ! $p->visible || mb_strlen( $msg ) < 10 ) {
		wp_safe_redirect( add_query_arg( 'msg', 'error', $back ) );
		exit;
	}
	$body = '<p>' . esc_html( $me->name ) . ( $me->institution ? ' (' . esc_html( $me->institution ) . ')' : '' ) . ' sent you a message through the USUCGER member area:</p>'
		. '<blockquote style="border-left:3px solid #ddd;margin:0 0 14px;padding:6px 14px;color:#333">' . nl2br( esc_html( $msg ) ) . '</blockquote>'
		. '<p>Reply to this email to answer ' . esc_html( $me->first ? $me->first : $me->name ) . ' directly — your address is shared only if you reply.</p>';
	$html = usucger_email_letter( usucger_email_inline( $body ), 'Sent through the USUCGER member directory. You can hide your profile in the member area.' );
	$headers   = usucger_mail_headers();
	$headers   = array_values( array_filter( $headers, function ( $h ) {
		return 0 !== stripos( $h, 'Reply-To:' );
	} ) );
	$headers[] = 'Reply-To: ' . $me->name . ' <' . $me->email . '>';
	wp_mail( $p->email, 'USUCGER member message from ' . $me->name, $html, $headers );
	set_transient( 'usg_msgs_' . get_current_user_id(), $sent + 1, DAY_IN_SECONDS );
	Usucger_DB::log( 'member_message', 'user:' . $to, 'from user ' . get_current_user_id() );
	wp_safe_redirect( add_query_arg( 'msg', 'sent', $back ) );
	exit;
} );

/* ------------------------------------------------------- email login link */

add_action( 'init', function () {
	// request a link
	if ( isset( $_POST['usg_login_link'] ) && isset( $_POST['usg_ll_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['usg_ll_nonce'] ) ), 'usg_login_link' ) ) {
		$email = strtolower( sanitize_email( wp_unslash( $_POST['usg_login_link'] ) ) );
		$key   = 'usg_ll_' . md5( $email );
		if ( is_email( $email ) && ! get_transient( $key ) ) {
			set_transient( $key, 1, 2 * MINUTE_IN_SECONDS );
			$u = get_user_by( 'email', $email );
			if ( $u && ! user_can( $u, 'manage_options' ) && ! in_array( (int) $u->ID, array_map( 'intval', (array) usucger_core_opt( 'approvers' ) ), true ) && ! usucger_2fa_required( $u ) ) { // staff use password + sign-in code
				$token = wp_generate_password( 40, false, false );
				update_user_meta( $u->ID, 'usg_login_token', array( wp_hash_password( $token ), time() + 20 * MINUTE_IN_SECONDS ) );
				$link  = add_query_arg( array( 'usg_login' => $token, 'u' => $u->ID ), usucger_portal_url() );
				$body  = '<p>Hello ' . esc_html( $u->first_name ? $u->first_name : $u->display_name ) . ',</p><p>Use the button below to sign in to the USUCGER member area. The link works once and expires in 20 minutes.</p>'
					. '<table role="presentation" cellpadding="0" cellspacing="0" style="margin:0 0 18px"><tr><td style="background:#C2410C;border-radius:4px"><a href="' . esc_url( $link ) . '" style="display:inline-block;padding:12px 22px;font-family:Arial,sans-serif;font-size:15px;font-weight:700;color:#fff;text-decoration:none">Sign in to USUCGER &rarr;</a></td></tr></table>'
					. '<p style="font-size:13px;color:#686460">If you did not ask for this, you can ignore this email.</p>';
				wp_mail( $email, 'Your USUCGER sign-in link', usucger_email_letter( usucger_email_inline( $body ), 'Automatic message from usucger.org.' ), usucger_mail_headers() );
			}
		}
		wp_safe_redirect( add_query_arg( 'linksent', 1, usucger_portal_url() ) );
		exit;
	}
	// use a link. GET only shows a "Continue" button: university link scanners (Safe Links,
	// Proofpoint) open links automatically and would otherwise use up the one-time token.
	if ( isset( $_REQUEST['usg_login'], $_REQUEST['u'] ) && ! is_user_logged_in() ) { // phpcs:ignore WordPress.Security.NonceVerification
		$uid = (int) $_REQUEST['u']; // phpcs:ignore WordPress.Security.NonceVerification
		$tok = sanitize_text_field( wp_unslash( $_REQUEST['usg_login'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
		if ( 'POST' !== ( isset( $_SERVER['REQUEST_METHOD'] ) ? $_SERVER['REQUEST_METHOD'] : '' ) ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
			nocache_headers();
			wp_die( '<h2 style="font-family:Georgia,serif">Sign in to USUCGER</h2><form method="post"><input type="hidden" name="usg_login" value="' . esc_attr( $tok ) . '"><input type="hidden" name="u" value="' . (int) $uid . '"><button type="submit" style="background:#1A1A1A;color:#fff;border:0;border-radius:6px;padding:12px 22px;font-size:16px;font-weight:700;cursor:pointer">Continue to the member area &rarr;</button></form>', 'Sign in — USUCGER', array( 'response' => 200 ) );
		}
		$data = get_user_meta( $uid, 'usg_login_token', true );
		$ok   = is_array( $data ) && $data[1] >= time() && wp_check_password( $tok, $data[0], $uid ) && ! user_can( $uid, 'manage_options' ) && ! user_can( $uid, 'usucger_approve' ) && ! usucger_2fa_required( get_userdata( $uid ) );
		if ( $ok ) {
			delete_user_meta( $uid, 'usg_login_token' ); // used up only on success
			wp_set_current_user( $uid );
			wp_set_auth_cookie( $uid, true );
			Usucger_DB::log( 'login_link_used', 'user:' . $uid );
			wp_safe_redirect( usucger_portal_url() );
		} else {
			wp_safe_redirect( add_query_arg( 'linkbad', 1, usucger_portal_url() ) );
		}
		exit;
	}
} );

/* Track last visit (for "new since your last visit"). */
add_action( 'template_redirect', function () {
	if ( is_user_logged_in() && ! wp_doing_ajax() ) {
		$uid  = get_current_user_id();
		$seen = (int) get_user_meta( $uid, 'usg_seen', true );
		if ( time() - $seen > HOUR_IN_SECONDS ) {
			update_user_meta( $uid, 'usg_prev_seen', $seen ? $seen : time() );
			update_user_meta( $uid, 'usg_seen', time() );
		}
	}
}, 5 );
