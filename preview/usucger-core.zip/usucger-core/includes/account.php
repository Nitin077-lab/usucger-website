<?php
/**
 * Member self-service: a "USUCGER membership" tab in WooCommerce My Account (also
 * available anywhere as [usucger_my_membership]) showing status, end date, a renew
 * button, directory listing on/off, institution, and email preferences.
 *
 * @package usucger-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function usucger_my_contact() {
	$u = wp_get_current_user();
	if ( ! $u->ID ) {
		return null;
	}
	$c = Usucger_Members::find_for_user( $u->ID, strtolower( $u->user_email ), $u->first_name, $u->last_name );
	return $c;
}

function usucger_my_membership_html() {
	if ( ! is_user_logged_in() ) {
		return '<div class="usg-notice">Please <a href="' . esc_url( usucger_core_url( 'login' ) ) . '">log in</a> to see your membership.</div>';
	}
	$c     = usucger_my_contact();
	$cycle = esc_html( usucger_core_opt( 'cycle' ) );
	$o     = '';
	if ( isset( $_GET['usg_saved'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		$o .= '<div class="usg-notice" style="margin-bottom:1rem"><strong>Saved.</strong> Your preferences are updated.' . ( 'inst' === $_GET['usg_saved'] ? ' Your new institution will show once the Membership Coordinator confirms it (it decides which institution you vote with).' : '' ) . '</div>'; // phpcs:ignore
	}
	if ( ! $c ) {
		return $o . '<div class="usg-notice"><strong>No USUCGER membership found for this account.</strong><br>Membership is ' . esc_html( usucger_core_opt( 'dues' ) ) . ' per person for the ' . $cycle . ' cycle. <a href="' . esc_url( usucger_core_url( 'membership' ) ) . '">See the options &rarr;</a><br><span style="font-size:.85em">Already paid under a different email? Write to ' . esc_html( usucger_core_opt( 'contact_email' ) ) . '.</span></div>';
	}
	$labels = array( 'current' => 'Active member', 'lapsed' => 'Not renewed for ' . $cycle, 'former' => 'Former member', 'prospect' => 'Not a member' );
	$o     .= '<div class="usg-notice" style="margin-bottom:1.2rem"><strong>' . esc_html( isset( $labels[ $c->status ] ) ? $labels[ $c->status ] : $c->status ) . '</strong>';
	if ( $c->category ) {
		$o .= ' &middot; ' . esc_html( $c->category );
	}
	if ( $c->end_date ) {
		$o .= '<br>Membership ' . ( $c->end_date < usucger_today() ? 'ended' : 'runs through' ) . ' ' . esc_html( usucger_fmt_date( $c->end_date, 'F j, Y' ) ) . '.';
	}
	if ( 'current' !== $c->status ) {
		$o .= '<br><a class="btn btn-amber" style="margin-top:.8rem" href="' . esc_url( usucger_renew_url() ) . '">Renew for ' . esc_html( usucger_core_opt( 'dues' ) ) . ' (' . $cycle . ') &rarr;</a>';
	}
	if ( in_array( $c->status, array( 'current', 'lapsed' ), true ) && function_exists( 'usucger_receipt_url' ) ) {
		$o .= '<br><a href="' . esc_url( usucger_receipt_url() ) . '" target="_blank" rel="noopener">Printable membership confirmation &rarr;</a>';
	}
	$o .= '</div>';
	$o .= '<form method="post" class="usg-prefs" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">' . wp_nonce_field( 'usucger_prefs', '_wpnonce', true, false ) . '<input type="hidden" name="action" value="usucger_prefs">';
	$pend = function_exists( 'usucger_inst_requests' ) ? usucger_inst_requests() : array();
	$o   .= '<p><label for="usg_inst"><strong>Institution / affiliation</strong> (as shown in the directory)</label><br><input type="text" id="usg_inst" name="institution" value="' . esc_attr( $c->institution ) . '" style="width:100%;max-width:520px">' . ( isset( $pend[ $c->id ] ) ? '<br><small>Change to “' . esc_html( $pend[ $c->id ]['new'] ) . '” is waiting for confirmation.</small>' : '' ) . '</p>';
	$o .= '<p><label><input type="checkbox" name="in_directory" value="1"' . checked( (int) $c->in_directory, 1, false ) . '> List me in the public membership directory and member map (current members only)</label></p>';
	$o .= '<p><strong>Email</strong><br><label><input type="checkbox" name="news" value="1"' . checked( (int) $c->unsub_news, 0, false ) . '> USUCGER announcements (awards, grants, positions, meetings)</label><br>';
	$o .= '<label><input type="checkbox" name="renewal" value="1"' . checked( (int) $c->unsub_renewal, 0, false ) . '> Membership renewal reminders</label></p>';
	$o .= '<p><button type="submit" class="btn btn-cobalt">Save preferences</button></p></form>';
	return $o;
}

add_shortcode( 'usucger_my_membership', 'usucger_my_membership_html' );

add_action( 'admin_post_usucger_prefs', function () {
	check_admin_referer( 'usucger_prefs' );
	$c = usucger_my_contact();
	if ( $c ) {
		global $wpdb;
		$wpdb->update( Usucger_DB::t( 'contacts' ), array(
			'in_directory'  => empty( $_POST['in_directory'] ) ? 0 : 1,
			'unsub_news'    => empty( $_POST['news'] ) ? 1 : 0,
			'unsub_renewal' => empty( $_POST['renewal'] ) ? 1 : 0,
			'updated'       => current_time( 'mysql' ),
		), array( 'id' => $c->id ) );
		$q = usucger_change_institution( $c, wp_unslash( isset( $_POST['institution'] ) ? $_POST['institution'] : '' ) );
		Usucger_DB::log( 'member_prefs', 'contact:' . $c->id );
		usucger_bump_content_version();
	}
	wp_safe_redirect( add_query_arg( 'usg_saved', isset( $q ) && 'queued' === $q ? 'inst' : 1, wp_get_referer() ? wp_get_referer() : home_url( '/' ) ) );
	exit;
} );

/* WooCommerce My Account tab. */
add_action( 'init', function () {
	if ( function_exists( 'WC' ) ) {
		add_rewrite_endpoint( 'usucger-membership', EP_ROOT | EP_PAGES );
	}
} );
add_filter( 'woocommerce_account_menu_items', function ( $items ) {
	$new = array();
	foreach ( $items as $k => $v ) {
		$new[ $k ] = $v;
		if ( 'dashboard' === $k ) {
			$new['usucger-membership'] = 'USUCGER membership';
		}
	}
	return $new;
} );
add_action( 'woocommerce_account_usucger-membership_endpoint', function () {
	echo usucger_my_membership_html(); // phpcs:ignore WordPress.Security.EscapeOutput
} );
