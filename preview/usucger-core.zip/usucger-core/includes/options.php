<?php
/**
 * Settings store (single option "usucger_core").
 *
 * @package usucger-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function usucger_core_defaults() {
	return array(
		// identity / contact
		'contact_email'      => 'webmaster@usucger.org',
		'board_email'        => 'uboard@usucger.org',
		'credit'             => 'Website designed by Dr. Nitin Tiwari, Southern Illinois University Carbondale, IL',
		// email sending
		'from_name'          => 'USUCGER',
		'from_email'         => 'webmaster@usucger.org',
		'reply_to'           => 'webmaster@usucger.org',
		'notify_emails'      => '', // approvers to notify; empty = all administrators
		'batch_size'         => 8, // emails per minute (SiteGround limits hourly sending; use an SMTP service to go faster)
		'letter_color'       => '#C2410C',
		'signer_name'        => 'Estéfan Garcia',
		'signer_title'       => 'Membership Coordinator, USUCGER',
		'annual_meeting'     => 'the USUCGER Annual Meeting at the ASCE Conference (ASCE2027) in Philadelphia',
		'mailing_address'    => 'USUCGER · United States Universities Council on Geotechnical Education and Research',
		// membership
		'cycle'              => '2025–2027',
		'cycle_end'          => '2027-12-31',
		'dues'               => '$75',
		'join_univ'          => 'https://usucger.org/membership/usucger-3-year-membership-us-universities-2025-2027/',
		'join_assoc'         => 'https://usucger.org/membership/usucger-3-year-membership-associate-2025-2027/',
		'renew_url'          => '',  // empty = join_univ
		'current_plans'      => array( 2547, 2626 ), // usucger.org: US Universities + Associate 2025–2027 (check in Settings)
		'previous_plans'     => array( 903, 900, 194, 77 ), // usucger.org: 2022–2024 and 2019–2021 plans
		'institution_meta'   => 'billing_company', // user meta holding the member's institution
		'grace_days'         => 60,
		'auto_sync'          => 1,
		'auto_queue_plan'    => 0, // 1 = scheduled reminders are approved automatically
		// workflow
		'board_unfiltered'   => 1, // Board role may save HTML/scripts (changes are still reviewed)
		'board_can_send'     => 0, // 1 = Board emails skip approval
		'position_days'      => 365,
		'election_officers'  => array(), // user IDs who run elections and approve election emails
		'approver_titles'    => array(),
		'approvers'          => array(), // President (and any co-approvers): same approval authority as the webmaster
		// tracking
		'track_views'        => 1,
		'delete_on_uninstall' => 0,
		'form_positions'     => 1, // "Post a position" opens the online form instead of email
		'form_awards'        => 1, // award nominations use the online form
		'form_travel'        => 0, // travel grants keep the Google Form until switched on
		'two_factor'         => 1, // email sign-in code for administrators, approvers, officers and Board
		'bounce_secret'      => '', // shared secret for the bounce webhook (empty = webhook off)
		'retention_days'     => 400, // email bodies in the outbox are cleared after this many days
		'staging_mode'       => 'auto', // auto (staging hosts) | on | off
		'staging_allow'      => '', // extra addresses that may receive email on staging
		'token_purge_days'   => 60, // ballot links are cleared this many days after certification
	);
}

function usucger_core_opts() {
	if ( empty( $GLOBALS['usucger_opts_cache'] ) ) {
		$GLOBALS['usucger_opts_cache'] = wp_parse_args( (array) get_option( 'usucger_core', array() ), usucger_core_defaults() );
	}
	return $GLOBALS['usucger_opts_cache'];
}

function usucger_core_opt( $key ) {
	$o = usucger_core_opts();
	return isset( $o[ $key ] ) ? $o[ $key ] : null;
}

function usucger_core_save_opts( $new ) {
	$cur = (array) get_option( 'usucger_core', array() );
	update_option( 'usucger_core', array_merge( $cur, $new ), false );
	$GLOBALS['usucger_opts_cache'] = null;
}

function usucger_renew_url() {
	$u = usucger_core_opt( 'renew_url' );
	return $u ? $u : usucger_core_opt( 'join_univ' );
}

/** Link resolver: uses the theme's usucger_url() when the USUCGER theme is active. */
function usucger_core_url( $ref ) {
	if ( function_exists( 'usucger_url' ) ) {
		return usucger_url( $ref );
	}
	if ( preg_match( '#^(https?:|mailto:)#i', $ref ) ) {
		return $ref;
	}
	$frag = '';
	if ( false !== strpos( $ref, '#' ) ) {
		list( $ref, $frag ) = explode( '#', $ref, 2 );
		$frag = '#' . $frag;
	}
	$slug = preg_replace( '#\.html?$#', '', trim( $ref, '/' ) );
	if ( '' === $slug || 'index' === $slug ) {
		return home_url( '/' ) . $frag;
	}
	if ( 'login' === $slug ) {
		return ( function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : wp_login_url() ) . $frag;
	}
	$p = get_page_by_path( $slug );
	return ( $p ? get_permalink( $p ) : home_url( '/' . $slug . '/' ) ) . $frag;
}
