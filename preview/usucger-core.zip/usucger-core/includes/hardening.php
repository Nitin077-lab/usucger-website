<?php
/**
 * Production hardening: page caching exclusions, old-URL redirects, privacy export/erase,
 * cron health and a lock for the daily job.
 *
 * @package usucger-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* --------------------------------------------------- never cache personal pages */
add_action( 'template_redirect', function () {
	$personal = is_user_logged_in() || is_page( array( 'members', 'elections', 'webmaster', 'post-a-position', 'nominate', 'travel-grant-application' ) ); // forms carry nonces
	foreach ( array( 'usg_ballot', 'usg_packet', 'usg_nominee', 'usg_login', 'usucger_unsub', 'receipt' ) as $q ) {
		$personal = $personal || isset( $_GET[ $q ] ); // phpcs:ignore WordPress.Security.NonceVerification
	}
	if ( $personal ) {
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true ); // SiteGround Optimizer, WP Super Cache, W3TC, etc.
		}
		nocache_headers();
		header( 'X-Cache-Control: no-cache' );
	}
}, 0 );

/* ---------------------------------------------------------- old URL redirects */
function usucger_redirects_default() {
	return array(
		'/usucger-by-laws/'        => '/bylaws/',
		'/usucger-board-members/'  => '/board/',
		'/academic-positions/'     => '/positions/',
		'/membership-directory/'   => '/directory/',
		'/member-universities/'    => '/universities/',
		'/usucger-awards/'         => '/awards/',
		'/student-travel-grants/'  => '/travel-grants/',
		'/meeting-minutes/'        => '/minutes/',
		'/contact-us/'             => '/contact/',
		// addresses of the Divi site (2021–2026)
		'/usucger-history-and-mission/'                       => '/about/',
		'/usucger-awards-for-research-service-and-education/' => '/awards/',
		'/usucger-membership-overview/'                       => '/membership/',
		'/member-directory/'                                  => '/directory/',
		'/usucger-member-directory/'                          => '/directory/',
		'/small-research-grants/'                             => '/research-grants/',
		'/email-usucger/'                                     => '/contact/',
		'/login/'                                             => '/members/',
		'/directory-of-geotechnical-software/'                => '/software/',
		);
}

function usucger_redirects() {
	$r = get_option( 'usucger_redirects', null );
	if ( null === $r ) {
		$r = usucger_redirects_default();
		update_option( 'usucger_redirects', $r, false );
		update_option( 'usucger_redirects_ver', 2, false );
	} elseif ( is_array( $r ) && 2 > (int) get_option( 'usucger_redirects_ver' ) ) {
		$r += usucger_redirects_default(); // add the Divi-site addresses once; edits are kept
		update_option( 'usucger_redirects', $r, false );
		update_option( 'usucger_redirects_ver', 2, false );
	}
	$r = is_array( $r ) ? $r : array();
	foreach ( $r as $from => $to ) {
		if ( strtolower( '/' . trim( $from, '/' ) . '/' ) === strtolower( '/' . trim( (string) $to, '/' ) . '/' ) ) {
			unset( $r[ $from ] ); // a redirect to itself would loop
		}
	}
	return $r;
}

add_action( 'template_redirect', function () {
	if ( ! is_404() ) {
		return;
	}
	$path = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_parse_url( esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ), PHP_URL_PATH ) : '';
	$path = '/' . trim( $path, '/' ) . '/';
	foreach ( usucger_redirects() as $from => $to ) {
		if ( strtolower( '/' . trim( $from, '/' ) . '/' ) === strtolower( $path ) && $to ) {
			wp_safe_redirect( preg_match( '#^https?://#', $to ) ? $to : home_url( $to ), 301 );
			exit;
		}
	}
}, 1 );

/* ------------------------------------------------------ privacy export / erase */
add_filter( 'wp_privacy_personal_data_exporters', function ( $ex ) {
	$ex['usucger'] = array(
		'exporter_friendly_name' => 'USUCGER membership, profile and email records',
		'callback'               => function ( $email ) {
			global $wpdb;
			$items = array();
			$c     = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . Usucger_DB::t( 'contacts' ) . ' WHERE email = %s', strtolower( $email ) ), ARRAY_A );
			if ( $c ) {
				$data = array();
				foreach ( array( 'first_name', 'last_name', 'institution', 'category', 'status', 'end_date', 'in_directory', 'tags', 'unsub_news', 'unsub_renewal' ) as $k ) {
					$data[] = array( 'name' => $k, 'value' => (string) $c[ $k ] );
				}
				$items[] = array( 'group_id' => 'usucger-member', 'group_label' => 'USUCGER membership', 'item_id' => 'contact-' . $c['id'], 'data' => $data );
			}
			$u = get_user_by( 'email', $email );
			if ( $u ) {
				$p = usucger_profile( $u->ID );
				$items[] = array( 'group_id' => 'usucger-profile', 'group_label' => 'USUCGER profile', 'item_id' => 'profile-' . $u->ID, 'data' => array(
					array( 'name' => 'Rank', 'value' => $p->rank ),
					array( 'name' => 'Title', 'value' => $p->title ),
					array( 'name' => 'Expertise', 'value' => implode( ', ', $p->expertise ) ),
					array( 'name' => 'Summary', 'value' => $p->summary ),
				) );
				foreach ( usucger_my_events( $u->ID ) as $r ) {
					$items[] = array( 'group_id' => 'usucger-events', 'group_label' => 'USUCGER events', 'item_id' => 'event-' . $r->id, 'data' => array( array( 'name' => 'Event', 'value' => $r->event_name . ' (' . $r->role . ')' ) ) );
				}
			}
			$n = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . Usucger_DB::t( 'outbox' ) . ' WHERE email = %s', strtolower( $email ) ) );
			$items[] = array( 'group_id' => 'usucger-email', 'group_label' => 'USUCGER emails', 'item_id' => 'emails', 'data' => array( array( 'name' => 'Emails sent to this address', 'value' => (string) $n ) ) );
			return array( 'data' => $items, 'done' => true );
		},
	);
	return $ex;
} );

add_filter( 'wp_privacy_personal_data_erasers', function ( $er ) {
	$er['usucger'] = array(
		'eraser_friendly_name' => 'USUCGER membership, profile and email records',
		'callback'             => function ( $email ) {
			global $wpdb;
			$email = strtolower( $email );
			$n     = 0;
			$n    += (int) $wpdb->query( $wpdb->prepare( 'UPDATE ' . Usucger_DB::t( 'contacts' ) . " SET email = '', first_name = 'Removed', last_name = 'person', notes = '', tags = '', in_directory = 0, status = 'former', token = '' WHERE email = %s", $email ) );
			$n    += (int) $wpdb->query( $wpdb->prepare( 'UPDATE ' . Usucger_DB::t( 'outbox' ) . " SET email = '', name = '', body = '' WHERE email = %s", $email ) );
			$u     = get_user_by( 'email', $email );
			if ( $u ) {
				foreach ( array( 'usg_rank', 'usg_title', 'usg_expertise', 'usg_summary', 'usg_links', 'usg_photo', 'usg_visible' ) as $k ) {
					delete_user_meta( $u->ID, $k );
				}
				$n += (int) $wpdb->delete( Usucger_DB::t( 'attendance' ), array( 'user_id' => $u->ID ) );
			}
			usucger_bump_content_version();
			// ballots are anonymous and are never linked to a person, so nothing to erase there
			return array( 'items_removed' => $n > 0, 'items_retained' => false, 'messages' => array( 'Election participation records are anonymous; institution-level voting records are kept as required by the By-Laws.' ), 'done' => true );
		},
	);
	return $er;
} );

add_action( 'admin_init', function () {
	if ( function_exists( 'wp_add_privacy_policy_content' ) ) {
		wp_add_privacy_policy_content( 'USUCGER Core', wp_kses_post( '<p>We keep members’ names, institutions, email addresses, membership status and email preferences to run the membership, directory and elections. Profiles (expertise, research summary, photo) are visible only to signed-in members and only if the member chooses. We count page views without cookies or IP addresses. Election ballots are stored without any link to the voter or institution. Email is sent through our email service provider. To get a copy of your data or ask us to delete it, write to ' . esc_html( usucger_core_opt( 'contact_email' ) ) . '.</p>' ) );
	}
} );

/* ----------------------------------------------------------------- cron health */
function usucger_cron_health() {
	global $wpdb;
	$last   = (int) get_option( 'usucger_last_tick' );
	$queued = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . Usucger_DB::t( 'outbox' ) . " WHERE status IN ('queued','sending')" ); // phpcs:ignore WordPress.DB
	if ( $queued && ( ! $last || time() - $last > 15 * MINUTE_IN_SECONDS ) ) {
		return sprintf( '%d emails are waiting but the sender has not run for %s. Check the SiteGround cron job (USUCGER → Setup & import).', $queued, $last ? human_time_diff( $last ) : 'a long time' );
	}
	return '';
}
add_action( 'admin_notices', function () {
	if ( usucger_can_approve() && usucger_cron_health() ) {
		echo '<div class="notice notice-error"><p><strong>USUCGER outbox:</strong> ' . esc_html( usucger_cron_health() ) . '</p></div>';
	}
} );

/* One daily run at a time (cron can double-fire on busy hosts). */
add_action( 'usucger_daily', function () {
	if ( ! add_option( 'usucger_daily_lock', time(), '', 'no' ) ) {
		$t = (int) get_option( 'usucger_daily_lock' );
		if ( time() - $t < HOUR_IN_SECONDS ) {
			remove_all_actions( 'usucger_daily' ); // another run is in progress
			return;
		}
		update_option( 'usucger_daily_lock', time(), false );
	}
	add_action( 'shutdown', function () {
		delete_option( 'usucger_daily_lock' );
	} );
}, -100 );
