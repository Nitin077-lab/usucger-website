<?php
/**
 * Elections that follow the USUCGER By-Laws.
 *
 *  Voters (Art. III §2–3, §6; Art. VI §2): one ballot per member institution that has paid
 *  dues (at least one current member) and has a delegate on file who is a current member.
 *  The delegate may name ONE alternate at the same institution; whoever votes first casts
 *  the institution's ballot. Each ballot has one junior vote and one senior vote.
 *
 *  Candidates: junior = Assistant Professor at nomination; senior = Associate or Full
 *  Professor; must be a current member at a member institution; only one Board member
 *  per institution; at least two nominees per seat (≥4 total). The site checks these and
 *  shows warnings — the webmaster decides who goes on the ballot.
 *
 *  Timeline (Art. VI §2): nominations announced by Sept 30, close Oct 30, votes by Dec 1.
 *
 *  Secret ballot: the voter roll records THAT an institution voted; ballots are stored with
 *  a random id, no timestamp and no link to the institution. The voter gets a receipt code
 *  that can be used to check the ballot was counted.
 *
 *  Ties are flagged for the Board's secret ballot. Results are published only after an
 *  approver certifies them. Also usable for By-Law amendments / dues (yes-no, ⅔ threshold).
 *
 * @package usucger-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ===================================================================== model */

function usucger_election( $id ) {
	global $wpdb;
	$t = Usucger_DB::t( 'elections' );
	$e = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $t WHERE id = %d", $id ) );
	if ( $e ) {
		$e->settings = wp_parse_args( (array) json_decode( (string) $e->settings, true ), array( 'threshold' => 'plurality', 'seats' => array( 'junior' => 1, 'senior' => 1 ), 'auto_send' => 0, 'steps_done' => array() ) );
		$e->results  = json_decode( (string) $e->results, true );
	}
	return $e;
}

function usucger_elections( $limit = 50 ) {
	global $wpdb;
	$t = Usucger_DB::t( 'elections' );
	return $wpdb->get_results( $wpdb->prepare( "SELECT id FROM $t ORDER BY vote_close DESC, id DESC LIMIT %d", $limit ) );
}

function usucger_election_save( $data, $id = 0 ) {
	global $wpdb;
	$t = Usucger_DB::t( 'elections' );
	if ( isset( $data['settings'] ) && is_array( $data['settings'] ) ) {
		$data['settings'] = wp_json_encode( $data['settings'] );
	}
	if ( isset( $data['results'] ) && is_array( $data['results'] ) ) {
		$data['results'] = wp_json_encode( $data['results'] );
	}
	if ( $id ) {
		$wpdb->update( $t, $data, array( 'id' => $id ) );
		return $id;
	}
	$data['created'] = current_time( 'mysql' );
	$wpdb->insert( $t, $data );
	return (int) $wpdb->insert_id;
}

/** draft | scheduled | nominations | review | voting | closed | certified */
function usucger_election_phase( $e ) {
	if ( ! $e ) {
		return '';
	}
	if ( 'certified' === $e->status ) {
		return 'certified';
	}
	if ( 'draft' === $e->status ) {
		return 'draft';
	}
	$d = usucger_today();
	if ( 'board' === $e->kind ) {
		if ( $e->nom_open && $d < $e->nom_open ) {
			return 'scheduled';
		}
		if ( $e->nom_close && $d <= $e->nom_close ) {
			return 'nominations';
		}
	}
	if ( $d < $e->vote_open ) {
		return 'board' === $e->kind ? 'review' : 'scheduled';
	}
	if ( $d <= $e->vote_close ) {
		return 'voting';
	}
	return 'closed';
}

function usucger_phase_labels() {
	return array(
		'draft'       => 'Draft (not announced)',
		'scheduled'   => 'Scheduled',
		'nominations' => 'Nominations open',
		'review'      => 'Preparing the ballot',
		'voting'      => 'Voting open',
		'closed'      => 'Voting closed — counting',
		'certified'   => 'Results certified',
	);
}

/** The election members should see now: active (not draft), most recent. */
function usucger_current_election() {
	global $wpdb;
	$t  = Usucger_DB::t( 'elections' );
	$id = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $t WHERE status = 'active' AND vote_close >= %s ORDER BY vote_open ASC LIMIT 1", usucger_today() ) );
	if ( ! $id ) { // closed but not yet certified
		$id = $wpdb->get_var( "SELECT id FROM $t WHERE status = 'active' ORDER BY vote_close DESC LIMIT 1" ); // phpcs:ignore WordPress.DB
	}
	if ( ! $id ) {
		$id = $wpdb->get_var( "SELECT id FROM $t WHERE status = 'certified' ORDER BY certified_at DESC LIMIT 1" ); // phpcs:ignore WordPress.DB
	}
	return $id ? usucger_election( $id ) : null;
}

function usucger_positions_for( $e ) {
	return 'board' === $e->kind ? array( 'junior' => 'Junior Director', 'senior' => 'Senior Director' ) : array( 'question' => 'Question' );
}

/* ================================================================ candidates */

function usucger_candidates( $eid, $statuses = null ) {
	global $wpdb;
	$t   = Usucger_DB::t( 'candidates' );
	$sql = $wpdb->prepare( "SELECT * FROM $t WHERE election_id = %d", $eid );
	if ( $statuses ) {
		$sql .= " AND status IN ('" . implode( "','", array_map( 'esc_sql', (array) $statuses ) ) . "')";
	}
	return $wpdb->get_results( $sql . ' ORDER BY position, sort, name' ); // phpcs:ignore WordPress.DB
}

function usucger_candidate( $id ) {
	global $wpdb;
	$t = Usucger_DB::t( 'candidates' );
	return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $t WHERE id = %d", $id ) );
}

function usucger_candidate_token( $c ) {
	return substr( hash_hmac( 'sha256', 'cand|' . $c->election_id . '|' . $c->id . '|' . strtolower( (string) $c->email ), wp_salt( 'auth' ) ), 0, 32 );
}

/** By-Laws checks for one nominee: list of [level ok|warn|error, message]. */
function usucger_candidate_checks( $c, $e ) {
	global $wpdb;
	$out = array();
	if ( 'board' !== $e->kind ) {
		return $out;
	}
	$ranks = usucger_ranks();
	$band  = isset( $ranks[ $c->rank_title ] ) ? $ranks[ $c->rank_title ] : '';
	if ( ! $c->rank_title ) {
		$out[] = array( 'warn', 'Rank not given — junior seats need an Assistant Professor, senior seats an Associate or Full Professor (Art. III §3).' );
	} elseif ( $band !== $c->position ) {
		$out[] = array( 'error', sprintf( '%s cannot run for a %s seat (Art. III §3: junior = Assistant Professor; senior = Associate or Full Professor).', $c->rank_title, $c->position ) );
	} else {
		$out[] = array( 'ok', 'Rank matches the ' . $c->position . ' seat.' );
	}
	$ct  = Usucger_DB::t( 'contacts' );
	$mem = $c->email ? $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $ct WHERE email = %s", strtolower( $c->email ) ) ) : null;
	if ( $mem && 'current' === $mem->status ) {
		$out[] = array( 'ok', 'Current paid member.' );
	} else {
		$out[] = array( 'error', 'Not a current paid member' . ( $c->email ? '' : ' (no email given)' ) . '.' );
	}
	$inst = null;
	foreach ( Usucger_Members::institutions() as $i ) {
		if ( usucger_norm( $i->name ) === usucger_norm( $c->institution ) ) {
			$inst = $i;
		}
	}
	if ( ! $inst ) {
		$out[] = array( 'error', 'Institution is not on the member-institution list.' );
	} else {
		$v = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . Usucger_DB::t( 'voters' ) . ' WHERE election_id = %d AND institution_id = %d', $e->id, $inst->id ) );
		if ( $v && ! $v->eligible ) {
			$out[] = array( 'error', 'Institution is not a voting member right now: ' . $v->reason );
		}
		$is_del = $c->email && in_array( strtolower( $c->email ), array( strtolower( $inst->contact_email ), strtolower( $inst->alternate_email ) ), true );
		$out[]  = $is_del ? array( 'ok', 'Is the institution\'s delegate/alternate on file.' ) : array( 'warn', 'Not the institution\'s delegate on file — Art. VI §2 says nominees are chosen from among the delegates. Update the delegate if appropriate.' );
		// one Board member per institution
		$year = (int) substr( $e->vote_close, 0, 4 );
		foreach ( usucger_items( 'usucger_board' ) as $b ) {
			if ( ! in_array( $b['seat'], array( 'junior', 'senior' ), true ) ) {
				continue;
			}
			$end = preg_match( '/(\d{4})\D*$/', (string) $b['term'], $m ) ? (int) $m[1] : 0;
			if ( usucger_norm( $b['inst'] ) === usucger_norm( $inst->name ) && $end > $year + 1 && usucger_norm( $b['title'] ) !== usucger_norm( $c->name ) ) {
				$out[] = array( 'error', sprintf( '%s (%s) continues on the Board until %d — only one delegate per institution may serve at a time (Art. VI §1).', $b['title'], $inst->name, $end ) );
			}
			if ( usucger_norm( $b['title'] ) === usucger_norm( $c->name ) ) {
				$out[] = array( 'warn', 'Currently on the Board (term ' . $b['term'] . '). Directors may serve two successive full terms, then must wait until the second annual meeting (Art. VI §1).' );
			}
		}
	}
	return apply_filters( 'usucger_candidate_checks', $out, $c, $e );
}

function usucger_election_checks( $e ) {
	$out = array();
	if ( 'board' === $e->kind ) {
		foreach ( usucger_positions_for( $e ) as $pos => $label ) {
			$n = count( array_filter( usucger_candidates( $e->id, array( 'approved' ) ), function ( $c ) use ( $pos ) {
				return $c->position === $pos;
			} ) );
			$out[] = $n >= 2 ? array( 'ok', "$n approved nominees for the $label seat." ) : array( 'warn', "Only $n approved nominee(s) for the $label seat — the By-Laws ask for at least two per seat (Art. VI §2)." );
		}
		if ( $e->nom_open && $e->nom_open > substr( $e->nom_open, 0, 4 ) . '-09-30' ) {
			$out[] = array( 'warn', 'Nominations should be announced by September 30 (Art. VI §2).' );
		}
		if ( $e->vote_close && $e->vote_close > substr( $e->vote_close, 0, 4 ) . '-12-01' ) {
			$out[] = array( 'warn', 'Votes are due by December 1 (Art. VI §2).' );
		}
	}
	$r = usucger_turnout( $e->id );
	$out[] = $r['eligible'] ? array( 'ok', $r['eligible'] . ' institutions can vote.' ) : array( 'error', 'The voter roll is empty — build it on the Voter roll tab.' );
	return $out;
}

/* ================================================================ voter roll */

/** Find a contact for "Last, First" (or "First Last") at an institution. */
function usucger_contact_by_name( $name, $institution = '' ) {
	global $wpdb;
	$name = trim( $name );
	if ( ! $name ) {
		return null;
	}
	if ( false !== strpos( $name, ',' ) ) {
		list( $last, $first ) = array_map( 'trim', explode( ',', $name, 2 ) );
	} else {
		$parts = preg_split( '/\s+/', $name );
		$last  = array_pop( $parts );
		$first = implode( ' ', $parts );
	}
	$first = preg_replace( '/\s.*$/', '', $first ); // first word only
	$ct    = Usucger_DB::t( 'contacts' );
	$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $ct WHERE LOWER(last_name) = %s AND status <> 'former'", mb_strtolower( $last ) ) );
	foreach ( $rows as $r ) {
		if ( '' === $first || '' === (string) $r->first_name ) {
			continue; // never match on a last name alone
		}
		if ( 0 === mb_stripos( $r->first_name, $first ) || 0 === mb_stripos( $first, $r->first_name ) ) {
			if ( ! $institution || usucger_norm( $r->institution ) === usucger_norm( $institution ) || ! $r->institution ) {
				return $r;
			}
		}
	}
	return null;
}

/**
 * Build or refresh the voter roll. Rows that already voted are never changed.
 * Returns counts.
 */
function usucger_election_build_roll( $eid ) {
	global $wpdb;
	$vt   = Usucger_DB::t( 'voters' );
	$ct   = Usucger_DB::t( 'contacts' );
	$paid = array();
	foreach ( $wpdb->get_results( "SELECT institution, COUNT(*) n FROM $ct WHERE status = 'current' AND source <> 'import' GROUP BY institution" ) as $p ) { // phpcs:ignore WordPress.DB -- imported directory rows are not proof of payment
		$paid[ usucger_norm( $p->institution ) ] = (int) $p->n;
	}
	$n = array( 'eligible' => 0, 'ineligible' => 0 );
	foreach ( Usucger_Members::institutions() as $i ) {
		$names = array_merge( array( $i->name ), array_filter( array_map( 'trim', explode( ';', (string) $i->aliases ) ) ) );
		$npaid = 0;
		foreach ( $names as $nm ) {
			$npaid += isset( $paid[ usucger_norm( $nm ) ] ) ? $paid[ usucger_norm( $nm ) ] : 0;
		}
		// delegate
		$del_email = strtolower( trim( $i->contact_email ) );
		$del       = $del_email ? $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $ct WHERE email = %s", $del_email ) ) : usucger_contact_by_name( $i->contact_name, $i->name );
		if ( ! $del_email && $del && $del->email ) {
			$del_email = strtolower( $del->email );
		}
		$alt_email = strtolower( trim( $i->alternate_email ) );
		$alt       = $alt_email ? $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $ct WHERE email = %s", $alt_email ) ) : null;
		$reason    = '';
		if ( ! $npaid ) {
			$reason = 'No paid member at this institution (Art. III §6)';
		} elseif ( ! $i->contact_name && ! $del_email ) {
			$reason = 'No delegate on file';
		} elseif ( ! $del_email ) {
			$reason = 'Delegate has no email address on file';
		} elseif ( ! $del || 'current' !== $del->status ) {
			$reason = 'Delegate is not a current paid member (Art. III)';
		}
		// alternate must also be a paid member of the same institution, with a member record
		if ( $alt_email && ( ! $alt || 'current' !== $alt->status || ( $alt->institution && ! in_array( usucger_norm( $alt->institution ), array_map( 'usucger_norm', $names ), true ) ) ) ) {
			$alt_email = '';
		}
		$row = array(
			'election_id'     => $eid,
			'institution_id'  => $i->id,
			'institution'     => $i->name,
			'delegate_name'   => $del ? trim( $del->first_name . ' ' . $del->last_name ) : $i->contact_name,
			'delegate_email'  => $del_email,
			'alternate_name'  => $alt_email ? ( $i->alternate_name ? $i->alternate_name : ( $alt ? trim( $alt->first_name . ' ' . $alt->last_name ) : '' ) ) : '',
			'alternate_email' => $alt_email,
			'eligible'        => $reason ? 0 : 1,
			'reason'          => $reason,
		);
		$have = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $vt WHERE election_id = %d AND institution_id = %d", $eid, $i->id ) );
		if ( $have ) {
			if ( ! $have->voted_at ) {
				// a new delegate gets a new link; the old delegate's link stops working
				if ( strtolower( (string) $have->delegate_email ) !== $row['delegate_email'] ) {
					$row['token'] = wp_generate_password( 32, false, false );
				}
				// eligibility is frozen once voting opens (By-Laws: the roll at the start of voting)
				$el = usucger_election( $eid );
				if ( $el && usucger_today() >= $el->vote_open ) {
					unset( $row['eligible'], $row['reason'] );
				}
				$wpdb->update( $vt, $row, array( 'id' => $have->id ) );
			}
		} else {
			$row['token'] = wp_generate_password( 32, false, false );
			$wpdb->insert( $vt, $row );
		}
		$n[ $reason ? 'ineligible' : 'eligible' ]++;
	}
	Usucger_DB::log( 'voter_roll_built', 'election:' . $eid, $n );
	return $n;
}

function usucger_voters( $eid, $where = '' ) {
	global $wpdb;
	$vt = Usucger_DB::t( 'voters' );
	return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $vt WHERE election_id = %d $where ORDER BY institution", $eid ) ); // phpcs:ignore WordPress.DB
}

function usucger_turnout( $eid ) {
	global $wpdb;
	$vt = Usucger_DB::t( 'voters' );
	$r  = $wpdb->get_row( $wpdb->prepare( "SELECT SUM(eligible=1) eligible, SUM(eligible=1 AND voted_at IS NOT NULL) voted FROM $vt WHERE election_id = %d", $eid ) );
	$el = (int) ( $r ? $r->eligible : 0 );
	$vo = (int) ( $r ? $r->voted : 0 );
	return array( 'eligible' => $el, 'voted' => $vo, 'pct' => $el ? round( 100 * $vo / $el ) : 0 );
}

function usucger_alt_token( $v ) {
	// bound to the alternate's address: replacing the alternate invalidates the old link
	return substr( hash_hmac( 'sha256', 'alt|' . $v->token . '|' . strtolower( (string) $v->alternate_email ), wp_salt( 'auth' ) ), 0, 32 );
}

/** Ballot link for a specific email (delegate or alternate). */
function usucger_ballot_url( $v, $email ) {
	$tok = strtolower( $email ) === strtolower( $v->alternate_email ) && strtolower( $email ) !== strtolower( $v->delegate_email ) ? usucger_alt_token( $v ) : $v->token;
	return add_query_arg( array( 'usg_ballot' => $tok, 'e' => $v->election_id ), usucger_election_page_url() );
}

/** Resolve a ballot token → [voter row, 'delegate'|'alternate']. */
function usucger_voter_by_token( $eid, $tok ) {
	global $wpdb;
	$vt = Usucger_DB::t( 'voters' );
	if ( strlen( (string) $tok ) < 20 ) { // purged links are empty strings; never match them
		return array( null, '' );
	}
	$v  = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $vt WHERE election_id = %d AND token = %s", $eid, $tok ) );
	if ( $v ) {
		return array( $v, 'delegate' );
	}
	foreach ( usucger_voters( $eid, "AND alternate_email <> '' AND token <> ''" ) as $v ) {
		if ( hash_equals( usucger_alt_token( $v ), $tok ) ) {
			return array( $v, 'alternate' );
		}
	}
	return array( null, '' );
}

/** The signed-in user's ballot in the current election, if they are a delegate/alternate. */
function usucger_my_ballot() {
	static $memo = false;
	if ( false !== $memo ) {
		return $memo;
	}
	$memo = null;
	$e    = usucger_current_election();
	if ( ! $e || ! is_user_logged_in() ) {
		return $memo;
	}
	global $wpdb;
	$vt    = Usucger_DB::t( 'voters' );
	$email = strtolower( wp_get_current_user()->user_email );
	$v     = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $vt WHERE election_id = %d AND eligible = 1 AND (delegate_email = %s OR alternate_email = %s)", $e->id, $email, $email ) );
	if ( $v ) {
		$memo = (object) array( 'election' => $e, 'voter' => $v, 'phase' => usucger_election_phase( $e ), 'role' => $v->delegate_email === $email ? 'delegate' : 'alternate', 'url' => wp_nonce_url( admin_url( 'admin-post.php?action=usucger_resend_ballot' ), 'usucger_resend_ballot' ) );
	}
	return $memo;
}

function usucger_election_page_url() {
	$p = get_page_by_path( 'elections' );
	return $p ? get_permalink( $p ) : home_url( '/elections/' );
}

/* ==================================================================== voting */

/** Cast a ballot. $choices: position => candidate id (0 = abstain). Returns receipt code or WP_Error. */
function usucger_cast_ballot( $e, $v, $choices, $by ) {
	global $wpdb;
	if ( 'voting' !== usucger_election_phase( $e ) ) {
		return new WP_Error( 'closed', 'Voting is not open.' );
	}
	if ( ! $v->eligible ) {
		return new WP_Error( 'inelig', 'This institution is not eligible to vote: ' . $v->reason );
	}
	$valid = array();
	foreach ( usucger_candidates( $e->id, array( 'approved' ) ) as $c ) {
		$valid[ $c->position ][ (int) $c->id ] = true;
	}
	$clean = array();
	foreach ( usucger_positions_for( $e ) as $pos => $label ) {
		$cid = isset( $choices[ $pos ] ) ? (int) $choices[ $pos ] : 0;
		if ( $cid && empty( $valid[ $pos ][ $cid ] ) ) {
			return new WP_Error( 'bad', 'Invalid choice.' );
		}
		$clean[ $pos ] = $cid;
	}
	if ( ! array_filter( $clean ) ) {
		return new WP_Error( 'empty', 'Choose at least one candidate.' );
	}
	$vt = Usucger_DB::t( 'voters' );
	$wpdb->query( 'START TRANSACTION' );
	// lock the institution's ballot first — only one can succeed
	$ok = $wpdb->query( $wpdb->prepare( "UPDATE $vt SET voted_at = %s, voted_by = %s WHERE id = %d AND voted_at IS NULL", current_time( 'mysql' ), $by, $v->id ) );
	if ( 1 !== (int) $ok ) {
		$wpdb->query( 'ROLLBACK' );
		return new WP_Error( 'voted', 'Your institution has already voted.' );
	}
	$receipt = strtoupper( substr( wp_generate_password( 12, false, false ), 0, 4 ) . '-' . substr( wp_generate_password( 12, false, false ), 0, 4 ) . '-' . substr( wp_generate_password( 12, false, false ), 0, 4 ) );
	$hash    = hash( 'sha256', $receipt );
	$bt      = Usucger_DB::t( 'ballots' );
	foreach ( $clean as $pos => $cid ) {
		// random id: ballots cannot be ordered to match the voter roll
		if ( ! $wpdb->insert( $bt, array( 'id' => random_int( 1000000, PHP_INT_MAX >> 1 ), 'election_id' => $e->id, 'position' => $pos, 'candidate_id' => $cid ) ) ) {
			$wpdb->query( 'ROLLBACK' );
			$wpdb->query( $wpdb->prepare( "UPDATE $vt SET voted_at = NULL, voted_by = '' WHERE id = %d", $v->id ) );
			return new WP_Error( 'db', 'Your ballot could not be saved. Please try again.' );
		}
	}
	if ( ! $wpdb->insert( Usucger_DB::t( 'receipts' ), array( 'id' => random_int( 1000000, PHP_INT_MAX >> 1 ), 'election_id' => $e->id, 'receipt_hash' => $hash ) ) ) {
		$wpdb->query( 'ROLLBACK' );
		$wpdb->query( $wpdb->prepare( "UPDATE $vt SET voted_at = NULL, voted_by = '' WHERE id = %d", $v->id ) );
		return new WP_Error( 'db', 'Your ballot could not be saved. Please try again.' );
	}
	$wpdb->query( 'COMMIT' );
	Usucger_DB::log( 'ballot_cast', 'election:' . $e->id, 'institution ballot recorded' );
	return $receipt;
}

function usucger_tally( $e ) {
	global $wpdb;
	$bt    = Usucger_DB::t( 'ballots' );
	$out   = array();
	$cands = usucger_candidates( $e->id, array( 'approved' ) );
	foreach ( usucger_positions_for( $e ) as $pos => $label ) {
		$rows = array();
		foreach ( $cands as $c ) {
			if ( $c->position === $pos ) {
				$rows[ (int) $c->id ] = array( 'id' => (int) $c->id, 'name' => $c->name, 'institution' => $c->institution, 'votes' => 0 );
			}
		}
		$abst = 0;
		foreach ( $wpdb->get_results( $wpdb->prepare( "SELECT candidate_id, COUNT(*) n FROM $bt WHERE election_id = %d AND position = %s GROUP BY candidate_id", $e->id, $pos ) ) as $r ) {
			if ( (int) $r->candidate_id && isset( $rows[ (int) $r->candidate_id ] ) ) {
				$rows[ (int) $r->candidate_id ]['votes'] = (int) $r->n;
			} else {
				$abst += (int) $r->n;
			}
		}
		usort( $rows, function ( $a, $b ) {
			return $b['votes'] - $a['votes'];
		} );
		$top    = $rows ? $rows[0]['votes'] : 0;
		$tied   = count( array_filter( $rows, function ( $r ) use ( $top ) {
			return $r['votes'] === $top;
		} ) ) > 1 && $top > 0;
		$cast   = array_sum( wp_list_pluck( $rows, 'votes' ) );
		$winner = null;
		if ( 'question' === $pos ) {
			$yes  = 0;
			foreach ( $rows as $r ) {
				if ( 'yes' === strtolower( $r['name'] ) ) {
					$yes = $r['votes'];
				}
			}
			$need   = 'two_thirds' === $e->settings['threshold'] ? 2 / 3 : 0.5;
			$winner = $cast ? ( ( $yes / $cast ) >= $need && ( 'two_thirds' === $e->settings['threshold'] || $yes * 2 > $cast ) ? 'Passed' : 'Not passed' ) : null;
			$tied   = false;
		} elseif ( ! $tied && $top > 0 ) {
			$winner = $rows[0]['name'];
		}
		$out[ $pos ] = array( 'label' => $label, 'rows' => $rows, 'abstain' => $abst, 'cast' => $cast, 'tie' => $tied, 'winner' => $winner );
	}
	return $out;
}

/* ============================================================ email support */

add_filter( 'usucger_email_groups', function ( $g ) {
	$g['voters_all']     = array( 'Election: all delegates & alternates who can vote (current election)', 'official' );
	$g['voters_pending'] = array( 'Election: delegates & alternates whose institution has NOT voted yet', 'official' );
	$g['candidates']     = array( 'Election: nominees on the ballot', 'official' );
	return $g;
} );

add_filter( 'usucger_recipients', function ( $rows, $group, $args ) {
	if ( ! in_array( $group, array( 'voters_all', 'voters_pending', 'candidates' ), true ) ) {
		return $rows;
	}
	$e = ! empty( $args['election'] ) ? usucger_election( (int) $args['election'] ) : usucger_current_election();
	if ( ! $e ) {
		return array();
	}
	$out = array();
	if ( 'candidates' === $group ) {
		foreach ( usucger_candidates( $e->id, array( 'approved' ) ) as $c ) {
			$out[] = Usucger_Members::ensure_contact( $c->email, $c->name, $c->institution );
		}
		return $out;
	}
	foreach ( usucger_voters( $e->id, 'AND eligible = 1' . ( 'voters_pending' === $group ? ' AND voted_at IS NULL' : '' ) ) as $v ) {
		$out[] = Usucger_Members::ensure_contact( $v->delegate_email, $v->delegate_name, $v->institution );
		if ( $v->alternate_email ) {
			$out[] = Usucger_Members::ensure_contact( $v->alternate_email, $v->alternate_name, $v->institution );
		}
	}
	return $out;
}, 10, 3 );

/* Don't send a "you haven't voted" reminder if the institution voted after the email was queued. */
add_filter( 'usucger_outbox_skip', function ( $skip, $row, $batch ) {
	if ( $skip || ! $batch || 'voters_pending' !== $batch->group_key ) {
		return $skip;
	}
	$e = ! empty( $batch->args['election'] ) ? usucger_election( (int) $batch->args['election'] ) : usucger_current_election();
	if ( ! $e ) {
		return $skip;
	}
	global $wpdb;
	$vt = Usucger_DB::t( 'voters' );
	return (bool) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $vt WHERE election_id = %d AND voted_at IS NOT NULL AND (delegate_email = %s OR alternate_email = %s)", $e->id, $row->email, $row->email ) );
}, 10, 3 );

add_filter( 'usucger_merge_tag_help', function ( $t ) {
	return $t + array(
		'{election_title}'  => 'Election title',
		'{nom_close}'       => 'Nominations close date',
		'{vote_open}'       => 'Voting opens date',
		'{vote_close}'      => 'Voting closes date',
		'{ballot_button}'   => 'Personal "Cast your institution\'s ballot" button (delegates)',
		'{voter_institution}' => 'Institution the delegate votes for',
		'{candidates_list}' => 'Nominees on the ballot',
		'{nominate_url}'    => 'Link to the nomination form',
		'{election_url}'    => 'Elections page',
		'{turnout}'         => 'Turnout so far (e.g. 96 of 160)',
		'{results}'         => 'Certified results',
		'{nominees_list}'   => 'Nominees by seat with rank and institution (Nominating Committee slate)',
		'{nominating_committee}' => 'Nominating Committee members (election settings)',
		'{nomination_contacts}'  => 'Who to send nominations to (election settings)',
		'{board_url}'       => 'Board of Directors page',
		'{bylaws_url}'      => 'By-Laws page',
	);
} );

add_filter( 'usucger_merge_map', function ( $map, $c, $kind, $text ) {
	if ( false === strpos( $text, '{election' ) && false === strpos( $text, '{nomin' ) && false === strpos( $text, '{board_url' ) && false === strpos( $text, '{bylaws' ) && false === strpos( $text, '{ballot' ) && false === strpos( $text, '{vote' ) && false === strpos( $text, '{nom' ) && false === strpos( $text, '{candidates' ) && false === strpos( $text, '{turnout' ) && false === strpos( $text, '{results' ) && false === strpos( $text, '{voter_' ) ) {
		return $map;
	}
	$ra = isset( $GLOBALS['usucger_render_args'] ) ? (array) $GLOBALS['usucger_render_args'] : array();
	$e  = ! empty( $ra['election'] ) ? usucger_election( (int) $ra['election'] ) : usucger_current_election();
	if ( ! $e ) {
		return $map;
	}
	$col = sanitize_hex_color( usucger_core_opt( 'letter_color' ) );
	$col = $col ? $col : '#C2410C';
	$map['{election_title}'] = esc_html( $e->title );
	$map['{nom_close}']      = esc_html( usucger_fmt_date( $e->nom_close, 'F j, Y' ) );
	$map['{vote_open}']      = esc_html( usucger_fmt_date( $e->vote_open, 'F j, Y' ) );
	$map['{vote_close}']     = esc_html( usucger_fmt_date( $e->vote_close, 'F j, Y' ) );
	$map['{election_url}']   = esc_url( usucger_election_page_url() );
	$map['{nominate_url}']   = esc_url( add_query_arg( 'nominate', 1, usucger_election_page_url() ) . '#nominate' );
	$t                       = usucger_turnout( $e->id );
	$map['{turnout}']        = (int) $t['voted'] . ' of ' . (int) $t['eligible'];
	// candidates list
	$list = '';
	foreach ( usucger_positions_for( $e ) as $pos => $label ) {
		$names = array();
		foreach ( usucger_candidates( $e->id, array( 'approved' ) ) as $cd ) {
			if ( $cd->position === $pos ) {
				$names[] = '<li>' . esc_html( $cd->name ) . ( $cd->institution ? ', ' . esc_html( $cd->institution ) : '' ) . '</li>';
			}
		}
		if ( $names ) {
			$list .= '<p style="margin:0 0 4px"><strong>' . esc_html( $label ) . '</strong></p><ul style="margin:0 0 12px;padding-left:20px">' . implode( '', $names ) . '</ul>';
		}
	}
	$map['{candidates_list}'] = $list;
	$slate = '';
	foreach ( usucger_positions_for( $e ) as $pos => $label ) {
		$items = array();
		foreach ( usucger_candidates( $e->id, array( 'nominated', 'accepted', 'approved' ) ) as $cd ) {
			if ( $cd->position === $pos && 'question' !== $pos ) {
				$items[] = '<li>' . esc_html( implode( ', ', array_filter( array( $cd->name, $cd->title_line ? $cd->title_line : $cd->rank_title, $cd->institution ) ) ) ) . '</li>';
			}
		}
		if ( $items ) {
			$slate .= '<p style="margin:0 0 4px"><strong>' . ( 'junior' === $pos ? 'Junior Position' : 'Senior Position' ) . '</strong></p><ul style="margin:0 0 14px;padding-left:20px">' . implode( '', $items ) . '</ul>';
		}
	}
	$map['{nominees_list}']        = $slate;
	$map['{nominating_committee}'] = esc_html( isset( $e->settings['committee'] ) ? $e->settings['committee'] : '' );
	$nc                            = isset( $e->settings['nom_contacts'] ) ? $e->settings['nom_contacts'] : usucger_core_opt( 'board_email' );
	$map['{nomination_contacts}']  = preg_replace( '/([A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,})/i', '<a href="mailto:$1">$1</a>', esc_html( $nc ) );
	$map['{board_url}']            = esc_url( usucger_core_url( 'board' ) );
	$map['{bylaws_url}']           = esc_url( usucger_core_url( 'bylaws' ) );
	// results
	$res = '';
	if ( 'certified' === $e->status && is_array( $e->results ) ) {
		foreach ( $e->results['tally'] as $pos => $r ) {
			$res .= '<p style="margin:0 0 4px"><strong>' . esc_html( $r['label'] ) . ':</strong> ' . esc_html( $r['winner'] ? $r['winner'] : 'tie — decided by the Board' ) . '</p>';
		}
	}
	$map['{results}'] = $res;
	// personal ballot
	global $wpdb;
	$email = isset( $c->email ) ? strtolower( $c->email ) : '';
	$v     = $email ? $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . Usucger_DB::t( 'voters' ) . ' WHERE election_id = %d AND eligible = 1 AND (delegate_email = %s OR alternate_email = %s)', $e->id, $email, $email ) ) : null;
	if ( $v ) {
		$url                        = usucger_ballot_url( $v, $email );
		$map['{voter_institution}'] = esc_html( $v->institution );
		$ph                         = usucger_personal_placeholder( 'ballot_button' );
		$map['{ballot_button}']     = null !== $ph ? $ph : '<table role="presentation" cellpadding="0" cellspacing="0" style="margin:0 0 18px"><tr><td style="background:' . $col . ';border-radius:4px"><a href="' . esc_url( $url ) . '" style="display:inline-block;padding:12px 22px;font-family:Arial,Helvetica,sans-serif;font-size:15px;font-weight:700;color:#FFFFFF;text-decoration:none">Cast ' . esc_html( $v->institution ) . '’s ballot &rarr;</a></td></tr></table><p style="font-size:12px;color:#686460;margin:-8px 0 14px">This link is personal — please don’t forward it. One ballot per institution: if your alternate votes first, the ballot is closed.</p>';
	} else {
		$map['{voter_institution}'] = '';
		$map['{ballot_button}']     = '<p><a href="' . esc_url( usucger_election_page_url() ) . '">Elections page &rarr;</a></p>';
	}
	return $map;
}, 10, 4 );

/* =================================================================== schedule */

/** Planned emails for an election: key => [date, template, group, label]. */
function usucger_election_steps( $e ) {
	$minus = function ( $d, $n ) {
		return $d ? gmdate( 'Y-m-d', strtotime( $d . " -$n days" ) ) : '';
	};
	if ( 'board' !== $e->kind ) {
		return array(
			'voting'   => array( $e->vote_open, 'election_voting', 'voters_all', 'Ballot to all delegates' ),
			'remind7'  => array( $minus( $e->vote_close, 7 ), 'election_reminder', 'voters_pending', 'Reminder: 7 days left (non-voters only)' ),
			'remind1'  => array( $minus( $e->vote_close, 1 ), 'election_reminder', 'voters_pending', 'Last-day reminder (non-voters only)' ),
		);
	}
	return array(
		'nominations' => array( $e->nom_open, 'election_slate', 'current', 'Nominating Committee slate + call for more nominations (all members)' ),
		'packet_request' => array( $minus( usucger_packet_due( $e ), 21 ), 'election_packet_request', 'candidates_not_asked', 'Ask nominees for candidate statement, photo and CV' ),
		'nom_remind'  => array( $minus( $e->nom_close, 7 ), 'election_nom_reminder', 'current', 'Nominations close in a week' ),
		'packet_remind' => array( $minus( usucger_packet_due( $e ), 3 ), 'election_packet_reminder', 'candidates_packet', 'Remind nominees whose statement is missing' ),
		'voting'      => array( $e->vote_open, 'election_voting', 'voters_all', 'Ballot to all delegates & alternates' ),
		'candidates'  => array( $e->vote_open, 'election_candidates', 'current', 'Meet the candidates — all members' ),
		'remind14'    => array( $minus( $e->vote_close, 14 ), 'election_reminder', 'voters_pending', 'Reminder: 2 weeks left (non-voters only)' ),
		'remind7'     => array( $minus( $e->vote_close, 7 ), 'election_reminder', 'voters_pending', 'Reminder: 1 week left (non-voters only)' ),
		'remind1'     => array( $minus( $e->vote_close, 1 ), 'election_reminder', 'voters_pending', 'Last-day reminder (non-voters only)' ),
	);
}

function usucger_election_run_step( $e, $key ) {
	$steps = usucger_election_steps( $e );
	if ( ! isset( $steps[ $key ] ) || ! empty( $e->settings['steps_done'][ $key ] ) ) {
		return 0;
	}
	$s    = $steps[ $key ];
	$tpls = usucger_email_templates();
	if ( empty( $tpls[ $s[1] ] ) ) {
		return 0;
	}
	if ( in_array( $s[2], array( 'voters_all', 'voters_pending' ), true ) ) {
		usucger_election_build_roll( $e->id ); // fresh roll before every ballot email
	}
	$args = array( 'election' => $e->id );
	if ( ! empty( $e->settings['signature'] ) && in_array( $key, array( 'nominations', 'nom_remind' ), true ) ) {
		$args['sign']      = 'custom';
		$args['sign_text'] = $e->settings['signature'];
	}
	$id = usucger_batch_save( array(
		'kind'         => 'official',
		'group_key'    => $s[2],
		'args'         => $args,
		'template_key' => $s[1],
		'subject'      => $tpls[ $s[1] ]['subject'],
		'body'         => $tpls[ $s[1] ]['body'],
		'source'       => 'election',
	) );
	$e->settings['steps_done'][ $key ] = $id;
	usucger_election_save( array( 'settings' => $e->settings ), $e->id );
	$b = usucger_batch( $id );
	$n = count( usucger_batch_recipients( $b ) );
	if ( ! $n ) {
		usucger_batch_save( array( 'status' => 'done', 'note' => 'Nobody to send to (everyone has voted).' ), $id );
		return $id;
	}
	usucger_batch_save( array( 'status' => 'pending', 'submitted' => current_time( 'mysql' ), 'total' => $n ), $id );
	if ( ! empty( $e->settings['auto_send'] ) ) {
		usucger_batch_approve( $id );
	} else {
		usucger_notify( usucger_election_notify_to(), 'Election email ready: ' . $s[3], '<p>The scheduled election email <strong>' . esc_html( $s[3] ) . '</strong> for ' . esc_html( $e->title ) . ' is ready to send to ' . (int) $n . ' people.</p><p><a href="' . esc_url( usucger_desk_url() ) . '">Approve on the webmaster desk</a> or <a href="' . esc_url( usucger_admin_url( 'usucger-outbox', array( 'batch' => $id ) ) ) . '">preview in the outbox</a>.</p>' );
	}
	Usucger_DB::log( 'election_email', 'election:' . $e->id, $key );
	return $id;
}

add_action( 'usucger_daily', function () {
	$today = usucger_today();
	foreach ( usucger_elections( 10 ) as $row ) {
		$e = usucger_election( $row->id );
		if ( ! $e || 'active' !== $e->status ) {
			continue;
		}
		foreach ( usucger_election_steps( $e ) as $key => $s ) {
			if ( $s[0] && $s[0] <= $today && usucger_days_between( $s[0], $today ) <= 2 && empty( $e->settings['steps_done'][ $key ] ) && $today <= $e->vote_close ) {
				usucger_election_run_step( $e, $key );
				$e = usucger_election( $e->id );
			}
		}
		// voting closed: tell approvers the count is ready
		if ( 'closed' === usucger_election_phase( $e ) && empty( $e->settings['steps_done']['closed_notice'] ) ) {
			$e->settings['steps_done']['closed_notice'] = 1;
			usucger_election_save( array( 'settings' => $e->settings ), $e->id );
			$t = usucger_turnout( $e->id );
			usucger_notify( usucger_election_notify_to(), 'Voting closed: ' . $e->title, '<p>Voting has closed with <strong>' . (int) $t['voted'] . ' of ' . (int) $t['eligible'] . '</strong> institutions voting. Review the count and certify the results.</p><p><a href="' . esc_url( usucger_admin_url( 'usucger-elections', array( 'id' => $e->id, 'view' => 'results' ) ) ) . '">Open the results</a></p>' );
		}
	}
}, 30 );

/** Certify: freeze results; queue the results announcement for approval. */
function usucger_election_certify( $eid ) {
	$e = usucger_election( $eid );
	if ( ! $e || 'closed' !== usucger_election_phase( $e ) ) {
		return new WP_Error( 'state', 'Results can be certified after voting closes.' );
	}
	$tally = usucger_tally( $e );
	usucger_election_save( array(
		'status'       => 'certified',
		'results'      => array( 'tally' => $tally, 'turnout' => usucger_turnout( $eid ) ),
		'certified_at' => current_time( 'mysql' ),
		'certified_by' => get_current_user_id(),
	), $eid );
	Usucger_DB::log( 'election_certified', 'election:' . $eid, wp_list_pluck( $tally, 'winner' ) );
	$tpls = usucger_email_templates();
	if ( ! empty( $tpls['election_results'] ) ) {
		usucger_batch_save( array( 'kind' => 'official', 'group_key' => 'current', 'args' => array( 'election' => $eid ), 'template_key' => 'election_results', 'subject' => $tpls['election_results']['subject'], 'body' => $tpls['election_results']['body'], 'source' => 'election' ) );
	}
	return true;
}

/* ============================================================== nominations */

add_action( 'admin_post_usucger_nominate', 'usucger_handle_nominate' );
function usucger_handle_nominate() {
	check_admin_referer( 'usucger_nominate' );
	$e = usucger_election( (int) $_POST['election'] );
	if ( ! $e || 'nominations' !== usucger_election_phase( $e ) || ! usucger_is_member_viewer() ) {
		wp_die( 'Nominations are not open.' );
	}
	$rl = (int) get_transient( 'usg_nom_' . get_current_user_id() );
	if ( $rl >= 5 ) {
		wp_die( 'You have submitted several nominations today. Please contact the election officer for more.' );
	}
	set_transient( 'usg_nom_' . get_current_user_id(), $rl + 1, DAY_IN_SECONDS );
	$p   = wp_unslash( $_POST );
	$pos = 'senior' === $p['position'] ? 'senior' : 'junior';
	global $wpdb;
	$em  = strtolower( sanitize_email( $p['email'] ) );
	if ( ! is_email( $em ) || '' === trim( (string) $p['name'] ) ) {
		wp_die( 'Please give the nominee’s name and email address.' );
	}
	// one nomination record per person per election: a second nomination is noted, not duplicated
	$dup = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . Usucger_DB::t( 'candidates' ) . ' WHERE election_id = %d AND email = %s', $e->id, $em ) );
	if ( $dup ) {
		Usucger_DB::log( 'nomination_repeat', 'election:' . $e->id, $dup->name . ' (also nominated by ' . wp_get_current_user()->display_name . ')' );
		wp_safe_redirect( add_query_arg( 'nominated', 'again', usucger_election_page_url() ) . '#nominate' );
		exit;
	}
	$wpdb->insert( Usucger_DB::t( 'candidates' ), array(
		'election_id'    => $e->id,
		'position'       => $pos,
		'name'           => sanitize_text_field( $p['name'] ),
		'email'          => $em,
		'institution'    => sanitize_text_field( $p['institution'] ),
		'rank_title'     => isset( usucger_ranks()[ $p['rank'] ] ) ? $p['rank'] : '',
		'statement'      => mb_substr( sanitize_textarea_field( $p['statement'] ), 0, 1500 ),
		'status'         => 'nominated',
		'nominated_by'   => get_current_user_id(),
		'nominator_note' => mb_substr( sanitize_text_field( $p['why'] ), 0, 250 ),
		'created'        => current_time( 'mysql' ),
	) );
	$c = usucger_candidate( $wpdb->insert_id );
	$self = strtolower( wp_get_current_user()->user_email ) === $c->email;
	if ( $self ) {
		$wpdb->update( Usucger_DB::t( 'candidates' ), array( 'status' => 'accepted' ), array( 'id' => $c->id ) );
	} elseif ( is_email( $c->email ) ) {
		usucger_queue_accept_requests( $e, false ); // officer approves the "please confirm" email
	}
	usucger_notify( usucger_election_notify_to(), 'New nomination: ' . $c->name, '<p>' . esc_html( wp_get_current_user()->display_name ) . ' nominated <strong>' . esc_html( $c->name ) . '</strong> (' . esc_html( $c->institution ) . ') for the ' . esc_html( $c->position ) . ' seat.</p><p><a href="' . esc_url( usucger_admin_url( 'usucger-elections', array( 'id' => $e->id, 'view' => 'candidates' ) ) ) . '">Review nominees and By-Laws checks</a></p>' );
	Usucger_DB::log( 'nomination', 'election:' . $e->id, $c->name );
	wp_safe_redirect( add_query_arg( 'nominated', 1, usucger_election_page_url() ) . '#nominate' );
	exit;
}

add_action( 'admin_post_usucger_nominee', 'usucger_handle_nominee' );
add_action( 'admin_post_nopriv_usucger_nominee', 'usucger_handle_nominee' );
function usucger_handle_nominee() {
	$c = usucger_candidate( (int) $_POST['cand'] );
	if ( ! $c || ! hash_equals( usucger_candidate_token( $c ), (string) wp_unslash( $_POST['k'] ) ) ) {
		wp_die( 'Invalid link.' );
	}
	$accept = ! empty( $_POST['accept'] );
	if ( ! in_array( $c->status, array( 'nominated', 'accepted', 'declined' ), true ) ) {
		wp_die( 'This nomination can no longer be changed. Please contact the election officer.' );
	}
	$ranks  = usucger_ranks();
	$rank   = isset( $_POST['rank'], $ranks[ wp_unslash( $_POST['rank'] ) ] ) ? wp_unslash( $_POST['rank'] ) : $c->rank_title;
	if ( ! isset( $_POST['statement'] ) ) {
		$_POST['statement'] = wp_slash( (string) $c->statement );
	}
	usucger_cand_meta_set( $c, $accept ? 'accepted_at' : 'declined_at', current_time( 'mysql' ) );
	$GLOBALS['wpdb']->update( Usucger_DB::t( 'candidates' ), array(
		'status'     => $accept ? 'accepted' : 'declined',
		'statement'  => mb_substr( sanitize_textarea_field( wp_unslash( $_POST['statement'] ) ), 0, 1500 ),
		'rank_title' => $rank,
	), array( 'id' => $c->id ) );
	usucger_notify( usucger_election_notify_to(), ( $accept ? 'Nomination accepted: ' : 'Nomination declined: ' ) . $c->name, '<p>' . esc_html( $c->name ) . ' has ' . ( $accept ? 'accepted' : 'declined' ) . ' the nomination.</p>' . ( $accept ? '<p>Ask them for their candidate statement from the <a href="' . esc_url( usucger_desk_url() ) . '">desk</a> (one click, you approve the email).</p>' : '' ) );
	if ( ! empty( $_POST['from_portal'] ) && is_email( $c->email ) ) {
		wp_mail( $c->email, 'Your nomination: ' . ( $accept ? 'accepted' : 'declined' ), usucger_email_letter( usucger_email_inline( '<p>Dear ' . esc_html( $c->name ) . ',</p><p>We recorded that you <strong>' . ( $accept ? 'accepted' : 'declined' ) . '</strong> the nomination for the ' . esc_html( ucfirst( $c->position ) ) . ' Director seat in the member area. If this was not you, please reply to this email.</p>' ), 'Official USUCGER election notice.' ), usucger_mail_headers() );
	}
	if ( ! empty( $_POST['from_portal'] ) ) {
		wp_safe_redirect( add_query_arg( 'nomination', $accept ? 'accepted' : 'declined', usucger_portal_url() ) );
		exit;
	}
	wp_safe_redirect( $accept ? add_query_arg( 'accepted', 1, usucger_packet_url( $c ) ) : add_query_arg( array( 'usg_nominee' => $c->id, 'k' => usucger_candidate_token( $c ), 'done' => 'declined' ), usucger_election_page_url() ) );
	exit;
}

/* ========================================================= public page / ballot */

add_action( 'admin_post_usucger_vote', 'usucger_handle_vote' );
add_action( 'admin_post_nopriv_usucger_vote', 'usucger_handle_vote' );
function usucger_handle_vote() {
	$e   = usucger_election( (int) $_POST['election'] );
	$tok = sanitize_text_field( wp_unslash( $_POST['tok'] ) );
	if ( ! $e || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_usgv'] ) ), 'usucger_vote_' . $tok ) ) {
		wp_die( 'This ballot form has expired. Please open your ballot link again.' );
	}
	list( $v, $role ) = usucger_voter_by_token( $e->id, $tok );
	if ( ! $v ) {
		wp_die( 'Invalid ballot link.' );
	}
	$by      = 'alternate' === $role ? $v->alternate_email : $v->delegate_email;
	$choices = array_map( 'intval', (array) ( isset( $_POST['choice'] ) ? wp_unslash( $_POST['choice'] ) : array() ) );
	$r       = usucger_cast_ballot( $e, $v, $choices, $role . ':' . $by );
	$back    = add_query_arg( array( 'usg_ballot' => $tok, 'e' => $e->id ), usucger_election_page_url() );
	if ( is_wp_error( $r ) ) {
		wp_safe_redirect( add_query_arg( usucger_flash_arg( 'verr', $r->get_error_message() ), $back ) );
		exit;
	}
	// email the receipt to the voter (not the choices)
	$body = '<p>Thank you. The ballot for <strong>' . esc_html( $v->institution ) . '</strong> in the ' . esc_html( $e->title ) . ' has been recorded.</p><p>Your receipt code is <strong style="font-size:18px;letter-spacing:1px">' . esc_html( $r ) . '</strong></p><p>You can use it on the <a href="' . esc_url( usucger_election_page_url() ) . '#receipt">elections page</a> to confirm your ballot was counted. Your choices are not stored with your name or institution.</p>';
	wp_mail( $by, 'Ballot received — ' . $e->title, usucger_email_letter( usucger_email_inline( $body ), 'Official USUCGER election notice.' ), usucger_mail_headers() );
	$rk = wp_generate_password( 20, false, false ); // one-time key, unrelated to the voter token
	set_transient( 'usg_rc_' . $rk, $r, 10 * MINUTE_IN_SECONDS );
	wp_safe_redirect( add_query_arg( array( 'voted' => 1, 'rk' => $rk ), $back ) );
	exit;
}

function usucger_ballot_html( $e, $v, $tok, $role ) {
	$o = '<div class="usg-ballot" id="ballot">';
	if ( isset( $_GET['voted'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		$rk = isset( $_GET['rk'] ) ? sanitize_key( $_GET['rk'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		$rc = $rk ? get_transient( 'usg_rc_' . $rk ) : '';
		if ( $rk ) {
			delete_transient( 'usg_rc_' . $rk ); // shown once
		}
		return $o . '<div class="usg-card usg-ok"><h2>Ballot recorded — thank you</h2><p>The ballot for <strong>' . esc_html( $v->institution ) . '</strong> has been counted.' . ( $rc ? ' Your receipt code is <strong class="usg-receipt">' . esc_html( $rc ) . '</strong> (also emailed to you).' : '' ) . '</p></div></div>';
	}
	$phase = usucger_election_phase( $e );
	if ( $v->voted_at ) {
		return $o . '<div class="usg-card"><h2>Your institution has voted</h2><p>The ballot for ' . esc_html( $v->institution ) . ' was cast on ' . esc_html( mysql2date( 'F j, Y', $v->voted_at ) ) . ' by the ' . esc_html( 0 === strpos( $v->voted_by, 'alternate' ) ? 'alternate' : 'delegate' ) . '. Each institution casts one ballot (By-Laws Art. III §3).</p></div></div>';
	}
	if ( ! $v->eligible ) {
		return $o . '<div class="usg-card"><h2>Not eligible to vote</h2><p>' . esc_html( $v->institution ) . ': ' . esc_html( $v->reason ) . '. Contact ' . esc_html( usucger_core_opt( 'contact_email' ) ) . ' if this is wrong.</p></div></div>';
	}
	if ( 'voting' !== $phase ) {
		return $o . '<div class="usg-card"><h2>Voting is not open</h2><p>' . ( 'closed' === $phase || 'certified' === $phase ? 'Voting closed on ' : 'Voting opens on ' . esc_html( usucger_fmt_date( $e->vote_open, 'F j, Y' ) ) . ' and closes on ' ) . esc_html( usucger_fmt_date( $e->vote_close, 'F j, Y' ) ) . '.</p></div></div>';
	}
	$o .= '<form method="post" class="usg-card usg-form" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" onsubmit="return confirm(\'Submit the ballot for ' . esc_attr( $v->institution ) . '? It cannot be changed afterwards.\')">'
		. '<input type="hidden" name="action" value="usucger_vote"><input type="hidden" name="election" value="' . (int) $e->id . '"><input type="hidden" name="tok" value="' . esc_attr( $tok ) . '"><input type="hidden" name="_usgv" value="' . esc_attr( wp_create_nonce( 'usucger_vote_' . $tok ) ) . '">'
		. '<div class="eyebrow"><span class="eyebrow-line"></span>Official ballot</div><h2>' . esc_html( $e->title ) . '</h2>'
		. '<p>Voting for <strong>' . esc_html( $v->institution ) . '</strong> as its ' . esc_html( $role ) . '. One ballot per institution — ' . ( 'board' === $e->kind ? 'one vote for the junior seat and one for the senior seat.' : 'one vote.' ) . ' Closes ' . esc_html( usucger_fmt_date( $e->vote_close, 'F j, Y' ) ) . '.</p>';
	if ( usucger_flash_read( 'verr' ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		$o .= '<div class="usg-notice">' . esc_html( usucger_flash_read( 'verr' ) ) . '</div>'; // phpcs:ignore WordPress.Security.NonceVerification
	}
	if ( 'board' !== $e->kind && $e->question ) {
		$o .= '<div class="usg-question">' . wpautop( wp_kses_post( $e->question ) ) . '</div>';
	}
	foreach ( usucger_positions_for( $e ) as $pos => $label ) {
		$o .= '<fieldset class="usg-seat"><legend>' . esc_html( $label ) . '</legend>';
		foreach ( usucger_candidates( $e->id, array( 'approved' ) ) as $c ) {
			if ( $c->position !== $pos ) {
				continue;
			}
			if ( 'question' === $pos ) {
				$o .= '<label class="usg-cand"><input type="radio" name="choice[' . esc_attr( $pos ) . ']" value="' . (int) $c->id . '" required><span><strong>' . esc_html( $c->name ) . '</strong></span></label>';
			} else {
				$o .= '<label class="usg-cand usg-cand-card"><input type="radio" name="choice[' . esc_attr( $pos ) . ']" value="' . (int) $c->id . '" required>' . usucger_candidate_card( $c ) . '</label>';
			}
		}
		$o .= '<label class="usg-cand usg-abstain"><input type="radio" name="choice[' . esc_attr( $pos ) . ']" value="0"><span>Abstain for this ' . ( 'question' === $pos ? 'question' : 'seat' ) . '</span></label></fieldset>';
	}
	return $o . '<button class="btn btn-amber" type="submit">Submit ' . esc_html( $v->institution ) . '’s ballot</button><p class="usg-small">Your choices are stored without your name or institution. You will get a receipt code to confirm your ballot was counted.</p></form></div>';
}

function usucger_election_page_html() {
	$eid = isset( $_GET['e'] ) ? (int) $_GET['e'] : 0; // phpcs:ignore WordPress.Security.NonceVerification
	$e   = $eid ? usucger_election( $eid ) : usucger_current_election();
	$o   = '';
	// candidate statement packet
	if ( isset( $_GET['usg_packet'], $_GET['k'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		$c = usucger_candidate( (int) $_GET['usg_packet'] ); // phpcs:ignore WordPress.Security.NonceVerification
		if ( $c && hash_equals( usucger_candidate_token( $c ), sanitize_text_field( wp_unslash( $_GET['k'] ) ) ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return usucger_packet_form_html( $c );
		}
		return '<div class="usg-notice">This link is not valid. Please use the link in your most recent email.</div>';
	}
	// nominee accept/decline
	if ( isset( $_GET['usg_nominee'], $_GET['k'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		$c = usucger_candidate( (int) $_GET['usg_nominee'] ); // phpcs:ignore WordPress.Security.NonceVerification
		if ( $c && hash_equals( usucger_candidate_token( $c ), sanitize_text_field( wp_unslash( $_GET['k'] ) ) ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			if ( isset( $_GET['done'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
				return '<div class="usg-card usg-ok"><h2>Thank you</h2><p>Your response (' . esc_html( sanitize_key( $_GET['done'] ) ) . ') has been recorded. The webmaster will confirm the ballot.</p></div>'; // phpcs:ignore WordPress.Security.NonceVerification
			}
			$o = '<form method="post" class="usg-card usg-form" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="usucger_nominee"><input type="hidden" name="cand" value="' . (int) $c->id . '"><input type="hidden" name="k" value="' . esc_attr( usucger_candidate_token( $c ) ) . '">'
				. '<h2>Your nomination</h2><p>You were nominated for the <strong>' . esc_html( ucfirst( $c->position ) ) . ' Director</strong> seat.</p><label for="usgrank">Your rank</label><select id="usgrank" name="rank">';
			foreach ( usucger_ranks() as $r => $x ) {
				$o .= '<option' . selected( $c->rank_title, $r, false ) . '>' . esc_html( $r ) . '</option>';
			}
			$o .= '</select><label for="usgst">Statement for the ballot (up to 1,500 characters)</label><textarea id="usgst" name="statement" rows="6">' . esc_textarea( (string) $c->statement ) . '</textarea><p><button class="btn btn-cobalt" name="accept" value="1">I accept the nomination</button> <button class="btn btn-outline" name="decline" value="1">I decline</button></p></form>';
			return $o;
		}
	}
	// ballot by link
	if ( isset( $_GET['usg_ballot'] ) && $e ) { // phpcs:ignore WordPress.Security.NonceVerification
		$tok              = sanitize_text_field( wp_unslash( $_GET['usg_ballot'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
		list( $v, $role ) = usucger_voter_by_token( $e->id, $tok );
		if ( $v ) {
			return usucger_ballot_html( $e, $v, $tok, $role );
		}
		$o .= '<div class="usg-notice">This ballot link is not valid. Use the newest email you received, or contact ' . esc_html( usucger_core_opt( 'contact_email' ) ) . '.</div>';
	}
	if ( ! $e || 'draft' === $e->status ) {
		return $o . '<div class="usg-card"><h2>No election is under way</h2><p>Board elections follow the By-Laws: nominations are announced by September 30, close October 30, and delegates vote by December 1.</p></div>' . usucger_receipt_form();
	}
	$phase = usucger_election_phase( $e );
	$t     = usucger_turnout( $e->id );
	$o    .= '<div class="usg-card"><div class="eyebrow"><span class="eyebrow-line"></span>' . esc_html( usucger_phase_labels()[ $phase ] ) . '</div><h2>' . esc_html( $e->title ) . '</h2>';
	if ( 'board' === $e->kind ) {
		$steps = array(
			array( 'nominations', 'Nominations open', $e->nom_open ),
			array( 'review', 'Nominations close', $e->nom_close ),
			array( 'voting', 'Voting opens', $e->vote_open ),
			array( 'closed', 'Voting closes', $e->vote_close ),
			array( 'certified', 'Results', $e->certified_at ? substr( $e->certified_at, 0, 10 ) : '' ),
		);
		$order = array_flip( array( 'scheduled', 'nominations', 'review', 'voting', 'closed', 'certified' ) );
		$o    .= '<ol class="usg-timeline">';
		foreach ( $steps as $s ) {
			$state = isset( $order[ $s[0] ] ) && $order[ $phase ] >= $order[ $s[0] ] ? ( $order[ $phase ] === $order[ $s[0] ] ? 'now' : 'done' ) : '';
			$o    .= '<li class="' . $state . '"><b>' . esc_html( $s[1] ) . '</b><span>' . esc_html( $s[2] ? usucger_fmt_date( $s[2] ) : '—' ) . '</span></li>';
		}
		$o .= '</ol>';
	} else {
		$o .= '<p>Voting ' . esc_html( usucger_fmt_date( $e->vote_open ) . ' – ' . usucger_fmt_date( $e->vote_close ) ) . '. ' . ( 'two_thirds' === $e->settings['threshold'] ? 'Passes with two-thirds of the delegates voting (Art. IX).' : 'Simple majority.' ) . '</p>' . wpautop( wp_kses_post( $e->question ) );
	}
	if ( in_array( $phase, array( 'voting', 'closed' ), true ) ) {
		$o .= '<div class="usg-turnout"><div class="usg-meter"><i style="width:' . (int) $t['pct'] . '%"></i></div><span><strong>' . (int) $t['voted'] . '</strong> of ' . (int) $t['eligible'] . ' member institutions have voted (' . (int) $t['pct'] . '%)</span></div>';
	}
	$o .= '<p class="usg-small"><strong>Who votes:</strong> each member institution with paid dues casts one ballot through its designated delegate (or the one alternate the delegate names) — ' . ( 'board' === $e->kind ? 'one vote for a junior and one for a senior Board candidate' : 'one vote' ) . '. No proxy votes (By-Laws Art. III §2–3).</p></div>';

	// my ballot (signed in)
	$mine = usucger_my_ballot();
	if ( $mine && $mine->election->id === $e->id ) {
		if ( 'voting' === $phase && ! $mine->voter->voted_at ) {
			$o .= '<div class="usg-card usg-cta"><h3>You can vote for ' . esc_html( $mine->voter->institution ) . '</h3><p>You are the institution’s ' . esc_html( $mine->role ) . '. Voting closes ' . esc_html( usucger_fmt_date( $e->vote_close, 'F j, Y' ) ) . '.</p><a class="btn btn-amber" href="' . esc_url( $mine->url ) . '">Email me my ballot link &rarr;</a><p class="usg-small">For security, ballots open only from the personal link sent to the delegate’s and alternate’s addresses on file.</p></div>';
		} elseif ( $mine->voter->voted_at ) {
			$o .= '<div class="usg-card usg-ok"><h3>' . esc_html( $mine->voter->institution ) . ' has voted</h3><p>Thank you.</p></div>';
		} else {
			$o .= '<div class="usg-card"><h3>You are ' . esc_html( $mine->voter->institution ) . '’s ' . esc_html( $mine->role ) . '</h3><p>Your ballot link will be emailed when voting opens on ' . esc_html( usucger_fmt_date( $e->vote_open, 'F j, Y' ) ) . '.</p></div>';
		}
	}

	// nominees
	$cands = usucger_candidates( $e->id, array( 'approved' ) );
	if ( $cands && in_array( $phase, array( 'review', 'voting', 'closed', 'certified' ), true ) ) {
		$o .= '<div class="usg-grid2">';
		foreach ( usucger_positions_for( $e ) as $pos => $label ) {
			if ( 'question' === $pos ) {
				continue;
			}
			$o .= '<div class="usg-card"><h3>' . esc_html( $label ) . ' nominees</h3>';
			foreach ( $cands as $c ) {
				if ( $c->position === $pos ) {
					$o .= usucger_candidate_card( $c );
				}
			}
			$o .= '</div>';
		}
		$o .= '</div>';
	}

	// nomination form
	if ( 'nominations' === $phase ) {
		$o .= '<div class="usg-card" id="nominate"><h3>Nominate a colleague (or yourself)</h3>';
		if ( isset( $_GET['nominated'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			$o .= 'again' === $_GET['nominated'] // phpcs:ignore
				? '<div class="usg-notice"><strong>Thank you.</strong> That person has already been nominated in this election; the election officer has noted your support.</div>'
				: '<div class="usg-notice"><strong>Thank you.</strong> The election officer has been notified and will ask the nominee whether they are willing to stand.</div>';
		}
		if ( ! usucger_is_member_viewer() ) {
			$o .= '<p>Current members can nominate after <a href="' . esc_url( usucger_portal_url() ) . '">signing in</a>. Nominations close ' . esc_html( usucger_fmt_date( $e->nom_close, 'F j, Y' ) ) . '.</p>';
		} else {
			$o .= '<p class="usg-muted">Junior seat: Assistant Professor. Senior seat: Associate or Full Professor. Nominees must be paid members at a member institution, and only one delegate per institution can serve on the Board. Closes ' . esc_html( usucger_fmt_date( $e->nom_close, 'F j, Y' ) ) . '.</p>'
				. '<form method="post" class="usg-form" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">' . wp_nonce_field( 'usucger_nominate', '_wpnonce', true, false ) . '<input type="hidden" name="action" value="usucger_nominate"><input type="hidden" name="election" value="' . (int) $e->id . '">'
				. '<div class="usg-row2"><div><label for="usgnn">Nominee name</label><input id="usgnn" name="name" required></div><div><label for="usgne">Nominee email</label><input id="usgne" type="email" name="email" required></div></div>'
				. '<div class="usg-row2"><div><label for="usgni">Institution</label><input id="usgni" name="institution" required list="usgInst"></div><div><label for="usgnr">Rank</label><select id="usgnr" name="rank" required><option value="">Choose…</option>';
			foreach ( usucger_ranks() as $r => $x ) {
				$o .= '<option>' . esc_html( $r ) . '</option>';
			}
			$o .= '</select></div></div><datalist id="usgInst">';
			foreach ( Usucger_Members::institutions() as $i ) {
				$o .= '<option value="' . esc_attr( $i->name ) . '">';
			}
			$o .= '</datalist><label for="usgnp">Seat</label><select id="usgnp" name="position"><option value="junior">Junior Director</option><option value="senior">Senior Director</option></select>'
				. '<label for="usgnw">Why this person? (optional)</label><input id="usgnw" name="why" maxlength="250"><input type="hidden" name="statement" value=""><button class="btn btn-cobalt" type="submit">Submit nomination</button></form>';
		}
		$o .= '</div>';
	}

	// results
	if ( 'certified' === $phase && is_array( $e->results ) ) {
		$o .= '<div class="usg-card"><h3>Results</h3>';
		foreach ( $e->results['tally'] as $pos => $r ) {
			$o .= '<h4>' . esc_html( $r['label'] ) . ': ' . esc_html( $r['winner'] ? $r['winner'] : 'tie — decided by secret ballot of the Board' ) . '</h4><table class="usg-table"><tbody>';
			foreach ( $r['rows'] as $row ) {
				$o .= '<tr><td>' . esc_html( $row['name'] ) . '</td><td>' . (int) $row['votes'] . '</td></tr>';
			}
			$o .= '<tr><td><em>Abstained</em></td><td>' . (int) $r['abstain'] . '</td></tr></tbody></table>';
		}
		$o .= '<p class="usg-small">Turnout: ' . (int) $e->results['turnout']['voted'] . ' of ' . (int) $e->results['turnout']['eligible'] . ' member institutions. Certified ' . esc_html( mysql2date( 'F j, Y', $e->certified_at ) ) . '.</p></div>';
	}
	return $o . usucger_receipt_form();
}

function usucger_receipt_form() {
	$o = '<div class="usg-card" id="receipt"><h3>Check a ballot receipt</h3>';
	if ( isset( $_GET['receipt'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		global $wpdb;
		$code = strtoupper( sanitize_text_field( wp_unslash( $_GET['receipt'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification
		$n    = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . Usucger_DB::t( 'receipts' ) . ' WHERE receipt_hash = %s', hash( 'sha256', $code ) ) );
		$o   .= $n ? '<div class="usg-notice usg-ok-n"><strong>Counted.</strong> A ballot with this receipt is in the count.</div>' : '<div class="usg-notice">No ballot found with that receipt code.</div>';
	}
	return $o . '<form method="get" action="' . esc_url( usucger_election_page_url() ) . '#receipt" class="usg-search"><input name="receipt" placeholder="XXXX-XXXX-XXXX" aria-label="Receipt code"><button class="btn btn-outline" type="submit">Check</button></form></div>';
}

add_shortcode( 'usucger_election', function () {
	return '<section class="section bg-white usg-portal"><div class="wrap">' . usucger_election_page_html() . '</div></section>';
} );

/** Member area tab. */
function usucger_portal_vote() {
	return ( function_exists( 'usucger_portal_nomination_box' ) ? usucger_portal_nomination_box() : '' ) . usucger_election_page_html() . ( function_exists( 'usucger_alternate_box' ) ? usucger_alternate_box() : '' );
}

/** Banner for the member area home page. */
function usucger_portal_election_banner() {
	$mine = usucger_my_ballot();
	if ( $mine && 'voting' === $mine->phase && ! $mine->voter->voted_at ) {
		return '<div class="usg-banner"><div><strong>Your institution’s ballot is open.</strong> You are ' . esc_html( $mine->voter->institution ) . '’s ' . esc_html( $mine->role ) . ' for the ' . esc_html( $mine->election->title ) . '. Voting closes ' . esc_html( usucger_fmt_date( $mine->election->vote_close, 'F j' ) ) . '. Your personal ballot link is in your email.</div><a class="btn btn-amber" href="' . esc_url( $mine->url ) . '">Email me my ballot link &rarr;</a></div>';
	}
	$e = usucger_current_election();
	if ( $e && 'nominations' === usucger_election_phase( $e ) ) {
		return '<div class="usg-banner"><div><strong>Board nominations are open</strong> until ' . esc_html( usucger_fmt_date( $e->nom_close, 'F j' ) ) . '. Nominate a colleague — or yourself — for a junior or senior seat.</div><a class="btn btn-amber" href="' . esc_url( usucger_election_page_url() ) . '#nominate">Nominate &rarr;</a></div>';
	}
	return '';
}

/* =================================================================== templates */

add_action( 'init', function () {
	$have = usucger_email_templates();
	$add  = array(
		'election_nominations'  => array( 'Election: call for nominations', 'official', 'Call for nominations: USUCGER Board of Directors', "<p>Dear {first_name},</p>\n<p>Nominations are open for the <strong>{election_title}</strong>. Each year USUCGER elects one <strong>junior</strong> director (Assistant Professor) and one <strong>senior</strong> director (Associate or Full Professor) for four-year terms.</p>\n<p>Any current member may nominate a colleague or themselves. Nominees must be paid members at a member institution, and only one delegate per institution may serve on the Board at a time.</p>\n<p><a href=\"{nominate_url}\">Submit a nomination</a> by <strong>{nom_close}</strong>.</p>\n{signature}" ),
		'election_slate'        => array( 'Election: Nominating Committee slate + call for nominations', 'official', 'USUCGER Board of Directors: nominees and call for additional nominations', "<p>Colleagues,</p>\n<p>The USUCGER Board of Directors Nominating Committee is preparing for our upcoming election cycle, and we have nominated the following members for two open positions on the Board: one junior-level (Assistant Professor) and one senior-level (Associate or Full Professor) Board position.</p>\n{nominees_list}\n<p>Per the <a href=\"{bylaws_url}\">USUCGER By-Laws</a>, a Nominating Committee consisting of two current Board members and three external members was formed. This year's nominating committee included {nominating_committee}.</p>\n<p>We are now soliciting additional nominations from all USUCGER members, according to the by-laws. Any USUCGER member can self-nominate or be nominated by the general membership, above and beyond those names put forward by the Nominating Committee. The current Board members are listed <a href=\"{board_url}\">here</a>, and terms are four years in duration. Please <a href=\"{nominate_url}\">submit nominations online</a> or send them to {nomination_contacts} by <strong>{nom_close}</strong> at the latest, after checking that the person you nominate is willing to serve if elected.</p>\n<p>Elections will be held in November once the nomination period is closed, and we will reach out with instructions regarding voting at that time. Thank you in advance, and feel free to contact me with any questions.</p>\n{signature}" ),
		'election_nom_reminder' => array( 'Election: nominations close soon', 'official', 'One week left to nominate for the USUCGER Board', "<p>Dear {first_name},</p>\n<p>Nominations for the {election_title} close on <strong>{nom_close}</strong>. <a href=\"{nominate_url}\">Nominate a colleague or yourself</a>.</p>\n{signature}" ),
		'election_voting'       => array( 'Election: ballot to delegates', 'official', 'Your institution’s ballot: {election_title}', "<p>Dear {first_name},</p>\n<p>As the delegate (or alternate) for <strong>{voter_institution}</strong>, you can now cast your institution’s ballot in the {election_title}: one vote for the junior seat and one for the senior seat.</p>\n{candidates_list}\n{ballot_button}\n<p>Voting closes on <strong>{vote_close}</strong>. Each institution casts one ballot; no proxy votes (By-Laws Art. III).</p>\n{signature}" ),
		'election_reminder'     => array( 'Election: reminder to delegates who have not voted', 'official', 'Reminder: {voter_institution} has not voted yet', "<p>Dear {first_name},</p>\n<p>Our records show that <strong>{voter_institution}</strong> has not yet cast its ballot in the {election_title}. Voting closes on <strong>{vote_close}</strong> — so far {turnout} member institutions have voted.</p>\n{ballot_button}\n<p>If you have voted in the last few hours, thank you — please ignore this message.</p>\n{signature}" ),
		'election_results'      => array( 'Election: results announcement', 'official', 'Results: {election_title}', "<p>Dear {first_name},</p>\n<p>The results of the {election_title} have been certified:</p>\n{results}\n<p>Thank you to all nominees and to the {turnout} member institutions that voted. New directors take office at the annual meeting.</p>\n{signature}" ),
	);
	$changed = false;
	foreach ( $add as $k => $v ) {
		if ( ! isset( $have[ $k ] ) ) {
			$have[ $k ] = array( 'name' => $v[0], 'kind' => $v[1], 'subject' => $v[2], 'body' => $v[3] );
			$changed    = true;
		}
	}
	if ( $changed ) {
		update_option( 'usucger_templates', $have, false );
	}
}, 20 );


/* Re-send the ballot link to the delegate/alternate address ON FILE (never shown on screen). */
add_action( 'admin_post_usucger_resend_ballot', function () {
	check_admin_referer( 'usucger_resend_ballot' );
	$mine = usucger_my_ballot();
	if ( $mine && 'voting' === $mine->phase && ! $mine->voter->voted_at && ! get_transient( 'usg_rs_' . $mine->voter->id ) ) {
		set_transient( 'usg_rs_' . $mine->voter->id, 1, 10 * MINUTE_IN_SECONDS );
		$v     = $mine->voter;
		$email = 'delegate' === $mine->role ? $v->delegate_email : $v->alternate_email;
		$url   = usucger_ballot_url( $v, $email );
		$body  = '<p>Here is the ballot link for <strong>' . esc_html( $v->institution ) . '</strong> in the ' . esc_html( $mine->election->title ) . '. It is personal — please do not forward it.</p><table role="presentation" cellpadding="0" cellspacing="0" style="margin:0 0 18px"><tr><td style="background:#C2410C;border-radius:4px"><a href="' . esc_url( $url ) . '" style="display:inline-block;padding:12px 22px;font-family:Arial,sans-serif;font-size:15px;font-weight:700;color:#fff;text-decoration:none">Cast ' . esc_html( $v->institution ) . '’s ballot &rarr;</a></td></tr></table><p>Voting closes ' . esc_html( usucger_fmt_date( $mine->election->vote_close, 'F j, Y' ) ) . '.</p>';
		wp_mail( $email, 'Your ballot link — ' . $mine->election->title, usucger_email_letter( usucger_email_inline( $body ), 'Official USUCGER election notice.' ), usucger_mail_headers() );
		Usucger_DB::log( 'ballot_link_resent', 'election:' . $mine->election->id, $v->institution );
	}
	wp_safe_redirect( add_query_arg( array( 'tab' => 'vote', 'sent' => 1 ), usucger_portal_url() ) );
	exit;
} );
