<?php
/**
 * Online forms that replace "email the webmaster" links:
 *   [usucger_submit_position]      → pending Position in the review queue
 *   [usucger_award_nomination]     → private Nomination for the Board (with PDF uploads)
 *   [usucger_travel_grant_apply]   → private Travel-grant application (advisor must be a current member)
 * Submissions are listed in USUCGER → Submissions. Uploaded files are stored outside public
 * listing (random names, no directory index) and downloaded through a permission-checked link.
 *
 * @package usucger-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'init', function () {
	foreach ( array(
		'usucger_nomination' => array( 'Award nomination', 'Award nominations' ),
		'usucger_tg_app'     => array( 'Travel grant application', 'Travel grant applications' ),
	) as $pt => $l ) {
		register_post_type( $pt, array(
			'labels'          => array( 'name' => $l[1], 'singular_name' => $l[0] ),
			'public'          => false,
			'show_ui'         => false,
			'capability_type' => 'post',
			'map_meta_cap'    => true,
		) );
	}
} );

/* ------------------------------------------------------------------ helpers */

function usucger_form_guard( $key ) {
	$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	$k   = 'usg_f_' . $key . '_' . md5( $ip );
	$n   = (int) get_transient( $k );
	if ( $n >= 8 ) {
		return new WP_Error( 'rate', 'Too many submissions from this connection today. Please email ' . usucger_core_opt( 'contact_email' ) . '.' );
	}
	if ( ! empty( $_POST['usg_website'] ) ) { // honeypot
		return new WP_Error( 'spam', 'Submission blocked.' );
	}
	$t = explode( '.', sanitize_text_field( wp_unslash( isset( $_POST['usg_t'] ) ? $_POST['usg_t'] : '' ) ) );
	if ( 2 !== count( $t ) || ! hash_equals( substr( hash_hmac( 'sha256', $t[0], wp_salt( 'nonce' ) ), 0, 16 ), $t[1] ) || time() - (int) $t[0] < 4 ) { // signed: filled in faster than a human can
		return new WP_Error( 'spam', 'Please take a moment to complete the form and try again.' );
	}
	set_transient( $k, $n + 1, DAY_IN_SECONDS );
	return true;
}

function usucger_form_trap() {
	$now = (string) time();
	return '<div style="display:none" aria-hidden="true"><label>Website <input name="usg_website" tabindex="-1" autocomplete="off"></label></div><input type="hidden" name="usg_t" value="' . $now . '.' . substr( hash_hmac( 'sha256', $now, wp_salt( 'nonce' ) ), 0, 16 ) . '">';
}

/** Private upload: random name in uploads/usucger-private/<year>/, PDFs only (or images if allowed). */
function usucger_private_upload( $field, $index = null, $types = array( 'pdf' => 'application/pdf' ), $max_mb = 10 ) {
	if ( null === $index ) {
		$f = isset( $_FILES[ $field ] ) ? $_FILES[ $field ] : null; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	} else {
		$f = isset( $_FILES[ $field ]['name'][ $index ] ) ? array( // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
			'name'     => $_FILES[ $field ]['name'][ $index ], // phpcs:ignore
			'type'     => $_FILES[ $field ]['type'][ $index ], // phpcs:ignore
			'tmp_name' => $_FILES[ $field ]['tmp_name'][ $index ], // phpcs:ignore
			'error'    => $_FILES[ $field ]['error'][ $index ], // phpcs:ignore
			'size'     => $_FILES[ $field ]['size'][ $index ], // phpcs:ignore
		) : null;
	}
	if ( ! $f || empty( $f['name'] ) || ! empty( $f['error'] ) ) {
		return '';
	}
	if ( (int) $f['size'] > $max_mb * MB_IN_BYTES ) {
		return new WP_Error( 'size', sprintf( '%s is larger than %d MB.', $f['name'], $max_mb ) );
	}
	$check = wp_check_filetype_and_ext( $f['tmp_name'], $f['name'], $types );
	if ( empty( $check['ext'] ) ) {
		return new WP_Error( 'type', sprintf( '%s must be a PDF.', $f['name'] ) );
	}
	$up  = wp_upload_dir();
	$dir = $up['basedir'] . '/usucger-private/' . wp_date( 'Y' );
	if ( ! wp_mkdir_p( $dir ) ) {
		return new WP_Error( 'dir', 'Could not store the file.' );
	}
	foreach ( array( $up['basedir'] . '/usucger-private', $dir ) as $root ) {
		if ( ! file_exists( $root . '/.htaccess' ) ) {
			file_put_contents( $root . '/.htaccess', "<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n" ); // phpcs:ignore
		}
		if ( ! file_exists( $root . '/index.php' ) ) {
			file_put_contents( $root . '/index.php', "<?php // Silence.\n" ); // phpcs:ignore
		}
	}
	$name = sanitize_file_name( pathinfo( $f['name'], PATHINFO_FILENAME ) ) . '-' . strtolower( wp_generate_password( 10, false, false ) ) . '.' . $check['ext'];
	if ( ! move_uploaded_file( $f['tmp_name'], $dir . '/' . $name ) ) {
		return new WP_Error( 'move', 'Could not store the file.' );
	}
	return wp_date( 'Y' ) . '/' . $name; // relative path inside usucger-private
}

function usucger_private_file_url( $post_id, $rel ) {
	return wp_nonce_url( admin_url( 'admin-post.php?action=usucger_file&p=' . (int) $post_id . '&f=' . rawurlencode( $rel ) ), 'usucger_file_' . $post_id );
}

add_action( 'admin_post_usucger_file', function () {
	$pid = isset( $_GET['p'] ) ? (int) $_GET['p'] : 0;
	check_admin_referer( 'usucger_file_' . $pid );
	if ( ! current_user_can( 'usucger_view_members' ) ) {
		wp_die( 'Not allowed.' );
	}
	$rel   = isset( $_GET['f'] ) ? sanitize_text_field( wp_unslash( $_GET['f'] ) ) : '';
	$files = (array) get_post_meta( $pid, '_files', true );
	if ( ! in_array( $rel, $files, true ) || false !== strpos( $rel, '..' ) ) {
		wp_die( 'File not found.' );
	}
	$up   = wp_upload_dir();
	$path = $up['basedir'] . '/usucger-private/' . $rel;
	if ( ! file_exists( $path ) ) {
		wp_die( 'File not found.' );
	}
	nocache_headers();
	header( 'Content-Type: application/pdf' );
	header( 'Content-Disposition: inline; filename="' . basename( $path ) . '"' );
	header( 'Content-Length: ' . filesize( $path ) );
	readfile( $path ); // phpcs:ignore
	exit;
} );

function usucger_form_notice() {
	if ( usucger_flash_read( 'usg_ok' ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		return '<div class="usg-notice usg-ok"><strong>Thank you — received.</strong> ' . esc_html( usucger_flash_read( 'usg_ok' ) ) . '</div>'; // phpcs:ignore
	}
	if ( usucger_flash_read( 'usg_err' ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		return '<div class="usg-notice"><strong>Not sent.</strong> ' . esc_html( usucger_flash_read( 'usg_err' ) ) . '</div>'; // phpcs:ignore
	}
	return '';
}

function usucger_form_back( $ok, $msg ) {
	$ref = wp_get_referer() ? remove_query_arg( array( 'usg_ok', 'usg_err', 'usg_ok_s', 'usg_err_s' ), wp_get_referer() ) : home_url( '/' );
	wp_safe_redirect( add_query_arg( usucger_flash_arg( $ok ? 'usg_ok' : 'usg_err', $msg ), $ref ) . '#usgform' );
	exit;
}

/** Next open deadline whose label contains $word (e.g. 'award', 'travel'). */
function usucger_next_deadline( $word ) {
	$best = null;
	foreach ( usucger_items( 'usucger_deadline' ) as $d ) {
		if ( false !== stripos( $d['title'], $word ) && $d['date'] >= usucger_today() && ( ! $best || $d['date'] < $best['date'] ) ) {
			$best = $d;
		}
	}
	return $best;
}

/* ======================================================== position submission */

add_shortcode( 'usucger_submit_position', function () {
	$u = wp_get_current_user();
	return '<section class="section bg-white usg-portal" id="usgform"><div class="wrap"><div class="usg-grid2"><div>' . usucger_form_notice()
		. '<form class="usg-card usg-form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">' . wp_nonce_field( 'usucger_pos', '_wpnonce', true, false ) . '<input type="hidden" name="action" value="usucger_submit_position">' . usucger_form_trap()
		. '<h2>Post a position</h2><p class="usg-muted">Free for member institutions. Listings are reviewed by the webmaster and stay up for one year (or until the closing date).</p>'
		. '<label for="pt">Position title</label><input id="pt" name="title" required maxlength="200" placeholder="Assistant Professor in Geotechnical Engineering">'
		. '<div class="usg-row2"><div><label for="pi">Institution / employer</label><input id="pi" name="institution" required maxlength="190"></div><div><label for="pl">Location <span class="usg-opt">(optional)</span></label><input id="pl" name="location" maxlength="120" placeholder="City, State"></div></div>'
		. '<label for="pu">Link to the official posting</label><input id="pu" type="url" name="url" required placeholder="https://">'
		. '<div class="usg-row2"><div><label for="pk">Board</label><select id="pk" name="kind"><option value="academic">Academic (faculty, lecturer, postdoc)</option><option value="industry"' . selected( isset( $_GET['kind'] ) && 'industry' === $_GET['kind'], true, false ) . '>Industry or agency</option></select></div><div><label for="pc">Closing date <span class="usg-opt">(optional)</span></label><input id="pc" type="date" name="closes"></div></div>'
		. '<div class="usg-row2"><div><label for="pn">Your name</label><input id="pn" name="contact_name" required autocomplete="name" value="' . esc_attr( $u->ID ? $u->display_name : '' ) . '"></div><div><label for="pe">Your email</label><input id="pe" type="email" name="contact_email" required autocomplete="email" value="' . esc_attr( $u->ID ? $u->user_email : '' ) . '"></div></div>'
		. '<button class="btn btn-cobalt" type="submit">Submit for posting</button></form></div>'
		. '<aside><div class="info-callout"><div class="ic-head">What happens next</div><div class="ic-body">The webmaster checks the link and publishes the listing, usually within a few days. You will get an email when it is live.</div></div></aside></div></div></section>';
} );

add_action( 'admin_post_usucger_submit_position', 'usucger_handle_position' );
add_action( 'admin_post_nopriv_usucger_submit_position', 'usucger_handle_position' );
function usucger_handle_position() {
	check_admin_referer( 'usucger_pos' );
	$g = usucger_form_guard( 'pos' );
	if ( is_wp_error( $g ) ) {
		usucger_form_back( false, $g->get_error_message() );
	}
	$p   = wp_unslash( $_POST );
	$url = esc_url_raw( $p['url'] );
	$em  = sanitize_email( $p['contact_email'] );
	if ( ! $url || ! is_email( $em ) || ! trim( $p['title'] ) ) {
		usucger_form_back( false, 'Please fill in the title, link and your email.' );
	}
	$id = wp_insert_post( array( 'post_type' => 'usucger_position', 'post_status' => 'pending', 'post_title' => sanitize_text_field( $p['title'] ), 'post_author' => get_current_user_id() ) );
	foreach ( array( 'institution' => sanitize_text_field( $p['institution'] ), 'location' => sanitize_text_field( $p['location'] ), 'url' => $url, 'kind' => 'industry' === $p['kind'] ? 'industry' : 'academic', 'posted' => usucger_today(), 'closes' => preg_match( '/^\d{4}-\d{2}-\d{2}$/', $p['closes'] ) ? $p['closes'] : '', '_submitter' => sanitize_text_field( $p['contact_name'] ) . ' <' . $em . '>' ) as $k => $v ) {
		update_post_meta( $id, $k, $v );
	}
	usucger_notify( usucger_approver_emails(), 'Position submitted: ' . sanitize_text_field( $p['title'] ), '<p>' . esc_html( sanitize_text_field( $p['contact_name'] ) ) . ' (' . esc_html( $em ) . ') submitted a position at <strong>' . esc_html( sanitize_text_field( $p['institution'] ) ) . '</strong>.</p><p><a href="' . esc_url( $url ) . '">Official posting</a> · <a href="' . esc_url( usucger_desk_url() ) . '">Approve on the dashboard</a></p>' );
	Usucger_DB::log( 'position_submitted', 'post:' . $id, $em );
	usucger_form_back( true, 'The webmaster will review the listing and email you when it is live.' );
}

/* Tell the submitter when their listing goes live. */
add_action( 'transition_post_status', function ( $new, $old, $post ) {
	if ( 'usucger_position' === $post->post_type && 'publish' === $new && 'publish' !== $old ) {
		$sub = (string) get_post_meta( $post->ID, '_submitter', true );
		if ( preg_match( '/<([^>]+)>/', $sub, $m ) && is_email( $m[1] ) ) {
			usucger_notify( $m[1], 'Your position is posted: ' . $post->post_title, '<p>Your listing <strong>' . esc_html( $post->post_title ) . '</strong> is now on the <a href="' . esc_url( usucger_core_url( 'positions' ) ) . '">USUCGER positions board</a>.</p>' );
		}
	}
}, 10, 3 );

/* ========================================================= award nomination */

add_shortcode( 'usucger_award_nomination', function () {
	$u     = wp_get_current_user();
	$dl    = usucger_next_deadline( 'award' );
	$types = $dl ? usucger_open_awards( $dl ) : array();
	$o = '<section class="section bg-white usg-portal" id="usgform"><div class="wrap"><div class="usg-grid2"><div>' . usucger_form_notice();
	if ( ! $dl ) {
		return $o . '<div class="usg-card"><h2>Nominations are closed</h2><p>The next call for award nominations will be announced to members and posted here.</p></div></div></div></div></section>';
	}
	$o .= '<form class="usg-card usg-form" method="post" enctype="multipart/form-data" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">' . wp_nonce_field( 'usucger_nom', '_wpnonce', true, false ) . '<input type="hidden" name="action" value="usucger_award_nomination">' . usucger_form_trap()
		. '<div class="eyebrow"><span class="eyebrow-line"></span>Due ' . esc_html( usucger_fmt_date( $dl['date'], 'F j, Y' ) ) . '</div><h2>Nominate for a USUCGER award</h2>'
		. '<label for="na">Award</label><select id="na" name="award" required>';
	foreach ( $types as $k => $name ) {
		$o .= '<option value="' . esc_attr( $k ) . '">' . esc_html( $name ) . '</option>';
	}
	$o .= '</select><div class="usg-row2"><div><label for="nn">Nominee name</label><input id="nn" name="nominee" required></div><div><label for="ni">Nominee institution</label><input id="ni" name="nominee_inst" required></div></div>'
		. '<label for="ne">Nominee email <span class="usg-opt">(optional)</span></label><input id="ne" type="email" name="nominee_email">'
		. '<div class="usg-row2"><div><label for="mn">Your name</label><input id="mn" name="nominator" required autocomplete="name" value="' . esc_attr( $u->ID ? $u->display_name : '' ) . '"></div><div><label for="me">Your email</label><input id="me" type="email" name="nominator_email" required autocomplete="email" value="' . esc_attr( $u->ID ? $u->user_email : '' ) . '"></div></div>'
		. '<fieldset class="usg-pkg"><legend>Nomination package</legend><p class="usg-small">The call asks for: the nominee’s CV (up to 4 pages), your nominator’s statement (up to 2 pages) and two recommendation letters (up to 2 pages each). Upload them <strong>as one combined PDF</strong>, or as separate PDFs below.</p>'
		. '<label for="nfp">Complete package — one PDF</label><input id="nfp" type="file" name="package" accept="application/pdf">'
		. '<details><summary>Or upload the four parts separately</summary>'
		. '<label for="nf2">Nominee CV (PDF, up to 4 pages)</label><input id="nf2" type="file" name="cv" accept="application/pdf">'
		. '<label for="nf1">Nominator’s statement (PDF, up to 2 pages)</label><input id="nf1" type="file" name="letter" accept="application/pdf">'
		. '<label for="nf3">Recommendation letter 1 (PDF)</label><input id="nf3" type="file" name="support[]" accept="application/pdf">'
		. '<label for="nf4">Recommendation letter 2 (PDF)</label><input id="nf4" type="file" name="support[]" accept="application/pdf"></details></fieldset>'
		. '<label for="ns">Anything the Board should know <span class="usg-opt">(optional)</span></label><textarea id="ns" name="statement" rows="3" maxlength="3000"></textarea>'
		. '<p class="usg-small">The nominator must be from a USUCGER member institution or an Associate member. ' . ( ! empty( $dl['pdf'] ) ? 'Full rules: <a href="' . esc_url( is_numeric( $dl['pdf'] ) ? wp_get_attachment_url( (int) $dl['pdf'] ) : $dl['pdf'] ) . '" target="_blank" rel="noopener">call for nominations (PDF)</a>. ' : '' ) . 'Files go only to the USUCGER Board.</p>'
		. '<button class="btn btn-cobalt" type="submit">Submit nomination</button></form></div>'
		. '<aside><div class="info-callout"><div class="ic-head">Questions?</div><div class="ic-body">Write to <a href="mailto:' . esc_attr( usucger_core_opt( 'board_email' ) ) . '">' . esc_html( usucger_core_opt( 'board_email' ) ) . '</a>.</div></div></aside></div></div></section>';
	return $o;
} );

add_action( 'admin_post_usucger_award_nomination', 'usucger_handle_nomination' );
add_action( 'admin_post_nopriv_usucger_award_nomination', 'usucger_handle_nomination' );
function usucger_handle_nomination() {
	check_admin_referer( 'usucger_nom' );
	$g = usucger_form_guard( 'nom' );
	if ( is_wp_error( $g ) ) {
		usucger_form_back( false, $g->get_error_message() );
	}
	if ( ! usucger_next_deadline( 'award' ) ) {
		usucger_form_back( false, 'Nominations are closed.' );
	}
	$p     = wp_unslash( $_POST );
	$types = usucger_award_types();
	$em    = sanitize_email( $p['nominator_email'] );
	if ( ! is_email( $em ) || ! isset( $types[ $p['award'] ] ) ) {
		usucger_form_back( false, 'Please check the award and your email.' );
	}
	if ( ! isset( usucger_open_awards( usucger_next_deadline( 'award' ) )[ $p['award'] ] ) ) {
		usucger_form_back( false, 'That award is not open for nominations in this call.' );
	}
	$files = array();
	$pkg   = usucger_private_upload( 'package', null, array( 'pdf' => 'application/pdf' ), 25 );
	if ( is_wp_error( $pkg ) ) {
		usucger_form_back( false, $pkg->get_error_message() );
	}
	if ( $pkg ) {
		$files['package'] = $pkg;
	}
	foreach ( array( 'letter' => null, 'cv' => null ) as $f => $i ) {
		$r = usucger_private_upload( $f );
		if ( is_wp_error( $r ) ) {
			usucger_form_back( false, $r->get_error_message() );
		}
		if ( $r ) {
			$files[ $f ] = $r;
		}
	}

	for ( $i = 0; $i < 3; $i++ ) {
		$r = usucger_private_upload( 'support', $i );
		if ( is_wp_error( $r ) ) {
			usucger_form_back( false, $r->get_error_message() );
		}
		if ( $r ) {
			$files[ 'support' . ( $i + 1 ) ] = $r;
		}
	}
	if ( empty( $files['package'] ) && ( empty( $files['cv'] ) || empty( $files['letter'] ) || empty( $files['support1'] ) || empty( $files['support2'] ) ) ) {
		usucger_form_back( false, 'Please upload the complete package as one PDF, or all four parts: CV, nominator’s statement and two recommendation letters.' );
	}
	$title = sanitize_text_field( $p['nominee'] ) . ' — ' . $types[ $p['award'] ]['name'];
	$id    = wp_insert_post( array( 'post_type' => 'usucger_nomination', 'post_status' => 'private', 'post_title' => $title, 'post_content' => sanitize_textarea_field( $p['statement'] ) ) );
	foreach ( array( 'award' => $p['award'], 'nominee' => sanitize_text_field( $p['nominee'] ), 'nominee_inst' => sanitize_text_field( $p['nominee_inst'] ), 'nominee_email' => sanitize_email( $p['nominee_email'] ), 'nominator' => sanitize_text_field( $p['nominator'] ), 'nominator_email' => $em, 'cycle' => wp_date( 'Y' ), '_status' => 'received' ) as $k => $v ) {
		update_post_meta( $id, $k, $v );
	}
	update_post_meta( $id, '_files', $files ); // label => relative path
	$to = array_merge( array( usucger_core_opt( 'board_email' ) ), usucger_approver_emails() );
	usucger_notify( array_unique( array_filter( $to, 'is_email' ) ), 'Award nomination: ' . $title, '<p>' . esc_html( sanitize_text_field( $p['nominator'] ) ) . ' nominated <strong>' . esc_html( $title ) . '</strong> (' . count( $files ) . ' file(s)).</p><p><a href="' . esc_url( usucger_admin_url( 'usucger-submissions', array( 'view' => $id ) ) ) . '">Open the nomination</a> (sign-in required)</p>' );
	usucger_notify( $em, 'Nomination received: ' . $title, '<p>Thank you — we received your nomination of ' . esc_html( $title ) . '. The Board will review all nominations after the deadline.</p>' );
	Usucger_DB::log( 'award_nomination', 'post:' . $id, $title );
	usucger_form_back( true, 'A confirmation has been emailed to you.' );
}

/* ====================================================== travel grant application */

add_shortcode( 'usucger_travel_grant_apply', function () {
	$dl = usucger_next_deadline( 'travel' );
	$o  = '<section class="section bg-white usg-portal" id="usgform"><div class="wrap"><div class="usg-grid2"><div>' . usucger_form_notice();
	if ( ! $dl ) {
		return $o . '<div class="usg-card"><h2>Applications are closed</h2><p>Dates for the next cycle will be posted on the travel grants page.</p></div></div></div></div></section>';
	}
	$o .= '<form class="usg-card usg-form" method="post" enctype="multipart/form-data" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">' . wp_nonce_field( 'usucger_tg', '_wpnonce', true, false ) . '<input type="hidden" name="action" value="usucger_travel_grant">' . usucger_form_trap()
		. '<div class="eyebrow"><span class="eyebrow-line"></span>' . esc_html( $dl['title'] ) . ' · due ' . esc_html( usucger_fmt_date( $dl['date'], 'F j, Y' ) ) . '</div><h2>Student travel grant application</h2>'
		. '<div class="usg-row2"><div><label for="sn">Student name</label><input id="sn" name="student" required autocomplete="name"></div><div><label for="se">Student email</label><input id="se" type="email" name="student_email" required autocomplete="email"></div></div>'
		. '<div class="usg-row2"><div><label for="su">University</label><input id="su" name="university" required></div><div><label for="sd">Degree program</label><select id="sd" name="degree"><option>PhD</option><option>MS</option><option>Undergraduate</option></select></div></div>'
		. '<div class="usg-row2"><div><label for="an">Advisor name</label><input id="an" name="advisor" required></div><div><label for="ae">Advisor email</label><input id="ae" type="email" name="advisor_email" required></div></div>'
		. '<p class="usg-small">The advisor must be a current USUCGER member — we check this automatically.</p>'
		. '<label for="cn">Conference</label><input id="cn" name="conference" required list="usgConfs"><datalist id="usgConfs">';
	foreach ( usucger_items( 'usucger_conference' ) as $c ) {
		$o .= '<option value="' . esc_attr( $c['title'] ) . '">';
	}
	$o .= '</datalist><div class="usg-row2"><div><label for="cd">Conference dates</label><input id="cd" name="conf_dates" required placeholder="e.g. Mar 1–5, 2027"></div><div><label for="cl">Location</label><input id="cl" name="conf_location" required></div></div>'
		. '<label for="pt2">Presentation title</label><input id="pt2" name="presentation" required>'
		. '<div class="usg-row2"><div><label for="ptp">Presentation type</label><select id="ptp" name="ptype"><option>Oral</option><option>Poster</option></select></div><div><label for="am">Amount requested (up to $1,000)</label><input id="am" type="number" name="amount" min="0" max="1000" step="1" required></div></div>'
		. '<label for="of">Other travel funding <span class="usg-opt">(optional)</span></label><input id="of" name="other_funding">'
		. '<label for="ab">Abstract / acceptance notice (PDF)</label><input id="ab" type="file" name="abstract" accept="application/pdf" required>'
		. '<label for="al">Advisor support letter (PDF, optional — the advisor can also email it)</label><input id="al" type="file" name="letter" accept="application/pdf">'
		. '<button class="btn btn-cobalt" type="submit">Submit application</button></form></div>'
		. '<aside><div class="info-callout"><div class="ic-head">Eligibility</div><div class="ic-body">Up to $1,000 per student to present at a geotechnical conference. Full rules: <a href="' . esc_url( usucger_core_url( 'travel-grants' ) ) . '">travel grants page</a>.</div></div></aside></div></div></section>';
	return $o;
} );

add_action( 'admin_post_usucger_travel_grant', 'usucger_handle_tg' );
add_action( 'admin_post_nopriv_usucger_travel_grant', 'usucger_handle_tg' );
function usucger_handle_tg() {
	check_admin_referer( 'usucger_tg' );
	$g = usucger_form_guard( 'tg' );
	if ( is_wp_error( $g ) ) {
		usucger_form_back( false, $g->get_error_message() );
	}
	$dl = usucger_next_deadline( 'travel' );
	if ( ! $dl ) {
		usucger_form_back( false, 'Applications are closed.' );
	}
	global $wpdb;
	$p   = wp_unslash( $_POST );
	$ae  = strtolower( sanitize_email( $p['advisor_email'] ) );
	$se  = sanitize_email( $p['student_email'] );
	$adv = $ae ? $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . Usucger_DB::t( 'contacts' ) . " WHERE email = %s AND status = 'current'", $ae ) ) : null;
	if ( ! $adv ) {
		// only the advisor's member email proves membership; never reveal who is or is not a member
		usucger_form_back( false, 'Please enter the email address your advisor uses for their USUCGER membership. The advisor must be a current member (they can renew at ' . usucger_core_url( 'membership' ) . ').' );
	}
	$ae = strtolower( $adv->email ); // all advisor mail goes to the member record, never to a typed address
	$files = array();
	foreach ( array( 'abstract', 'letter' ) as $f ) {
		$r = usucger_private_upload( $f );
		if ( is_wp_error( $r ) ) {
			usucger_form_back( false, $r->get_error_message() );
		}
		if ( $r ) {
			$files[ $f ] = $r;
		}
	}
	if ( empty( $files['abstract'] ) ) {
		usucger_form_back( false, 'Please attach the abstract or acceptance notice (PDF).' );
	}
	$title = sanitize_text_field( $p['student'] ) . ' — ' . sanitize_text_field( $p['conference'] );
	$id    = wp_insert_post( array( 'post_type' => 'usucger_tg_app', 'post_status' => 'private', 'post_title' => $title ) );
	foreach ( array( 'student' => sanitize_text_field( $p['student'] ), 'student_email' => $se, 'university' => sanitize_text_field( $p['university'] ), 'degree' => sanitize_text_field( $p['degree'] ), 'advisor' => sanitize_text_field( $p['advisor'] ), 'advisor_email' => $ae, 'advisor_member' => trim( $adv->first_name . ' ' . $adv->last_name ), 'conference' => sanitize_text_field( $p['conference'] ), 'conf_dates' => sanitize_text_field( $p['conf_dates'] ), 'conf_location' => sanitize_text_field( $p['conf_location'] ), 'presentation' => sanitize_text_field( $p['presentation'] ), 'ptype' => sanitize_text_field( $p['ptype'] ), 'amount' => min( 1000, max( 0, (int) $p['amount'] ) ), 'other_funding' => sanitize_text_field( $p['other_funding'] ), 'cycle' => $dl['title'] . ' (' . $dl['date'] . ')', '_status' => 'received' ) as $k => $v ) {
		update_post_meta( $id, $k, $v );
	}
	update_post_meta( $id, '_files', $files ); // label => relative path
	$to = array_merge( array( usucger_core_opt( 'board_email' ) ), usucger_approver_emails() );
	usucger_notify( array_unique( array_filter( $to, 'is_email' ) ), 'Travel grant application: ' . $title, '<p>New application from <strong>' . esc_html( $title ) . '</strong>. Advisor ' . esc_html( $p['advisor'] ) . ' is a current member.</p><p><a href="' . esc_url( usucger_admin_url( 'usucger-submissions', array( 'view' => $id ) ) ) . '">Open the application</a> (sign-in required)</p>' );
	if ( is_email( $se ) ) {
		usucger_notify( $se, 'Application received', '<p>Thank you — we received your USUCGER student travel grant application for ' . esc_html( sanitize_text_field( $p['conference'] ) ) . '. Decisions are emailed after the deadline (' . esc_html( usucger_fmt_date( $dl['date'], 'F j, Y' ) ) . ').</p>' );
	}
	if ( is_email( $ae ) && empty( $files['letter'] ) ) {
		usucger_notify( $ae, 'Support letter requested: ' . sanitize_text_field( $p['student'] ), '<p>' . esc_html( sanitize_text_field( $p['student'] ) ) . ' applied for a USUCGER student travel grant and named you as advisor. Please email a short support letter to ' . esc_html( usucger_core_opt( 'board_email' ) ) . ' by ' . esc_html( usucger_fmt_date( $dl['date'], 'F j, Y' ) ) . '.</p>' );
	}
	Usucger_DB::log( 'travel_grant_application', 'post:' . $id, $title );
	usucger_form_back( true, 'A confirmation has been emailed to the student' . ( empty( $files['letter'] ) ? ', and the advisor was asked for a support letter' : '' ) . '.' );
}

/* Point existing links at the online forms (settings decide). */
add_filter( 'the_content', function ( $html ) {
	if ( usucger_core_opt( 'form_positions' ) ) {
		$html = preg_replace_callback( '#href="mailto:[^"]*subject=([A-Za-z]*)%20Position%20Posting"#i', function ( $m ) {
			return 'href="' . esc_url( add_query_arg( 'kind', 'industry' === strtolower( $m[1] ) ? 'industry' : 'academic', usucger_core_url( 'post-a-position' ) ) ) . '"';
		}, $html );
	}
	if ( usucger_core_opt( 'form_awards' ) && usucger_next_deadline( 'award' ) ) {
		$form = esc_url( usucger_core_url( 'nominate' ) );
		$html = preg_replace( '#Send to (<a href="mailto:[^"]*subject=USUCGER%20Award%20Nomination"[^>]*>)[^<]*</a>#i', 'Submit through the <a href="' . $form . '">online nomination form</a>', $html );
		$html = preg_replace( '#href="mailto:[^"]*subject=USUCGER%20Award%20Nomination"#i', 'href="' . $form . '"', $html );
	}
	if ( usucger_core_opt( 'form_travel' ) ) {
		$html = preg_replace( '#Advisors may send their letter separately through <a href="https://docs\.google\.com/forms/[^"]*"[^>]*>this form</a>#i', 'Advisors can upload their letter on the same online application, or email it to ' . esc_html( usucger_core_opt( 'board_email' ) ), $html );
		// only the application link; any other Google Form stays as it is
		$html = preg_replace( '#<a href="https://docs\.google\.com/forms/[^"]*"([^>]*)>([^<]*application[^<]*)</a>#i', '<a href="' . esc_url( usucger_core_url( 'travel-grant-application' ) ) . '">$2</a>', $html );
	}
	return $html;
}, 20 );

add_filter( 'usucger_position_post_link', function () {
	return usucger_core_opt( 'form_positions' ) ? usucger_core_url( 'post-a-position' ) : '';
} );

/** Online-form address for an old email/Google-Form link, or '' to keep the link. */
function usucger_form_link_for( $href ) {
	$href = html_entity_decode( (string) $href );
	if ( usucger_core_opt( 'form_positions' ) && preg_match( '#^mailto:[^?]*\?subject=([A-Za-z]*)%20Position%20Posting#i', $href, $m ) ) {
		return add_query_arg( 'kind', 'industry' === strtolower( $m[1] ) ? 'industry' : 'academic', usucger_core_url( 'post-a-position' ) );
	}
	if ( usucger_core_opt( 'form_awards' ) && usucger_next_deadline( 'award' ) && preg_match( '#^mailto:[^?]*\?subject=USUCGER%20Award%20Nomination#i', $href ) ) {
		return usucger_core_url( 'nominate' );
	}
	return '';
}

/* Page-header buttons (hero "actions") follow the same switches as links in the text. */
add_filter( 'usucger_action_href', function ( $href, $ref = '' ) {
	// static-site file links ("assets/travel-grants/x.pdf") point at the imported media file
	if ( preg_match( '#^assets/(?:minutes|travel-grants)/(.+)$#', (string) $ref, $m ) && function_exists( 'usucger_seed_media' ) ) {
		$u = usucger_seed_media( rawurldecode( $m[1] ) );
		if ( $u ) {
			return $u;
		}
	}
	$form = usucger_form_link_for( $href );
	return $form ? $form : $href;
}, 10, 2 );
