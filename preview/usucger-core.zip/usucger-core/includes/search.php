<?php
/**
 * Instant site search (the Ctrl+K overlay): builds window.USUCGER_INDEX from pages
 * (one entry per page plus each h2/h3 section), positions, conferences, Board, the
 * membership directory and member universities. Served as a cached script whose URL
 * changes whenever content changes.
 *
 * @package usucger-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function usucger_core_search_index_url() {
	return add_query_arg( array( 'usucger_search_index' => get_option( 'usucger_content_ver', 1 ) ), home_url( '/' ) );
}

function usucger_strip( $html ) {
	$html = preg_replace( '#<(script|style)[^>]*>.*?</\1>#s', ' ', $html );
	$html = wp_strip_all_tags( $html );
	$html = html_entity_decode( $html, ENT_QUOTES, 'UTF-8' );
	return trim( preg_replace( '/\s+/u', ' ', $html ) );
}

function usucger_build_search_index() {
	$e = array();
	foreach ( get_pages( array( 'post_status' => 'publish' ) ) as $p ) {
		if ( get_post_meta( $p->ID, '_usucger_cr_of', true ) ) {
			continue;
		}
		$hero  = get_post_meta( $p->ID, '_usucger_hero', true );
		$hero  = is_array( $hero ) ? $hero : array();
		$title = usucger_strip( ! empty( $hero['h1'] ) ? $hero['h1'] : $p->post_title );
		$url   = get_permalink( $p );
		$body  = strip_shortcodes( $p->post_content );
		$e[]   = array( 't' => $title, 'u' => $url, 's' => mb_substr( usucger_strip( isset( $hero['description'] ) ? $hero['description'] : '' ), 0, 160 ), 'k' => mb_strtolower( mb_substr( usucger_strip( $body ), 0, 1500 ) ), 'p' => 1 );
		if ( preg_match_all( '#<h([23])[^>]*?(?:id="([^"]+)")?[^>]*>(.*?)</h\1>#s', $body, $mm, PREG_SET_ORDER | PREG_OFFSET_CAPTURE ) ) {
			foreach ( $mm as $m ) {
				$h = usucger_strip( $m[3][0] );
				if ( ! $h || mb_strlen( $h ) > 90 ) {
					continue;
				}
				$after = usucger_strip( substr( $body, $m[0][1] + strlen( $m[0][0] ), 600 ) );
				$e[]   = array( 't' => $h, 'u' => $url . ( ! empty( $m[2][0] ) ? '#' . $m[2][0] : '' ), 's' => $title, 'k' => mb_strtolower( mb_substr( $h . ' ' . $after, 0, 600 ) ) );
			}
		}
	}
	$pos = usucger_core_url( 'positions' );
	foreach ( usucger_items( 'usucger_position' ) as $p ) {
		$e[] = array( 't' => $p['title'], 'u' => $p['url'] ? $p['url'] : $pos, 's' => $p['institution'] . ' · Position', 'k' => mb_strtolower( $p['title'] . ' ' . $p['institution'] . ' ' . $p['location'] ) );
	}
	foreach ( usucger_items( 'usucger_conference' ) as $c ) {
		$e[] = array( 't' => $c['title'], 'u' => usucger_core_url( 'conferences' ), 's' => usucger_fmt_date( $c['start'] ) . ' · ' . $c['location'], 'k' => mb_strtolower( $c['title'] . ' ' . $c['location'] . ' ' . $c['note'] ) );
	}
	foreach ( usucger_items( 'usucger_board' ) as $b ) {
		$e[] = array( 't' => $b['title'], 'u' => usucger_core_url( 'board' ), 's' => $b['role'] . ' · ' . $b['inst'], 'k' => mb_strtolower( $b['title'] . ' ' . $b['role'] . ' ' . $b['inst'] ) );
	}
	$dir = usucger_core_url( 'directory' );
	foreach ( Usucger_Members::directory_rows() as $m ) {
		$e[] = array( 't' => trim( $m[0] . ' ' . $m[1] ), 'u' => $dir, 's' => $m[2] . ' · Membership directory', 'k' => mb_strtolower( implode( ' ', $m ) ) );
	}
	$uni = usucger_core_url( 'universities' );
	foreach ( Usucger_Members::institutions() as $i ) {
		$e[] = array( 't' => $i->name, 'u' => $uni, 's' => 'Member university' . ( $i->contact_name ? ' · contact: ' . $i->contact_name : '' ), 'k' => mb_strtolower( $i->name . ' ' . $i->contact_name ) );
	}
	return $e;
}

add_action( 'init', function () {
	if ( ! isset( $_GET['usucger_search_index'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		return;
	}
	$ver  = get_option( 'usucger_content_ver', 1 );
	$data = get_transient( 'usucger_search_index' );
	if ( ! $data || $data['v'] != $ver ) { // phpcs:ignore Universal.Operators.StrictComparisons
		$data = array( 'v' => $ver, 'js' => 'window.USUCGER_INDEX=' . wp_json_encode( usucger_build_search_index(), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . ';' );
		set_transient( 'usucger_search_index', $data, WEEK_IN_SECONDS );
	}
	header( 'Content-Type: application/javascript; charset=utf-8' );
	header( 'Cache-Control: public, max-age=31536000, immutable' );
	echo $data['js']; // phpcs:ignore WordPress.Security.EscapeOutput
	exit;
}, 99 );
