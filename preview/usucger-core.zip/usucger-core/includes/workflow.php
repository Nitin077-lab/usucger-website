<?php
/**
 * Board editing with webmaster approval.
 *
 * Role "Board Member" (usucger_board): can write and edit drafts of pages, positions,
 * conferences, Board entries, minutes and deadlines, upload files, and compose email —
 * but cannot publish. Their work goes live only after an approver (administrator or any
 * user with the usucger_approve capability) approves it.
 *
 *  • New items: Board member clicks "Submit for Review" → status Pending → approvers are
 *    emailed → approver publishes → the author is emailed.
 *  • Changes to a live page/item: "Suggest changes" makes a private working copy linked to
 *    the original. The live page is untouched until an approver clicks "Approve changes",
 *    which copies the new text and settings into the original (WordPress keeps the old
 *    version in Revisions) and removes the working copy. "Return with note" sends it back.
 *
 * @package usucger-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function usucger_core_roles() {
	$board_caps = array(
		'read'                 => true,
		'edit_posts'           => true,
		'edit_pages'           => true,
		'delete_posts'         => true,
		'delete_pages'         => true,
		'upload_files'         => true,
		'usucger_compose'      => true,
		'usucger_view_members' => true,
	);
	if ( usucger_core_opt( 'board_unfiltered' ) ) {
		$board_caps['unfiltered_html'] = true;
	}
	remove_role( 'usucger_board' );
	add_role( 'usucger_board', 'Board Member', $board_caps );
	// Membership Coordinator: manages members, renewals and member email; approvals still go to the webmaster/President
	remove_role( 'usucger_coordinator' );
	add_role( 'usucger_coordinator', 'Membership Coordinator', array_merge( $board_caps, array( 'usucger_manage' => true ) ) );
	foreach ( array( 'administrator' ) as $r ) {
		$role = get_role( $r );
		if ( $role ) {
			foreach ( array( 'usucger_approve', 'usucger_compose', 'usucger_view_members', 'usucger_manage' ) as $cap ) {
				$role->add_cap( $cap );
			}
		}
	}
}

/** Post types that go through review. */
function usucger_reviewed_types() {
	return apply_filters( 'usucger_reviewed_types', array_merge( array( 'page', 'post' ), array_keys( usucger_cpt_defs() ) ) );
}

/* ------------------------------------------------------------ suggest changes */

add_filter( 'page_row_actions', 'usucger_row_suggest', 10, 2 );
add_filter( 'post_row_actions', 'usucger_row_suggest', 10, 2 );
function usucger_row_suggest( $actions, $post ) {
	if ( 'publish' === $post->post_status && in_array( $post->post_type, usucger_reviewed_types(), true ) && current_user_can( 'edit_posts' ) && ! get_post_meta( $post->ID, '_usucger_cr_of', true ) ) {
		$url = wp_nonce_url( admin_url( 'admin-post.php?action=usucger_suggest&post=' . $post->ID ), 'usucger_suggest_' . $post->ID );
		$label = current_user_can( 'edit_post', $post->ID ) ? 'Draft changes for review' : 'Suggest changes';
		$actions['usucger_suggest'] = '<a href="' . esc_url( $url ) . '">' . esc_html( $label ) . '</a>';
	}
	return $actions;
}

/** Board members land on a locked live page: send them to a working copy instead. */
add_action( 'load-post.php', function () {
	$id = isset( $_GET['post'] ) ? (int) $_GET['post'] : 0; // phpcs:ignore WordPress.Security.NonceVerification
	if ( ! $id ) {
		return;
	}
	$p = get_post( $id );
	if ( $p && 'publish' === $p->post_status && in_array( $p->post_type, usucger_reviewed_types(), true ) && ! current_user_can( 'edit_post', $id ) && current_user_can( 'edit_posts' ) ) {
		wp_safe_redirect( admin_url( 'admin-post.php?action=usucger_suggest&post=' . $id . '&_wpnonce=' . wp_create_nonce( 'usucger_suggest_' . $id ) ) );
		exit;
	}
} );

add_action( 'admin_post_usucger_suggest', function () {
	$id = isset( $_GET['post'] ) ? (int) $_GET['post'] : 0;
	check_admin_referer( 'usucger_suggest_' . $id );
	$orig = get_post( $id );
	if ( ! $orig || 'publish' !== $orig->post_status || ! current_user_can( 'edit_posts' ) || ! in_array( $orig->post_type, usucger_reviewed_types(), true ) ) {
		wp_die( 'Not allowed.' );
	}
	// reuse this user's open copy if there is one
	$open = get_posts( array(
		'post_type'   => $orig->post_type,
		'post_status' => array( 'draft', 'pending' ),
		'author'      => get_current_user_id(),
		'meta_key'    => '_usucger_cr_of', // phpcs:ignore WordPress.DB.SlowDBQuery
		'meta_value'  => $id, // phpcs:ignore WordPress.DB.SlowDBQuery
		'numberposts' => 1,
	) );
	if ( $open ) {
		wp_safe_redirect( get_edit_post_link( $open[0]->ID, 'raw' ) );
		exit;
	}
	$copy = wp_insert_post( wp_slash( array(
		'post_type'    => $orig->post_type,
		'post_status'  => 'draft',
		'post_author'  => get_current_user_id(),
		'post_title'   => $orig->post_title,
		'post_content' => $orig->post_content,
		'post_excerpt' => $orig->post_excerpt,
		'post_parent'  => $orig->post_parent,
		'menu_order'   => $orig->menu_order,
		'post_name'    => $orig->post_name . '-proposed',
	) ), true );
	if ( is_wp_error( $copy ) ) {
		wp_die( esc_html( $copy->get_error_message() ) );
	}
	foreach ( get_post_meta( $id ) as $k => $vals ) {
		if ( in_array( $k, array( '_edit_lock', '_edit_last', '_wp_old_slug' ), true ) ) {
			continue;
		}
		foreach ( $vals as $v ) {
			add_post_meta( $copy, $k, wp_slash( maybe_unserialize( $v ) ) );
		}
	}
	update_post_meta( $copy, '_usucger_cr_of', $id );
	update_post_meta( $copy, '_usucger_cr_base', $orig->post_modified_gmt ); // to warn if the live page changes meanwhile
	Usucger_DB::log( 'change_started', 'post:' . $id, 'copy ' . $copy );
	wp_safe_redirect( get_edit_post_link( $copy, 'raw' ) );
	exit;
} );

/* Banner + review box on working copies and pending items. */
add_action( 'add_meta_boxes', function () {
	foreach ( usucger_reviewed_types() as $pt ) {
		add_meta_box( 'usucger_review', 'Review &amp; approval', 'usucger_review_box', $pt, 'side', 'high' );
	}
} );

function usucger_review_box( $post ) {
	$of = (int) get_post_meta( $post->ID, '_usucger_cr_of', true );
	if ( $of ) {
		$orig = get_post( $of );
		$base = get_post_meta( $post->ID, '_usucger_cr_base', true );
		if ( $orig && $base && $orig->post_modified_gmt > $base ) {
			echo '<div style="background:#fcf0f1;border-left:3px solid #b32d2e;padding:6px 8px;margin:0 0 8px"><strong>The live page was edited after this copy was made.</strong> Approving will replace those later edits — compare first.</div>';
		}
		echo '<p><strong>Proposed changes</strong> to the live ' . esc_html( get_post_type_object( $post->post_type )->labels->singular_name ) . ' <a href="' . esc_url( get_permalink( $of ) ) . '" target="_blank">' . esc_html( $orig ? $orig->post_title : '#' . $of ) . '</a>. The live version does not change until this is approved.</p>';
	} elseif ( 'publish' === $post->post_status ) {
		echo '<p>This is live. Use <em>Suggest changes</em> (Board) or edit directly (approvers).</p>';
		return;
	} else {
		echo '<p>New item — goes live when approved.</p>';
	}
	$note = get_post_meta( $post->ID, '_usucger_review_note', true );
	if ( $note ) {
		echo '<div style="background:#fcf9e8;border-left:3px solid #dba617;padding:6px 8px;margin:8px 0"><strong>Note from reviewer:</strong><br>' . nl2br( esc_html( $note ) ) . '</div>';
	}
	if ( 'pending' === $post->post_status ) {
		echo '<p style="color:#996800"><strong>Waiting for approval.</strong></p>';
	} elseif ( ! usucger_can_approve() ) {
		echo '<p>When ready, click <strong>Submit for Review</strong> (or <strong>Save</strong> then <em>Submit</em>) — the webmaster is notified.</p>';
	}
	if ( usucger_can_approve() && $post->post_status !== 'auto-draft' ) {
		$ap = wp_nonce_url( admin_url( 'admin-post.php?action=usucger_approve&post=' . $post->ID ), 'usucger_approve_' . $post->ID );
		echo '<p><a class="button button-primary" href="' . esc_url( $ap ) . '">' . ( $of ? 'Approve changes &amp; update live page' : 'Approve &amp; publish' ) . '</a></p>';
		if ( $of ) {
			echo '<p><a href="' . esc_url( usucger_admin_url( 'usucger-review', array( 'diff' => $post->ID ) ) ) . '">Compare with live version</a></p>';
		}
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="usucger_return"><input type="hidden" name="post" value="' . (int) $post->ID . '">';
		wp_nonce_field( 'usucger_return_' . $post->ID );
		echo '<textarea name="note" rows="3" style="width:100%" placeholder="What should change? (sent to the author)"></textarea><button class="button" type="submit">Return with note</button></form>';
	}
}

/** Apply an approved working copy to its original, or publish a pending item. */
function usucger_approve_post( $id ) {
	$p = get_post( $id );
	if ( ! $p ) {
		return false;
	}
	$of     = (int) get_post_meta( $id, '_usucger_cr_of', true );
	$author = (int) $p->post_author;
	if ( $of && get_post( $of ) ) {
		wp_update_post( wp_slash( array(
			'ID'           => $of,
			'post_title'   => $p->post_title,
			'post_content' => $p->post_content,
			'post_excerpt' => $p->post_excerpt,
			'menu_order'   => $p->menu_order,
		) ) );
		foreach ( get_post_meta( $id ) as $k => $vals ) {
			if ( in_array( $k, array( '_edit_lock', '_edit_last', '_usucger_cr_of', '_usucger_review_note', '_wp_old_slug', '_usucger_cr_base' ), true ) ) {
				continue;
			}
			delete_post_meta( $of, $k );
			foreach ( $vals as $v ) {
				add_post_meta( $of, $k, wp_slash( maybe_unserialize( $v ) ) );
			}
		}
		$thumb = get_post_thumbnail_id( $id );
		if ( $thumb ) {
			set_post_thumbnail( $of, $thumb );
		}
		wp_delete_post( $id, true );
		$target = $of;
	} else {
		wp_update_post( array( 'ID' => $id, 'post_status' => 'publish' ) );
		delete_post_meta( $id, '_usucger_review_note' );
		$target = $id;
	}
	usucger_bump_content_version();
	Usucger_DB::log( 'content_approved', 'post:' . $target, $of ? 'changes from copy ' . $id : 'published' );
	if ( $author && $author !== get_current_user_id() ) {
		$u = get_userdata( $author );
		if ( $u ) {
			usucger_notify( $u->user_email, 'Approved: ' . get_the_title( $target ), '<p>Your ' . ( $of ? 'changes to' : 'submission' ) . ' <strong>' . esc_html( get_the_title( $target ) ) . '</strong> ' . ( $of ? 'are now live' : 'is now published' ) . '.</p><p><a href="' . esc_url( get_permalink( $target ) ? get_permalink( $target ) : admin_url() ) . '">View it on the website</a></p>' );
		}
	}
	return $target;
}

add_action( 'admin_post_usucger_approve', function () {
	$id = isset( $_GET['post'] ) ? (int) $_GET['post'] : 0;
	check_admin_referer( 'usucger_approve_' . $id );
	if ( ! usucger_can_approve() ) {
		wp_die( 'Only approvers can do this.' );
	}
	$target = usucger_approve_post( $id );
	$back   = isset( $_GET['back'] ) ? esc_url_raw( wp_unslash( $_GET['back'] ) ) : '';
	usucger_back( $back ? $back : get_edit_post_link( $target, 'raw' ), 'Approved — the website is updated.' );
} );

add_action( 'admin_post_usucger_return', function () {
	$id = isset( $_POST['post'] ) ? (int) $_POST['post'] : 0;
	check_admin_referer( 'usucger_return_' . $id );
	if ( ! usucger_can_approve() ) {
		wp_die( 'Only approvers can do this.' );
	}
	$note = sanitize_textarea_field( wp_unslash( isset( $_POST['note'] ) ? $_POST['note'] : '' ) );
	$p    = get_post( $id );
	update_post_meta( $id, '_usucger_review_note', $note );
	wp_update_post( array( 'ID' => $id, 'post_status' => 'draft' ) );
	Usucger_DB::log( 'content_returned', 'post:' . $id, $note );
	$u = get_userdata( $p->post_author );
	if ( $u && $u->ID !== get_current_user_id() ) {
		usucger_notify( $u->user_email, 'Returned for changes: ' . $p->post_title, '<p>The webmaster returned <strong>' . esc_html( $p->post_title ) . '</strong> with this note:</p><blockquote style="border-left:3px solid #ccc;margin:0;padding:4px 12px">' . nl2br( esc_html( $note ) ) . '</blockquote><p><a href="' . esc_url( get_edit_post_link( $id, 'raw' ) ) . '">Open it to edit</a></p>' );
	}
	$back = isset( $_POST['back'] ) ? esc_url_raw( wp_unslash( $_POST['back'] ) ) : '';
	usucger_back( $back ? $back : usucger_admin_url( 'usucger-review' ), 'Returned to the author.' );
} );

/*
 * A working copy is never published directly (that would create a duplicate page, and in the
 * block editor the copy would vanish mid-save). Publishing it is turned into "submit for review";
 * approvers use "Approve changes & update live page" instead.
 */
add_filter( 'wp_insert_post_data', function ( $data, $postarr ) {
	if ( ! empty( $postarr['ID'] ) && 'publish' === $data['post_status'] && get_post_meta( (int) $postarr['ID'], '_usucger_cr_of', true ) && empty( $GLOBALS['usucger_merging'] ) ) {
		$data['post_status'] = 'pending';
	}
	return $data;
}, 10, 2 );
/* Notify approvers when something is submitted for review. */
add_action( 'transition_post_status', function ( $new, $old, $post ) {
	if ( 'pending' !== $new || 'pending' === $old || ! in_array( $post->post_type, usucger_reviewed_types(), true ) ) {
		return;
	}
	$of     = (int) get_post_meta( $post->ID, '_usucger_cr_of', true );
	$author = get_userdata( $post->post_author );
	$who    = $author ? $author->display_name : 'A Board member';
	$type   = get_post_type_object( $post->post_type )->labels->singular_name;
	$body   = '<p><strong>' . esc_html( $who ) . '</strong> ' . ( $of ? 'proposed changes to the live ' . esc_html( strtolower( $type ) ) : 'submitted a new ' . esc_html( strtolower( $type ) ) ) . ': <strong>' . esc_html( $post->post_title ) . '</strong>.</p>'
		. '<p><a href="' . esc_url( usucger_admin_url( 'usucger-review' ) ) . '">Open the review queue</a> to compare, approve or return it.</p>';
	usucger_notify( usucger_approver_emails(), 'For approval: ' . $post->post_title, $body );
	Usucger_DB::log( 'content_submitted', 'post:' . $post->ID, $who );
}, 10, 3 );

/* Labels in the list screens. */
add_filter( 'display_post_states', function ( $states, $post ) {
	if ( get_post_meta( $post->ID, '_usucger_cr_of', true ) ) {
		$states['usucger_cr'] = 'Proposed changes';
	}
	return $states;
}, 10, 2 );

/** Pending work for the review queue. */
function usucger_review_items() {
	return get_posts( array(
		'post_type'      => usucger_reviewed_types(),
		'post_status'    => 'pending',
		'posts_per_page' => 100,
		'orderby'        => 'modified',
		'order'          => 'DESC',
	) );
}

/* Admin notices from usucger_back(). */
add_action( 'admin_notices', function () {
	$n = get_transient( 'usucger_notice_' . get_current_user_id() );
	if ( $n ) {
		delete_transient( 'usucger_notice_' . get_current_user_id() );
		echo '<div class="notice notice-' . esc_attr( $n[1] ) . ' is-dismissible"><p>' . wp_kses_post( $n[0] ) . '</p></div>';
	}
	$screen = get_current_screen();
	if ( $screen && 'post' === $screen->base && ! usucger_can_approve() && current_user_can( 'edit_posts' ) ) {
		echo '<div class="notice notice-info"><p>Your edits are saved as a draft. Click <strong>Submit for Review</strong> when ready — the webmaster approves before anything appears on the website.</p></div>';
	}
} );

/* Board members: tidy wp-admin (no comments/tools/plugins), land on the USUCGER dashboard. */
add_action( 'admin_menu', function () {
	if ( current_user_can( 'usucger_board_ui' ) || ( ! current_user_can( 'manage_options' ) && current_user_can( 'usucger_compose' ) ) ) {
		remove_menu_page( 'edit-comments.php' );
		remove_menu_page( 'tools.php' );
	}
}, 999 );
add_filter( 'login_redirect', function ( $to, $req, $user ) {
	if ( $user instanceof WP_User && ( in_array( 'usucger_board', (array) $user->roles, true ) || in_array( (int) $user->ID, array_map( 'intval', (array) usucger_core_opt( 'approvers' ) ), true ) ) && ( ! $to || admin_url() === $to || false !== strpos( $to, 'wp-admin' ) ) ) {
		return function_exists( 'usucger_desk_url' ) ? usucger_desk_url() : admin_url( 'admin.php?page=usucger' );
	}
	// members without staff rights go to the member area, not the bare WordPress profile screen
	if ( $user instanceof WP_User && ! user_can( $user, 'edit_posts' ) && ( ! $to || admin_url() === $to || false !== strpos( $to, 'wp-admin/profile.php' ) || admin_url( 'profile.php' ) === $to ) && function_exists( 'usucger_portal_url' ) ) {
		return usucger_portal_url();
	}
	return $to;
}, 20, 3 );
/* WooCommerce sends non-admins to My Account; let Board members into wp-admin. */
add_filter( 'woocommerce_prevent_admin_access', function ( $prevent ) {
	return current_user_can( 'usucger_compose' ) ? false : $prevent;
} );
add_filter( 'woocommerce_disable_admin_bar', function ( $disable ) {
	return current_user_can( 'usucger_compose' ) ? false : $disable;
} );
