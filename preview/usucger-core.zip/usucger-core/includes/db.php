<?php
/**
 * Custom tables: contacts (members and mailing list), institutions, email batches,
 * outbox, page views and an audit log.
 *
 * @package usucger-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Usucger_DB {

	public static function t( $name ) {
		global $wpdb;
		return $wpdb->prefix . 'usucger_' . $name;
	}

	public static function install() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$c = $wpdb->get_charset_collate();

		dbDelta( 'CREATE TABLE ' . self::t( 'contacts' ) . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  email varchar(190) NOT NULL DEFAULT '',
  first_name varchar(100) NOT NULL DEFAULT '',
  last_name varchar(100) NOT NULL DEFAULT '',
  institution varchar(190) NOT NULL DEFAULT '',
  category varchar(100) NOT NULL DEFAULT '',
  user_id bigint(20) unsigned NOT NULL DEFAULT 0,
  source varchar(20) NOT NULL DEFAULT 'manual',
  status varchar(20) NOT NULL DEFAULT 'current',
  plan_id bigint(20) unsigned NOT NULL DEFAULT 0,
  start_date date DEFAULT NULL,
  end_date date DEFAULT NULL,
  in_directory tinyint(1) NOT NULL DEFAULT 1,
  is_uni_contact tinyint(1) NOT NULL DEFAULT 0,
  tags varchar(255) NOT NULL DEFAULT '',
  unsub_news tinyint(1) NOT NULL DEFAULT 0,
  unsub_renewal tinyint(1) NOT NULL DEFAULT 0,
  bounced tinyint(1) NOT NULL DEFAULT 0,
  bounce_note varchar(190) NOT NULL DEFAULT '',
  token varchar(40) NOT NULL DEFAULT '',
  notes text,
  created datetime DEFAULT NULL,
  updated datetime DEFAULT NULL,
  PRIMARY KEY  (id),
  KEY email (email),
  KEY user_id (user_id),
  KEY status (status),
  KEY token (token)
) $c;" );

		dbDelta( 'CREATE TABLE ' . self::t( 'institutions' ) . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  name varchar(190) NOT NULL DEFAULT '',
  state varchar(8) NOT NULL DEFAULT '',
  contact_name varchar(190) NOT NULL DEFAULT '',
  contact_email varchar(190) NOT NULL DEFAULT '',
  status varchar(20) NOT NULL DEFAULT 'member',
  aliases varchar(255) NOT NULL DEFAULT '',
  alternate_name varchar(190) NOT NULL DEFAULT '',
  alternate_email varchar(190) NOT NULL DEFAULT '',
  notes text,
  updated datetime DEFAULT NULL,
  PRIMARY KEY  (id),
  KEY name (name),
  KEY status (status)
) $c;" );

		dbDelta( 'CREATE TABLE ' . self::t( 'batches' ) . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  kind varchar(20) NOT NULL DEFAULT 'news',
  group_key varchar(60) NOT NULL DEFAULT '',
  group_args longtext,
  template_key varchar(60) NOT NULL DEFAULT '',
  subject varchar(255) NOT NULL DEFAULT '',
  body longtext,
  status varchar(20) NOT NULL DEFAULT 'draft',
  created_by bigint(20) unsigned NOT NULL DEFAULT 0,
  created datetime DEFAULT NULL,
  submitted datetime DEFAULT NULL,
  approved_by bigint(20) unsigned NOT NULL DEFAULT 0,
  approved_at datetime DEFAULT NULL,
  note text,
  total int(11) NOT NULL DEFAULT 0,
  sent int(11) NOT NULL DEFAULT 0,
  failed int(11) NOT NULL DEFAULT 0,
  source varchar(40) NOT NULL DEFAULT 'compose',
  PRIMARY KEY  (id),
  KEY status (status)
) $c;" );

		dbDelta( 'CREATE TABLE ' . self::t( 'outbox' ) . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  batch_id bigint(20) unsigned NOT NULL DEFAULT 0,
  contact_id bigint(20) unsigned NOT NULL DEFAULT 0,
  email varchar(190) NOT NULL DEFAULT '',
  name varchar(190) NOT NULL DEFAULT '',
  subject varchar(255) NOT NULL DEFAULT '',
  body longtext,
  status varchar(20) NOT NULL DEFAULT 'queued',
  attempts int(11) NOT NULL DEFAULT 0,
  error varchar(255) NOT NULL DEFAULT '',
  created datetime DEFAULT NULL,
  sent_at datetime DEFAULT NULL,
  PRIMARY KEY  (id),
  KEY batch_id (batch_id),
  KEY status (status)
) $c;" );

		dbDelta( 'CREATE TABLE ' . self::t( 'views' ) . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  day date NOT NULL,
  path varchar(190) NOT NULL DEFAULT '',
  views int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY  (id),
  KEY day_path (day,path)
) $c;" );

		dbDelta( 'CREATE TABLE ' . self::t( 'log' ) . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  time datetime DEFAULT NULL,
  user_id bigint(20) unsigned NOT NULL DEFAULT 0,
  action varchar(60) NOT NULL DEFAULT '',
  object varchar(120) NOT NULL DEFAULT '',
  detail text,
  PRIMARY KEY  (id),
  KEY action (action)
) $c;" );

		dbDelta( 'CREATE TABLE ' . self::t( 'attendance' ) . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  user_id bigint(20) unsigned NOT NULL DEFAULT 0,
  conference_id bigint(20) unsigned NOT NULL DEFAULT 0,
  event_name varchar(255) NOT NULL DEFAULT '',
  event_start date DEFAULT NULL,
  event_end date DEFAULT NULL,
  location varchar(190) NOT NULL DEFAULT '',
  role varchar(30) NOT NULL DEFAULT 'attending',
  note varchar(255) NOT NULL DEFAULT '',
  created datetime DEFAULT NULL,
  PRIMARY KEY  (id),
  KEY user_id (user_id),
  KEY conference_id (conference_id)
) $c;" );

		dbDelta( 'CREATE TABLE ' . self::t( 'elections' ) . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  title varchar(255) NOT NULL DEFAULT '',
  kind varchar(20) NOT NULL DEFAULT 'board',
  question text,
  nom_open date DEFAULT NULL,
  nom_close date DEFAULT NULL,
  vote_open date DEFAULT NULL,
  vote_close date DEFAULT NULL,
  status varchar(20) NOT NULL DEFAULT 'draft',
  settings longtext,
  results longtext,
  created datetime DEFAULT NULL,
  certified_at datetime DEFAULT NULL,
  certified_by bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY  (id)
) $c;" );

		dbDelta( 'CREATE TABLE ' . self::t( 'candidates' ) . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  election_id bigint(20) unsigned NOT NULL DEFAULT 0,
  position varchar(20) NOT NULL DEFAULT 'junior',
  name varchar(190) NOT NULL DEFAULT '',
  email varchar(190) NOT NULL DEFAULT '',
  user_id bigint(20) unsigned NOT NULL DEFAULT 0,
  institution varchar(190) NOT NULL DEFAULT '',
  rank_title varchar(60) NOT NULL DEFAULT '',
  statement text,
  title_line varchar(190) NOT NULL DEFAULT '',
  department varchar(255) NOT NULL DEFAULT '',
  experience text,
  vision text,
  photo varchar(255) NOT NULL DEFAULT '',
  cv_url varchar(255) NOT NULL DEFAULT '',
  packet_url varchar(255) NOT NULL DEFAULT '',
  packet_at datetime DEFAULT NULL,
  status varchar(20) NOT NULL DEFAULT 'nominated',
  checks longtext,
  nominated_by bigint(20) unsigned NOT NULL DEFAULT 0,
  nominator_note varchar(255) NOT NULL DEFAULT '',
  sort int(11) NOT NULL DEFAULT 0,
  created datetime DEFAULT NULL,
  PRIMARY KEY  (id),
  KEY election_id (election_id)
) $c;" );

		dbDelta( 'CREATE TABLE ' . self::t( 'voters' ) . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  election_id bigint(20) unsigned NOT NULL DEFAULT 0,
  institution_id bigint(20) unsigned NOT NULL DEFAULT 0,
  institution varchar(190) NOT NULL DEFAULT '',
  delegate_name varchar(190) NOT NULL DEFAULT '',
  delegate_email varchar(190) NOT NULL DEFAULT '',
  alternate_name varchar(190) NOT NULL DEFAULT '',
  alternate_email varchar(190) NOT NULL DEFAULT '',
  eligible tinyint(1) NOT NULL DEFAULT 0,
  reason varchar(255) NOT NULL DEFAULT '',
  token varchar(64) NOT NULL DEFAULT '',
  voted_at datetime DEFAULT NULL,
  voted_by varchar(190) NOT NULL DEFAULT '',
  reminders int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY  (id),
  KEY election_id (election_id),
  KEY token (token)
) $c;" );

		dbDelta( 'CREATE TABLE ' . self::t( 'ballots' ) . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  election_id bigint(20) unsigned NOT NULL DEFAULT 0,
  position varchar(20) NOT NULL DEFAULT '',
  candidate_id bigint(20) unsigned NOT NULL DEFAULT 0,
  receipt_hash varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY  (id),
  KEY election_id (election_id)
) $c;" );

		// receipts are kept apart from the ballots so a receipt can prove "counted" but never "how"
		dbDelta( 'CREATE TABLE ' . self::t( 'receipts' ) . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  election_id bigint(20) unsigned NOT NULL DEFAULT 0,
  receipt_hash varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY  (id),
  KEY receipt_hash (receipt_hash)
) $c;" );
		$bt = self::t( 'ballots' );
		$rt = self::t( 'receipts' );
		foreach ( $wpdb->get_results( "SELECT DISTINCT election_id, receipt_hash FROM $bt WHERE receipt_hash <> ''" ) as $r ) { // phpcs:ignore WordPress.DB
			$wpdb->insert( $rt, array( 'id' => random_int( 1000000, PHP_INT_MAX >> 1 ), 'election_id' => $r->election_id, 'receipt_hash' => $r->receipt_hash ) );
		}
		$wpdb->query( "UPDATE $bt SET receipt_hash = '' WHERE receipt_hash <> ''" ); // phpcs:ignore WordPress.DB

		update_option( 'usucger_db_ver', USUCGER_CORE_DB_VER );
	}

	/** Audit trail: approvals, sends, removals, imports. */
	public static function log( $action, $object = '', $detail = '' ) {
		global $wpdb;
		$wpdb->insert( self::t( 'log' ), array(
			'time'    => current_time( 'mysql' ),
			'user_id' => get_current_user_id(),
			'action'  => substr( $action, 0, 60 ),
			'object'  => substr( (string) $object, 0, 120 ),
			'detail'  => ( function_exists( 'usucger_approver_label' ) && is_user_logged_in() && usucger_approver_label() && false !== strpos( $action, 'approved' ) ? '[' . usucger_approver_label() . '] ' : '' ) . ( is_scalar( $detail ) ? (string) $detail : wp_json_encode( $detail ) ),
		) );
	}
}
