<?php
/**
 * Bounce / complaint webhook. Point your email service at
 *   POST https://usucger.org/wp-json/usucger/v1/bounce?key=SECRET
 * Understands Amazon SES (via SNS), Postmark, Brevo/Sendinblue, Mailgun, SendGrid and a plain
 * {"email": "...", "type": "hard"} body. Hard bounces and spam complaints mark the contact as
 * Hard bounces mark the contact "bounced": skipped by every mailing, listed under Data cleanup.
 * Spam complaints opt the person out of announcements (official notices such as ballots still go).
 * Soft bounces are only logged.
 *
 * @package usucger-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'rest_api_init', function () {
	register_rest_route( 'usucger/v1', '/bounce', array(
		'methods'             => 'POST',
		'permission_callback' => function ( WP_REST_Request $r ) {
			$secret = (string) usucger_core_opt( 'bounce_secret' );
			$given  = (string) ( $r->get_param( 'key' ) ? $r->get_param( 'key' ) : $r->get_header( 'x-usucger-key' ) );
			return '' !== $secret && strlen( $secret ) >= 16 && hash_equals( $secret, $given );
		},
		'callback'            => 'usucger_bounce_webhook',
	) );
} );

/** Returns a list of [email, kind(hard|soft|complaint), note]. */
function usucger_bounce_parse( $body ) {
	$out = array();
	if ( ! is_array( $body ) ) {
		return $out;
	}
	// Amazon SNS envelope
	if ( isset( $body['Type'] ) && isset( $body['Message'] ) && is_string( $body['Message'] ) ) {
		if ( 'SubscriptionConfirmation' === $body['Type'] ) {
			return array( array( '', 'subscribe', isset( $body['SubscribeURL'] ) ? (string) $body['SubscribeURL'] : '' ) );
		}
		$msg = json_decode( $body['Message'], true );
		return is_array( $msg ) ? usucger_bounce_parse( $msg ) : $out;
	}
	// Amazon SES notification
	$ses_type = isset( $body['notificationType'] ) ? $body['notificationType'] : ( isset( $body['eventType'] ) ? $body['eventType'] : '' );
	if ( 'Bounce' === $ses_type && isset( $body['bounce']['bouncedRecipients'] ) ) {
		$kind = 'Permanent' === ( isset( $body['bounce']['bounceType'] ) ? $body['bounce']['bounceType'] : '' ) ? 'hard' : 'soft';
		foreach ( $body['bounce']['bouncedRecipients'] as $r ) {
			if ( empty( $r['emailAddress'] ) ) {
				continue;
			}
			$out[] = array( $r['emailAddress'], $kind, isset( $r['diagnosticCode'] ) ? $r['diagnosticCode'] : 'SES ' . $kind . ' bounce' );
		}
		return $out;
	}
	if ( 'Complaint' === $ses_type && isset( $body['complaint']['complainedRecipients'] ) ) {
		foreach ( $body['complaint']['complainedRecipients'] as $r ) {
			if ( empty( $r['emailAddress'] ) ) {
				continue;
			}
			$out[] = array( $r['emailAddress'], 'complaint', 'Marked as spam' );
		}
		return $out;
	}
	// SendGrid / generic arrays of events
	if ( isset( $body[0] ) && is_array( $body[0] ) ) {
		foreach ( $body as $ev ) {
			$out = array_merge( $out, usucger_bounce_parse( $ev ) );
		}
		return $out;
	}
	// Postmark
	if ( isset( $body['RecordType'] ) ) {
		$email = isset( $body['Email'] ) ? $body['Email'] : '';
		if ( 'SpamComplaint' === $body['RecordType'] ) {
			return array( array( $email, 'complaint', 'Marked as spam' ) );
		}
		if ( 'Bounce' === $body['RecordType'] ) {
			$hard = in_array( isset( $body['Type'] ) ? $body['Type'] : '', array( 'HardBounce', 'BadEmailAddress', 'ManuallyDeactivated', 'Blocked' ), true );
			return array( array( $email, $hard ? 'hard' : 'soft', isset( $body['Description'] ) ? $body['Description'] : $body['Type'] ) );
		}
		return $out;
	}
	// Mailgun
	if ( isset( $body['event-data'] ) ) {
		$d = $body['event-data'];
		$e = isset( $d['event'] ) ? $d['event'] : '';
		if ( 'complained' === $e ) {
			return array( array( $d['recipient'], 'complaint', 'Marked as spam' ) );
		}
		if ( 'failed' === $e ) {
			return array( array( $d['recipient'], 'permanent' === ( isset( $d['severity'] ) ? $d['severity'] : '' ) ? 'hard' : 'soft', isset( $d['delivery-status']['description'] ) ? $d['delivery-status']['description'] : 'Mailgun failure' ) );
		}
		return $out;
	}
	// Brevo / SendGrid single event / generic
	$email = isset( $body['email'] ) ? $body['email'] : ( isset( $body['recipient'] ) ? $body['recipient'] : '' );
	$ev    = strtolower( (string) ( isset( $body['event'] ) ? $body['event'] : ( isset( $body['type'] ) ? $body['type'] : '' ) ) );
	$reason = strtolower( (string) ( isset( $body['reason'] ) ? $body['reason'] : '' ) );
	$stype  = strtolower( (string) ( isset( $body['type'] ) && isset( $body['event'] ) ? $body['type'] : '' ) ); // SendGrid bounce sub-type
	if ( 'bounce' === $ev && 'blocked' === $stype ) {
		$ev = 'soft'; // SendGrid: temporary block by the receiving server
	} elseif ( 'dropped' === $ev ) {
		// SendGrid drops for many reasons; only a known-bad address is a hard bounce
		$ev = ( false !== strpos( $reason, 'bounced address' ) || false !== strpos( $reason, 'invalid' ) ) ? 'hard' : ( false !== strpos( $reason, 'spam' ) ? 'complaint' : 'ignore' );
	}
	if ( $email ) {
		if ( in_array( $ev, array( 'hard_bounce', 'hard', 'bounce', 'bounced', 'invalid_email' ), true ) ) {
			$out[] = array( $email, 'hard', isset( $body['reason'] ) ? (string) $body['reason'] : $ev );
		} elseif ( in_array( $ev, array( 'spam', 'complaint', 'spamreport', 'complained' ), true ) ) {
			$out[] = array( $email, 'complaint', 'Marked as spam' );
		} elseif ( in_array( $ev, array( 'soft_bounce', 'soft', 'deferred', 'blocked' ), true ) ) {
			$out[] = array( $email, 'soft', $ev );
		}
	}
	return $out;
}

function usucger_mark_bounced( $email, $kind, $note ) {
	global $wpdb;
	$email = strtolower( trim( sanitize_email( $email ) ) );
	if ( ! is_email( $email ) ) {
		return false;
	}
	$ct = Usucger_DB::t( 'contacts' );
	if ( 'soft' === $kind ) {
		Usucger_DB::log( 'email_soft_bounce', 'email:' . $email, mb_substr( sanitize_text_field( $note ), 0, 180 ) );
		return false;
	}
	$note = mb_substr( ( 'complaint' === $kind ? 'Spam complaint' : 'Bounced' ) . ' ' . wp_date( 'Y-m-d' ) . ': ' . sanitize_text_field( $note ), 0, 190 );
	$data = array( 'bounced' => 1, 'bounce_note' => $note, 'updated' => current_time( 'mysql' ) );
	if ( 'complaint' === $kind ) {
		// a spam report opts the person out of announcements; governance notices (ballots) still go
		$data = array( 'unsub_news' => 1, 'bounce_note' => $note, 'updated' => current_time( 'mysql' ) );
	}
	$n = $wpdb->update( $ct, $data, array( 'email' => $email ) );
	if ( ! $n ) {
		$c = Usucger_Members::ensure_contact( $email );
		if ( $c ) {
			$wpdb->update( $ct, $data, array( 'id' => $c->id ) );
		}
	}
	delete_transient( 'usucger_datafix_counts' );
	Usucger_DB::log( 'complaint' === $kind ? 'email_complaint' : 'email_bounced', 'email:' . $email, $note );
	return true;
}

function usucger_bounce_webhook( WP_REST_Request $r ) {
	$body = $r->get_json_params();
	if ( ! $body ) {
		$body = json_decode( (string) $r->get_body(), true );
	}
	if ( ! $body ) {
		$body = $r->get_body_params(); // form-encoded (Mailgun legacy, Brevo test)
	}
	$n = 0;
	foreach ( usucger_bounce_parse( $body ) as $ev ) {
		if ( 'subscribe' === $ev[1] ) {
			// Amazon SNS: confirm the subscription once (only to amazonaws.com)
			$host = (string) wp_parse_url( $ev[2], PHP_URL_HOST );
			if ( preg_match( '/(^|\.)amazonaws\.com$/', $host ) ) {
				wp_remote_get( esc_url_raw( $ev[2] ), array( 'timeout' => 10 ) );
				Usucger_DB::log( 'bounce_webhook_subscribed', 'sns', $host );
			}
			continue;
		}
		$n += usucger_mark_bounced( $ev[0], $ev[1], $ev[2] ) ? 1 : 0;
	}
	return new WP_REST_Response( array( 'ok' => true, 'marked' => $n ), 200 );
}
